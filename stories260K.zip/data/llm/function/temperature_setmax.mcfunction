scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
