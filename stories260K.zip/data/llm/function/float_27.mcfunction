scoreboard players operation xb llm /= 100000 llm
scoreboard players operation r llm = xb llm
scoreboard players operation xb llm *= 100000 llm
