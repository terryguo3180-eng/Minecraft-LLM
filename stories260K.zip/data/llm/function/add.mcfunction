execute if score xb llm matches 0 run scoreboard players operation xe llm = ye llm
execute if score yb llm matches 0 run scoreboard players operation ye llm = xe llm
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
