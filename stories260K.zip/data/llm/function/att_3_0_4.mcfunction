scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 98304
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 0b tx
scoreboard players operation ye llm = 0e tx
scoreboard players operation ys llm = 0s tx
function llm:add
scoreboard players operation 0b tx = xb llm
scoreboard players operation 0e tx = xe llm
scoreboard players operation 0s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 1b tx
scoreboard players operation ye llm = 1e tx
scoreboard players operation ys llm = 1s tx
function llm:add
scoreboard players operation 1b tx = xb llm
scoreboard players operation 1e tx = xe llm
scoreboard players operation 1s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 2b tx
scoreboard players operation ye llm = 2e tx
scoreboard players operation ys llm = 2s tx
function llm:add
scoreboard players operation 2b tx = xb llm
scoreboard players operation 2e tx = xe llm
scoreboard players operation 2s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 3b tx
scoreboard players operation ye llm = 3e tx
scoreboard players operation ys llm = 3s tx
function llm:add
scoreboard players operation 3b tx = xb llm
scoreboard players operation 3e tx = xe llm
scoreboard players operation 3s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 4b tx
scoreboard players operation ye llm = 4e tx
scoreboard players operation ys llm = 4s tx
function llm:add
scoreboard players operation 4b tx = xb llm
scoreboard players operation 4e tx = xe llm
scoreboard players operation 4s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 5b tx
scoreboard players operation ye llm = 5e tx
scoreboard players operation ys llm = 5s tx
function llm:add
scoreboard players operation 5b tx = xb llm
scoreboard players operation 5e tx = xe llm
scoreboard players operation 5s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 6b tx
scoreboard players operation ye llm = 6e tx
scoreboard players operation ys llm = 6s tx
function llm:add
scoreboard players operation 6b tx = xb llm
scoreboard players operation 6e tx = xe llm
scoreboard players operation 6s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 7b tx
scoreboard players operation ye llm = 7e tx
scoreboard players operation ys llm = 7s tx
function llm:add
scoreboard players operation 7b tx = xb llm
scoreboard players operation 7e tx = xe llm
scoreboard players operation 7s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_3_0_4
