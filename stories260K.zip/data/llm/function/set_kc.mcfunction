$scoreboard players operation $(i)b kc = xb llm
$scoreboard players operation $(i)e kc = xe llm
$scoreboard players operation $(i)s kc = xs llm
