scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 8
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 16b tx
scoreboard players operation ye llm = 16e tx
scoreboard players operation ys llm = 16s tx
function llm:add
scoreboard players operation 16b tx = xb llm
scoreboard players operation 16e tx = xe llm
scoreboard players operation 16s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 17b tx
scoreboard players operation ye llm = 17e tx
scoreboard players operation ys llm = 17s tx
function llm:add
scoreboard players operation 17b tx = xb llm
scoreboard players operation 17e tx = xe llm
scoreboard players operation 17s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 18b tx
scoreboard players operation ye llm = 18e tx
scoreboard players operation ys llm = 18s tx
function llm:add
scoreboard players operation 18b tx = xb llm
scoreboard players operation 18e tx = xe llm
scoreboard players operation 18s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 19b tx
scoreboard players operation ye llm = 19e tx
scoreboard players operation ys llm = 19s tx
function llm:add
scoreboard players operation 19b tx = xb llm
scoreboard players operation 19e tx = xe llm
scoreboard players operation 19s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 20b tx
scoreboard players operation ye llm = 20e tx
scoreboard players operation ys llm = 20s tx
function llm:add
scoreboard players operation 20b tx = xb llm
scoreboard players operation 20e tx = xe llm
scoreboard players operation 20s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 21b tx
scoreboard players operation ye llm = 21e tx
scoreboard players operation ys llm = 21s tx
function llm:add
scoreboard players operation 21b tx = xb llm
scoreboard players operation 21e tx = xe llm
scoreboard players operation 21s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 22b tx
scoreboard players operation ye llm = 22e tx
scoreboard players operation ys llm = 22s tx
function llm:add
scoreboard players operation 22b tx = xb llm
scoreboard players operation 22e tx = xe llm
scoreboard players operation 22s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 23b tx
scoreboard players operation ye llm = 23e tx
scoreboard players operation ys llm = 23s tx
function llm:add
scoreboard players operation 23b tx = xb llm
scoreboard players operation 23e tx = xe llm
scoreboard players operation 23s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_0_2_4
