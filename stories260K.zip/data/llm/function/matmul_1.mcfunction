$scoreboard players set $(i)b $(out) 0
$scoreboard players set $(i)e $(out) 0
$scoreboard players set $(i)s $(out) 0
scoreboard players set j llm 0
data modify storage llm args.j set value 0
function llm:matmul_2 with storage llm args
scoreboard players add i llm 1
execute if score i llm = s1 llm run return 1
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:matmul_1 with storage llm args
