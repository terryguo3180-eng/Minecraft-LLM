scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 8
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 24b tx
scoreboard players operation ye llm = 24e tx
scoreboard players operation ys llm = 24s tx
function llm:add
scoreboard players operation 24b tx = xb llm
scoreboard players operation 24e tx = xe llm
scoreboard players operation 24s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 25b tx
scoreboard players operation ye llm = 25e tx
scoreboard players operation ys llm = 25s tx
function llm:add
scoreboard players operation 25b tx = xb llm
scoreboard players operation 25e tx = xe llm
scoreboard players operation 25s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 26b tx
scoreboard players operation ye llm = 26e tx
scoreboard players operation ys llm = 26s tx
function llm:add
scoreboard players operation 26b tx = xb llm
scoreboard players operation 26e tx = xe llm
scoreboard players operation 26s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 27b tx
scoreboard players operation ye llm = 27e tx
scoreboard players operation ys llm = 27s tx
function llm:add
scoreboard players operation 27b tx = xb llm
scoreboard players operation 27e tx = xe llm
scoreboard players operation 27s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 28b tx
scoreboard players operation ye llm = 28e tx
scoreboard players operation ys llm = 28s tx
function llm:add
scoreboard players operation 28b tx = xb llm
scoreboard players operation 28e tx = xe llm
scoreboard players operation 28s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 29b tx
scoreboard players operation ye llm = 29e tx
scoreboard players operation ys llm = 29s tx
function llm:add
scoreboard players operation 29b tx = xb llm
scoreboard players operation 29e tx = xe llm
scoreboard players operation 29s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 30b tx
scoreboard players operation ye llm = 30e tx
scoreboard players operation ys llm = 30s tx
function llm:add
scoreboard players operation 30b tx = xb llm
scoreboard players operation 30e tx = xe llm
scoreboard players operation 30s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 31b tx
scoreboard players operation ye llm = 31e tx
scoreboard players operation ys llm = 31s tx
function llm:add
scoreboard players operation 31b tx = xb llm
scoreboard players operation 31e tx = xe llm
scoreboard players operation 31s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_0_3_4
