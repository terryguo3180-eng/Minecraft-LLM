execute if score t3 llm matches 3 run return run scoreboard players operation t2 llm /= 1000 llm
execute if score t3 llm matches 4 run return run scoreboard players operation t2 llm /= 10000 llm
scoreboard players operation t2 llm /= 100000 llm
