$scoreboard players operation $(i)b av = xb llm
$scoreboard players operation $(i)e av = xe llm
$scoreboard players operation $(i)s av = xs llm
