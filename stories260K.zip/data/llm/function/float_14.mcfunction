execute if score xe llm > ye llm run return run scoreboard players set r llm 1
execute if score xe llm < ye llm run return run scoreboard players set r llm -1
execute if score xb llm > yb llm run return run scoreboard players set r llm 1
execute if score xb llm < yb llm run return run scoreboard players set r llm -1
scoreboard players set r llm 0
