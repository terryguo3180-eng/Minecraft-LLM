execute store result score progress llm run bossbar get progress value
execute store result bossbar progress value run scoreboard players add progress llm 1
scoreboard players set n llm 0
schedule function llm:matmul_logits_schedule 1t
