$execute store result score xb llm run data get storage llm params.$(m).$(idx)b
$execute store result score xe llm run data get storage llm params.$(m).$(idx)e
$execute store result score xs llm run data get storage llm params.$(m).$(idx)s
$scoreboard players operation yb llm = $(j)b $(in)
$scoreboard players operation ye llm = $(j)e $(in)
$scoreboard players operation ys llm = $(j)s $(in)
function llm:mul
$scoreboard players operation yb llm = $(i)b $(out)
$scoreboard players operation ye llm = $(i)e $(out)
$scoreboard players operation ys llm = $(i)s $(out)
function llm:add
$scoreboard players operation $(i)b $(out) = xb llm
$scoreboard players operation $(i)e $(out) = xe llm
$scoreboard players operation $(i)s $(out) = xs llm
scoreboard players add j llm 1
execute store result storage llm args.idx int 1 run scoreboard players add idx llm 1
execute if score j llm = s2 llm run return 1
execute store result storage llm args.j int 1 run scoreboard players get j llm
function llm:matmul_2 with storage llm args
