$execute store result score $(i)b x run data get storage llm params.emb.$(j)b
$execute store result score $(i)e x run data get storage llm params.emb.$(j)e
$execute store result score $(i)s x run data get storage llm params.emb.$(j)s
execute if score i llm matches 64 run return 0
execute store result storage llm args.i int 1 run scoreboard players add i llm 1
execute store result storage llm args.j int 1 run scoreboard players add j llm 1
function llm:copy_emb with storage llm args
