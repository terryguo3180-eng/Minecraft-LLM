scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= ys llm
scoreboard players operation xe llm += ye llm
execute if score xb llm matches 0 store result score xs llm run scoreboard players set xe llm 0
execute if score xb llm matches 100000000.. run function llm:float_15
