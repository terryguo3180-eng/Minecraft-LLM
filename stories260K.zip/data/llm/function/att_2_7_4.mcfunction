scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 65560
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 56b tx
scoreboard players operation ye llm = 56e tx
scoreboard players operation ys llm = 56s tx
function llm:add
scoreboard players operation 56b tx = xb llm
scoreboard players operation 56e tx = xe llm
scoreboard players operation 56s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 57b tx
scoreboard players operation ye llm = 57e tx
scoreboard players operation ys llm = 57s tx
function llm:add
scoreboard players operation 57b tx = xb llm
scoreboard players operation 57e tx = xe llm
scoreboard players operation 57s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 58b tx
scoreboard players operation ye llm = 58e tx
scoreboard players operation ys llm = 58s tx
function llm:add
scoreboard players operation 58b tx = xb llm
scoreboard players operation 58e tx = xe llm
scoreboard players operation 58s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 59b tx
scoreboard players operation ye llm = 59e tx
scoreboard players operation ys llm = 59s tx
function llm:add
scoreboard players operation 59b tx = xb llm
scoreboard players operation 59e tx = xe llm
scoreboard players operation 59s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 60b tx
scoreboard players operation ye llm = 60e tx
scoreboard players operation ys llm = 60s tx
function llm:add
scoreboard players operation 60b tx = xb llm
scoreboard players operation 60e tx = xe llm
scoreboard players operation 60s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 61b tx
scoreboard players operation ye llm = 61e tx
scoreboard players operation ys llm = 61s tx
function llm:add
scoreboard players operation 61b tx = xb llm
scoreboard players operation 61e tx = xe llm
scoreboard players operation 61s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 62b tx
scoreboard players operation ye llm = 62e tx
scoreboard players operation ys llm = 62s tx
function llm:add
scoreboard players operation 62b tx = xb llm
scoreboard players operation 62e tx = xe llm
scoreboard players operation 62s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 63b tx
scoreboard players operation ye llm = 63e tx
scoreboard players operation ys llm = 63s tx
function llm:add
scoreboard players operation 63b tx = xb llm
scoreboard players operation 63e tx = xe llm
scoreboard players operation 63s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_2_7_4
