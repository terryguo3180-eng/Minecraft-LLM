data modify storage llm args.s set value ""
execute if score xs llm matches -1 run data modify storage llm args.s set value "-"
execute store result storage llm args.e int 1 run scoreboard players remove xe llm 7
execute store result storage llm args.b int 1 run scoreboard players get xb llm
execute summon marker run function llm:float_20 with storage llm args
scoreboard players set xe llm 0
scoreboard players set xs llm 1
execute if score xb llm matches ..-1 run function llm:float_21
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
