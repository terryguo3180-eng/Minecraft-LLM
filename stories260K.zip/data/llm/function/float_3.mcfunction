execute if score t3 llm matches 1 run return run scoreboard players operation t2 llm /= 10 llm
scoreboard players operation t2 llm /= 100 llm
