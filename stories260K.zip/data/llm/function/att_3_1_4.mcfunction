scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 98304
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 8b tx
scoreboard players operation ye llm = 8e tx
scoreboard players operation ys llm = 8s tx
function llm:add
scoreboard players operation 8b tx = xb llm
scoreboard players operation 8e tx = xe llm
scoreboard players operation 8s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 9b tx
scoreboard players operation ye llm = 9e tx
scoreboard players operation ys llm = 9s tx
function llm:add
scoreboard players operation 9b tx = xb llm
scoreboard players operation 9e tx = xe llm
scoreboard players operation 9s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 10b tx
scoreboard players operation ye llm = 10e tx
scoreboard players operation ys llm = 10s tx
function llm:add
scoreboard players operation 10b tx = xb llm
scoreboard players operation 10e tx = xe llm
scoreboard players operation 10s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 11b tx
scoreboard players operation ye llm = 11e tx
scoreboard players operation ys llm = 11s tx
function llm:add
scoreboard players operation 11b tx = xb llm
scoreboard players operation 11e tx = xe llm
scoreboard players operation 11s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 12b tx
scoreboard players operation ye llm = 12e tx
scoreboard players operation ys llm = 12s tx
function llm:add
scoreboard players operation 12b tx = xb llm
scoreboard players operation 12e tx = xe llm
scoreboard players operation 12s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 13b tx
scoreboard players operation ye llm = 13e tx
scoreboard players operation ys llm = 13s tx
function llm:add
scoreboard players operation 13b tx = xb llm
scoreboard players operation 13e tx = xe llm
scoreboard players operation 13s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 14b tx
scoreboard players operation ye llm = 14e tx
scoreboard players operation ys llm = 14s tx
function llm:add
scoreboard players operation 14b tx = xb llm
scoreboard players operation 14e tx = xe llm
scoreboard players operation 14s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 15b tx
scoreboard players operation ye llm = 15e tx
scoreboard players operation ys llm = 15s tx
function llm:add
scoreboard players operation 15b tx = xb llm
scoreboard players operation 15e tx = xe llm
scoreboard players operation 15s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_3_1_4
