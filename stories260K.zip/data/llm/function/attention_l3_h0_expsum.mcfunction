execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation yb llm = maxb llm
scoreboard players operation ye llm = maxe llm
scoreboard players operation ys llm = maxs llm
scoreboard players operation ys llm *= -1 llm
function llm:add
function llm:exp
function llm:set_av with storage llm args
scoreboard players operation yb llm = expsumb llm
scoreboard players operation ye llm = expsume llm
scoreboard players operation ys llm = expsums llm
function llm:add
scoreboard players operation expsumb llm = xb llm
scoreboard players operation expsume llm = xe llm
scoreboard players operation expsums llm = xs llm
scoreboard players add i llm 1
execute if score i llm < window_len llm run function llm:attention_l3_h0_expsum
