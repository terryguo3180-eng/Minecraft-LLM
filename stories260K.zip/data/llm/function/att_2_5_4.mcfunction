scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 65552
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 40b tx
scoreboard players operation ye llm = 40e tx
scoreboard players operation ys llm = 40s tx
function llm:add
scoreboard players operation 40b tx = xb llm
scoreboard players operation 40e tx = xe llm
scoreboard players operation 40s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 41b tx
scoreboard players operation ye llm = 41e tx
scoreboard players operation ys llm = 41s tx
function llm:add
scoreboard players operation 41b tx = xb llm
scoreboard players operation 41e tx = xe llm
scoreboard players operation 41s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 42b tx
scoreboard players operation ye llm = 42e tx
scoreboard players operation ys llm = 42s tx
function llm:add
scoreboard players operation 42b tx = xb llm
scoreboard players operation 42e tx = xe llm
scoreboard players operation 42s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 43b tx
scoreboard players operation ye llm = 43e tx
scoreboard players operation ys llm = 43s tx
function llm:add
scoreboard players operation 43b tx = xb llm
scoreboard players operation 43e tx = xe llm
scoreboard players operation 43s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 44b tx
scoreboard players operation ye llm = 44e tx
scoreboard players operation ys llm = 44s tx
function llm:add
scoreboard players operation 44b tx = xb llm
scoreboard players operation 44e tx = xe llm
scoreboard players operation 44s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 45b tx
scoreboard players operation ye llm = 45e tx
scoreboard players operation ys llm = 45s tx
function llm:add
scoreboard players operation 45b tx = xb llm
scoreboard players operation 45e tx = xe llm
scoreboard players operation 45s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 46b tx
scoreboard players operation ye llm = 46e tx
scoreboard players operation ys llm = 46s tx
function llm:add
scoreboard players operation 46b tx = xb llm
scoreboard players operation 46e tx = xe llm
scoreboard players operation 46s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 47b tx
scoreboard players operation ye llm = 47e tx
scoreboard players operation ys llm = 47s tx
function llm:add
scoreboard players operation 47b tx = xb llm
scoreboard players operation 47e tx = xe llm
scoreboard players operation 47s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_2_5_4
