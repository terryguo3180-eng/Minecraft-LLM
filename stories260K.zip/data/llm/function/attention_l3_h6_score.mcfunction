scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 98328
scoreboard players set scoreb llm 0
scoreboard players set scoree llm 0
scoreboard players set scores llm 0
scoreboard players operation yb llm = 48b q
scoreboard players operation ye llm = 48e q
scoreboard players operation ys llm = 48s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 49b q
scoreboard players operation ye llm = 49e q
scoreboard players operation ys llm = 49s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 50b q
scoreboard players operation ye llm = 50e q
scoreboard players operation ys llm = 50s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 51b q
scoreboard players operation ye llm = 51e q
scoreboard players operation ys llm = 51s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 52b q
scoreboard players operation ye llm = 52e q
scoreboard players operation ys llm = 52s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 53b q
scoreboard players operation ye llm = 53e q
scoreboard players operation ys llm = 53s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 54b q
scoreboard players operation ye llm = 54e q
scoreboard players operation ys llm = 54s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 55b q
scoreboard players operation ye llm = 55e q
scoreboard players operation ys llm = 55s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation xb llm = scoreb llm
scoreboard players operation xe llm = scoree llm
scoreboard players operation xs llm = scores llm
scoreboard players set yb llm 28284271
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:div
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:set_av with storage llm args
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:attention_l3_h6_score
