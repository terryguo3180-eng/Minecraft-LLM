scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 98328
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 48b tx
scoreboard players operation ye llm = 48e tx
scoreboard players operation ys llm = 48s tx
function llm:add
scoreboard players operation 48b tx = xb llm
scoreboard players operation 48e tx = xe llm
scoreboard players operation 48s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 49b tx
scoreboard players operation ye llm = 49e tx
scoreboard players operation ys llm = 49s tx
function llm:add
scoreboard players operation 49b tx = xb llm
scoreboard players operation 49e tx = xe llm
scoreboard players operation 49s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 50b tx
scoreboard players operation ye llm = 50e tx
scoreboard players operation ys llm = 50s tx
function llm:add
scoreboard players operation 50b tx = xb llm
scoreboard players operation 50e tx = xe llm
scoreboard players operation 50s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 51b tx
scoreboard players operation ye llm = 51e tx
scoreboard players operation ys llm = 51s tx
function llm:add
scoreboard players operation 51b tx = xb llm
scoreboard players operation 51e tx = xe llm
scoreboard players operation 51s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 52b tx
scoreboard players operation ye llm = 52e tx
scoreboard players operation ys llm = 52s tx
function llm:add
scoreboard players operation 52b tx = xb llm
scoreboard players operation 52e tx = xe llm
scoreboard players operation 52s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 53b tx
scoreboard players operation ye llm = 53e tx
scoreboard players operation ys llm = 53s tx
function llm:add
scoreboard players operation 53b tx = xb llm
scoreboard players operation 53e tx = xe llm
scoreboard players operation 53s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 54b tx
scoreboard players operation ye llm = 54e tx
scoreboard players operation ys llm = 54s tx
function llm:add
scoreboard players operation 54b tx = xb llm
scoreboard players operation 54e tx = xe llm
scoreboard players operation 54s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 55b tx
scoreboard players operation ye llm = 55e tx
scoreboard players operation ys llm = 55s tx
function llm:add
scoreboard players operation 55b tx = xb llm
scoreboard players operation 55e tx = xe llm
scoreboard players operation 55s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_3_6_4
