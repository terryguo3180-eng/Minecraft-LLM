$scoreboard players operation xb llm = $(i)b logits
$scoreboard players operation xe llm = $(i)e logits
$scoreboard players operation xs llm = $(i)s logits
scoreboard players operation yb llm = cdfb llm
scoreboard players operation ye llm = cdfe llm
scoreboard players operation ys llm = cdfs llm
function llm:add
scoreboard players operation cdfb llm = xb llm
scoreboard players operation cdfe llm = xe llm
scoreboard players operation cdfs llm = xs llm
scoreboard players operation yb llm = rb llm
scoreboard players operation ye llm = re llm
scoreboard players operation ys llm = rs llm
function llm:cmp
execute if score r llm matches 1 run return run scoreboard players operation tok llm = i llm
execute store result score t0 llm store result score t1 llm store result storage llm args.i int 1 run scoreboard players add i llm 1
scoreboard players operation t0 llm %= 100 llm
scoreboard players add t1 llm 2048
execute if score t0 llm matches 99 store result bossbar progress value run scoreboard players operation t1 llm /= 100 llm
execute if score i llm matches ..511 run function llm:temperature_cdf with storage llm args
