execute if data storage llm args{c:'~'} run return run scoreboard players set tok llm 510
execute if data storage llm args{c:']'} run return run scoreboard players set tok llm 509
execute if data storage llm args{c:'['} run return run scoreboard players set tok llm 508
execute if data storage llm args{c:'™'} run return run scoreboard players set tok llm 507
execute if data storage llm args{c:'|'} run return run scoreboard players set tok llm 506
execute if data storage llm args{c:'>'} run return run scoreboard players set tok llm 505
execute if data storage llm args{c:'<'} run return run scoreboard players set tok llm 504
execute if data storage llm args{c:'€'} run return run scoreboard players set tok llm 503
execute if data storage llm args{c:'â'} run return run scoreboard players set tok llm 502
execute if data storage llm args{c:'%'} run return run scoreboard players set tok llm 501
execute if data storage llm args{c:'\\'} run return run scoreboard players set tok llm 500
execute if data storage llm args{c:'&'} run return run scoreboard players set tok llm 499
execute if data storage llm args{c:'*'} run return run scoreboard players set tok llm 497
execute if data storage llm args{c:'+'} run return run scoreboard players set tok llm 496
execute if data storage llm args{c:'`'} run return run scoreboard players set tok llm 495
execute if data storage llm args{c:'$'} run return run scoreboard players set tok llm 494
execute if data storage llm args{c:'ñ'} run return run scoreboard players set tok llm 493
execute if data storage llm args{c:'/'} run return run scoreboard players set tok llm 492
execute if data storage llm args{c:'7'} run return run scoreboard players set tok llm 491
execute if data storage llm args{c:'6'} run return run scoreboard players set tok llm 490
execute if data storage llm args{c:'('} run return run scoreboard players set tok llm 489
execute if data storage llm args{c:')'} run return run scoreboard players set tok llm 488
execute if data storage llm args{c:'8'} run return run scoreboard players set tok llm 487
execute if data storage llm args{c:'…'} run return run scoreboard players set tok llm 486
execute if data storage llm args{c:'é'} run return run scoreboard players set tok llm 485
execute if data storage llm args{c:'4'} run return run scoreboard players set tok llm 484
execute if data storage llm args{c:'9'} run return run scoreboard players set tok llm 483
execute if data storage llm args{c:'‘'} run return run scoreboard players set tok llm 482
execute if data storage llm args{c:'—'} run return run scoreboard players set tok llm 481
execute if data storage llm args{c:'5'} run return run scoreboard players set tok llm 480
execute if data storage llm args{c:'2'} run return run scoreboard players set tok llm 479
execute if data storage llm args{c:'X'} run return run scoreboard players set tok llm 478
execute if data storage llm args{c:'0'} run return run scoreboard players set tok llm 477
execute if data storage llm args{c:'–'} run return run scoreboard players set tok llm 476
execute if data storage llm args{c:'1'} run return run scoreboard players set tok llm 475
execute if data storage llm args{c:';'} run return run scoreboard players set tok llm 474
execute if data storage llm args{c:'Q'} run return run scoreboard players set tok llm 473
execute if data storage llm args{c:'3'} run return run scoreboard players set tok llm 472
execute if data storage llm args{c:'U'} run return run scoreboard players set tok llm 471
execute if data storage llm args{c:'V'} run return run scoreboard players set tok llm 470
execute if data storage llm args{c:'Z'} run return run scoreboard players set tok llm 469
execute if data storage llm args{c:'’'} run return run scoreboard players set tok llm 468
execute if data storage llm args{c:':'} run return run scoreboard players set tok llm 467
execute if data storage llm args{c:'”'} run return run scoreboard players set tok llm 466
execute if data storage llm args{c:'“'} run return run scoreboard players set tok llm 465
execute if data storage llm args{c:'-'} run return run scoreboard players set tok llm 464
execute if data storage llm args{c:'G'} run return run scoreboard players set tok llm 463
execute if data storage llm args{c:'K'} run return run scoreboard players set tok llm 462
execute if data storage llm args{c:'R'} run return run scoreboard players set tok llm 461
execute if data storage llm args{c:'P'} run return run scoreboard players set tok llm 460
execute if data storage llm args{c:'E'} run return run scoreboard players set tok llm 459
execute if data storage llm args{c:'N'} run return run scoreboard players set tok llm 458
execute if data storage llm args{c:'C'} run return run scoreboard players set tok llm 457
execute if data storage llm args{c:'q'} run return run scoreboard players set tok llm 456
execute if data storage llm args{c:'D'} run return run scoreboard players set tok llm 455
execute if data storage llm args{c:'J'} run return run scoreboard players set tok llm 454
execute if data storage llm args{c:'F'} run return run scoreboard players set tok llm 453
execute if data storage llm args{c:'Y'} run return run scoreboard players set tok llm 452
execute if data storage llm args{c:'z'} run return run scoreboard players set tok llm 451
execute if data storage llm args{c:'?'} run return run scoreboard players set tok llm 450
execute if data storage llm args{c:'j'} run return run scoreboard players set tok llm 449
execute if data storage llm args{c:'W'} run return run scoreboard players set tok llm 448
execute if data storage llm args{c:'A'} run return run scoreboard players set tok llm 447
execute if data storage llm args{c:'M'} run return run scoreboard players set tok llm 446
execute if data storage llm args{c:'B'} run return run scoreboard players set tok llm 445
execute if data storage llm args{c:'x'} run return run scoreboard players set tok llm 444
execute if data storage llm args{c:'!'} run return run scoreboard players set tok llm 443
execute if data storage llm args{c:'I'} run return run scoreboard players set tok llm 442
execute if data storage llm args{c:'O'} run return run scoreboard players set tok llm 441
execute if data storage llm args{c:'H'} run return run scoreboard players set tok llm 440
execute if data storage llm args{c:"'"} run return run scoreboard players set tok llm 439
execute if data storage llm args{c:'L'} run return run scoreboard players set tok llm 438
execute if data storage llm args{c:'S'} run return run scoreboard players set tok llm 437
execute if data storage llm args{c:'"'} run return run scoreboard players set tok llm 436
execute if data storage llm args{c:'v'} run return run scoreboard players set tok llm 435
execute if data storage llm args{c:'T'} run return run scoreboard players set tok llm 434
execute if data storage llm args{c:'k'} run return run scoreboard players set tok llm 433
execute if data storage llm args{c:','} run return run scoreboard players set tok llm 432
execute if data storage llm args{c:'f'} run return run scoreboard players set tok llm 431
execute if data storage llm args{c:'b'} run return run scoreboard players set tok llm 430
execute if data storage llm args{c:'c'} run return run scoreboard players set tok llm 429
execute if data storage llm args{c:'g'} run return run scoreboard players set tok llm 428
execute if data storage llm args{c:'p'} run return run scoreboard players set tok llm 427
execute if data storage llm args{c:'.'} run return run scoreboard players set tok llm 426
execute if data storage llm args{c:'u'} run return run scoreboard players set tok llm 425
execute if data storage llm args{c:'w'} run return run scoreboard players set tok llm 424
execute if data storage llm args{c:'m'} run return run scoreboard players set tok llm 423
execute if data storage llm args{c:'y'} run return run scoreboard players set tok llm 422
execute if data storage llm args{c:'l'} run return run scoreboard players set tok llm 421
execute if data storage llm args{c:'r'} run return run scoreboard players set tok llm 420
execute if data storage llm args{c:'s'} run return run scoreboard players set tok llm 419
execute if data storage llm args{c:'d'} run return run scoreboard players set tok llm 418
execute if data storage llm args{c:'i'} run return run scoreboard players set tok llm 417
execute if data storage llm args{c:'n'} run return run scoreboard players set tok llm 416
execute if data storage llm args{c:'h'} run return run scoreboard players set tok llm 415
execute if data storage llm args{c:'o'} run return run scoreboard players set tok llm 414
execute if data storage llm args{c:'t'} run return run scoreboard players set tok llm 413
execute if data storage llm args{c:'a'} run return run scoreboard players set tok llm 412
execute if data storage llm args{c:'e'} run return run scoreboard players set tok llm 411
execute if data storage llm args{c:' '} run return run scoreboard players set tok llm 410
execute if data storage llm args{c:' k'} run return run scoreboard players set tok llm 409
execute if data storage llm args{c:'out'} run return run scoreboard players set tok llm 408
execute if data storage llm args{c:' upon'} run return run scoreboard players set tok llm 407
execute if data storage llm args{c:'es'} run return run scoreboard players set tok llm 406
execute if data storage llm args{c:' Timmy'} run return run scoreboard players set tok llm 405
execute if data storage llm args{c:' ne'} run return run scoreboard players set tok llm 404
execute if data storage llm args{c:' Once'} run return run scoreboard players set tok llm 403
execute if data storage llm args{c:'ch'} run return run scoreboard players set tok llm 402
execute if data storage llm args{c:' lo'} run return run scoreboard players set tok llm 401
execute if data storage llm args{c:' do'} run return run scoreboard players set tok llm 400
execute if data storage llm args{c:' very'} run return run scoreboard players set tok llm 399
execute if data storage llm args{c:' but'} run return run scoreboard players set tok llm 398
execute if data storage llm args{c:' li'} run return run scoreboard players set tok llm 397
execute if data storage llm args{c:'ved'} run return run scoreboard players set tok llm 396
execute if data storage llm args{c:' named'} run return run scoreboard players set tok llm 395
execute if data storage llm args{c:' saw'} run return run scoreboard players set tok llm 394
execute if data storage llm args{c:' happy'} run return run scoreboard players set tok llm 393
execute if data storage llm args{c:' M'} run return run scoreboard players set tok llm 392
execute if data storage llm args{c:' want'} run return run scoreboard players set tok llm 391
execute if data storage llm args{c:' nam'} run return run scoreboard players set tok llm 390
execute if data storage llm args{c:'ould'} run return run scoreboard players set tok llm 389
execute if data storage llm args{c:'all'} run return run scoreboard players set tok llm 388
execute if data storage llm args{c:' for'} run return run scoreboard players set tok llm 387
execute if data storage llm args{c:'her'} run return run scoreboard players set tok llm 386
execute if data storage llm args{c:' One'} run return run scoreboard players set tok llm 385
execute if data storage llm args{c:' so'} run return run scoreboard players set tok llm 384
execute if data storage llm args{c:' there'} run return run scoreboard players set tok llm 383
execute if data storage llm args{c:' we'} run return run scoreboard players set tok llm 382
execute if data storage llm args{c:' had'} run return run scoreboard players set tok llm 381
execute if data storage llm args{c:'ad'} run return run scoreboard players set tok llm 380
execute if data storage llm args{c:'un'} run return run scoreboard players set tok llm 379
execute if data storage llm args{c:' time'} run return run scoreboard players set tok llm 378
execute if data storage llm args{c:'ent'} run return run scoreboard players set tok llm 377
execute if data storage llm args{c:' little'} run return run scoreboard players set tok llm 376
execute if data storage llm args{c:'ittle'} run return run scoreboard players set tok llm 375
execute if data storage llm args{c:' friend'} run return run scoreboard players set tok llm 374
execute if data storage llm args{c:' of'} run return run scoreboard players set tok llm 373
execute if data storage llm args{c:'se'} run return run scoreboard players set tok llm 372
execute if data storage llm args{c:' fri'} run return run scoreboard players set tok llm 371
execute if data storage llm args{c:' big'} run return run scoreboard players set tok llm 370
execute if data storage llm args{c:'ime'} run return run scoreboard players set tok llm 369
execute if data storage llm args{c:' B'} run return run scoreboard players set tok llm 368
execute if data storage llm args{c:'end'} run return run scoreboard players set tok llm 367
execute if data storage llm args{c:' they'} run return run scoreboard players set tok llm 366
execute if data storage llm args{c:' happ'} run return run scoreboard players set tok llm 365
execute if data storage llm args{c:' you'} run return run scoreboard players set tok llm 364
execute if data storage llm args{c:'very'} run return run scoreboard players set tok llm 363
execute if data storage llm args{c:'itt'} run return run scoreboard players set tok llm 362
execute if data storage llm args{c:'nt'} run return run scoreboard players set tok llm 361
execute if data storage llm args{c:'ve'} run return run scoreboard players set tok llm 360
execute if data storage llm args{c:' I'} run return run scoreboard players set tok llm 359
execute if data storage llm args{c:' she'} run return run scoreboard players set tok llm 358
execute if data storage llm args{c:' mom'} run return run scoreboard players set tok llm 357
execute if data storage llm args{c:'st'} run return run scoreboard players set tok llm 356
execute if data storage llm args{c:'ked'} run return run scoreboard players set tok llm 355
execute if data storage llm args{c:'ke'} run return run scoreboard players set tok llm 354
execute if data storage llm args{c:' on'} run return run scoreboard players set tok llm 353
execute if data storage llm args{c:' r'} run return run scoreboard players set tok llm 352
execute if data storage llm args{c:' that'} run return run scoreboard players set tok llm 351
execute if data storage llm args{c:' up'} run return run scoreboard players set tok llm 350
execute if data storage llm args{c:' st'} run return run scoreboard players set tok llm 349
execute if data storage llm args{c:' y'} run return run scoreboard players set tok llm 348
execute if data storage llm args{c:'oo'} run return run scoreboard players set tok llm 347
execute if data storage llm args{c:' He'} run return run scoreboard players set tok llm 346
execute if data storage llm args{c:' his'} run return run scoreboard players set tok llm 345
execute if data storage llm args{c:' e'} run return run scoreboard players set tok llm 344
execute if data storage llm args{c:'my'} run return run scoreboard players set tok llm 343
execute if data storage llm args{c:' They'} run return run scoreboard players set tok llm 342
execute if data storage llm args{c:'ld'} run return run scoreboard players set tok llm 341
execute if data storage llm args{c:'ck'} run return run scoreboard players set tok llm 340
execute if data storage llm args{c:'pp'} run return run scoreboard players set tok llm 339
execute if data storage llm args{c:' She'} run return run scoreboard players set tok llm 338
execute if data storage llm args{c:' play'} run return run scoreboard players set tok llm 337
execute if data storage llm args{c:' said'} run return run scoreboard players set tok llm 336
execute if data storage llm args{c:' with'} run return run scoreboard players set tok llm 335
execute if data storage llm args{c:' o'} run return run scoreboard players set tok llm 334
execute if data storage llm args{c:'ig'} run return run scoreboard players set tok llm 333
execute if data storage llm args{c:'ith'} run return run scoreboard players set tok llm 332
execute if data storage llm args{c:'ce'} run return run scoreboard players set tok llm 331
execute if data storage llm args{c:'ver'} run return run scoreboard players set tok llm 330
execute if data storage llm args{c:' be'} run return run scoreboard players set tok llm 329
execute if data storage llm args{c:' day'} run return run scoreboard players set tok llm 328
execute if data storage llm args{c:'ow'} run return run scoreboard players set tok llm 327
execute if data storage llm args{c:' Tim'} run return run scoreboard players set tok llm 326
execute if data storage llm args{c:'ri'} run return run scoreboard players set tok llm 325
execute if data storage llm args{c:' pl'} run return run scoreboard players set tok llm 324
execute if data storage llm args{c:'ut'} run return run scoreboard players set tok llm 323
execute if data storage llm args{c:' in'} run return run scoreboard players set tok llm 322
execute if data storage llm args{c:' On'} run return run scoreboard players set tok llm 321
execute if data storage llm args{c:' H'} run return run scoreboard players set tok llm 320
execute if data storage llm args{c:' O'} run return run scoreboard players set tok llm 319
execute if data storage llm args{c:' u'} run return run scoreboard players set tok llm 318
execute if data storage llm args{c:' Lily'} run return run scoreboard players set tok llm 317
execute if data storage llm args{c:'et'} run return run scoreboard players set tok llm 316
execute if data storage llm args{c:'ir'} run return run scoreboard players set tok llm 315
execute if data storage llm args{c:'am'} run return run scoreboard players set tok llm 314
execute if data storage llm args{c:' "'} run return run scoreboard players set tok llm 313
execute if data storage llm args{c:' it'} run return run scoreboard players set tok llm 312
execute if data storage llm args{c:' her'} run return run scoreboard players set tok llm 311
execute if data storage llm args{c:'ily'} run return run scoreboard players set tok llm 310
execute if data storage llm args{c:'ot'} run return run scoreboard players set tok llm 309
execute if data storage llm args{c:' th'} run return run scoreboard players set tok llm 308
execute if data storage llm args{c:' L'} run return run scoreboard players set tok llm 307
execute if data storage llm args{c:'ll'} run return run scoreboard players set tok llm 306
execute if data storage llm args{c:'le'} run return run scoreboard players set tok llm 305
execute if data storage llm args{c:'or'} run return run scoreboard players set tok llm 304
execute if data storage llm args{c:'an'} run return run scoreboard players set tok llm 303
execute if data storage llm args{c:'en'} run return run scoreboard players set tok llm 302
execute if data storage llm args{c:' S'} run return run scoreboard players set tok llm 301
execute if data storage llm args{c:' ha'} run return run scoreboard players set tok llm 300
execute if data storage llm args{c:'ing'} run return run scoreboard players set tok llm 299
execute if data storage llm args{c:' g'} run return run scoreboard players set tok llm 298
execute if data storage llm args{c:' n'} run return run scoreboard players set tok llm 297
execute if data storage llm args{c:' sa'} run return run scoreboard players set tok llm 296
execute if data storage llm args{c:'ar'} run return run scoreboard players set tok llm 295
execute if data storage llm args{c:'at'} run return run scoreboard players set tok llm 294
execute if data storage llm args{c:'is'} run return run scoreboard players set tok llm 293
execute if data storage llm args{c:'id'} run return run scoreboard players set tok llm 292
execute if data storage llm args{c:' The'} run return run scoreboard players set tok llm 291
execute if data storage llm args{c:'il'} run return run scoreboard players set tok llm 290
execute if data storage llm args{c:'on'} run return run scoreboard players set tok llm 289
execute if data storage llm args{c:'im'} run return run scoreboard players set tok llm 288
execute if data storage llm args{c:'om'} run return run scoreboard players set tok llm 287
execute if data storage llm args{c:' was'} run return run scoreboard players set tok llm 286
execute if data storage llm args{c:'er'} run return run scoreboard players set tok llm 285
execute if data storage llm args{c:' m'} run return run scoreboard players set tok llm 284
execute if data storage llm args{c:'ay'} run return run scoreboard players set tok llm 283
execute if data storage llm args{c:' p'} run return run scoreboard players set tok llm 282
execute if data storage llm args{c:' he'} run return run scoreboard players set tok llm 281
execute if data storage llm args{c:' c'} run return run scoreboard players set tok llm 280
execute if data storage llm args{c:' d'} run return run scoreboard players set tok llm 279
execute if data storage llm args{c:' l'} run return run scoreboard players set tok llm 278
execute if data storage llm args{c:'ou'} run return run scoreboard players set tok llm 277
execute if data storage llm args{c:'re'} run return run scoreboard players set tok llm 276
execute if data storage llm args{c:'it'} run return run scoreboard players set tok llm 275
execute if data storage llm args{c:' T'} run return run scoreboard players set tok llm 274
execute if data storage llm args{c:' wa'} run return run scoreboard players set tok llm 273
execute if data storage llm args{c:' f'} run return run scoreboard players set tok llm 272
execute if data storage llm args{c:'in'} run return run scoreboard players set tok llm 271
execute if data storage llm args{c:' h'} run return run scoreboard players set tok llm 270
execute if data storage llm args{c:' and'} run return run scoreboard players set tok llm 269
execute if data storage llm args{c:' b'} run return run scoreboard players set tok llm 268
execute if data storage llm args{c:' to'} run return run scoreboard players set tok llm 267
execute if data storage llm args{c:'ed'} run return run scoreboard players set tok llm 266
execute if data storage llm args{c:' the'} run return run scoreboard players set tok llm 265
execute if data storage llm args{c:'nd'} run return run scoreboard players set tok llm 264
execute if data storage llm args{c:' w'} run return run scoreboard players set tok llm 263
execute if data storage llm args{c:' s'} run return run scoreboard players set tok llm 262
execute if data storage llm args{c:' a'} run return run scoreboard players set tok llm 261
execute if data storage llm args{c:'he'} run return run scoreboard players set tok llm 260
execute if data storage llm args{c:' t'} run return run scoreboard players set tok llm 259
execute if data storage llm args{c:'ÿ'} run return run scoreboard players set tok llm 258
execute if data storage llm args{c:'þ'} run return run scoreboard players set tok llm 257
execute if data storage llm args{c:'ý'} run return run scoreboard players set tok llm 256
execute if data storage llm args{c:'ü'} run return run scoreboard players set tok llm 255
execute if data storage llm args{c:'û'} run return run scoreboard players set tok llm 254
execute if data storage llm args{c:'ú'} run return run scoreboard players set tok llm 253
execute if data storage llm args{c:'ù'} run return run scoreboard players set tok llm 252
execute if data storage llm args{c:'ø'} run return run scoreboard players set tok llm 251
execute if data storage llm args{c:'÷'} run return run scoreboard players set tok llm 250
execute if data storage llm args{c:'ö'} run return run scoreboard players set tok llm 249
execute if data storage llm args{c:'õ'} run return run scoreboard players set tok llm 248
execute if data storage llm args{c:'ô'} run return run scoreboard players set tok llm 247
execute if data storage llm args{c:'ó'} run return run scoreboard players set tok llm 246
execute if data storage llm args{c:'ò'} run return run scoreboard players set tok llm 245
execute if data storage llm args{c:'ñ'} run return run scoreboard players set tok llm 244
execute if data storage llm args{c:'ð'} run return run scoreboard players set tok llm 243
execute if data storage llm args{c:'ï'} run return run scoreboard players set tok llm 242
execute if data storage llm args{c:'î'} run return run scoreboard players set tok llm 241
execute if data storage llm args{c:'í'} run return run scoreboard players set tok llm 240
execute if data storage llm args{c:'ì'} run return run scoreboard players set tok llm 239
execute if data storage llm args{c:'ë'} run return run scoreboard players set tok llm 238
execute if data storage llm args{c:'ê'} run return run scoreboard players set tok llm 237
execute if data storage llm args{c:'é'} run return run scoreboard players set tok llm 236
execute if data storage llm args{c:'è'} run return run scoreboard players set tok llm 235
execute if data storage llm args{c:'ç'} run return run scoreboard players set tok llm 234
execute if data storage llm args{c:'æ'} run return run scoreboard players set tok llm 233
execute if data storage llm args{c:'å'} run return run scoreboard players set tok llm 232
execute if data storage llm args{c:'ä'} run return run scoreboard players set tok llm 231
execute if data storage llm args{c:'ã'} run return run scoreboard players set tok llm 230
execute if data storage llm args{c:'â'} run return run scoreboard players set tok llm 229
execute if data storage llm args{c:'á'} run return run scoreboard players set tok llm 228
execute if data storage llm args{c:'à'} run return run scoreboard players set tok llm 227
execute if data storage llm args{c:'ß'} run return run scoreboard players set tok llm 226
execute if data storage llm args{c:'Þ'} run return run scoreboard players set tok llm 225
execute if data storage llm args{c:'Ý'} run return run scoreboard players set tok llm 224
execute if data storage llm args{c:'Ü'} run return run scoreboard players set tok llm 223
execute if data storage llm args{c:'Û'} run return run scoreboard players set tok llm 222
execute if data storage llm args{c:'Ú'} run return run scoreboard players set tok llm 221
execute if data storage llm args{c:'Ù'} run return run scoreboard players set tok llm 220
execute if data storage llm args{c:'Ø'} run return run scoreboard players set tok llm 219
execute if data storage llm args{c:'×'} run return run scoreboard players set tok llm 218
execute if data storage llm args{c:'Ö'} run return run scoreboard players set tok llm 217
execute if data storage llm args{c:'Õ'} run return run scoreboard players set tok llm 216
execute if data storage llm args{c:'Ô'} run return run scoreboard players set tok llm 215
execute if data storage llm args{c:'Ó'} run return run scoreboard players set tok llm 214
execute if data storage llm args{c:'Ò'} run return run scoreboard players set tok llm 213
execute if data storage llm args{c:'Ñ'} run return run scoreboard players set tok llm 212
execute if data storage llm args{c:'Ð'} run return run scoreboard players set tok llm 211
execute if data storage llm args{c:'Ï'} run return run scoreboard players set tok llm 210
execute if data storage llm args{c:'Î'} run return run scoreboard players set tok llm 209
execute if data storage llm args{c:'Í'} run return run scoreboard players set tok llm 208
execute if data storage llm args{c:'Ì'} run return run scoreboard players set tok llm 207
execute if data storage llm args{c:'Ë'} run return run scoreboard players set tok llm 206
execute if data storage llm args{c:'Ê'} run return run scoreboard players set tok llm 205
execute if data storage llm args{c:'É'} run return run scoreboard players set tok llm 204
execute if data storage llm args{c:'È'} run return run scoreboard players set tok llm 203
execute if data storage llm args{c:'Ç'} run return run scoreboard players set tok llm 202
execute if data storage llm args{c:'Æ'} run return run scoreboard players set tok llm 201
execute if data storage llm args{c:'Å'} run return run scoreboard players set tok llm 200
execute if data storage llm args{c:'Ä'} run return run scoreboard players set tok llm 199
execute if data storage llm args{c:'Ã'} run return run scoreboard players set tok llm 198
execute if data storage llm args{c:'Â'} run return run scoreboard players set tok llm 197
execute if data storage llm args{c:'Á'} run return run scoreboard players set tok llm 196
execute if data storage llm args{c:'À'} run return run scoreboard players set tok llm 195
execute if data storage llm args{c:'¿'} run return run scoreboard players set tok llm 194
execute if data storage llm args{c:'¾'} run return run scoreboard players set tok llm 193
execute if data storage llm args{c:'½'} run return run scoreboard players set tok llm 192
execute if data storage llm args{c:'¼'} run return run scoreboard players set tok llm 191
execute if data storage llm args{c:'»'} run return run scoreboard players set tok llm 190
execute if data storage llm args{c:'º'} run return run scoreboard players set tok llm 189
execute if data storage llm args{c:'¹'} run return run scoreboard players set tok llm 188
execute if data storage llm args{c:'¸'} run return run scoreboard players set tok llm 187
execute if data storage llm args{c:'·'} run return run scoreboard players set tok llm 186
execute if data storage llm args{c:'¶'} run return run scoreboard players set tok llm 185
execute if data storage llm args{c:'µ'} run return run scoreboard players set tok llm 184
execute if data storage llm args{c:'´'} run return run scoreboard players set tok llm 183
execute if data storage llm args{c:'³'} run return run scoreboard players set tok llm 182
execute if data storage llm args{c:'²'} run return run scoreboard players set tok llm 181
execute if data storage llm args{c:'±'} run return run scoreboard players set tok llm 180
execute if data storage llm args{c:'°'} run return run scoreboard players set tok llm 179
execute if data storage llm args{c:'¯'} run return run scoreboard players set tok llm 178
execute if data storage llm args{c:'®'} run return run scoreboard players set tok llm 177
execute if data storage llm args{c:'¬'} run return run scoreboard players set tok llm 175
execute if data storage llm args{c:'«'} run return run scoreboard players set tok llm 174
execute if data storage llm args{c:'ª'} run return run scoreboard players set tok llm 173
execute if data storage llm args{c:'©'} run return run scoreboard players set tok llm 172
execute if data storage llm args{c:'¨'} run return run scoreboard players set tok llm 171
execute if data storage llm args{c:'§'} run return run scoreboard players set tok llm 170
execute if data storage llm args{c:'¦'} run return run scoreboard players set tok llm 169
execute if data storage llm args{c:'¥'} run return run scoreboard players set tok llm 168
execute if data storage llm args{c:'¤'} run return run scoreboard players set tok llm 167
execute if data storage llm args{c:'£'} run return run scoreboard players set tok llm 166
execute if data storage llm args{c:'¢'} run return run scoreboard players set tok llm 165
execute if data storage llm args{c:'¡'} run return run scoreboard players set tok llm 164
execute if data storage llm args{c:'~'} run return run scoreboard players set tok llm 129
execute if data storage llm args{c:'}'} run return run scoreboard players set tok llm 128
execute if data storage llm args{c:'|'} run return run scoreboard players set tok llm 127
execute if data storage llm args{c:'{'} run return run scoreboard players set tok llm 126
execute if data storage llm args{c:'z'} run return run scoreboard players set tok llm 125
execute if data storage llm args{c:'y'} run return run scoreboard players set tok llm 124
execute if data storage llm args{c:'x'} run return run scoreboard players set tok llm 123
execute if data storage llm args{c:'w'} run return run scoreboard players set tok llm 122
execute if data storage llm args{c:'v'} run return run scoreboard players set tok llm 121
execute if data storage llm args{c:'u'} run return run scoreboard players set tok llm 120
execute if data storage llm args{c:'t'} run return run scoreboard players set tok llm 119
execute if data storage llm args{c:'s'} run return run scoreboard players set tok llm 118
execute if data storage llm args{c:'r'} run return run scoreboard players set tok llm 117
execute if data storage llm args{c:'q'} run return run scoreboard players set tok llm 116
execute if data storage llm args{c:'p'} run return run scoreboard players set tok llm 115
execute if data storage llm args{c:'o'} run return run scoreboard players set tok llm 114
execute if data storage llm args{c:'n'} run return run scoreboard players set tok llm 113
execute if data storage llm args{c:'m'} run return run scoreboard players set tok llm 112
execute if data storage llm args{c:'l'} run return run scoreboard players set tok llm 111
execute if data storage llm args{c:'k'} run return run scoreboard players set tok llm 110
execute if data storage llm args{c:'j'} run return run scoreboard players set tok llm 109
execute if data storage llm args{c:'i'} run return run scoreboard players set tok llm 108
execute if data storage llm args{c:'h'} run return run scoreboard players set tok llm 107
execute if data storage llm args{c:'g'} run return run scoreboard players set tok llm 106
execute if data storage llm args{c:'f'} run return run scoreboard players set tok llm 105
execute if data storage llm args{c:'e'} run return run scoreboard players set tok llm 104
execute if data storage llm args{c:'d'} run return run scoreboard players set tok llm 103
execute if data storage llm args{c:'c'} run return run scoreboard players set tok llm 102
execute if data storage llm args{c:'b'} run return run scoreboard players set tok llm 101
execute if data storage llm args{c:'a'} run return run scoreboard players set tok llm 100
execute if data storage llm args{c:'`'} run return run scoreboard players set tok llm 99
execute if data storage llm args{c:'_'} run return run scoreboard players set tok llm 98
execute if data storage llm args{c:'^'} run return run scoreboard players set tok llm 97
execute if data storage llm args{c:']'} run return run scoreboard players set tok llm 96
execute if data storage llm args{c:'\\'} run return run scoreboard players set tok llm 95
execute if data storage llm args{c:'['} run return run scoreboard players set tok llm 94
execute if data storage llm args{c:'Z'} run return run scoreboard players set tok llm 93
execute if data storage llm args{c:'Y'} run return run scoreboard players set tok llm 92
execute if data storage llm args{c:'X'} run return run scoreboard players set tok llm 91
execute if data storage llm args{c:'W'} run return run scoreboard players set tok llm 90
execute if data storage llm args{c:'V'} run return run scoreboard players set tok llm 89
execute if data storage llm args{c:'U'} run return run scoreboard players set tok llm 88
execute if data storage llm args{c:'T'} run return run scoreboard players set tok llm 87
execute if data storage llm args{c:'S'} run return run scoreboard players set tok llm 86
execute if data storage llm args{c:'R'} run return run scoreboard players set tok llm 85
execute if data storage llm args{c:'Q'} run return run scoreboard players set tok llm 84
execute if data storage llm args{c:'P'} run return run scoreboard players set tok llm 83
execute if data storage llm args{c:'O'} run return run scoreboard players set tok llm 82
execute if data storage llm args{c:'N'} run return run scoreboard players set tok llm 81
execute if data storage llm args{c:'M'} run return run scoreboard players set tok llm 80
execute if data storage llm args{c:'L'} run return run scoreboard players set tok llm 79
execute if data storage llm args{c:'K'} run return run scoreboard players set tok llm 78
execute if data storage llm args{c:'J'} run return run scoreboard players set tok llm 77
execute if data storage llm args{c:'I'} run return run scoreboard players set tok llm 76
execute if data storage llm args{c:'H'} run return run scoreboard players set tok llm 75
execute if data storage llm args{c:'G'} run return run scoreboard players set tok llm 74
execute if data storage llm args{c:'F'} run return run scoreboard players set tok llm 73
execute if data storage llm args{c:'E'} run return run scoreboard players set tok llm 72
execute if data storage llm args{c:'D'} run return run scoreboard players set tok llm 71
execute if data storage llm args{c:'C'} run return run scoreboard players set tok llm 70
execute if data storage llm args{c:'B'} run return run scoreboard players set tok llm 69
execute if data storage llm args{c:'A'} run return run scoreboard players set tok llm 68
execute if data storage llm args{c:'@'} run return run scoreboard players set tok llm 67
execute if data storage llm args{c:'?'} run return run scoreboard players set tok llm 66
execute if data storage llm args{c:'>'} run return run scoreboard players set tok llm 65
execute if data storage llm args{c:'='} run return run scoreboard players set tok llm 64
execute if data storage llm args{c:'<'} run return run scoreboard players set tok llm 63
execute if data storage llm args{c:';'} run return run scoreboard players set tok llm 62
execute if data storage llm args{c:':'} run return run scoreboard players set tok llm 61
execute if data storage llm args{c:'9'} run return run scoreboard players set tok llm 60
execute if data storage llm args{c:'8'} run return run scoreboard players set tok llm 59
execute if data storage llm args{c:'7'} run return run scoreboard players set tok llm 58
execute if data storage llm args{c:'6'} run return run scoreboard players set tok llm 57
execute if data storage llm args{c:'5'} run return run scoreboard players set tok llm 56
execute if data storage llm args{c:'4'} run return run scoreboard players set tok llm 55
execute if data storage llm args{c:'3'} run return run scoreboard players set tok llm 54
execute if data storage llm args{c:'2'} run return run scoreboard players set tok llm 53
execute if data storage llm args{c:'1'} run return run scoreboard players set tok llm 52
execute if data storage llm args{c:'0'} run return run scoreboard players set tok llm 51
execute if data storage llm args{c:'/'} run return run scoreboard players set tok llm 50
execute if data storage llm args{c:'.'} run return run scoreboard players set tok llm 49
execute if data storage llm args{c:'-'} run return run scoreboard players set tok llm 48
execute if data storage llm args{c:','} run return run scoreboard players set tok llm 47
execute if data storage llm args{c:'+'} run return run scoreboard players set tok llm 46
execute if data storage llm args{c:'*'} run return run scoreboard players set tok llm 45
execute if data storage llm args{c:')'} run return run scoreboard players set tok llm 44
execute if data storage llm args{c:'('} run return run scoreboard players set tok llm 43
execute if data storage llm args{c:"'"} run return run scoreboard players set tok llm 42
execute if data storage llm args{c:'&'} run return run scoreboard players set tok llm 41
execute if data storage llm args{c:'%'} run return run scoreboard players set tok llm 40
execute if data storage llm args{c:'$'} run return run scoreboard players set tok llm 39
execute if data storage llm args{c:'#'} run return run scoreboard players set tok llm 38
execute if data storage llm args{c:'"'} run return run scoreboard players set tok llm 37
execute if data storage llm args{c:'!'} run return run scoreboard players set tok llm 36
execute if data storage llm args{c:' '} run return run scoreboard players set tok llm 35
execute if data storage llm args{c:'\n'} run return run scoreboard players set tok llm 13
execute if data storage llm args{c:'\t'} run return run scoreboard players set tok llm 12
execute if data storage llm args{c:'\n</s>\n'} run return run scoreboard players set tok llm 2
execute if data storage llm args{c:'\n<s>\n'} run return run scoreboard players set tok llm 1
execute if data storage llm args{c:'<unk>'} run return run scoreboard players set tok llm 0
scoreboard players set tok llm -1
