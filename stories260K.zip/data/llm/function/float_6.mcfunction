execute if score xb llm matches 100000..999999 run return run function llm:float_10
execute if score xb llm matches 1000000..9999999 run return run function llm:float_11
