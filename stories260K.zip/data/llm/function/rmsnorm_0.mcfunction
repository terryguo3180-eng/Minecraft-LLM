scoreboard players set ssb llm 0
scoreboard players set sse llm 0
scoreboard players set sss llm 0
scoreboard players operation xb llm = 0b x
scoreboard players operation xe llm = 0e x
scoreboard players operation xs llm = 0s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 1b x
scoreboard players operation xe llm = 1e x
scoreboard players operation xs llm = 1s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 2b x
scoreboard players operation xe llm = 2e x
scoreboard players operation xs llm = 2s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 3b x
scoreboard players operation xe llm = 3e x
scoreboard players operation xs llm = 3s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 4b x
scoreboard players operation xe llm = 4e x
scoreboard players operation xs llm = 4s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 5b x
scoreboard players operation xe llm = 5e x
scoreboard players operation xs llm = 5s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 6b x
scoreboard players operation xe llm = 6e x
scoreboard players operation xs llm = 6s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 7b x
scoreboard players operation xe llm = 7e x
scoreboard players operation xs llm = 7s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 8b x
scoreboard players operation xe llm = 8e x
scoreboard players operation xs llm = 8s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 9b x
scoreboard players operation xe llm = 9e x
scoreboard players operation xs llm = 9s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 10b x
scoreboard players operation xe llm = 10e x
scoreboard players operation xs llm = 10s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 11b x
scoreboard players operation xe llm = 11e x
scoreboard players operation xs llm = 11s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 12b x
scoreboard players operation xe llm = 12e x
scoreboard players operation xs llm = 12s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 13b x
scoreboard players operation xe llm = 13e x
scoreboard players operation xs llm = 13s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 14b x
scoreboard players operation xe llm = 14e x
scoreboard players operation xs llm = 14s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 15b x
scoreboard players operation xe llm = 15e x
scoreboard players operation xs llm = 15s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 16b x
scoreboard players operation xe llm = 16e x
scoreboard players operation xs llm = 16s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 17b x
scoreboard players operation xe llm = 17e x
scoreboard players operation xs llm = 17s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 18b x
scoreboard players operation xe llm = 18e x
scoreboard players operation xs llm = 18s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 19b x
scoreboard players operation xe llm = 19e x
scoreboard players operation xs llm = 19s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 20b x
scoreboard players operation xe llm = 20e x
scoreboard players operation xs llm = 20s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 21b x
scoreboard players operation xe llm = 21e x
scoreboard players operation xs llm = 21s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 22b x
scoreboard players operation xe llm = 22e x
scoreboard players operation xs llm = 22s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 23b x
scoreboard players operation xe llm = 23e x
scoreboard players operation xs llm = 23s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 24b x
scoreboard players operation xe llm = 24e x
scoreboard players operation xs llm = 24s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 25b x
scoreboard players operation xe llm = 25e x
scoreboard players operation xs llm = 25s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 26b x
scoreboard players operation xe llm = 26e x
scoreboard players operation xs llm = 26s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 27b x
scoreboard players operation xe llm = 27e x
scoreboard players operation xs llm = 27s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 28b x
scoreboard players operation xe llm = 28e x
scoreboard players operation xs llm = 28s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 29b x
scoreboard players operation xe llm = 29e x
scoreboard players operation xs llm = 29s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 30b x
scoreboard players operation xe llm = 30e x
scoreboard players operation xs llm = 30s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 31b x
scoreboard players operation xe llm = 31e x
scoreboard players operation xs llm = 31s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 32b x
scoreboard players operation xe llm = 32e x
scoreboard players operation xs llm = 32s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 33b x
scoreboard players operation xe llm = 33e x
scoreboard players operation xs llm = 33s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 34b x
scoreboard players operation xe llm = 34e x
scoreboard players operation xs llm = 34s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 35b x
scoreboard players operation xe llm = 35e x
scoreboard players operation xs llm = 35s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 36b x
scoreboard players operation xe llm = 36e x
scoreboard players operation xs llm = 36s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 37b x
scoreboard players operation xe llm = 37e x
scoreboard players operation xs llm = 37s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 38b x
scoreboard players operation xe llm = 38e x
scoreboard players operation xs llm = 38s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 39b x
scoreboard players operation xe llm = 39e x
scoreboard players operation xs llm = 39s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 40b x
scoreboard players operation xe llm = 40e x
scoreboard players operation xs llm = 40s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 41b x
scoreboard players operation xe llm = 41e x
scoreboard players operation xs llm = 41s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 42b x
scoreboard players operation xe llm = 42e x
scoreboard players operation xs llm = 42s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 43b x
scoreboard players operation xe llm = 43e x
scoreboard players operation xs llm = 43s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 44b x
scoreboard players operation xe llm = 44e x
scoreboard players operation xs llm = 44s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 45b x
scoreboard players operation xe llm = 45e x
scoreboard players operation xs llm = 45s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 46b x
scoreboard players operation xe llm = 46e x
scoreboard players operation xs llm = 46s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 47b x
scoreboard players operation xe llm = 47e x
scoreboard players operation xs llm = 47s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 48b x
scoreboard players operation xe llm = 48e x
scoreboard players operation xs llm = 48s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 49b x
scoreboard players operation xe llm = 49e x
scoreboard players operation xs llm = 49s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 50b x
scoreboard players operation xe llm = 50e x
scoreboard players operation xs llm = 50s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 51b x
scoreboard players operation xe llm = 51e x
scoreboard players operation xs llm = 51s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 52b x
scoreboard players operation xe llm = 52e x
scoreboard players operation xs llm = 52s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 53b x
scoreboard players operation xe llm = 53e x
scoreboard players operation xs llm = 53s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 54b x
scoreboard players operation xe llm = 54e x
scoreboard players operation xs llm = 54s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 55b x
scoreboard players operation xe llm = 55e x
scoreboard players operation xs llm = 55s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 56b x
scoreboard players operation xe llm = 56e x
scoreboard players operation xs llm = 56s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 57b x
scoreboard players operation xe llm = 57e x
scoreboard players operation xs llm = 57s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 58b x
scoreboard players operation xe llm = 58e x
scoreboard players operation xs llm = 58s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 59b x
scoreboard players operation xe llm = 59e x
scoreboard players operation xs llm = 59s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 60b x
scoreboard players operation xe llm = 60e x
scoreboard players operation xs llm = 60s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 61b x
scoreboard players operation xe llm = 61e x
scoreboard players operation xs llm = 61s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 62b x
scoreboard players operation xe llm = 62e x
scoreboard players operation xs llm = 62s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players operation xb llm = 63b x
scoreboard players operation xe llm = 63e x
scoreboard players operation xs llm = 63s x
function llm:sq
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:add
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
scoreboard players set xb llm 64
scoreboard players set xe llm 7
scoreboard players set xs llm 1
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = ssb llm
scoreboard players operation xe llm = sse llm
scoreboard players operation xs llm = sss llm
function llm:div
scoreboard players add xb llm 1
execute if score xb llm matches 100000000.. run function llm:float_15
function llm:sqrt
function llm:inv
scoreboard players operation ssb llm = xb llm
scoreboard players operation sse llm = xe llm
scoreboard players operation sss llm = xs llm
