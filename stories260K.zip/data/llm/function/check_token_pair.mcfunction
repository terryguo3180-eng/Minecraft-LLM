$data modify storage llm args.c set value "$(tok0)$(tok1)"
function llm:lookup_vocab with storage llm args
execute unless score tok llm matches -1 run function llm:merge_tokens
execute store result storage llm args.i int 1 run scoreboard players add i llm 1
execute store result storage llm args.j int 1 run scoreboard players add j llm 1
function llm:get_token_pair with storage llm args
execute if score i llm < len llm run function llm:check_token_pair with storage llm args
