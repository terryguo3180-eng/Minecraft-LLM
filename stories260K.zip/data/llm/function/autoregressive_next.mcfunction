execute unless data storage llm args{prompt_tokens:[]} run return run function llm:next_prompt_token
execute if score temperature llm matches 0 run function llm:argmax
execute unless score temperature llm matches 0 run function llm:temperature_sample
function llm:get_token
data modify storage llm args.tokens append from storage llm args.tok
tellraw @a ["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",{"storage":"llm","nbt":"args.tokens[]","separator":""}]
scoreboard players add pos llm 1
execute if score pos llm = steps llm run return 1
bossbar set progress players
function llm:autoregressive
