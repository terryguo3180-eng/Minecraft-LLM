execute if score xb llm matches 100..999 run return run function llm:float_12
execute if score xb llm matches 1000..9999 run return run function llm:float_13
scoreboard players operation xb llm *= 10000 llm
scoreboard players remove xe llm 4
