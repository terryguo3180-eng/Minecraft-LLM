function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_2"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 24
schedule function llm:forward_23 1t
