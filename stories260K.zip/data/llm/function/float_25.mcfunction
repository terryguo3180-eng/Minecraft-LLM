scoreboard players operation xb llm /= 1000 llm
scoreboard players operation r llm = xb llm
scoreboard players operation xb llm *= 1000 llm
