execute if score xb llm matches 0 run return run scoreboard players operation xe llm /= 2 llm
scoreboard players operation t0 llm = xe llm
scoreboard players operation t0 llm %= 2 llm
execute if score t0 llm matches 0 run function llm:float_11
scoreboard players operation xe llm /= 2 llm
function llm:float_16
scoreboard players operation t1 llm = xb llm
scoreboard players operation t1 llm /= t0 llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm /= 2 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t1 llm /= t0 llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm /= 2 llm
scoreboard players operation t1 llm = t0 llm
scoreboard players operation t1 llm *= t0 llm
execute if score t1 llm > xb llm run function llm:float_19
scoreboard players operation xb llm -= t1 llm
scoreboard players operation xb llm *= 500 llm
scoreboard players operation xb llm /= t0 llm
scoreboard players operation t0 llm *= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xb llm *= 10 llm
execute if score xb llm matches 100000000.. run function llm:float_15
