execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:matmul_logits_i with storage llm args
