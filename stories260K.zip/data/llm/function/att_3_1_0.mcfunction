scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 98304
scoreboard players set scoreb llm 0
scoreboard players set scoree llm 0
scoreboard players set scores llm 0
scoreboard players operation yb llm = 8b q
scoreboard players operation ye llm = 8e q
scoreboard players operation ys llm = 8s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 9b q
scoreboard players operation ye llm = 9e q
scoreboard players operation ys llm = 9s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 10b q
scoreboard players operation ye llm = 10e q
scoreboard players operation ys llm = 10s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 11b q
scoreboard players operation ye llm = 11e q
scoreboard players operation ys llm = 11s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 12b q
scoreboard players operation ye llm = 12e q
scoreboard players operation ys llm = 12s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 13b q
scoreboard players operation ye llm = 13e q
scoreboard players operation ys llm = 13s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 14b q
scoreboard players operation ye llm = 14e q
scoreboard players operation ys llm = 14s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 15b q
scoreboard players operation ye llm = 15e q
scoreboard players operation ys llm = 15s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation xb llm = scoreb llm
scoreboard players operation xe llm = scoree llm
scoreboard players operation xs llm = scores llm
scoreboard players set yb llm 28284271
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:div
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:set_av with storage llm args
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_3_1_0
