data modify storage llm args.s set value ""
execute if score xs llm matches -1 run data modify storage llm args.s set value "-"
scoreboard players operation t0 llm = xe llm
execute store result storage llm args.e int 1 run scoreboard players remove t0 llm 7
execute store result storage llm args.b int 1 run scoreboard players get xb llm
function llm:float_32 with storage llm args
