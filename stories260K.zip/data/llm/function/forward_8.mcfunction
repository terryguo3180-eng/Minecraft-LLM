data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_1"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 10
schedule function llm:forward_9 1t
