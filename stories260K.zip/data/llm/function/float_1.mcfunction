scoreboard players operation xb llm >< t2 llm
scoreboard players operation xe llm = ye llm
scoreboard players operation t3 llm *= -1 llm
scoreboard players operation xs llm = ys llm
