scoreboard players operation t0 llm /= 24703 llm
scoreboard players add t0 llm 4750
