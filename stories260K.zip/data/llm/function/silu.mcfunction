scoreboard players operation xb llm = 0b th
scoreboard players operation xe llm = 0e th
scoreboard players operation xs llm = 0s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 0b th2
scoreboard players operation xe llm = 0e th2
scoreboard players operation xs llm = 0s th2
function llm:div
scoreboard players operation yb llm = 0b th
scoreboard players operation ye llm = 0e th
scoreboard players operation ys llm = 0s th
function llm:mul
scoreboard players operation 0b th = xb llm
scoreboard players operation 0e th = xe llm
scoreboard players operation 0s th = xs llm
scoreboard players operation xb llm = 1b th
scoreboard players operation xe llm = 1e th
scoreboard players operation xs llm = 1s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 1b th2
scoreboard players operation xe llm = 1e th2
scoreboard players operation xs llm = 1s th2
function llm:div
scoreboard players operation yb llm = 1b th
scoreboard players operation ye llm = 1e th
scoreboard players operation ys llm = 1s th
function llm:mul
scoreboard players operation 1b th = xb llm
scoreboard players operation 1e th = xe llm
scoreboard players operation 1s th = xs llm
scoreboard players operation xb llm = 2b th
scoreboard players operation xe llm = 2e th
scoreboard players operation xs llm = 2s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 2b th2
scoreboard players operation xe llm = 2e th2
scoreboard players operation xs llm = 2s th2
function llm:div
scoreboard players operation yb llm = 2b th
scoreboard players operation ye llm = 2e th
scoreboard players operation ys llm = 2s th
function llm:mul
scoreboard players operation 2b th = xb llm
scoreboard players operation 2e th = xe llm
scoreboard players operation 2s th = xs llm
scoreboard players operation xb llm = 3b th
scoreboard players operation xe llm = 3e th
scoreboard players operation xs llm = 3s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 3b th2
scoreboard players operation xe llm = 3e th2
scoreboard players operation xs llm = 3s th2
function llm:div
scoreboard players operation yb llm = 3b th
scoreboard players operation ye llm = 3e th
scoreboard players operation ys llm = 3s th
function llm:mul
scoreboard players operation 3b th = xb llm
scoreboard players operation 3e th = xe llm
scoreboard players operation 3s th = xs llm
scoreboard players operation xb llm = 4b th
scoreboard players operation xe llm = 4e th
scoreboard players operation xs llm = 4s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 4b th2
scoreboard players operation xe llm = 4e th2
scoreboard players operation xs llm = 4s th2
function llm:div
scoreboard players operation yb llm = 4b th
scoreboard players operation ye llm = 4e th
scoreboard players operation ys llm = 4s th
function llm:mul
scoreboard players operation 4b th = xb llm
scoreboard players operation 4e th = xe llm
scoreboard players operation 4s th = xs llm
scoreboard players operation xb llm = 5b th
scoreboard players operation xe llm = 5e th
scoreboard players operation xs llm = 5s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 5b th2
scoreboard players operation xe llm = 5e th2
scoreboard players operation xs llm = 5s th2
function llm:div
scoreboard players operation yb llm = 5b th
scoreboard players operation ye llm = 5e th
scoreboard players operation ys llm = 5s th
function llm:mul
scoreboard players operation 5b th = xb llm
scoreboard players operation 5e th = xe llm
scoreboard players operation 5s th = xs llm
scoreboard players operation xb llm = 6b th
scoreboard players operation xe llm = 6e th
scoreboard players operation xs llm = 6s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 6b th2
scoreboard players operation xe llm = 6e th2
scoreboard players operation xs llm = 6s th2
function llm:div
scoreboard players operation yb llm = 6b th
scoreboard players operation ye llm = 6e th
scoreboard players operation ys llm = 6s th
function llm:mul
scoreboard players operation 6b th = xb llm
scoreboard players operation 6e th = xe llm
scoreboard players operation 6s th = xs llm
scoreboard players operation xb llm = 7b th
scoreboard players operation xe llm = 7e th
scoreboard players operation xs llm = 7s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 7b th2
scoreboard players operation xe llm = 7e th2
scoreboard players operation xs llm = 7s th2
function llm:div
scoreboard players operation yb llm = 7b th
scoreboard players operation ye llm = 7e th
scoreboard players operation ys llm = 7s th
function llm:mul
scoreboard players operation 7b th = xb llm
scoreboard players operation 7e th = xe llm
scoreboard players operation 7s th = xs llm
scoreboard players operation xb llm = 8b th
scoreboard players operation xe llm = 8e th
scoreboard players operation xs llm = 8s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 8b th2
scoreboard players operation xe llm = 8e th2
scoreboard players operation xs llm = 8s th2
function llm:div
scoreboard players operation yb llm = 8b th
scoreboard players operation ye llm = 8e th
scoreboard players operation ys llm = 8s th
function llm:mul
scoreboard players operation 8b th = xb llm
scoreboard players operation 8e th = xe llm
scoreboard players operation 8s th = xs llm
scoreboard players operation xb llm = 9b th
scoreboard players operation xe llm = 9e th
scoreboard players operation xs llm = 9s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 9b th2
scoreboard players operation xe llm = 9e th2
scoreboard players operation xs llm = 9s th2
function llm:div
scoreboard players operation yb llm = 9b th
scoreboard players operation ye llm = 9e th
scoreboard players operation ys llm = 9s th
function llm:mul
scoreboard players operation 9b th = xb llm
scoreboard players operation 9e th = xe llm
scoreboard players operation 9s th = xs llm
scoreboard players operation xb llm = 10b th
scoreboard players operation xe llm = 10e th
scoreboard players operation xs llm = 10s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 10b th2
scoreboard players operation xe llm = 10e th2
scoreboard players operation xs llm = 10s th2
function llm:div
scoreboard players operation yb llm = 10b th
scoreboard players operation ye llm = 10e th
scoreboard players operation ys llm = 10s th
function llm:mul
scoreboard players operation 10b th = xb llm
scoreboard players operation 10e th = xe llm
scoreboard players operation 10s th = xs llm
scoreboard players operation xb llm = 11b th
scoreboard players operation xe llm = 11e th
scoreboard players operation xs llm = 11s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 11b th2
scoreboard players operation xe llm = 11e th2
scoreboard players operation xs llm = 11s th2
function llm:div
scoreboard players operation yb llm = 11b th
scoreboard players operation ye llm = 11e th
scoreboard players operation ys llm = 11s th
function llm:mul
scoreboard players operation 11b th = xb llm
scoreboard players operation 11e th = xe llm
scoreboard players operation 11s th = xs llm
scoreboard players operation xb llm = 12b th
scoreboard players operation xe llm = 12e th
scoreboard players operation xs llm = 12s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 12b th2
scoreboard players operation xe llm = 12e th2
scoreboard players operation xs llm = 12s th2
function llm:div
scoreboard players operation yb llm = 12b th
scoreboard players operation ye llm = 12e th
scoreboard players operation ys llm = 12s th
function llm:mul
scoreboard players operation 12b th = xb llm
scoreboard players operation 12e th = xe llm
scoreboard players operation 12s th = xs llm
scoreboard players operation xb llm = 13b th
scoreboard players operation xe llm = 13e th
scoreboard players operation xs llm = 13s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 13b th2
scoreboard players operation xe llm = 13e th2
scoreboard players operation xs llm = 13s th2
function llm:div
scoreboard players operation yb llm = 13b th
scoreboard players operation ye llm = 13e th
scoreboard players operation ys llm = 13s th
function llm:mul
scoreboard players operation 13b th = xb llm
scoreboard players operation 13e th = xe llm
scoreboard players operation 13s th = xs llm
scoreboard players operation xb llm = 14b th
scoreboard players operation xe llm = 14e th
scoreboard players operation xs llm = 14s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 14b th2
scoreboard players operation xe llm = 14e th2
scoreboard players operation xs llm = 14s th2
function llm:div
scoreboard players operation yb llm = 14b th
scoreboard players operation ye llm = 14e th
scoreboard players operation ys llm = 14s th
function llm:mul
scoreboard players operation 14b th = xb llm
scoreboard players operation 14e th = xe llm
scoreboard players operation 14s th = xs llm
scoreboard players operation xb llm = 15b th
scoreboard players operation xe llm = 15e th
scoreboard players operation xs llm = 15s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 15b th2
scoreboard players operation xe llm = 15e th2
scoreboard players operation xs llm = 15s th2
function llm:div
scoreboard players operation yb llm = 15b th
scoreboard players operation ye llm = 15e th
scoreboard players operation ys llm = 15s th
function llm:mul
scoreboard players operation 15b th = xb llm
scoreboard players operation 15e th = xe llm
scoreboard players operation 15s th = xs llm
scoreboard players operation xb llm = 16b th
scoreboard players operation xe llm = 16e th
scoreboard players operation xs llm = 16s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 16b th2
scoreboard players operation xe llm = 16e th2
scoreboard players operation xs llm = 16s th2
function llm:div
scoreboard players operation yb llm = 16b th
scoreboard players operation ye llm = 16e th
scoreboard players operation ys llm = 16s th
function llm:mul
scoreboard players operation 16b th = xb llm
scoreboard players operation 16e th = xe llm
scoreboard players operation 16s th = xs llm
scoreboard players operation xb llm = 17b th
scoreboard players operation xe llm = 17e th
scoreboard players operation xs llm = 17s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 17b th2
scoreboard players operation xe llm = 17e th2
scoreboard players operation xs llm = 17s th2
function llm:div
scoreboard players operation yb llm = 17b th
scoreboard players operation ye llm = 17e th
scoreboard players operation ys llm = 17s th
function llm:mul
scoreboard players operation 17b th = xb llm
scoreboard players operation 17e th = xe llm
scoreboard players operation 17s th = xs llm
scoreboard players operation xb llm = 18b th
scoreboard players operation xe llm = 18e th
scoreboard players operation xs llm = 18s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 18b th2
scoreboard players operation xe llm = 18e th2
scoreboard players operation xs llm = 18s th2
function llm:div
scoreboard players operation yb llm = 18b th
scoreboard players operation ye llm = 18e th
scoreboard players operation ys llm = 18s th
function llm:mul
scoreboard players operation 18b th = xb llm
scoreboard players operation 18e th = xe llm
scoreboard players operation 18s th = xs llm
scoreboard players operation xb llm = 19b th
scoreboard players operation xe llm = 19e th
scoreboard players operation xs llm = 19s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 19b th2
scoreboard players operation xe llm = 19e th2
scoreboard players operation xs llm = 19s th2
function llm:div
scoreboard players operation yb llm = 19b th
scoreboard players operation ye llm = 19e th
scoreboard players operation ys llm = 19s th
function llm:mul
scoreboard players operation 19b th = xb llm
scoreboard players operation 19e th = xe llm
scoreboard players operation 19s th = xs llm
scoreboard players operation xb llm = 20b th
scoreboard players operation xe llm = 20e th
scoreboard players operation xs llm = 20s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 20b th2
scoreboard players operation xe llm = 20e th2
scoreboard players operation xs llm = 20s th2
function llm:div
scoreboard players operation yb llm = 20b th
scoreboard players operation ye llm = 20e th
scoreboard players operation ys llm = 20s th
function llm:mul
scoreboard players operation 20b th = xb llm
scoreboard players operation 20e th = xe llm
scoreboard players operation 20s th = xs llm
scoreboard players operation xb llm = 21b th
scoreboard players operation xe llm = 21e th
scoreboard players operation xs llm = 21s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 21b th2
scoreboard players operation xe llm = 21e th2
scoreboard players operation xs llm = 21s th2
function llm:div
scoreboard players operation yb llm = 21b th
scoreboard players operation ye llm = 21e th
scoreboard players operation ys llm = 21s th
function llm:mul
scoreboard players operation 21b th = xb llm
scoreboard players operation 21e th = xe llm
scoreboard players operation 21s th = xs llm
scoreboard players operation xb llm = 22b th
scoreboard players operation xe llm = 22e th
scoreboard players operation xs llm = 22s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 22b th2
scoreboard players operation xe llm = 22e th2
scoreboard players operation xs llm = 22s th2
function llm:div
scoreboard players operation yb llm = 22b th
scoreboard players operation ye llm = 22e th
scoreboard players operation ys llm = 22s th
function llm:mul
scoreboard players operation 22b th = xb llm
scoreboard players operation 22e th = xe llm
scoreboard players operation 22s th = xs llm
scoreboard players operation xb llm = 23b th
scoreboard players operation xe llm = 23e th
scoreboard players operation xs llm = 23s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 23b th2
scoreboard players operation xe llm = 23e th2
scoreboard players operation xs llm = 23s th2
function llm:div
scoreboard players operation yb llm = 23b th
scoreboard players operation ye llm = 23e th
scoreboard players operation ys llm = 23s th
function llm:mul
scoreboard players operation 23b th = xb llm
scoreboard players operation 23e th = xe llm
scoreboard players operation 23s th = xs llm
scoreboard players operation xb llm = 24b th
scoreboard players operation xe llm = 24e th
scoreboard players operation xs llm = 24s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 24b th2
scoreboard players operation xe llm = 24e th2
scoreboard players operation xs llm = 24s th2
function llm:div
scoreboard players operation yb llm = 24b th
scoreboard players operation ye llm = 24e th
scoreboard players operation ys llm = 24s th
function llm:mul
scoreboard players operation 24b th = xb llm
scoreboard players operation 24e th = xe llm
scoreboard players operation 24s th = xs llm
scoreboard players operation xb llm = 25b th
scoreboard players operation xe llm = 25e th
scoreboard players operation xs llm = 25s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 25b th2
scoreboard players operation xe llm = 25e th2
scoreboard players operation xs llm = 25s th2
function llm:div
scoreboard players operation yb llm = 25b th
scoreboard players operation ye llm = 25e th
scoreboard players operation ys llm = 25s th
function llm:mul
scoreboard players operation 25b th = xb llm
scoreboard players operation 25e th = xe llm
scoreboard players operation 25s th = xs llm
scoreboard players operation xb llm = 26b th
scoreboard players operation xe llm = 26e th
scoreboard players operation xs llm = 26s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 26b th2
scoreboard players operation xe llm = 26e th2
scoreboard players operation xs llm = 26s th2
function llm:div
scoreboard players operation yb llm = 26b th
scoreboard players operation ye llm = 26e th
scoreboard players operation ys llm = 26s th
function llm:mul
scoreboard players operation 26b th = xb llm
scoreboard players operation 26e th = xe llm
scoreboard players operation 26s th = xs llm
scoreboard players operation xb llm = 27b th
scoreboard players operation xe llm = 27e th
scoreboard players operation xs llm = 27s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 27b th2
scoreboard players operation xe llm = 27e th2
scoreboard players operation xs llm = 27s th2
function llm:div
scoreboard players operation yb llm = 27b th
scoreboard players operation ye llm = 27e th
scoreboard players operation ys llm = 27s th
function llm:mul
scoreboard players operation 27b th = xb llm
scoreboard players operation 27e th = xe llm
scoreboard players operation 27s th = xs llm
scoreboard players operation xb llm = 28b th
scoreboard players operation xe llm = 28e th
scoreboard players operation xs llm = 28s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 28b th2
scoreboard players operation xe llm = 28e th2
scoreboard players operation xs llm = 28s th2
function llm:div
scoreboard players operation yb llm = 28b th
scoreboard players operation ye llm = 28e th
scoreboard players operation ys llm = 28s th
function llm:mul
scoreboard players operation 28b th = xb llm
scoreboard players operation 28e th = xe llm
scoreboard players operation 28s th = xs llm
scoreboard players operation xb llm = 29b th
scoreboard players operation xe llm = 29e th
scoreboard players operation xs llm = 29s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 29b th2
scoreboard players operation xe llm = 29e th2
scoreboard players operation xs llm = 29s th2
function llm:div
scoreboard players operation yb llm = 29b th
scoreboard players operation ye llm = 29e th
scoreboard players operation ys llm = 29s th
function llm:mul
scoreboard players operation 29b th = xb llm
scoreboard players operation 29e th = xe llm
scoreboard players operation 29s th = xs llm
scoreboard players operation xb llm = 30b th
scoreboard players operation xe llm = 30e th
scoreboard players operation xs llm = 30s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 30b th2
scoreboard players operation xe llm = 30e th2
scoreboard players operation xs llm = 30s th2
function llm:div
scoreboard players operation yb llm = 30b th
scoreboard players operation ye llm = 30e th
scoreboard players operation ys llm = 30s th
function llm:mul
scoreboard players operation 30b th = xb llm
scoreboard players operation 30e th = xe llm
scoreboard players operation 30s th = xs llm
scoreboard players operation xb llm = 31b th
scoreboard players operation xe llm = 31e th
scoreboard players operation xs llm = 31s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 31b th2
scoreboard players operation xe llm = 31e th2
scoreboard players operation xs llm = 31s th2
function llm:div
scoreboard players operation yb llm = 31b th
scoreboard players operation ye llm = 31e th
scoreboard players operation ys llm = 31s th
function llm:mul
scoreboard players operation 31b th = xb llm
scoreboard players operation 31e th = xe llm
scoreboard players operation 31s th = xs llm
scoreboard players operation xb llm = 32b th
scoreboard players operation xe llm = 32e th
scoreboard players operation xs llm = 32s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 32b th2
scoreboard players operation xe llm = 32e th2
scoreboard players operation xs llm = 32s th2
function llm:div
scoreboard players operation yb llm = 32b th
scoreboard players operation ye llm = 32e th
scoreboard players operation ys llm = 32s th
function llm:mul
scoreboard players operation 32b th = xb llm
scoreboard players operation 32e th = xe llm
scoreboard players operation 32s th = xs llm
scoreboard players operation xb llm = 33b th
scoreboard players operation xe llm = 33e th
scoreboard players operation xs llm = 33s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 33b th2
scoreboard players operation xe llm = 33e th2
scoreboard players operation xs llm = 33s th2
function llm:div
scoreboard players operation yb llm = 33b th
scoreboard players operation ye llm = 33e th
scoreboard players operation ys llm = 33s th
function llm:mul
scoreboard players operation 33b th = xb llm
scoreboard players operation 33e th = xe llm
scoreboard players operation 33s th = xs llm
scoreboard players operation xb llm = 34b th
scoreboard players operation xe llm = 34e th
scoreboard players operation xs llm = 34s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 34b th2
scoreboard players operation xe llm = 34e th2
scoreboard players operation xs llm = 34s th2
function llm:div
scoreboard players operation yb llm = 34b th
scoreboard players operation ye llm = 34e th
scoreboard players operation ys llm = 34s th
function llm:mul
scoreboard players operation 34b th = xb llm
scoreboard players operation 34e th = xe llm
scoreboard players operation 34s th = xs llm
scoreboard players operation xb llm = 35b th
scoreboard players operation xe llm = 35e th
scoreboard players operation xs llm = 35s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 35b th2
scoreboard players operation xe llm = 35e th2
scoreboard players operation xs llm = 35s th2
function llm:div
scoreboard players operation yb llm = 35b th
scoreboard players operation ye llm = 35e th
scoreboard players operation ys llm = 35s th
function llm:mul
scoreboard players operation 35b th = xb llm
scoreboard players operation 35e th = xe llm
scoreboard players operation 35s th = xs llm
scoreboard players operation xb llm = 36b th
scoreboard players operation xe llm = 36e th
scoreboard players operation xs llm = 36s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 36b th2
scoreboard players operation xe llm = 36e th2
scoreboard players operation xs llm = 36s th2
function llm:div
scoreboard players operation yb llm = 36b th
scoreboard players operation ye llm = 36e th
scoreboard players operation ys llm = 36s th
function llm:mul
scoreboard players operation 36b th = xb llm
scoreboard players operation 36e th = xe llm
scoreboard players operation 36s th = xs llm
scoreboard players operation xb llm = 37b th
scoreboard players operation xe llm = 37e th
scoreboard players operation xs llm = 37s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 37b th2
scoreboard players operation xe llm = 37e th2
scoreboard players operation xs llm = 37s th2
function llm:div
scoreboard players operation yb llm = 37b th
scoreboard players operation ye llm = 37e th
scoreboard players operation ys llm = 37s th
function llm:mul
scoreboard players operation 37b th = xb llm
scoreboard players operation 37e th = xe llm
scoreboard players operation 37s th = xs llm
scoreboard players operation xb llm = 38b th
scoreboard players operation xe llm = 38e th
scoreboard players operation xs llm = 38s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 38b th2
scoreboard players operation xe llm = 38e th2
scoreboard players operation xs llm = 38s th2
function llm:div
scoreboard players operation yb llm = 38b th
scoreboard players operation ye llm = 38e th
scoreboard players operation ys llm = 38s th
function llm:mul
scoreboard players operation 38b th = xb llm
scoreboard players operation 38e th = xe llm
scoreboard players operation 38s th = xs llm
scoreboard players operation xb llm = 39b th
scoreboard players operation xe llm = 39e th
scoreboard players operation xs llm = 39s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 39b th2
scoreboard players operation xe llm = 39e th2
scoreboard players operation xs llm = 39s th2
function llm:div
scoreboard players operation yb llm = 39b th
scoreboard players operation ye llm = 39e th
scoreboard players operation ys llm = 39s th
function llm:mul
scoreboard players operation 39b th = xb llm
scoreboard players operation 39e th = xe llm
scoreboard players operation 39s th = xs llm
scoreboard players operation xb llm = 40b th
scoreboard players operation xe llm = 40e th
scoreboard players operation xs llm = 40s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 40b th2
scoreboard players operation xe llm = 40e th2
scoreboard players operation xs llm = 40s th2
function llm:div
scoreboard players operation yb llm = 40b th
scoreboard players operation ye llm = 40e th
scoreboard players operation ys llm = 40s th
function llm:mul
scoreboard players operation 40b th = xb llm
scoreboard players operation 40e th = xe llm
scoreboard players operation 40s th = xs llm
scoreboard players operation xb llm = 41b th
scoreboard players operation xe llm = 41e th
scoreboard players operation xs llm = 41s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 41b th2
scoreboard players operation xe llm = 41e th2
scoreboard players operation xs llm = 41s th2
function llm:div
scoreboard players operation yb llm = 41b th
scoreboard players operation ye llm = 41e th
scoreboard players operation ys llm = 41s th
function llm:mul
scoreboard players operation 41b th = xb llm
scoreboard players operation 41e th = xe llm
scoreboard players operation 41s th = xs llm
scoreboard players operation xb llm = 42b th
scoreboard players operation xe llm = 42e th
scoreboard players operation xs llm = 42s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 42b th2
scoreboard players operation xe llm = 42e th2
scoreboard players operation xs llm = 42s th2
function llm:div
scoreboard players operation yb llm = 42b th
scoreboard players operation ye llm = 42e th
scoreboard players operation ys llm = 42s th
function llm:mul
scoreboard players operation 42b th = xb llm
scoreboard players operation 42e th = xe llm
scoreboard players operation 42s th = xs llm
scoreboard players operation xb llm = 43b th
scoreboard players operation xe llm = 43e th
scoreboard players operation xs llm = 43s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 43b th2
scoreboard players operation xe llm = 43e th2
scoreboard players operation xs llm = 43s th2
function llm:div
scoreboard players operation yb llm = 43b th
scoreboard players operation ye llm = 43e th
scoreboard players operation ys llm = 43s th
function llm:mul
scoreboard players operation 43b th = xb llm
scoreboard players operation 43e th = xe llm
scoreboard players operation 43s th = xs llm
scoreboard players operation xb llm = 44b th
scoreboard players operation xe llm = 44e th
scoreboard players operation xs llm = 44s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 44b th2
scoreboard players operation xe llm = 44e th2
scoreboard players operation xs llm = 44s th2
function llm:div
scoreboard players operation yb llm = 44b th
scoreboard players operation ye llm = 44e th
scoreboard players operation ys llm = 44s th
function llm:mul
scoreboard players operation 44b th = xb llm
scoreboard players operation 44e th = xe llm
scoreboard players operation 44s th = xs llm
scoreboard players operation xb llm = 45b th
scoreboard players operation xe llm = 45e th
scoreboard players operation xs llm = 45s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 45b th2
scoreboard players operation xe llm = 45e th2
scoreboard players operation xs llm = 45s th2
function llm:div
scoreboard players operation yb llm = 45b th
scoreboard players operation ye llm = 45e th
scoreboard players operation ys llm = 45s th
function llm:mul
scoreboard players operation 45b th = xb llm
scoreboard players operation 45e th = xe llm
scoreboard players operation 45s th = xs llm
scoreboard players operation xb llm = 46b th
scoreboard players operation xe llm = 46e th
scoreboard players operation xs llm = 46s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 46b th2
scoreboard players operation xe llm = 46e th2
scoreboard players operation xs llm = 46s th2
function llm:div
scoreboard players operation yb llm = 46b th
scoreboard players operation ye llm = 46e th
scoreboard players operation ys llm = 46s th
function llm:mul
scoreboard players operation 46b th = xb llm
scoreboard players operation 46e th = xe llm
scoreboard players operation 46s th = xs llm
scoreboard players operation xb llm = 47b th
scoreboard players operation xe llm = 47e th
scoreboard players operation xs llm = 47s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 47b th2
scoreboard players operation xe llm = 47e th2
scoreboard players operation xs llm = 47s th2
function llm:div
scoreboard players operation yb llm = 47b th
scoreboard players operation ye llm = 47e th
scoreboard players operation ys llm = 47s th
function llm:mul
scoreboard players operation 47b th = xb llm
scoreboard players operation 47e th = xe llm
scoreboard players operation 47s th = xs llm
scoreboard players operation xb llm = 48b th
scoreboard players operation xe llm = 48e th
scoreboard players operation xs llm = 48s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 48b th2
scoreboard players operation xe llm = 48e th2
scoreboard players operation xs llm = 48s th2
function llm:div
scoreboard players operation yb llm = 48b th
scoreboard players operation ye llm = 48e th
scoreboard players operation ys llm = 48s th
function llm:mul
scoreboard players operation 48b th = xb llm
scoreboard players operation 48e th = xe llm
scoreboard players operation 48s th = xs llm
scoreboard players operation xb llm = 49b th
scoreboard players operation xe llm = 49e th
scoreboard players operation xs llm = 49s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 49b th2
scoreboard players operation xe llm = 49e th2
scoreboard players operation xs llm = 49s th2
function llm:div
scoreboard players operation yb llm = 49b th
scoreboard players operation ye llm = 49e th
scoreboard players operation ys llm = 49s th
function llm:mul
scoreboard players operation 49b th = xb llm
scoreboard players operation 49e th = xe llm
scoreboard players operation 49s th = xs llm
scoreboard players operation xb llm = 50b th
scoreboard players operation xe llm = 50e th
scoreboard players operation xs llm = 50s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 50b th2
scoreboard players operation xe llm = 50e th2
scoreboard players operation xs llm = 50s th2
function llm:div
scoreboard players operation yb llm = 50b th
scoreboard players operation ye llm = 50e th
scoreboard players operation ys llm = 50s th
function llm:mul
scoreboard players operation 50b th = xb llm
scoreboard players operation 50e th = xe llm
scoreboard players operation 50s th = xs llm
scoreboard players operation xb llm = 51b th
scoreboard players operation xe llm = 51e th
scoreboard players operation xs llm = 51s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 51b th2
scoreboard players operation xe llm = 51e th2
scoreboard players operation xs llm = 51s th2
function llm:div
scoreboard players operation yb llm = 51b th
scoreboard players operation ye llm = 51e th
scoreboard players operation ys llm = 51s th
function llm:mul
scoreboard players operation 51b th = xb llm
scoreboard players operation 51e th = xe llm
scoreboard players operation 51s th = xs llm
scoreboard players operation xb llm = 52b th
scoreboard players operation xe llm = 52e th
scoreboard players operation xs llm = 52s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 52b th2
scoreboard players operation xe llm = 52e th2
scoreboard players operation xs llm = 52s th2
function llm:div
scoreboard players operation yb llm = 52b th
scoreboard players operation ye llm = 52e th
scoreboard players operation ys llm = 52s th
function llm:mul
scoreboard players operation 52b th = xb llm
scoreboard players operation 52e th = xe llm
scoreboard players operation 52s th = xs llm
scoreboard players operation xb llm = 53b th
scoreboard players operation xe llm = 53e th
scoreboard players operation xs llm = 53s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 53b th2
scoreboard players operation xe llm = 53e th2
scoreboard players operation xs llm = 53s th2
function llm:div
scoreboard players operation yb llm = 53b th
scoreboard players operation ye llm = 53e th
scoreboard players operation ys llm = 53s th
function llm:mul
scoreboard players operation 53b th = xb llm
scoreboard players operation 53e th = xe llm
scoreboard players operation 53s th = xs llm
scoreboard players operation xb llm = 54b th
scoreboard players operation xe llm = 54e th
scoreboard players operation xs llm = 54s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 54b th2
scoreboard players operation xe llm = 54e th2
scoreboard players operation xs llm = 54s th2
function llm:div
scoreboard players operation yb llm = 54b th
scoreboard players operation ye llm = 54e th
scoreboard players operation ys llm = 54s th
function llm:mul
scoreboard players operation 54b th = xb llm
scoreboard players operation 54e th = xe llm
scoreboard players operation 54s th = xs llm
scoreboard players operation xb llm = 55b th
scoreboard players operation xe llm = 55e th
scoreboard players operation xs llm = 55s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 55b th2
scoreboard players operation xe llm = 55e th2
scoreboard players operation xs llm = 55s th2
function llm:div
scoreboard players operation yb llm = 55b th
scoreboard players operation ye llm = 55e th
scoreboard players operation ys llm = 55s th
function llm:mul
scoreboard players operation 55b th = xb llm
scoreboard players operation 55e th = xe llm
scoreboard players operation 55s th = xs llm
scoreboard players operation xb llm = 56b th
scoreboard players operation xe llm = 56e th
scoreboard players operation xs llm = 56s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 56b th2
scoreboard players operation xe llm = 56e th2
scoreboard players operation xs llm = 56s th2
function llm:div
scoreboard players operation yb llm = 56b th
scoreboard players operation ye llm = 56e th
scoreboard players operation ys llm = 56s th
function llm:mul
scoreboard players operation 56b th = xb llm
scoreboard players operation 56e th = xe llm
scoreboard players operation 56s th = xs llm
scoreboard players operation xb llm = 57b th
scoreboard players operation xe llm = 57e th
scoreboard players operation xs llm = 57s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 57b th2
scoreboard players operation xe llm = 57e th2
scoreboard players operation xs llm = 57s th2
function llm:div
scoreboard players operation yb llm = 57b th
scoreboard players operation ye llm = 57e th
scoreboard players operation ys llm = 57s th
function llm:mul
scoreboard players operation 57b th = xb llm
scoreboard players operation 57e th = xe llm
scoreboard players operation 57s th = xs llm
scoreboard players operation xb llm = 58b th
scoreboard players operation xe llm = 58e th
scoreboard players operation xs llm = 58s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 58b th2
scoreboard players operation xe llm = 58e th2
scoreboard players operation xs llm = 58s th2
function llm:div
scoreboard players operation yb llm = 58b th
scoreboard players operation ye llm = 58e th
scoreboard players operation ys llm = 58s th
function llm:mul
scoreboard players operation 58b th = xb llm
scoreboard players operation 58e th = xe llm
scoreboard players operation 58s th = xs llm
scoreboard players operation xb llm = 59b th
scoreboard players operation xe llm = 59e th
scoreboard players operation xs llm = 59s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 59b th2
scoreboard players operation xe llm = 59e th2
scoreboard players operation xs llm = 59s th2
function llm:div
scoreboard players operation yb llm = 59b th
scoreboard players operation ye llm = 59e th
scoreboard players operation ys llm = 59s th
function llm:mul
scoreboard players operation 59b th = xb llm
scoreboard players operation 59e th = xe llm
scoreboard players operation 59s th = xs llm
scoreboard players operation xb llm = 60b th
scoreboard players operation xe llm = 60e th
scoreboard players operation xs llm = 60s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 60b th2
scoreboard players operation xe llm = 60e th2
scoreboard players operation xs llm = 60s th2
function llm:div
scoreboard players operation yb llm = 60b th
scoreboard players operation ye llm = 60e th
scoreboard players operation ys llm = 60s th
function llm:mul
scoreboard players operation 60b th = xb llm
scoreboard players operation 60e th = xe llm
scoreboard players operation 60s th = xs llm
scoreboard players operation xb llm = 61b th
scoreboard players operation xe llm = 61e th
scoreboard players operation xs llm = 61s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 61b th2
scoreboard players operation xe llm = 61e th2
scoreboard players operation xs llm = 61s th2
function llm:div
scoreboard players operation yb llm = 61b th
scoreboard players operation ye llm = 61e th
scoreboard players operation ys llm = 61s th
function llm:mul
scoreboard players operation 61b th = xb llm
scoreboard players operation 61e th = xe llm
scoreboard players operation 61s th = xs llm
scoreboard players operation xb llm = 62b th
scoreboard players operation xe llm = 62e th
scoreboard players operation xs llm = 62s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 62b th2
scoreboard players operation xe llm = 62e th2
scoreboard players operation xs llm = 62s th2
function llm:div
scoreboard players operation yb llm = 62b th
scoreboard players operation ye llm = 62e th
scoreboard players operation ys llm = 62s th
function llm:mul
scoreboard players operation 62b th = xb llm
scoreboard players operation 62e th = xe llm
scoreboard players operation 62s th = xs llm
scoreboard players operation xb llm = 63b th
scoreboard players operation xe llm = 63e th
scoreboard players operation xs llm = 63s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 63b th2
scoreboard players operation xe llm = 63e th2
scoreboard players operation xs llm = 63s th2
function llm:div
scoreboard players operation yb llm = 63b th
scoreboard players operation ye llm = 63e th
scoreboard players operation ys llm = 63s th
function llm:mul
scoreboard players operation 63b th = xb llm
scoreboard players operation 63e th = xe llm
scoreboard players operation 63s th = xs llm
scoreboard players operation xb llm = 64b th
scoreboard players operation xe llm = 64e th
scoreboard players operation xs llm = 64s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 64b th2
scoreboard players operation xe llm = 64e th2
scoreboard players operation xs llm = 64s th2
function llm:div
scoreboard players operation yb llm = 64b th
scoreboard players operation ye llm = 64e th
scoreboard players operation ys llm = 64s th
function llm:mul
scoreboard players operation 64b th = xb llm
scoreboard players operation 64e th = xe llm
scoreboard players operation 64s th = xs llm
scoreboard players operation xb llm = 65b th
scoreboard players operation xe llm = 65e th
scoreboard players operation xs llm = 65s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 65b th2
scoreboard players operation xe llm = 65e th2
scoreboard players operation xs llm = 65s th2
function llm:div
scoreboard players operation yb llm = 65b th
scoreboard players operation ye llm = 65e th
scoreboard players operation ys llm = 65s th
function llm:mul
scoreboard players operation 65b th = xb llm
scoreboard players operation 65e th = xe llm
scoreboard players operation 65s th = xs llm
scoreboard players operation xb llm = 66b th
scoreboard players operation xe llm = 66e th
scoreboard players operation xs llm = 66s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 66b th2
scoreboard players operation xe llm = 66e th2
scoreboard players operation xs llm = 66s th2
function llm:div
scoreboard players operation yb llm = 66b th
scoreboard players operation ye llm = 66e th
scoreboard players operation ys llm = 66s th
function llm:mul
scoreboard players operation 66b th = xb llm
scoreboard players operation 66e th = xe llm
scoreboard players operation 66s th = xs llm
scoreboard players operation xb llm = 67b th
scoreboard players operation xe llm = 67e th
scoreboard players operation xs llm = 67s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 67b th2
scoreboard players operation xe llm = 67e th2
scoreboard players operation xs llm = 67s th2
function llm:div
scoreboard players operation yb llm = 67b th
scoreboard players operation ye llm = 67e th
scoreboard players operation ys llm = 67s th
function llm:mul
scoreboard players operation 67b th = xb llm
scoreboard players operation 67e th = xe llm
scoreboard players operation 67s th = xs llm
scoreboard players operation xb llm = 68b th
scoreboard players operation xe llm = 68e th
scoreboard players operation xs llm = 68s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 68b th2
scoreboard players operation xe llm = 68e th2
scoreboard players operation xs llm = 68s th2
function llm:div
scoreboard players operation yb llm = 68b th
scoreboard players operation ye llm = 68e th
scoreboard players operation ys llm = 68s th
function llm:mul
scoreboard players operation 68b th = xb llm
scoreboard players operation 68e th = xe llm
scoreboard players operation 68s th = xs llm
scoreboard players operation xb llm = 69b th
scoreboard players operation xe llm = 69e th
scoreboard players operation xs llm = 69s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 69b th2
scoreboard players operation xe llm = 69e th2
scoreboard players operation xs llm = 69s th2
function llm:div
scoreboard players operation yb llm = 69b th
scoreboard players operation ye llm = 69e th
scoreboard players operation ys llm = 69s th
function llm:mul
scoreboard players operation 69b th = xb llm
scoreboard players operation 69e th = xe llm
scoreboard players operation 69s th = xs llm
scoreboard players operation xb llm = 70b th
scoreboard players operation xe llm = 70e th
scoreboard players operation xs llm = 70s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 70b th2
scoreboard players operation xe llm = 70e th2
scoreboard players operation xs llm = 70s th2
function llm:div
scoreboard players operation yb llm = 70b th
scoreboard players operation ye llm = 70e th
scoreboard players operation ys llm = 70s th
function llm:mul
scoreboard players operation 70b th = xb llm
scoreboard players operation 70e th = xe llm
scoreboard players operation 70s th = xs llm
scoreboard players operation xb llm = 71b th
scoreboard players operation xe llm = 71e th
scoreboard players operation xs llm = 71s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 71b th2
scoreboard players operation xe llm = 71e th2
scoreboard players operation xs llm = 71s th2
function llm:div
scoreboard players operation yb llm = 71b th
scoreboard players operation ye llm = 71e th
scoreboard players operation ys llm = 71s th
function llm:mul
scoreboard players operation 71b th = xb llm
scoreboard players operation 71e th = xe llm
scoreboard players operation 71s th = xs llm
scoreboard players operation xb llm = 72b th
scoreboard players operation xe llm = 72e th
scoreboard players operation xs llm = 72s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 72b th2
scoreboard players operation xe llm = 72e th2
scoreboard players operation xs llm = 72s th2
function llm:div
scoreboard players operation yb llm = 72b th
scoreboard players operation ye llm = 72e th
scoreboard players operation ys llm = 72s th
function llm:mul
scoreboard players operation 72b th = xb llm
scoreboard players operation 72e th = xe llm
scoreboard players operation 72s th = xs llm
scoreboard players operation xb llm = 73b th
scoreboard players operation xe llm = 73e th
scoreboard players operation xs llm = 73s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 73b th2
scoreboard players operation xe llm = 73e th2
scoreboard players operation xs llm = 73s th2
function llm:div
scoreboard players operation yb llm = 73b th
scoreboard players operation ye llm = 73e th
scoreboard players operation ys llm = 73s th
function llm:mul
scoreboard players operation 73b th = xb llm
scoreboard players operation 73e th = xe llm
scoreboard players operation 73s th = xs llm
scoreboard players operation xb llm = 74b th
scoreboard players operation xe llm = 74e th
scoreboard players operation xs llm = 74s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 74b th2
scoreboard players operation xe llm = 74e th2
scoreboard players operation xs llm = 74s th2
function llm:div
scoreboard players operation yb llm = 74b th
scoreboard players operation ye llm = 74e th
scoreboard players operation ys llm = 74s th
function llm:mul
scoreboard players operation 74b th = xb llm
scoreboard players operation 74e th = xe llm
scoreboard players operation 74s th = xs llm
scoreboard players operation xb llm = 75b th
scoreboard players operation xe llm = 75e th
scoreboard players operation xs llm = 75s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 75b th2
scoreboard players operation xe llm = 75e th2
scoreboard players operation xs llm = 75s th2
function llm:div
scoreboard players operation yb llm = 75b th
scoreboard players operation ye llm = 75e th
scoreboard players operation ys llm = 75s th
function llm:mul
scoreboard players operation 75b th = xb llm
scoreboard players operation 75e th = xe llm
scoreboard players operation 75s th = xs llm
scoreboard players operation xb llm = 76b th
scoreboard players operation xe llm = 76e th
scoreboard players operation xs llm = 76s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 76b th2
scoreboard players operation xe llm = 76e th2
scoreboard players operation xs llm = 76s th2
function llm:div
scoreboard players operation yb llm = 76b th
scoreboard players operation ye llm = 76e th
scoreboard players operation ys llm = 76s th
function llm:mul
scoreboard players operation 76b th = xb llm
scoreboard players operation 76e th = xe llm
scoreboard players operation 76s th = xs llm
scoreboard players operation xb llm = 77b th
scoreboard players operation xe llm = 77e th
scoreboard players operation xs llm = 77s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 77b th2
scoreboard players operation xe llm = 77e th2
scoreboard players operation xs llm = 77s th2
function llm:div
scoreboard players operation yb llm = 77b th
scoreboard players operation ye llm = 77e th
scoreboard players operation ys llm = 77s th
function llm:mul
scoreboard players operation 77b th = xb llm
scoreboard players operation 77e th = xe llm
scoreboard players operation 77s th = xs llm
scoreboard players operation xb llm = 78b th
scoreboard players operation xe llm = 78e th
scoreboard players operation xs llm = 78s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 78b th2
scoreboard players operation xe llm = 78e th2
scoreboard players operation xs llm = 78s th2
function llm:div
scoreboard players operation yb llm = 78b th
scoreboard players operation ye llm = 78e th
scoreboard players operation ys llm = 78s th
function llm:mul
scoreboard players operation 78b th = xb llm
scoreboard players operation 78e th = xe llm
scoreboard players operation 78s th = xs llm
scoreboard players operation xb llm = 79b th
scoreboard players operation xe llm = 79e th
scoreboard players operation xs llm = 79s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 79b th2
scoreboard players operation xe llm = 79e th2
scoreboard players operation xs llm = 79s th2
function llm:div
scoreboard players operation yb llm = 79b th
scoreboard players operation ye llm = 79e th
scoreboard players operation ys llm = 79s th
function llm:mul
scoreboard players operation 79b th = xb llm
scoreboard players operation 79e th = xe llm
scoreboard players operation 79s th = xs llm
scoreboard players operation xb llm = 80b th
scoreboard players operation xe llm = 80e th
scoreboard players operation xs llm = 80s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 80b th2
scoreboard players operation xe llm = 80e th2
scoreboard players operation xs llm = 80s th2
function llm:div
scoreboard players operation yb llm = 80b th
scoreboard players operation ye llm = 80e th
scoreboard players operation ys llm = 80s th
function llm:mul
scoreboard players operation 80b th = xb llm
scoreboard players operation 80e th = xe llm
scoreboard players operation 80s th = xs llm
scoreboard players operation xb llm = 81b th
scoreboard players operation xe llm = 81e th
scoreboard players operation xs llm = 81s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 81b th2
scoreboard players operation xe llm = 81e th2
scoreboard players operation xs llm = 81s th2
function llm:div
scoreboard players operation yb llm = 81b th
scoreboard players operation ye llm = 81e th
scoreboard players operation ys llm = 81s th
function llm:mul
scoreboard players operation 81b th = xb llm
scoreboard players operation 81e th = xe llm
scoreboard players operation 81s th = xs llm
scoreboard players operation xb llm = 82b th
scoreboard players operation xe llm = 82e th
scoreboard players operation xs llm = 82s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 82b th2
scoreboard players operation xe llm = 82e th2
scoreboard players operation xs llm = 82s th2
function llm:div
scoreboard players operation yb llm = 82b th
scoreboard players operation ye llm = 82e th
scoreboard players operation ys llm = 82s th
function llm:mul
scoreboard players operation 82b th = xb llm
scoreboard players operation 82e th = xe llm
scoreboard players operation 82s th = xs llm
scoreboard players operation xb llm = 83b th
scoreboard players operation xe llm = 83e th
scoreboard players operation xs llm = 83s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 83b th2
scoreboard players operation xe llm = 83e th2
scoreboard players operation xs llm = 83s th2
function llm:div
scoreboard players operation yb llm = 83b th
scoreboard players operation ye llm = 83e th
scoreboard players operation ys llm = 83s th
function llm:mul
scoreboard players operation 83b th = xb llm
scoreboard players operation 83e th = xe llm
scoreboard players operation 83s th = xs llm
scoreboard players operation xb llm = 84b th
scoreboard players operation xe llm = 84e th
scoreboard players operation xs llm = 84s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 84b th2
scoreboard players operation xe llm = 84e th2
scoreboard players operation xs llm = 84s th2
function llm:div
scoreboard players operation yb llm = 84b th
scoreboard players operation ye llm = 84e th
scoreboard players operation ys llm = 84s th
function llm:mul
scoreboard players operation 84b th = xb llm
scoreboard players operation 84e th = xe llm
scoreboard players operation 84s th = xs llm
scoreboard players operation xb llm = 85b th
scoreboard players operation xe llm = 85e th
scoreboard players operation xs llm = 85s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 85b th2
scoreboard players operation xe llm = 85e th2
scoreboard players operation xs llm = 85s th2
function llm:div
scoreboard players operation yb llm = 85b th
scoreboard players operation ye llm = 85e th
scoreboard players operation ys llm = 85s th
function llm:mul
scoreboard players operation 85b th = xb llm
scoreboard players operation 85e th = xe llm
scoreboard players operation 85s th = xs llm
scoreboard players operation xb llm = 86b th
scoreboard players operation xe llm = 86e th
scoreboard players operation xs llm = 86s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 86b th2
scoreboard players operation xe llm = 86e th2
scoreboard players operation xs llm = 86s th2
function llm:div
scoreboard players operation yb llm = 86b th
scoreboard players operation ye llm = 86e th
scoreboard players operation ys llm = 86s th
function llm:mul
scoreboard players operation 86b th = xb llm
scoreboard players operation 86e th = xe llm
scoreboard players operation 86s th = xs llm
scoreboard players operation xb llm = 87b th
scoreboard players operation xe llm = 87e th
scoreboard players operation xs llm = 87s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 87b th2
scoreboard players operation xe llm = 87e th2
scoreboard players operation xs llm = 87s th2
function llm:div
scoreboard players operation yb llm = 87b th
scoreboard players operation ye llm = 87e th
scoreboard players operation ys llm = 87s th
function llm:mul
scoreboard players operation 87b th = xb llm
scoreboard players operation 87e th = xe llm
scoreboard players operation 87s th = xs llm
scoreboard players operation xb llm = 88b th
scoreboard players operation xe llm = 88e th
scoreboard players operation xs llm = 88s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 88b th2
scoreboard players operation xe llm = 88e th2
scoreboard players operation xs llm = 88s th2
function llm:div
scoreboard players operation yb llm = 88b th
scoreboard players operation ye llm = 88e th
scoreboard players operation ys llm = 88s th
function llm:mul
scoreboard players operation 88b th = xb llm
scoreboard players operation 88e th = xe llm
scoreboard players operation 88s th = xs llm
scoreboard players operation xb llm = 89b th
scoreboard players operation xe llm = 89e th
scoreboard players operation xs llm = 89s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 89b th2
scoreboard players operation xe llm = 89e th2
scoreboard players operation xs llm = 89s th2
function llm:div
scoreboard players operation yb llm = 89b th
scoreboard players operation ye llm = 89e th
scoreboard players operation ys llm = 89s th
function llm:mul
scoreboard players operation 89b th = xb llm
scoreboard players operation 89e th = xe llm
scoreboard players operation 89s th = xs llm
scoreboard players operation xb llm = 90b th
scoreboard players operation xe llm = 90e th
scoreboard players operation xs llm = 90s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 90b th2
scoreboard players operation xe llm = 90e th2
scoreboard players operation xs llm = 90s th2
function llm:div
scoreboard players operation yb llm = 90b th
scoreboard players operation ye llm = 90e th
scoreboard players operation ys llm = 90s th
function llm:mul
scoreboard players operation 90b th = xb llm
scoreboard players operation 90e th = xe llm
scoreboard players operation 90s th = xs llm
scoreboard players operation xb llm = 91b th
scoreboard players operation xe llm = 91e th
scoreboard players operation xs llm = 91s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 91b th2
scoreboard players operation xe llm = 91e th2
scoreboard players operation xs llm = 91s th2
function llm:div
scoreboard players operation yb llm = 91b th
scoreboard players operation ye llm = 91e th
scoreboard players operation ys llm = 91s th
function llm:mul
scoreboard players operation 91b th = xb llm
scoreboard players operation 91e th = xe llm
scoreboard players operation 91s th = xs llm
scoreboard players operation xb llm = 92b th
scoreboard players operation xe llm = 92e th
scoreboard players operation xs llm = 92s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 92b th2
scoreboard players operation xe llm = 92e th2
scoreboard players operation xs llm = 92s th2
function llm:div
scoreboard players operation yb llm = 92b th
scoreboard players operation ye llm = 92e th
scoreboard players operation ys llm = 92s th
function llm:mul
scoreboard players operation 92b th = xb llm
scoreboard players operation 92e th = xe llm
scoreboard players operation 92s th = xs llm
scoreboard players operation xb llm = 93b th
scoreboard players operation xe llm = 93e th
scoreboard players operation xs llm = 93s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 93b th2
scoreboard players operation xe llm = 93e th2
scoreboard players operation xs llm = 93s th2
function llm:div
scoreboard players operation yb llm = 93b th
scoreboard players operation ye llm = 93e th
scoreboard players operation ys llm = 93s th
function llm:mul
scoreboard players operation 93b th = xb llm
scoreboard players operation 93e th = xe llm
scoreboard players operation 93s th = xs llm
scoreboard players operation xb llm = 94b th
scoreboard players operation xe llm = 94e th
scoreboard players operation xs llm = 94s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 94b th2
scoreboard players operation xe llm = 94e th2
scoreboard players operation xs llm = 94s th2
function llm:div
scoreboard players operation yb llm = 94b th
scoreboard players operation ye llm = 94e th
scoreboard players operation ys llm = 94s th
function llm:mul
scoreboard players operation 94b th = xb llm
scoreboard players operation 94e th = xe llm
scoreboard players operation 94s th = xs llm
scoreboard players operation xb llm = 95b th
scoreboard players operation xe llm = 95e th
scoreboard players operation xs llm = 95s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 95b th2
scoreboard players operation xe llm = 95e th2
scoreboard players operation xs llm = 95s th2
function llm:div
scoreboard players operation yb llm = 95b th
scoreboard players operation ye llm = 95e th
scoreboard players operation ys llm = 95s th
function llm:mul
scoreboard players operation 95b th = xb llm
scoreboard players operation 95e th = xe llm
scoreboard players operation 95s th = xs llm
scoreboard players operation xb llm = 96b th
scoreboard players operation xe llm = 96e th
scoreboard players operation xs llm = 96s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 96b th2
scoreboard players operation xe llm = 96e th2
scoreboard players operation xs llm = 96s th2
function llm:div
scoreboard players operation yb llm = 96b th
scoreboard players operation ye llm = 96e th
scoreboard players operation ys llm = 96s th
function llm:mul
scoreboard players operation 96b th = xb llm
scoreboard players operation 96e th = xe llm
scoreboard players operation 96s th = xs llm
scoreboard players operation xb llm = 97b th
scoreboard players operation xe llm = 97e th
scoreboard players operation xs llm = 97s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 97b th2
scoreboard players operation xe llm = 97e th2
scoreboard players operation xs llm = 97s th2
function llm:div
scoreboard players operation yb llm = 97b th
scoreboard players operation ye llm = 97e th
scoreboard players operation ys llm = 97s th
function llm:mul
scoreboard players operation 97b th = xb llm
scoreboard players operation 97e th = xe llm
scoreboard players operation 97s th = xs llm
scoreboard players operation xb llm = 98b th
scoreboard players operation xe llm = 98e th
scoreboard players operation xs llm = 98s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 98b th2
scoreboard players operation xe llm = 98e th2
scoreboard players operation xs llm = 98s th2
function llm:div
scoreboard players operation yb llm = 98b th
scoreboard players operation ye llm = 98e th
scoreboard players operation ys llm = 98s th
function llm:mul
scoreboard players operation 98b th = xb llm
scoreboard players operation 98e th = xe llm
scoreboard players operation 98s th = xs llm
scoreboard players operation xb llm = 99b th
scoreboard players operation xe llm = 99e th
scoreboard players operation xs llm = 99s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 99b th2
scoreboard players operation xe llm = 99e th2
scoreboard players operation xs llm = 99s th2
function llm:div
scoreboard players operation yb llm = 99b th
scoreboard players operation ye llm = 99e th
scoreboard players operation ys llm = 99s th
function llm:mul
scoreboard players operation 99b th = xb llm
scoreboard players operation 99e th = xe llm
scoreboard players operation 99s th = xs llm
scoreboard players operation xb llm = 100b th
scoreboard players operation xe llm = 100e th
scoreboard players operation xs llm = 100s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 100b th2
scoreboard players operation xe llm = 100e th2
scoreboard players operation xs llm = 100s th2
function llm:div
scoreboard players operation yb llm = 100b th
scoreboard players operation ye llm = 100e th
scoreboard players operation ys llm = 100s th
function llm:mul
scoreboard players operation 100b th = xb llm
scoreboard players operation 100e th = xe llm
scoreboard players operation 100s th = xs llm
scoreboard players operation xb llm = 101b th
scoreboard players operation xe llm = 101e th
scoreboard players operation xs llm = 101s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 101b th2
scoreboard players operation xe llm = 101e th2
scoreboard players operation xs llm = 101s th2
function llm:div
scoreboard players operation yb llm = 101b th
scoreboard players operation ye llm = 101e th
scoreboard players operation ys llm = 101s th
function llm:mul
scoreboard players operation 101b th = xb llm
scoreboard players operation 101e th = xe llm
scoreboard players operation 101s th = xs llm
scoreboard players operation xb llm = 102b th
scoreboard players operation xe llm = 102e th
scoreboard players operation xs llm = 102s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 102b th2
scoreboard players operation xe llm = 102e th2
scoreboard players operation xs llm = 102s th2
function llm:div
scoreboard players operation yb llm = 102b th
scoreboard players operation ye llm = 102e th
scoreboard players operation ys llm = 102s th
function llm:mul
scoreboard players operation 102b th = xb llm
scoreboard players operation 102e th = xe llm
scoreboard players operation 102s th = xs llm
scoreboard players operation xb llm = 103b th
scoreboard players operation xe llm = 103e th
scoreboard players operation xs llm = 103s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 103b th2
scoreboard players operation xe llm = 103e th2
scoreboard players operation xs llm = 103s th2
function llm:div
scoreboard players operation yb llm = 103b th
scoreboard players operation ye llm = 103e th
scoreboard players operation ys llm = 103s th
function llm:mul
scoreboard players operation 103b th = xb llm
scoreboard players operation 103e th = xe llm
scoreboard players operation 103s th = xs llm
scoreboard players operation xb llm = 104b th
scoreboard players operation xe llm = 104e th
scoreboard players operation xs llm = 104s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 104b th2
scoreboard players operation xe llm = 104e th2
scoreboard players operation xs llm = 104s th2
function llm:div
scoreboard players operation yb llm = 104b th
scoreboard players operation ye llm = 104e th
scoreboard players operation ys llm = 104s th
function llm:mul
scoreboard players operation 104b th = xb llm
scoreboard players operation 104e th = xe llm
scoreboard players operation 104s th = xs llm
scoreboard players operation xb llm = 105b th
scoreboard players operation xe llm = 105e th
scoreboard players operation xs llm = 105s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 105b th2
scoreboard players operation xe llm = 105e th2
scoreboard players operation xs llm = 105s th2
function llm:div
scoreboard players operation yb llm = 105b th
scoreboard players operation ye llm = 105e th
scoreboard players operation ys llm = 105s th
function llm:mul
scoreboard players operation 105b th = xb llm
scoreboard players operation 105e th = xe llm
scoreboard players operation 105s th = xs llm
scoreboard players operation xb llm = 106b th
scoreboard players operation xe llm = 106e th
scoreboard players operation xs llm = 106s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 106b th2
scoreboard players operation xe llm = 106e th2
scoreboard players operation xs llm = 106s th2
function llm:div
scoreboard players operation yb llm = 106b th
scoreboard players operation ye llm = 106e th
scoreboard players operation ys llm = 106s th
function llm:mul
scoreboard players operation 106b th = xb llm
scoreboard players operation 106e th = xe llm
scoreboard players operation 106s th = xs llm
scoreboard players operation xb llm = 107b th
scoreboard players operation xe llm = 107e th
scoreboard players operation xs llm = 107s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 107b th2
scoreboard players operation xe llm = 107e th2
scoreboard players operation xs llm = 107s th2
function llm:div
scoreboard players operation yb llm = 107b th
scoreboard players operation ye llm = 107e th
scoreboard players operation ys llm = 107s th
function llm:mul
scoreboard players operation 107b th = xb llm
scoreboard players operation 107e th = xe llm
scoreboard players operation 107s th = xs llm
scoreboard players operation xb llm = 108b th
scoreboard players operation xe llm = 108e th
scoreboard players operation xs llm = 108s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 108b th2
scoreboard players operation xe llm = 108e th2
scoreboard players operation xs llm = 108s th2
function llm:div
scoreboard players operation yb llm = 108b th
scoreboard players operation ye llm = 108e th
scoreboard players operation ys llm = 108s th
function llm:mul
scoreboard players operation 108b th = xb llm
scoreboard players operation 108e th = xe llm
scoreboard players operation 108s th = xs llm
scoreboard players operation xb llm = 109b th
scoreboard players operation xe llm = 109e th
scoreboard players operation xs llm = 109s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 109b th2
scoreboard players operation xe llm = 109e th2
scoreboard players operation xs llm = 109s th2
function llm:div
scoreboard players operation yb llm = 109b th
scoreboard players operation ye llm = 109e th
scoreboard players operation ys llm = 109s th
function llm:mul
scoreboard players operation 109b th = xb llm
scoreboard players operation 109e th = xe llm
scoreboard players operation 109s th = xs llm
scoreboard players operation xb llm = 110b th
scoreboard players operation xe llm = 110e th
scoreboard players operation xs llm = 110s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 110b th2
scoreboard players operation xe llm = 110e th2
scoreboard players operation xs llm = 110s th2
function llm:div
scoreboard players operation yb llm = 110b th
scoreboard players operation ye llm = 110e th
scoreboard players operation ys llm = 110s th
function llm:mul
scoreboard players operation 110b th = xb llm
scoreboard players operation 110e th = xe llm
scoreboard players operation 110s th = xs llm
scoreboard players operation xb llm = 111b th
scoreboard players operation xe llm = 111e th
scoreboard players operation xs llm = 111s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 111b th2
scoreboard players operation xe llm = 111e th2
scoreboard players operation xs llm = 111s th2
function llm:div
scoreboard players operation yb llm = 111b th
scoreboard players operation ye llm = 111e th
scoreboard players operation ys llm = 111s th
function llm:mul
scoreboard players operation 111b th = xb llm
scoreboard players operation 111e th = xe llm
scoreboard players operation 111s th = xs llm
scoreboard players operation xb llm = 112b th
scoreboard players operation xe llm = 112e th
scoreboard players operation xs llm = 112s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 112b th2
scoreboard players operation xe llm = 112e th2
scoreboard players operation xs llm = 112s th2
function llm:div
scoreboard players operation yb llm = 112b th
scoreboard players operation ye llm = 112e th
scoreboard players operation ys llm = 112s th
function llm:mul
scoreboard players operation 112b th = xb llm
scoreboard players operation 112e th = xe llm
scoreboard players operation 112s th = xs llm
scoreboard players operation xb llm = 113b th
scoreboard players operation xe llm = 113e th
scoreboard players operation xs llm = 113s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 113b th2
scoreboard players operation xe llm = 113e th2
scoreboard players operation xs llm = 113s th2
function llm:div
scoreboard players operation yb llm = 113b th
scoreboard players operation ye llm = 113e th
scoreboard players operation ys llm = 113s th
function llm:mul
scoreboard players operation 113b th = xb llm
scoreboard players operation 113e th = xe llm
scoreboard players operation 113s th = xs llm
scoreboard players operation xb llm = 114b th
scoreboard players operation xe llm = 114e th
scoreboard players operation xs llm = 114s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 114b th2
scoreboard players operation xe llm = 114e th2
scoreboard players operation xs llm = 114s th2
function llm:div
scoreboard players operation yb llm = 114b th
scoreboard players operation ye llm = 114e th
scoreboard players operation ys llm = 114s th
function llm:mul
scoreboard players operation 114b th = xb llm
scoreboard players operation 114e th = xe llm
scoreboard players operation 114s th = xs llm
scoreboard players operation xb llm = 115b th
scoreboard players operation xe llm = 115e th
scoreboard players operation xs llm = 115s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 115b th2
scoreboard players operation xe llm = 115e th2
scoreboard players operation xs llm = 115s th2
function llm:div
scoreboard players operation yb llm = 115b th
scoreboard players operation ye llm = 115e th
scoreboard players operation ys llm = 115s th
function llm:mul
scoreboard players operation 115b th = xb llm
scoreboard players operation 115e th = xe llm
scoreboard players operation 115s th = xs llm
scoreboard players operation xb llm = 116b th
scoreboard players operation xe llm = 116e th
scoreboard players operation xs llm = 116s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 116b th2
scoreboard players operation xe llm = 116e th2
scoreboard players operation xs llm = 116s th2
function llm:div
scoreboard players operation yb llm = 116b th
scoreboard players operation ye llm = 116e th
scoreboard players operation ys llm = 116s th
function llm:mul
scoreboard players operation 116b th = xb llm
scoreboard players operation 116e th = xe llm
scoreboard players operation 116s th = xs llm
scoreboard players operation xb llm = 117b th
scoreboard players operation xe llm = 117e th
scoreboard players operation xs llm = 117s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 117b th2
scoreboard players operation xe llm = 117e th2
scoreboard players operation xs llm = 117s th2
function llm:div
scoreboard players operation yb llm = 117b th
scoreboard players operation ye llm = 117e th
scoreboard players operation ys llm = 117s th
function llm:mul
scoreboard players operation 117b th = xb llm
scoreboard players operation 117e th = xe llm
scoreboard players operation 117s th = xs llm
scoreboard players operation xb llm = 118b th
scoreboard players operation xe llm = 118e th
scoreboard players operation xs llm = 118s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 118b th2
scoreboard players operation xe llm = 118e th2
scoreboard players operation xs llm = 118s th2
function llm:div
scoreboard players operation yb llm = 118b th
scoreboard players operation ye llm = 118e th
scoreboard players operation ys llm = 118s th
function llm:mul
scoreboard players operation 118b th = xb llm
scoreboard players operation 118e th = xe llm
scoreboard players operation 118s th = xs llm
scoreboard players operation xb llm = 119b th
scoreboard players operation xe llm = 119e th
scoreboard players operation xs llm = 119s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 119b th2
scoreboard players operation xe llm = 119e th2
scoreboard players operation xs llm = 119s th2
function llm:div
scoreboard players operation yb llm = 119b th
scoreboard players operation ye llm = 119e th
scoreboard players operation ys llm = 119s th
function llm:mul
scoreboard players operation 119b th = xb llm
scoreboard players operation 119e th = xe llm
scoreboard players operation 119s th = xs llm
scoreboard players operation xb llm = 120b th
scoreboard players operation xe llm = 120e th
scoreboard players operation xs llm = 120s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 120b th2
scoreboard players operation xe llm = 120e th2
scoreboard players operation xs llm = 120s th2
function llm:div
scoreboard players operation yb llm = 120b th
scoreboard players operation ye llm = 120e th
scoreboard players operation ys llm = 120s th
function llm:mul
scoreboard players operation 120b th = xb llm
scoreboard players operation 120e th = xe llm
scoreboard players operation 120s th = xs llm
scoreboard players operation xb llm = 121b th
scoreboard players operation xe llm = 121e th
scoreboard players operation xs llm = 121s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 121b th2
scoreboard players operation xe llm = 121e th2
scoreboard players operation xs llm = 121s th2
function llm:div
scoreboard players operation yb llm = 121b th
scoreboard players operation ye llm = 121e th
scoreboard players operation ys llm = 121s th
function llm:mul
scoreboard players operation 121b th = xb llm
scoreboard players operation 121e th = xe llm
scoreboard players operation 121s th = xs llm
scoreboard players operation xb llm = 122b th
scoreboard players operation xe llm = 122e th
scoreboard players operation xs llm = 122s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 122b th2
scoreboard players operation xe llm = 122e th2
scoreboard players operation xs llm = 122s th2
function llm:div
scoreboard players operation yb llm = 122b th
scoreboard players operation ye llm = 122e th
scoreboard players operation ys llm = 122s th
function llm:mul
scoreboard players operation 122b th = xb llm
scoreboard players operation 122e th = xe llm
scoreboard players operation 122s th = xs llm
scoreboard players operation xb llm = 123b th
scoreboard players operation xe llm = 123e th
scoreboard players operation xs llm = 123s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 123b th2
scoreboard players operation xe llm = 123e th2
scoreboard players operation xs llm = 123s th2
function llm:div
scoreboard players operation yb llm = 123b th
scoreboard players operation ye llm = 123e th
scoreboard players operation ys llm = 123s th
function llm:mul
scoreboard players operation 123b th = xb llm
scoreboard players operation 123e th = xe llm
scoreboard players operation 123s th = xs llm
scoreboard players operation xb llm = 124b th
scoreboard players operation xe llm = 124e th
scoreboard players operation xs llm = 124s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 124b th2
scoreboard players operation xe llm = 124e th2
scoreboard players operation xs llm = 124s th2
function llm:div
scoreboard players operation yb llm = 124b th
scoreboard players operation ye llm = 124e th
scoreboard players operation ys llm = 124s th
function llm:mul
scoreboard players operation 124b th = xb llm
scoreboard players operation 124e th = xe llm
scoreboard players operation 124s th = xs llm
scoreboard players operation xb llm = 125b th
scoreboard players operation xe llm = 125e th
scoreboard players operation xs llm = 125s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 125b th2
scoreboard players operation xe llm = 125e th2
scoreboard players operation xs llm = 125s th2
function llm:div
scoreboard players operation yb llm = 125b th
scoreboard players operation ye llm = 125e th
scoreboard players operation ys llm = 125s th
function llm:mul
scoreboard players operation 125b th = xb llm
scoreboard players operation 125e th = xe llm
scoreboard players operation 125s th = xs llm
scoreboard players operation xb llm = 126b th
scoreboard players operation xe llm = 126e th
scoreboard players operation xs llm = 126s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 126b th2
scoreboard players operation xe llm = 126e th2
scoreboard players operation xs llm = 126s th2
function llm:div
scoreboard players operation yb llm = 126b th
scoreboard players operation ye llm = 126e th
scoreboard players operation ys llm = 126s th
function llm:mul
scoreboard players operation 126b th = xb llm
scoreboard players operation 126e th = xe llm
scoreboard players operation 126s th = xs llm
scoreboard players operation xb llm = 127b th
scoreboard players operation xe llm = 127e th
scoreboard players operation xs llm = 127s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 127b th2
scoreboard players operation xe llm = 127e th2
scoreboard players operation xs llm = 127s th2
function llm:div
scoreboard players operation yb llm = 127b th
scoreboard players operation ye llm = 127e th
scoreboard players operation ys llm = 127s th
function llm:mul
scoreboard players operation 127b th = xb llm
scoreboard players operation 127e th = xe llm
scoreboard players operation 127s th = xs llm
scoreboard players operation xb llm = 128b th
scoreboard players operation xe llm = 128e th
scoreboard players operation xs llm = 128s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 128b th2
scoreboard players operation xe llm = 128e th2
scoreboard players operation xs llm = 128s th2
function llm:div
scoreboard players operation yb llm = 128b th
scoreboard players operation ye llm = 128e th
scoreboard players operation ys llm = 128s th
function llm:mul
scoreboard players operation 128b th = xb llm
scoreboard players operation 128e th = xe llm
scoreboard players operation 128s th = xs llm
scoreboard players operation xb llm = 129b th
scoreboard players operation xe llm = 129e th
scoreboard players operation xs llm = 129s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 129b th2
scoreboard players operation xe llm = 129e th2
scoreboard players operation xs llm = 129s th2
function llm:div
scoreboard players operation yb llm = 129b th
scoreboard players operation ye llm = 129e th
scoreboard players operation ys llm = 129s th
function llm:mul
scoreboard players operation 129b th = xb llm
scoreboard players operation 129e th = xe llm
scoreboard players operation 129s th = xs llm
scoreboard players operation xb llm = 130b th
scoreboard players operation xe llm = 130e th
scoreboard players operation xs llm = 130s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 130b th2
scoreboard players operation xe llm = 130e th2
scoreboard players operation xs llm = 130s th2
function llm:div
scoreboard players operation yb llm = 130b th
scoreboard players operation ye llm = 130e th
scoreboard players operation ys llm = 130s th
function llm:mul
scoreboard players operation 130b th = xb llm
scoreboard players operation 130e th = xe llm
scoreboard players operation 130s th = xs llm
scoreboard players operation xb llm = 131b th
scoreboard players operation xe llm = 131e th
scoreboard players operation xs llm = 131s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 131b th2
scoreboard players operation xe llm = 131e th2
scoreboard players operation xs llm = 131s th2
function llm:div
scoreboard players operation yb llm = 131b th
scoreboard players operation ye llm = 131e th
scoreboard players operation ys llm = 131s th
function llm:mul
scoreboard players operation 131b th = xb llm
scoreboard players operation 131e th = xe llm
scoreboard players operation 131s th = xs llm
scoreboard players operation xb llm = 132b th
scoreboard players operation xe llm = 132e th
scoreboard players operation xs llm = 132s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 132b th2
scoreboard players operation xe llm = 132e th2
scoreboard players operation xs llm = 132s th2
function llm:div
scoreboard players operation yb llm = 132b th
scoreboard players operation ye llm = 132e th
scoreboard players operation ys llm = 132s th
function llm:mul
scoreboard players operation 132b th = xb llm
scoreboard players operation 132e th = xe llm
scoreboard players operation 132s th = xs llm
scoreboard players operation xb llm = 133b th
scoreboard players operation xe llm = 133e th
scoreboard players operation xs llm = 133s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 133b th2
scoreboard players operation xe llm = 133e th2
scoreboard players operation xs llm = 133s th2
function llm:div
scoreboard players operation yb llm = 133b th
scoreboard players operation ye llm = 133e th
scoreboard players operation ys llm = 133s th
function llm:mul
scoreboard players operation 133b th = xb llm
scoreboard players operation 133e th = xe llm
scoreboard players operation 133s th = xs llm
scoreboard players operation xb llm = 134b th
scoreboard players operation xe llm = 134e th
scoreboard players operation xs llm = 134s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 134b th2
scoreboard players operation xe llm = 134e th2
scoreboard players operation xs llm = 134s th2
function llm:div
scoreboard players operation yb llm = 134b th
scoreboard players operation ye llm = 134e th
scoreboard players operation ys llm = 134s th
function llm:mul
scoreboard players operation 134b th = xb llm
scoreboard players operation 134e th = xe llm
scoreboard players operation 134s th = xs llm
scoreboard players operation xb llm = 135b th
scoreboard players operation xe llm = 135e th
scoreboard players operation xs llm = 135s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 135b th2
scoreboard players operation xe llm = 135e th2
scoreboard players operation xs llm = 135s th2
function llm:div
scoreboard players operation yb llm = 135b th
scoreboard players operation ye llm = 135e th
scoreboard players operation ys llm = 135s th
function llm:mul
scoreboard players operation 135b th = xb llm
scoreboard players operation 135e th = xe llm
scoreboard players operation 135s th = xs llm
scoreboard players operation xb llm = 136b th
scoreboard players operation xe llm = 136e th
scoreboard players operation xs llm = 136s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 136b th2
scoreboard players operation xe llm = 136e th2
scoreboard players operation xs llm = 136s th2
function llm:div
scoreboard players operation yb llm = 136b th
scoreboard players operation ye llm = 136e th
scoreboard players operation ys llm = 136s th
function llm:mul
scoreboard players operation 136b th = xb llm
scoreboard players operation 136e th = xe llm
scoreboard players operation 136s th = xs llm
scoreboard players operation xb llm = 137b th
scoreboard players operation xe llm = 137e th
scoreboard players operation xs llm = 137s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 137b th2
scoreboard players operation xe llm = 137e th2
scoreboard players operation xs llm = 137s th2
function llm:div
scoreboard players operation yb llm = 137b th
scoreboard players operation ye llm = 137e th
scoreboard players operation ys llm = 137s th
function llm:mul
scoreboard players operation 137b th = xb llm
scoreboard players operation 137e th = xe llm
scoreboard players operation 137s th = xs llm
scoreboard players operation xb llm = 138b th
scoreboard players operation xe llm = 138e th
scoreboard players operation xs llm = 138s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 138b th2
scoreboard players operation xe llm = 138e th2
scoreboard players operation xs llm = 138s th2
function llm:div
scoreboard players operation yb llm = 138b th
scoreboard players operation ye llm = 138e th
scoreboard players operation ys llm = 138s th
function llm:mul
scoreboard players operation 138b th = xb llm
scoreboard players operation 138e th = xe llm
scoreboard players operation 138s th = xs llm
scoreboard players operation xb llm = 139b th
scoreboard players operation xe llm = 139e th
scoreboard players operation xs llm = 139s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 139b th2
scoreboard players operation xe llm = 139e th2
scoreboard players operation xs llm = 139s th2
function llm:div
scoreboard players operation yb llm = 139b th
scoreboard players operation ye llm = 139e th
scoreboard players operation ys llm = 139s th
function llm:mul
scoreboard players operation 139b th = xb llm
scoreboard players operation 139e th = xe llm
scoreboard players operation 139s th = xs llm
scoreboard players operation xb llm = 140b th
scoreboard players operation xe llm = 140e th
scoreboard players operation xs llm = 140s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 140b th2
scoreboard players operation xe llm = 140e th2
scoreboard players operation xs llm = 140s th2
function llm:div
scoreboard players operation yb llm = 140b th
scoreboard players operation ye llm = 140e th
scoreboard players operation ys llm = 140s th
function llm:mul
scoreboard players operation 140b th = xb llm
scoreboard players operation 140e th = xe llm
scoreboard players operation 140s th = xs llm
scoreboard players operation xb llm = 141b th
scoreboard players operation xe llm = 141e th
scoreboard players operation xs llm = 141s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 141b th2
scoreboard players operation xe llm = 141e th2
scoreboard players operation xs llm = 141s th2
function llm:div
scoreboard players operation yb llm = 141b th
scoreboard players operation ye llm = 141e th
scoreboard players operation ys llm = 141s th
function llm:mul
scoreboard players operation 141b th = xb llm
scoreboard players operation 141e th = xe llm
scoreboard players operation 141s th = xs llm
scoreboard players operation xb llm = 142b th
scoreboard players operation xe llm = 142e th
scoreboard players operation xs llm = 142s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 142b th2
scoreboard players operation xe llm = 142e th2
scoreboard players operation xs llm = 142s th2
function llm:div
scoreboard players operation yb llm = 142b th
scoreboard players operation ye llm = 142e th
scoreboard players operation ys llm = 142s th
function llm:mul
scoreboard players operation 142b th = xb llm
scoreboard players operation 142e th = xe llm
scoreboard players operation 142s th = xs llm
scoreboard players operation xb llm = 143b th
scoreboard players operation xe llm = 143e th
scoreboard players operation xs llm = 143s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 143b th2
scoreboard players operation xe llm = 143e th2
scoreboard players operation xs llm = 143s th2
function llm:div
scoreboard players operation yb llm = 143b th
scoreboard players operation ye llm = 143e th
scoreboard players operation ys llm = 143s th
function llm:mul
scoreboard players operation 143b th = xb llm
scoreboard players operation 143e th = xe llm
scoreboard players operation 143s th = xs llm
scoreboard players operation xb llm = 144b th
scoreboard players operation xe llm = 144e th
scoreboard players operation xs llm = 144s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 144b th2
scoreboard players operation xe llm = 144e th2
scoreboard players operation xs llm = 144s th2
function llm:div
scoreboard players operation yb llm = 144b th
scoreboard players operation ye llm = 144e th
scoreboard players operation ys llm = 144s th
function llm:mul
scoreboard players operation 144b th = xb llm
scoreboard players operation 144e th = xe llm
scoreboard players operation 144s th = xs llm
scoreboard players operation xb llm = 145b th
scoreboard players operation xe llm = 145e th
scoreboard players operation xs llm = 145s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 145b th2
scoreboard players operation xe llm = 145e th2
scoreboard players operation xs llm = 145s th2
function llm:div
scoreboard players operation yb llm = 145b th
scoreboard players operation ye llm = 145e th
scoreboard players operation ys llm = 145s th
function llm:mul
scoreboard players operation 145b th = xb llm
scoreboard players operation 145e th = xe llm
scoreboard players operation 145s th = xs llm
scoreboard players operation xb llm = 146b th
scoreboard players operation xe llm = 146e th
scoreboard players operation xs llm = 146s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 146b th2
scoreboard players operation xe llm = 146e th2
scoreboard players operation xs llm = 146s th2
function llm:div
scoreboard players operation yb llm = 146b th
scoreboard players operation ye llm = 146e th
scoreboard players operation ys llm = 146s th
function llm:mul
scoreboard players operation 146b th = xb llm
scoreboard players operation 146e th = xe llm
scoreboard players operation 146s th = xs llm
scoreboard players operation xb llm = 147b th
scoreboard players operation xe llm = 147e th
scoreboard players operation xs llm = 147s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 147b th2
scoreboard players operation xe llm = 147e th2
scoreboard players operation xs llm = 147s th2
function llm:div
scoreboard players operation yb llm = 147b th
scoreboard players operation ye llm = 147e th
scoreboard players operation ys llm = 147s th
function llm:mul
scoreboard players operation 147b th = xb llm
scoreboard players operation 147e th = xe llm
scoreboard players operation 147s th = xs llm
scoreboard players operation xb llm = 148b th
scoreboard players operation xe llm = 148e th
scoreboard players operation xs llm = 148s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 148b th2
scoreboard players operation xe llm = 148e th2
scoreboard players operation xs llm = 148s th2
function llm:div
scoreboard players operation yb llm = 148b th
scoreboard players operation ye llm = 148e th
scoreboard players operation ys llm = 148s th
function llm:mul
scoreboard players operation 148b th = xb llm
scoreboard players operation 148e th = xe llm
scoreboard players operation 148s th = xs llm
scoreboard players operation xb llm = 149b th
scoreboard players operation xe llm = 149e th
scoreboard players operation xs llm = 149s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 149b th2
scoreboard players operation xe llm = 149e th2
scoreboard players operation xs llm = 149s th2
function llm:div
scoreboard players operation yb llm = 149b th
scoreboard players operation ye llm = 149e th
scoreboard players operation ys llm = 149s th
function llm:mul
scoreboard players operation 149b th = xb llm
scoreboard players operation 149e th = xe llm
scoreboard players operation 149s th = xs llm
scoreboard players operation xb llm = 150b th
scoreboard players operation xe llm = 150e th
scoreboard players operation xs llm = 150s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 150b th2
scoreboard players operation xe llm = 150e th2
scoreboard players operation xs llm = 150s th2
function llm:div
scoreboard players operation yb llm = 150b th
scoreboard players operation ye llm = 150e th
scoreboard players operation ys llm = 150s th
function llm:mul
scoreboard players operation 150b th = xb llm
scoreboard players operation 150e th = xe llm
scoreboard players operation 150s th = xs llm
scoreboard players operation xb llm = 151b th
scoreboard players operation xe llm = 151e th
scoreboard players operation xs llm = 151s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 151b th2
scoreboard players operation xe llm = 151e th2
scoreboard players operation xs llm = 151s th2
function llm:div
scoreboard players operation yb llm = 151b th
scoreboard players operation ye llm = 151e th
scoreboard players operation ys llm = 151s th
function llm:mul
scoreboard players operation 151b th = xb llm
scoreboard players operation 151e th = xe llm
scoreboard players operation 151s th = xs llm
scoreboard players operation xb llm = 152b th
scoreboard players operation xe llm = 152e th
scoreboard players operation xs llm = 152s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 152b th2
scoreboard players operation xe llm = 152e th2
scoreboard players operation xs llm = 152s th2
function llm:div
scoreboard players operation yb llm = 152b th
scoreboard players operation ye llm = 152e th
scoreboard players operation ys llm = 152s th
function llm:mul
scoreboard players operation 152b th = xb llm
scoreboard players operation 152e th = xe llm
scoreboard players operation 152s th = xs llm
scoreboard players operation xb llm = 153b th
scoreboard players operation xe llm = 153e th
scoreboard players operation xs llm = 153s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 153b th2
scoreboard players operation xe llm = 153e th2
scoreboard players operation xs llm = 153s th2
function llm:div
scoreboard players operation yb llm = 153b th
scoreboard players operation ye llm = 153e th
scoreboard players operation ys llm = 153s th
function llm:mul
scoreboard players operation 153b th = xb llm
scoreboard players operation 153e th = xe llm
scoreboard players operation 153s th = xs llm
scoreboard players operation xb llm = 154b th
scoreboard players operation xe llm = 154e th
scoreboard players operation xs llm = 154s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 154b th2
scoreboard players operation xe llm = 154e th2
scoreboard players operation xs llm = 154s th2
function llm:div
scoreboard players operation yb llm = 154b th
scoreboard players operation ye llm = 154e th
scoreboard players operation ys llm = 154s th
function llm:mul
scoreboard players operation 154b th = xb llm
scoreboard players operation 154e th = xe llm
scoreboard players operation 154s th = xs llm
scoreboard players operation xb llm = 155b th
scoreboard players operation xe llm = 155e th
scoreboard players operation xs llm = 155s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 155b th2
scoreboard players operation xe llm = 155e th2
scoreboard players operation xs llm = 155s th2
function llm:div
scoreboard players operation yb llm = 155b th
scoreboard players operation ye llm = 155e th
scoreboard players operation ys llm = 155s th
function llm:mul
scoreboard players operation 155b th = xb llm
scoreboard players operation 155e th = xe llm
scoreboard players operation 155s th = xs llm
scoreboard players operation xb llm = 156b th
scoreboard players operation xe llm = 156e th
scoreboard players operation xs llm = 156s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 156b th2
scoreboard players operation xe llm = 156e th2
scoreboard players operation xs llm = 156s th2
function llm:div
scoreboard players operation yb llm = 156b th
scoreboard players operation ye llm = 156e th
scoreboard players operation ys llm = 156s th
function llm:mul
scoreboard players operation 156b th = xb llm
scoreboard players operation 156e th = xe llm
scoreboard players operation 156s th = xs llm
scoreboard players operation xb llm = 157b th
scoreboard players operation xe llm = 157e th
scoreboard players operation xs llm = 157s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 157b th2
scoreboard players operation xe llm = 157e th2
scoreboard players operation xs llm = 157s th2
function llm:div
scoreboard players operation yb llm = 157b th
scoreboard players operation ye llm = 157e th
scoreboard players operation ys llm = 157s th
function llm:mul
scoreboard players operation 157b th = xb llm
scoreboard players operation 157e th = xe llm
scoreboard players operation 157s th = xs llm
scoreboard players operation xb llm = 158b th
scoreboard players operation xe llm = 158e th
scoreboard players operation xs llm = 158s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 158b th2
scoreboard players operation xe llm = 158e th2
scoreboard players operation xs llm = 158s th2
function llm:div
scoreboard players operation yb llm = 158b th
scoreboard players operation ye llm = 158e th
scoreboard players operation ys llm = 158s th
function llm:mul
scoreboard players operation 158b th = xb llm
scoreboard players operation 158e th = xe llm
scoreboard players operation 158s th = xs llm
scoreboard players operation xb llm = 159b th
scoreboard players operation xe llm = 159e th
scoreboard players operation xs llm = 159s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 159b th2
scoreboard players operation xe llm = 159e th2
scoreboard players operation xs llm = 159s th2
function llm:div
scoreboard players operation yb llm = 159b th
scoreboard players operation ye llm = 159e th
scoreboard players operation ys llm = 159s th
function llm:mul
scoreboard players operation 159b th = xb llm
scoreboard players operation 159e th = xe llm
scoreboard players operation 159s th = xs llm
scoreboard players operation xb llm = 160b th
scoreboard players operation xe llm = 160e th
scoreboard players operation xs llm = 160s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 160b th2
scoreboard players operation xe llm = 160e th2
scoreboard players operation xs llm = 160s th2
function llm:div
scoreboard players operation yb llm = 160b th
scoreboard players operation ye llm = 160e th
scoreboard players operation ys llm = 160s th
function llm:mul
scoreboard players operation 160b th = xb llm
scoreboard players operation 160e th = xe llm
scoreboard players operation 160s th = xs llm
scoreboard players operation xb llm = 161b th
scoreboard players operation xe llm = 161e th
scoreboard players operation xs llm = 161s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 161b th2
scoreboard players operation xe llm = 161e th2
scoreboard players operation xs llm = 161s th2
function llm:div
scoreboard players operation yb llm = 161b th
scoreboard players operation ye llm = 161e th
scoreboard players operation ys llm = 161s th
function llm:mul
scoreboard players operation 161b th = xb llm
scoreboard players operation 161e th = xe llm
scoreboard players operation 161s th = xs llm
scoreboard players operation xb llm = 162b th
scoreboard players operation xe llm = 162e th
scoreboard players operation xs llm = 162s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 162b th2
scoreboard players operation xe llm = 162e th2
scoreboard players operation xs llm = 162s th2
function llm:div
scoreboard players operation yb llm = 162b th
scoreboard players operation ye llm = 162e th
scoreboard players operation ys llm = 162s th
function llm:mul
scoreboard players operation 162b th = xb llm
scoreboard players operation 162e th = xe llm
scoreboard players operation 162s th = xs llm
scoreboard players operation xb llm = 163b th
scoreboard players operation xe llm = 163e th
scoreboard players operation xs llm = 163s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 163b th2
scoreboard players operation xe llm = 163e th2
scoreboard players operation xs llm = 163s th2
function llm:div
scoreboard players operation yb llm = 163b th
scoreboard players operation ye llm = 163e th
scoreboard players operation ys llm = 163s th
function llm:mul
scoreboard players operation 163b th = xb llm
scoreboard players operation 163e th = xe llm
scoreboard players operation 163s th = xs llm
scoreboard players operation xb llm = 164b th
scoreboard players operation xe llm = 164e th
scoreboard players operation xs llm = 164s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 164b th2
scoreboard players operation xe llm = 164e th2
scoreboard players operation xs llm = 164s th2
function llm:div
scoreboard players operation yb llm = 164b th
scoreboard players operation ye llm = 164e th
scoreboard players operation ys llm = 164s th
function llm:mul
scoreboard players operation 164b th = xb llm
scoreboard players operation 164e th = xe llm
scoreboard players operation 164s th = xs llm
scoreboard players operation xb llm = 165b th
scoreboard players operation xe llm = 165e th
scoreboard players operation xs llm = 165s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 165b th2
scoreboard players operation xe llm = 165e th2
scoreboard players operation xs llm = 165s th2
function llm:div
scoreboard players operation yb llm = 165b th
scoreboard players operation ye llm = 165e th
scoreboard players operation ys llm = 165s th
function llm:mul
scoreboard players operation 165b th = xb llm
scoreboard players operation 165e th = xe llm
scoreboard players operation 165s th = xs llm
scoreboard players operation xb llm = 166b th
scoreboard players operation xe llm = 166e th
scoreboard players operation xs llm = 166s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 166b th2
scoreboard players operation xe llm = 166e th2
scoreboard players operation xs llm = 166s th2
function llm:div
scoreboard players operation yb llm = 166b th
scoreboard players operation ye llm = 166e th
scoreboard players operation ys llm = 166s th
function llm:mul
scoreboard players operation 166b th = xb llm
scoreboard players operation 166e th = xe llm
scoreboard players operation 166s th = xs llm
scoreboard players operation xb llm = 167b th
scoreboard players operation xe llm = 167e th
scoreboard players operation xs llm = 167s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 167b th2
scoreboard players operation xe llm = 167e th2
scoreboard players operation xs llm = 167s th2
function llm:div
scoreboard players operation yb llm = 167b th
scoreboard players operation ye llm = 167e th
scoreboard players operation ys llm = 167s th
function llm:mul
scoreboard players operation 167b th = xb llm
scoreboard players operation 167e th = xe llm
scoreboard players operation 167s th = xs llm
scoreboard players operation xb llm = 168b th
scoreboard players operation xe llm = 168e th
scoreboard players operation xs llm = 168s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 168b th2
scoreboard players operation xe llm = 168e th2
scoreboard players operation xs llm = 168s th2
function llm:div
scoreboard players operation yb llm = 168b th
scoreboard players operation ye llm = 168e th
scoreboard players operation ys llm = 168s th
function llm:mul
scoreboard players operation 168b th = xb llm
scoreboard players operation 168e th = xe llm
scoreboard players operation 168s th = xs llm
scoreboard players operation xb llm = 169b th
scoreboard players operation xe llm = 169e th
scoreboard players operation xs llm = 169s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 169b th2
scoreboard players operation xe llm = 169e th2
scoreboard players operation xs llm = 169s th2
function llm:div
scoreboard players operation yb llm = 169b th
scoreboard players operation ye llm = 169e th
scoreboard players operation ys llm = 169s th
function llm:mul
scoreboard players operation 169b th = xb llm
scoreboard players operation 169e th = xe llm
scoreboard players operation 169s th = xs llm
scoreboard players operation xb llm = 170b th
scoreboard players operation xe llm = 170e th
scoreboard players operation xs llm = 170s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 170b th2
scoreboard players operation xe llm = 170e th2
scoreboard players operation xs llm = 170s th2
function llm:div
scoreboard players operation yb llm = 170b th
scoreboard players operation ye llm = 170e th
scoreboard players operation ys llm = 170s th
function llm:mul
scoreboard players operation 170b th = xb llm
scoreboard players operation 170e th = xe llm
scoreboard players operation 170s th = xs llm
scoreboard players operation xb llm = 171b th
scoreboard players operation xe llm = 171e th
scoreboard players operation xs llm = 171s th
scoreboard players operation xs llm *= -1 llm
function llm:exp
scoreboard players set yb llm 10000000
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:add
scoreboard players operation yb llm = xb llm
scoreboard players operation ye llm = xe llm
scoreboard players operation ys llm = xs llm
scoreboard players operation xb llm = 171b th2
scoreboard players operation xe llm = 171e th2
scoreboard players operation xs llm = 171s th2
function llm:div
scoreboard players operation yb llm = 171b th
scoreboard players operation ye llm = 171e th
scoreboard players operation ys llm = 171s th
function llm:mul
scoreboard players operation 171b th = xb llm
scoreboard players operation 171e th = xe llm
scoreboard players operation 171s th = xs llm
