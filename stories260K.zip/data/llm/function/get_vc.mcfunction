$scoreboard players operation xb llm = $(i)b vc
$scoreboard players operation xe llm = $(i)e vc
$scoreboard players operation xs llm = $(i)s vc
