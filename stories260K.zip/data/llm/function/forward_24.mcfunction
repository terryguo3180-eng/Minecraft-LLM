data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_3"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 26
schedule function llm:forward_25 1t
