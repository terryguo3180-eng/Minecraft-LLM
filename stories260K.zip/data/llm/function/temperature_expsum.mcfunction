$scoreboard players operation xb llm = $(i)b logits
$scoreboard players operation xe llm = $(i)e logits
$scoreboard players operation xs llm = $(i)s logits
scoreboard players operation yb llm = nmb llm
scoreboard players operation ye llm = nme llm
scoreboard players operation ys llm = nms llm
function llm:add
function llm:exp
$scoreboard players operation $(i)b logits = xb llm
$scoreboard players operation $(i)e logits = xe llm
$scoreboard players operation $(i)s logits = xs llm
scoreboard players operation yb llm = expsumb llm
scoreboard players operation ye llm = expsume llm
scoreboard players operation ys llm = expsums llm
function llm:add
scoreboard players operation expsumb llm = xb llm
scoreboard players operation expsume llm = xe llm
scoreboard players operation expsums llm = xs llm
execute store result score t0 llm store result score t1 llm store result storage llm args.i int 1 run scoreboard players add i llm 1
scoreboard players operation t0 llm %= 100 llm
scoreboard players add t1 llm 1024
execute if score t0 llm matches 99 store result bossbar progress value run scoreboard players operation t1 llm /= 100 llm
execute if score i llm matches ..511 run function llm:temperature_expsum with storage llm args
