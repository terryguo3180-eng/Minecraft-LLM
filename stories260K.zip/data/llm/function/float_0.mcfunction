execute if score xe llm > ye llm run return run scoreboard players set t1 llm 0
execute if score xe llm = ye llm if score xb llm >= t2 llm run return run scoreboard players set t1 llm 0
scoreboard players set t1 llm 1
