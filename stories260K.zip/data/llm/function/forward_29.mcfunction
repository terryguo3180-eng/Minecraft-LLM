data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_3"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 31
schedule function llm:forward_30 1t
