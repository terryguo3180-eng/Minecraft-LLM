scoreboard players operation window_len llm = pos llm
scoreboard players add window_len llm 1
execute if score pos llm matches 513.. run scoreboard players set window_len llm 512
scoreboard players operation start llm = pos llm
scoreboard players operation start llm -= window_len llm
scoreboard players add start llm 1
