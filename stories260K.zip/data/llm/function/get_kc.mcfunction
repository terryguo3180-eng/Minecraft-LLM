$scoreboard players operation xb llm = $(i)b kc
$scoreboard players operation xe llm = $(i)e kc
$scoreboard players operation xs llm = $(i)s kc
