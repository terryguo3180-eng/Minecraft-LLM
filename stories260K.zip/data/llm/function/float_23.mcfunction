scoreboard players operation xb llm /= 10 llm
scoreboard players operation r llm = xb llm
scoreboard players operation xb llm *= 10 llm
