scoreboard players operation xb llm *= 100000000 llm
scoreboard players remove xe llm 8
