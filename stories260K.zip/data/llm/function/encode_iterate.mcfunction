scoreboard players set bs llm -2147483648
scoreboard players set bt llm -1
scoreboard players set bi llm -1
scoreboard players set i llm 0
scoreboard players set j llm 1
execute store result score len llm run data get storage llm args.prompt_tokens
data merge storage llm {args:{i:0,j:1}}
function llm:get_token_pair with storage llm args
function llm:check_token_pair with storage llm args
execute if score bi llm matches -1 run return 0
execute store result storage llm args.i int 1 run scoreboard players get bi llm
execute store result storage llm args.j int 1 run scoreboard players add bi llm 1
scoreboard players remove bi llm 1
function llm:apply_token_merge with storage llm args
function llm:encode_iterate
