scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 131088
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation ab llm = xb llm
scoreboard players operation ae llm = xe llm
scoreboard players operation as llm = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 32b tx
scoreboard players operation ye llm = 32e tx
scoreboard players operation ys llm = 32s tx
function llm:add
scoreboard players operation 32b tx = xb llm
scoreboard players operation 32e tx = xe llm
scoreboard players operation 32s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 33b tx
scoreboard players operation ye llm = 33e tx
scoreboard players operation ys llm = 33s tx
function llm:add
scoreboard players operation 33b tx = xb llm
scoreboard players operation 33e tx = xe llm
scoreboard players operation 33s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 34b tx
scoreboard players operation ye llm = 34e tx
scoreboard players operation ys llm = 34s tx
function llm:add
scoreboard players operation 34b tx = xb llm
scoreboard players operation 34e tx = xe llm
scoreboard players operation 34s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 35b tx
scoreboard players operation ye llm = 35e tx
scoreboard players operation ys llm = 35s tx
function llm:add
scoreboard players operation 35b tx = xb llm
scoreboard players operation 35e tx = xe llm
scoreboard players operation 35s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 36b tx
scoreboard players operation ye llm = 36e tx
scoreboard players operation ys llm = 36s tx
function llm:add
scoreboard players operation 36b tx = xb llm
scoreboard players operation 36e tx = xe llm
scoreboard players operation 36s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 37b tx
scoreboard players operation ye llm = 37e tx
scoreboard players operation ys llm = 37s tx
function llm:add
scoreboard players operation 37b tx = xb llm
scoreboard players operation 37e tx = xe llm
scoreboard players operation 37s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 38b tx
scoreboard players operation ye llm = 38e tx
scoreboard players operation ys llm = 38s tx
function llm:add
scoreboard players operation 38b tx = xb llm
scoreboard players operation 38e tx = xe llm
scoreboard players operation 38s tx = xs llm
scoreboard players operation yb llm = ab llm
scoreboard players operation ye llm = ae llm
scoreboard players operation ys llm = as llm
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_vc with storage llm args
function llm:mul
scoreboard players add cache_idx llm 1
scoreboard players operation yb llm = 39b tx
scoreboard players operation ye llm = 39e tx
scoreboard players operation ys llm = 39s tx
function llm:add
scoreboard players operation 39b tx = xb llm
scoreboard players operation 39e tx = xe llm
scoreboard players operation 39s tx = xs llm
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_4_4_4
