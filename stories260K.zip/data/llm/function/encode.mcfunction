data modify storage llm args.prompt_tokens set value [410]
scoreboard players set i llm 0
scoreboard players set j llm 1
execute store result score len llm run data get storage llm args.prompt
function llm:enumerate_prompt {i:0,j:1}
function llm:encode_iterate
