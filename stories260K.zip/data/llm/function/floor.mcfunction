execute if score xe llm matches 7.. run return run scoreboard players operation r llm = xb llm
execute if score xe llm matches 6 run return run function llm:float_23
execute if score xe llm matches 5 run return run function llm:float_24
execute if score xe llm matches 4 run return run function llm:float_25
execute if score xe llm matches 3 run return run function llm:float_26
execute if score xe llm matches 2 run return run function llm:float_27
execute if score xe llm matches 1 run return run function llm:float_28
execute if score xe llm matches 0 run return run function llm:float_29
scoreboard players set xb llm 0
scoreboard players set xe llm 0
scoreboard players set xs llm 0
scoreboard players set r llm 0
