execute if score t3 llm matches 1..2 run return run function llm:float_3
execute if score t3 llm matches 3..5 run return run function llm:float_4
execute if score t3 llm matches 6 run return run scoreboard players operation t2 llm /= 1000000 llm
execute if score t3 llm matches 7 run return run scoreboard players operation t2 llm /= 10000000 llm
scoreboard players operation t2 llm /= 1000000000 llm
