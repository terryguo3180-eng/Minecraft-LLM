execute if score xs llm > ys llm run return run scoreboard players set r llm 1
execute if score xs llm < ys llm run return run scoreboard players set r llm -1
function llm:float_14
execute if score xs llm matches -1 run scoreboard players operation r llm *= -1 llm
