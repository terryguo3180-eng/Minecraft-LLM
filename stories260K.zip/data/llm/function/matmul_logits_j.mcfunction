$execute store result score xb llm run data get storage llm params.emb.$(idx)b
$execute store result score xe llm run data get storage llm params.emb.$(idx)e
$execute store result score xs llm run data get storage llm params.emb.$(idx)s
$scoreboard players operation yb llm = $(j)b x
$scoreboard players operation ye llm = $(j)e x
$scoreboard players operation ys llm = $(j)s x
function llm:mul
$scoreboard players operation yb llm = $(i)b logits
$scoreboard players operation ye llm = $(i)e logits
$scoreboard players operation ys llm = $(i)s logits
function llm:add
$scoreboard players operation $(i)b logits = xb llm
$scoreboard players operation $(i)e logits = xe llm
$scoreboard players operation $(i)s logits = xs llm
scoreboard players add j llm 1
execute store result storage llm args.idx int 1 run scoreboard players add idx llm 1
execute if score j llm matches 64 run return 1
execute store result storage llm args.j int 1 run scoreboard players get j llm
function llm:matmul_logits_j with storage llm args
