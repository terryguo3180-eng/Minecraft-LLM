scoreboard players operation xb llm *= 10 llm
scoreboard players remove xe llm 1
