scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 16
scoreboard players set scoreb llm 0
scoreboard players set scoree llm 0
scoreboard players set scores llm 0
scoreboard players operation yb llm = 40b q
scoreboard players operation ye llm = 40e q
scoreboard players operation ys llm = 40s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 41b q
scoreboard players operation ye llm = 41e q
scoreboard players operation ys llm = 41s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 42b q
scoreboard players operation ye llm = 42e q
scoreboard players operation ys llm = 42s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 43b q
scoreboard players operation ye llm = 43e q
scoreboard players operation ys llm = 43s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 44b q
scoreboard players operation ye llm = 44e q
scoreboard players operation ys llm = 44s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 45b q
scoreboard players operation ye llm = 45e q
scoreboard players operation ys llm = 45s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 46b q
scoreboard players operation ye llm = 46e q
scoreboard players operation ys llm = 46s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 47b q
scoreboard players operation ye llm = 47e q
scoreboard players operation ys llm = 47s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation xb llm = scoreb llm
scoreboard players operation xe llm = scoree llm
scoreboard players operation xs llm = scores llm
scoreboard players set yb llm 28284271
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:div
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:set_av with storage llm args
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_0_5_0
