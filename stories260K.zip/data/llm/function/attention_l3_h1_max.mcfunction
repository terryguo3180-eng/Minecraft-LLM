execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation yb llm = maxb llm
scoreboard players operation ye llm = maxe llm
scoreboard players operation ys llm = maxs llm
function llm:cmp
execute if score r llm matches 1 run scoreboard players operation maxb llm = xb llm
execute if score r llm matches 1 run scoreboard players operation maxe llm = xe llm
execute if score r llm matches 1 run scoreboard players operation maxs llm = xs llm
scoreboard players add i llm 1
execute if score i llm < window_len llm run function llm:attention_l3_h1_max
