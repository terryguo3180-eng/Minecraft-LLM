scoreboard players operation t0 llm = xb llm
scoreboard players operation t1 llm = t0 llm
scoreboard players operation t1 llm %= 10000 llm
scoreboard players set xb llm 100000000
scoreboard players operation t2 llm = t0 llm
scoreboard players operation t0 llm /= 25 llm
scoreboard players operation t2 llm %= 25 llm
scoreboard players operation t3 llm = xb llm
scoreboard players operation xb llm /= t0 llm
scoreboard players operation xb llm *= 40 llm
scoreboard players operation t3 llm %= t0 llm
scoreboard players operation t3 llm *= 40 llm
scoreboard players operation t1 llm = t3 llm
scoreboard players operation t3 llm /= t0 llm
scoreboard players operation xb llm += t3 llm
scoreboard players operation t1 llm %= t0 llm
scoreboard players operation t1 llm *= 25 llm
scoreboard players operation t4 llm = t2 llm
scoreboard players operation t4 llm *= xb llm
scoreboard players operation t1 llm -= t4 llm
scoreboard players operation t1 llm *= 10 llm
scoreboard players operation t3 llm = t1 llm
scoreboard players operation t1 llm /= t0 llm
scoreboard players operation t1 llm *= 40 llm
scoreboard players operation t3 llm %= t0 llm
scoreboard players operation t3 llm *= 40 llm
scoreboard players operation t3 llm /= t0 llm
scoreboard players operation t1 llm += t3 llm
scoreboard players operation xe llm *= -1 llm
scoreboard players remove xe llm 1
execute if score xb llm matches 100000.. run return 0
scoreboard players operation xb llm *= 10000 llm
scoreboard players operation xb llm += t1 llm
execute if score xb llm matches 100000000.. run function llm:float_15
