execute if score xb llm matches 1..329475 run return run scoreboard players set t0 llm 744
scoreboard players operation t0 llm = xb llm
execute if score xb llm matches 329476..18688328 run return run function llm:float_17
execute if score xb llm matches 18688329..533609999 run return run function llm:float_18
scoreboard players operation t0 llm /= 79249 llm
scoreboard players add t0 llm 19750
