scoreboard players operation yb llm = tb llm
scoreboard players operation ye llm = te llm
scoreboard players operation ys llm = ts llm
bossbar set progress max 26
bossbar set progress value 0
bossbar set progress name [{"text":"Sampling","color":"gray","bold":true}]
bossbar set progress players @a
scoreboard players set i llm 0
function llm:temperature_apply_logits {i:0}
scoreboard players set yb llm 99999999
scoreboard players set ye llm 99999999
scoreboard players set ys llm -1
scoreboard players set i llm 0
function llm:temperature_findmax {i:0}
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players operation nmb llm = yb llm
scoreboard players operation nme llm = ye llm
scoreboard players operation nms llm = ys llm
scoreboard players operation nms llm *= -1 llm
scoreboard players set i llm 0
function llm:temperature_expsum {i:0}
scoreboard players set i llm 0
function llm:temperature_norm {i:0}
execute store result score xb llm run random value 0..99999999
scoreboard players set xe llm -1
scoreboard players set xs llm 1
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation rb llm = xb llm
scoreboard players operation re llm = xe llm
scoreboard players operation rs llm = xs llm
scoreboard players set cdfb llm 0
scoreboard players set cdfe llm 0
scoreboard players set cdfs llm 0
scoreboard players set i llm 0
function llm:temperature_cdf {i:0}
execute if score i llm matches 512 run scoreboard players set tok llm 511
