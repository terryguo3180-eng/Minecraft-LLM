$scoreboard players set steps llm $(s)
execute if score steps llm matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer!","color":"red"}
tellraw @a [{"text":"Resuming from step #","color":"green"},{"score":{"name":"pos","objective":"llm"}}]
scoreboard players operation steps llm += pos llm
function llm:autoregressive
