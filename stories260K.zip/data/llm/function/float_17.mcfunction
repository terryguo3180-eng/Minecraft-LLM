scoreboard players operation t0 llm /= 4750 llm
scoreboard players add t0 llm 744
