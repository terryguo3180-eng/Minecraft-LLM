scoreboard players set yb llm 99999999
scoreboard players set ye llm 99999999
scoreboard players set ys llm -1
scoreboard players set i llm 0
function llm:argmax_loop {i:0}
bossbar set progress max 6
bossbar set progress value 0
bossbar set progress name [{"text":"Sampling","color":"gray","bold":true}]
bossbar set progress players @a
