function llm:forward
function llm:argmax
function llm:sample
tellraw @a {"storage":"llm","nbt":"args.tokens[]","separator":""}
scoreboard players operation tok llm = max_i llm
scoreboard players add pos llm 1
execute if score pos llm = steps llm run return 1
function llm:autoregressive
