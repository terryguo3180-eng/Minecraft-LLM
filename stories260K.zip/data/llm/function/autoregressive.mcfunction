function llm:forward
schedule function llm:autoregressive_next 51t
