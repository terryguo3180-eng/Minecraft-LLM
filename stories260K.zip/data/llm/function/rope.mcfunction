scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 0b q
scoreboard players operation t0e llm = 0e q
scoreboard players operation t0s llm = 0s q
scoreboard players operation xb llm = 0b q
scoreboard players operation xe llm = 0e q
scoreboard players operation xs llm = 0s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 1b q
scoreboard players operation xe llm = 1e q
scoreboard players operation xs llm = 1s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 0b q = xb llm
scoreboard players operation 0e q = xe llm
scoreboard players operation 0s q = xs llm
scoreboard players operation xb llm = 1b q
scoreboard players operation xe llm = 1e q
scoreboard players operation xs llm = 1s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 1b q = xb llm
scoreboard players operation 1e q = xe llm
scoreboard players operation 1s q = xs llm
scoreboard players operation t0b llm = 0b k
scoreboard players operation t0e llm = 0e k
scoreboard players operation t0s llm = 0s k
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 0b k = xb llm
scoreboard players operation 0e k = xe llm
scoreboard players operation 0s k = xs llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 1b k = xb llm
scoreboard players operation 1e k = xe llm
scoreboard players operation 1s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 2b q
scoreboard players operation t0e llm = 2e q
scoreboard players operation t0s llm = 2s q
scoreboard players operation xb llm = 2b q
scoreboard players operation xe llm = 2e q
scoreboard players operation xs llm = 2s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 3b q
scoreboard players operation xe llm = 3e q
scoreboard players operation xs llm = 3s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 2b q = xb llm
scoreboard players operation 2e q = xe llm
scoreboard players operation 2s q = xs llm
scoreboard players operation xb llm = 3b q
scoreboard players operation xe llm = 3e q
scoreboard players operation xs llm = 3s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 3b q = xb llm
scoreboard players operation 3e q = xe llm
scoreboard players operation 3s q = xs llm
scoreboard players operation t0b llm = 2b k
scoreboard players operation t0e llm = 2e k
scoreboard players operation t0s llm = 2s k
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 2b k = xb llm
scoreboard players operation 2e k = xe llm
scoreboard players operation 2s k = xs llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 3b k = xb llm
scoreboard players operation 3e k = xe llm
scoreboard players operation 3s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 4b q
scoreboard players operation t0e llm = 4e q
scoreboard players operation t0s llm = 4s q
scoreboard players operation xb llm = 4b q
scoreboard players operation xe llm = 4e q
scoreboard players operation xs llm = 4s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 5b q
scoreboard players operation xe llm = 5e q
scoreboard players operation xs llm = 5s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 4b q = xb llm
scoreboard players operation 4e q = xe llm
scoreboard players operation 4s q = xs llm
scoreboard players operation xb llm = 5b q
scoreboard players operation xe llm = 5e q
scoreboard players operation xs llm = 5s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 5b q = xb llm
scoreboard players operation 5e q = xe llm
scoreboard players operation 5s q = xs llm
scoreboard players operation t0b llm = 4b k
scoreboard players operation t0e llm = 4e k
scoreboard players operation t0s llm = 4s k
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 4b k = xb llm
scoreboard players operation 4e k = xe llm
scoreboard players operation 4s k = xs llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 5b k = xb llm
scoreboard players operation 5e k = xe llm
scoreboard players operation 5s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 6b q
scoreboard players operation t0e llm = 6e q
scoreboard players operation t0s llm = 6s q
scoreboard players operation xb llm = 6b q
scoreboard players operation xe llm = 6e q
scoreboard players operation xs llm = 6s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 7b q
scoreboard players operation xe llm = 7e q
scoreboard players operation xs llm = 7s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 6b q = xb llm
scoreboard players operation 6e q = xe llm
scoreboard players operation 6s q = xs llm
scoreboard players operation xb llm = 7b q
scoreboard players operation xe llm = 7e q
scoreboard players operation xs llm = 7s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 7b q = xb llm
scoreboard players operation 7e q = xe llm
scoreboard players operation 7s q = xs llm
scoreboard players operation t0b llm = 6b k
scoreboard players operation t0e llm = 6e k
scoreboard players operation t0s llm = 6s k
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 6b k = xb llm
scoreboard players operation 6e k = xe llm
scoreboard players operation 6s k = xs llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 7b k = xb llm
scoreboard players operation 7e k = xe llm
scoreboard players operation 7s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 8b q
scoreboard players operation t0e llm = 8e q
scoreboard players operation t0s llm = 8s q
scoreboard players operation xb llm = 8b q
scoreboard players operation xe llm = 8e q
scoreboard players operation xs llm = 8s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 9b q
scoreboard players operation xe llm = 9e q
scoreboard players operation xs llm = 9s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 8b q = xb llm
scoreboard players operation 8e q = xe llm
scoreboard players operation 8s q = xs llm
scoreboard players operation xb llm = 9b q
scoreboard players operation xe llm = 9e q
scoreboard players operation xs llm = 9s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 9b q = xb llm
scoreboard players operation 9e q = xe llm
scoreboard players operation 9s q = xs llm
scoreboard players operation t0b llm = 8b k
scoreboard players operation t0e llm = 8e k
scoreboard players operation t0s llm = 8s k
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 8b k = xb llm
scoreboard players operation 8e k = xe llm
scoreboard players operation 8s k = xs llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 9b k = xb llm
scoreboard players operation 9e k = xe llm
scoreboard players operation 9s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 10b q
scoreboard players operation t0e llm = 10e q
scoreboard players operation t0s llm = 10s q
scoreboard players operation xb llm = 10b q
scoreboard players operation xe llm = 10e q
scoreboard players operation xs llm = 10s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 11b q
scoreboard players operation xe llm = 11e q
scoreboard players operation xs llm = 11s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 10b q = xb llm
scoreboard players operation 10e q = xe llm
scoreboard players operation 10s q = xs llm
scoreboard players operation xb llm = 11b q
scoreboard players operation xe llm = 11e q
scoreboard players operation xs llm = 11s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 11b q = xb llm
scoreboard players operation 11e q = xe llm
scoreboard players operation 11s q = xs llm
scoreboard players operation t0b llm = 10b k
scoreboard players operation t0e llm = 10e k
scoreboard players operation t0s llm = 10s k
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 10b k = xb llm
scoreboard players operation 10e k = xe llm
scoreboard players operation 10s k = xs llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 11b k = xb llm
scoreboard players operation 11e k = xe llm
scoreboard players operation 11s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 12b q
scoreboard players operation t0e llm = 12e q
scoreboard players operation t0s llm = 12s q
scoreboard players operation xb llm = 12b q
scoreboard players operation xe llm = 12e q
scoreboard players operation xs llm = 12s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 13b q
scoreboard players operation xe llm = 13e q
scoreboard players operation xs llm = 13s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 12b q = xb llm
scoreboard players operation 12e q = xe llm
scoreboard players operation 12s q = xs llm
scoreboard players operation xb llm = 13b q
scoreboard players operation xe llm = 13e q
scoreboard players operation xs llm = 13s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 13b q = xb llm
scoreboard players operation 13e q = xe llm
scoreboard players operation 13s q = xs llm
scoreboard players operation t0b llm = 12b k
scoreboard players operation t0e llm = 12e k
scoreboard players operation t0s llm = 12s k
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 12b k = xb llm
scoreboard players operation 12e k = xe llm
scoreboard players operation 12s k = xs llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 13b k = xb llm
scoreboard players operation 13e k = xe llm
scoreboard players operation 13s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 14b q
scoreboard players operation t0e llm = 14e q
scoreboard players operation t0s llm = 14s q
scoreboard players operation xb llm = 14b q
scoreboard players operation xe llm = 14e q
scoreboard players operation xs llm = 14s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 15b q
scoreboard players operation xe llm = 15e q
scoreboard players operation xs llm = 15s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 14b q = xb llm
scoreboard players operation 14e q = xe llm
scoreboard players operation 14s q = xs llm
scoreboard players operation xb llm = 15b q
scoreboard players operation xe llm = 15e q
scoreboard players operation xs llm = 15s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 15b q = xb llm
scoreboard players operation 15e q = xe llm
scoreboard players operation 15s q = xs llm
scoreboard players operation t0b llm = 14b k
scoreboard players operation t0e llm = 14e k
scoreboard players operation t0s llm = 14s k
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 14b k = xb llm
scoreboard players operation 14e k = xe llm
scoreboard players operation 14s k = xs llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 15b k = xb llm
scoreboard players operation 15e k = xe llm
scoreboard players operation 15s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 16b q
scoreboard players operation t0e llm = 16e q
scoreboard players operation t0s llm = 16s q
scoreboard players operation xb llm = 16b q
scoreboard players operation xe llm = 16e q
scoreboard players operation xs llm = 16s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 17b q
scoreboard players operation xe llm = 17e q
scoreboard players operation xs llm = 17s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 16b q = xb llm
scoreboard players operation 16e q = xe llm
scoreboard players operation 16s q = xs llm
scoreboard players operation xb llm = 17b q
scoreboard players operation xe llm = 17e q
scoreboard players operation xs llm = 17s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 17b q = xb llm
scoreboard players operation 17e q = xe llm
scoreboard players operation 17s q = xs llm
scoreboard players operation t0b llm = 16b k
scoreboard players operation t0e llm = 16e k
scoreboard players operation t0s llm = 16s k
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 16b k = xb llm
scoreboard players operation 16e k = xe llm
scoreboard players operation 16s k = xs llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 17b k = xb llm
scoreboard players operation 17e k = xe llm
scoreboard players operation 17s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 18b q
scoreboard players operation t0e llm = 18e q
scoreboard players operation t0s llm = 18s q
scoreboard players operation xb llm = 18b q
scoreboard players operation xe llm = 18e q
scoreboard players operation xs llm = 18s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 19b q
scoreboard players operation xe llm = 19e q
scoreboard players operation xs llm = 19s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 18b q = xb llm
scoreboard players operation 18e q = xe llm
scoreboard players operation 18s q = xs llm
scoreboard players operation xb llm = 19b q
scoreboard players operation xe llm = 19e q
scoreboard players operation xs llm = 19s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 19b q = xb llm
scoreboard players operation 19e q = xe llm
scoreboard players operation 19s q = xs llm
scoreboard players operation t0b llm = 18b k
scoreboard players operation t0e llm = 18e k
scoreboard players operation t0s llm = 18s k
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 18b k = xb llm
scoreboard players operation 18e k = xe llm
scoreboard players operation 18s k = xs llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 19b k = xb llm
scoreboard players operation 19e k = xe llm
scoreboard players operation 19s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 20b q
scoreboard players operation t0e llm = 20e q
scoreboard players operation t0s llm = 20s q
scoreboard players operation xb llm = 20b q
scoreboard players operation xe llm = 20e q
scoreboard players operation xs llm = 20s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 21b q
scoreboard players operation xe llm = 21e q
scoreboard players operation xs llm = 21s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 20b q = xb llm
scoreboard players operation 20e q = xe llm
scoreboard players operation 20s q = xs llm
scoreboard players operation xb llm = 21b q
scoreboard players operation xe llm = 21e q
scoreboard players operation xs llm = 21s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 21b q = xb llm
scoreboard players operation 21e q = xe llm
scoreboard players operation 21s q = xs llm
scoreboard players operation t0b llm = 20b k
scoreboard players operation t0e llm = 20e k
scoreboard players operation t0s llm = 20s k
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 20b k = xb llm
scoreboard players operation 20e k = xe llm
scoreboard players operation 20s k = xs llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 21b k = xb llm
scoreboard players operation 21e k = xe llm
scoreboard players operation 21s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 22b q
scoreboard players operation t0e llm = 22e q
scoreboard players operation t0s llm = 22s q
scoreboard players operation xb llm = 22b q
scoreboard players operation xe llm = 22e q
scoreboard players operation xs llm = 22s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 23b q
scoreboard players operation xe llm = 23e q
scoreboard players operation xs llm = 23s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 22b q = xb llm
scoreboard players operation 22e q = xe llm
scoreboard players operation 22s q = xs llm
scoreboard players operation xb llm = 23b q
scoreboard players operation xe llm = 23e q
scoreboard players operation xs llm = 23s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 23b q = xb llm
scoreboard players operation 23e q = xe llm
scoreboard players operation 23s q = xs llm
scoreboard players operation t0b llm = 22b k
scoreboard players operation t0e llm = 22e k
scoreboard players operation t0s llm = 22s k
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 22b k = xb llm
scoreboard players operation 22e k = xe llm
scoreboard players operation 22s k = xs llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 23b k = xb llm
scoreboard players operation 23e k = xe llm
scoreboard players operation 23s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 24b q
scoreboard players operation t0e llm = 24e q
scoreboard players operation t0s llm = 24s q
scoreboard players operation xb llm = 24b q
scoreboard players operation xe llm = 24e q
scoreboard players operation xs llm = 24s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 25b q
scoreboard players operation xe llm = 25e q
scoreboard players operation xs llm = 25s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 24b q = xb llm
scoreboard players operation 24e q = xe llm
scoreboard players operation 24s q = xs llm
scoreboard players operation xb llm = 25b q
scoreboard players operation xe llm = 25e q
scoreboard players operation xs llm = 25s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 25b q = xb llm
scoreboard players operation 25e q = xe llm
scoreboard players operation 25s q = xs llm
scoreboard players operation t0b llm = 24b k
scoreboard players operation t0e llm = 24e k
scoreboard players operation t0s llm = 24s k
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 24b k = xb llm
scoreboard players operation 24e k = xe llm
scoreboard players operation 24s k = xs llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 25b k = xb llm
scoreboard players operation 25e k = xe llm
scoreboard players operation 25s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 26b q
scoreboard players operation t0e llm = 26e q
scoreboard players operation t0s llm = 26s q
scoreboard players operation xb llm = 26b q
scoreboard players operation xe llm = 26e q
scoreboard players operation xs llm = 26s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 27b q
scoreboard players operation xe llm = 27e q
scoreboard players operation xs llm = 27s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 26b q = xb llm
scoreboard players operation 26e q = xe llm
scoreboard players operation 26s q = xs llm
scoreboard players operation xb llm = 27b q
scoreboard players operation xe llm = 27e q
scoreboard players operation xs llm = 27s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 27b q = xb llm
scoreboard players operation 27e q = xe llm
scoreboard players operation 27s q = xs llm
scoreboard players operation t0b llm = 26b k
scoreboard players operation t0e llm = 26e k
scoreboard players operation t0s llm = 26s k
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 26b k = xb llm
scoreboard players operation 26e k = xe llm
scoreboard players operation 26s k = xs llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 27b k = xb llm
scoreboard players operation 27e k = xe llm
scoreboard players operation 27s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 28b q
scoreboard players operation t0e llm = 28e q
scoreboard players operation t0s llm = 28s q
scoreboard players operation xb llm = 28b q
scoreboard players operation xe llm = 28e q
scoreboard players operation xs llm = 28s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 29b q
scoreboard players operation xe llm = 29e q
scoreboard players operation xs llm = 29s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 28b q = xb llm
scoreboard players operation 28e q = xe llm
scoreboard players operation 28s q = xs llm
scoreboard players operation xb llm = 29b q
scoreboard players operation xe llm = 29e q
scoreboard players operation xs llm = 29s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 29b q = xb llm
scoreboard players operation 29e q = xe llm
scoreboard players operation 29s q = xs llm
scoreboard players operation t0b llm = 28b k
scoreboard players operation t0e llm = 28e k
scoreboard players operation t0s llm = 28s k
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 28b k = xb llm
scoreboard players operation 28e k = xe llm
scoreboard players operation 28s k = xs llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 29b k = xb llm
scoreboard players operation 29e k = xe llm
scoreboard players operation 29s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 30b q
scoreboard players operation t0e llm = 30e q
scoreboard players operation t0s llm = 30s q
scoreboard players operation xb llm = 30b q
scoreboard players operation xe llm = 30e q
scoreboard players operation xs llm = 30s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 31b q
scoreboard players operation xe llm = 31e q
scoreboard players operation xs llm = 31s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 30b q = xb llm
scoreboard players operation 30e q = xe llm
scoreboard players operation 30s q = xs llm
scoreboard players operation xb llm = 31b q
scoreboard players operation xe llm = 31e q
scoreboard players operation xs llm = 31s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 31b q = xb llm
scoreboard players operation 31e q = xe llm
scoreboard players operation 31s q = xs llm
scoreboard players operation t0b llm = 30b k
scoreboard players operation t0e llm = 30e k
scoreboard players operation t0s llm = 30s k
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 30b k = xb llm
scoreboard players operation 30e k = xe llm
scoreboard players operation 30s k = xs llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b k = xb llm
scoreboard players operation t1e k = xe llm
scoreboard players operation t1s k = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b k
scoreboard players operation ye llm = t1e k
scoreboard players operation ys llm = t1s k
function llm:add
scoreboard players operation 31b k = xb llm
scoreboard players operation 31e k = xe llm
scoreboard players operation 31s k = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 32b q
scoreboard players operation t0e llm = 32e q
scoreboard players operation t0s llm = 32s q
scoreboard players operation xb llm = 32b q
scoreboard players operation xe llm = 32e q
scoreboard players operation xs llm = 32s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 33b q
scoreboard players operation xe llm = 33e q
scoreboard players operation xs llm = 33s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 32b q = xb llm
scoreboard players operation 32e q = xe llm
scoreboard players operation 32s q = xs llm
scoreboard players operation xb llm = 33b q
scoreboard players operation xe llm = 33e q
scoreboard players operation xs llm = 33s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 33b q = xb llm
scoreboard players operation 33e q = xe llm
scoreboard players operation 33s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 34b q
scoreboard players operation t0e llm = 34e q
scoreboard players operation t0s llm = 34s q
scoreboard players operation xb llm = 34b q
scoreboard players operation xe llm = 34e q
scoreboard players operation xs llm = 34s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 35b q
scoreboard players operation xe llm = 35e q
scoreboard players operation xs llm = 35s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 34b q = xb llm
scoreboard players operation 34e q = xe llm
scoreboard players operation 34s q = xs llm
scoreboard players operation xb llm = 35b q
scoreboard players operation xe llm = 35e q
scoreboard players operation xs llm = 35s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 35b q = xb llm
scoreboard players operation 35e q = xe llm
scoreboard players operation 35s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 36b q
scoreboard players operation t0e llm = 36e q
scoreboard players operation t0s llm = 36s q
scoreboard players operation xb llm = 36b q
scoreboard players operation xe llm = 36e q
scoreboard players operation xs llm = 36s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 37b q
scoreboard players operation xe llm = 37e q
scoreboard players operation xs llm = 37s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 36b q = xb llm
scoreboard players operation 36e q = xe llm
scoreboard players operation 36s q = xs llm
scoreboard players operation xb llm = 37b q
scoreboard players operation xe llm = 37e q
scoreboard players operation xs llm = 37s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 37b q = xb llm
scoreboard players operation 37e q = xe llm
scoreboard players operation 37s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 38b q
scoreboard players operation t0e llm = 38e q
scoreboard players operation t0s llm = 38s q
scoreboard players operation xb llm = 38b q
scoreboard players operation xe llm = 38e q
scoreboard players operation xs llm = 38s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 39b q
scoreboard players operation xe llm = 39e q
scoreboard players operation xs llm = 39s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 38b q = xb llm
scoreboard players operation 38e q = xe llm
scoreboard players operation 38s q = xs llm
scoreboard players operation xb llm = 39b q
scoreboard players operation xe llm = 39e q
scoreboard players operation xs llm = 39s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 39b q = xb llm
scoreboard players operation 39e q = xe llm
scoreboard players operation 39s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 40b q
scoreboard players operation t0e llm = 40e q
scoreboard players operation t0s llm = 40s q
scoreboard players operation xb llm = 40b q
scoreboard players operation xe llm = 40e q
scoreboard players operation xs llm = 40s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 41b q
scoreboard players operation xe llm = 41e q
scoreboard players operation xs llm = 41s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 40b q = xb llm
scoreboard players operation 40e q = xe llm
scoreboard players operation 40s q = xs llm
scoreboard players operation xb llm = 41b q
scoreboard players operation xe llm = 41e q
scoreboard players operation xs llm = 41s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 41b q = xb llm
scoreboard players operation 41e q = xe llm
scoreboard players operation 41s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 42b q
scoreboard players operation t0e llm = 42e q
scoreboard players operation t0s llm = 42s q
scoreboard players operation xb llm = 42b q
scoreboard players operation xe llm = 42e q
scoreboard players operation xs llm = 42s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 43b q
scoreboard players operation xe llm = 43e q
scoreboard players operation xs llm = 43s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 42b q = xb llm
scoreboard players operation 42e q = xe llm
scoreboard players operation 42s q = xs llm
scoreboard players operation xb llm = 43b q
scoreboard players operation xe llm = 43e q
scoreboard players operation xs llm = 43s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 43b q = xb llm
scoreboard players operation 43e q = xe llm
scoreboard players operation 43s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 44b q
scoreboard players operation t0e llm = 44e q
scoreboard players operation t0s llm = 44s q
scoreboard players operation xb llm = 44b q
scoreboard players operation xe llm = 44e q
scoreboard players operation xs llm = 44s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 45b q
scoreboard players operation xe llm = 45e q
scoreboard players operation xs llm = 45s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 44b q = xb llm
scoreboard players operation 44e q = xe llm
scoreboard players operation 44s q = xs llm
scoreboard players operation xb llm = 45b q
scoreboard players operation xe llm = 45e q
scoreboard players operation xs llm = 45s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 45b q = xb llm
scoreboard players operation 45e q = xe llm
scoreboard players operation 45s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 46b q
scoreboard players operation t0e llm = 46e q
scoreboard players operation t0s llm = 46s q
scoreboard players operation xb llm = 46b q
scoreboard players operation xe llm = 46e q
scoreboard players operation xs llm = 46s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 47b q
scoreboard players operation xe llm = 47e q
scoreboard players operation xs llm = 47s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 46b q = xb llm
scoreboard players operation 46e q = xe llm
scoreboard players operation 46s q = xs llm
scoreboard players operation xb llm = 47b q
scoreboard players operation xe llm = 47e q
scoreboard players operation xs llm = 47s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 47b q = xb llm
scoreboard players operation 47e q = xe llm
scoreboard players operation 47s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 48b q
scoreboard players operation t0e llm = 48e q
scoreboard players operation t0s llm = 48s q
scoreboard players operation xb llm = 48b q
scoreboard players operation xe llm = 48e q
scoreboard players operation xs llm = 48s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 49b q
scoreboard players operation xe llm = 49e q
scoreboard players operation xs llm = 49s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 48b q = xb llm
scoreboard players operation 48e q = xe llm
scoreboard players operation 48s q = xs llm
scoreboard players operation xb llm = 49b q
scoreboard players operation xe llm = 49e q
scoreboard players operation xs llm = 49s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 49b q = xb llm
scoreboard players operation 49e q = xe llm
scoreboard players operation 49s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 50b q
scoreboard players operation t0e llm = 50e q
scoreboard players operation t0s llm = 50s q
scoreboard players operation xb llm = 50b q
scoreboard players operation xe llm = 50e q
scoreboard players operation xs llm = 50s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 51b q
scoreboard players operation xe llm = 51e q
scoreboard players operation xs llm = 51s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 50b q = xb llm
scoreboard players operation 50e q = xe llm
scoreboard players operation 50s q = xs llm
scoreboard players operation xb llm = 51b q
scoreboard players operation xe llm = 51e q
scoreboard players operation xs llm = 51s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 51b q = xb llm
scoreboard players operation 51e q = xe llm
scoreboard players operation 51s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 52b q
scoreboard players operation t0e llm = 52e q
scoreboard players operation t0s llm = 52s q
scoreboard players operation xb llm = 52b q
scoreboard players operation xe llm = 52e q
scoreboard players operation xs llm = 52s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 53b q
scoreboard players operation xe llm = 53e q
scoreboard players operation xs llm = 53s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 52b q = xb llm
scoreboard players operation 52e q = xe llm
scoreboard players operation 52s q = xs llm
scoreboard players operation xb llm = 53b q
scoreboard players operation xe llm = 53e q
scoreboard players operation xs llm = 53s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 53b q = xb llm
scoreboard players operation 53e q = xe llm
scoreboard players operation 53s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 54b q
scoreboard players operation t0e llm = 54e q
scoreboard players operation t0s llm = 54s q
scoreboard players operation xb llm = 54b q
scoreboard players operation xe llm = 54e q
scoreboard players operation xs llm = 54s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 55b q
scoreboard players operation xe llm = 55e q
scoreboard players operation xs llm = 55s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 54b q = xb llm
scoreboard players operation 54e q = xe llm
scoreboard players operation 54s q = xs llm
scoreboard players operation xb llm = 55b q
scoreboard players operation xe llm = 55e q
scoreboard players operation xs llm = 55s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 55b q = xb llm
scoreboard players operation 55e q = xe llm
scoreboard players operation 55s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm 0
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 56b q
scoreboard players operation t0e llm = 56e q
scoreboard players operation t0s llm = 56s q
scoreboard players operation xb llm = 56b q
scoreboard players operation xe llm = 56e q
scoreboard players operation xs llm = 56s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 57b q
scoreboard players operation xe llm = 57e q
scoreboard players operation xs llm = 57s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 56b q = xb llm
scoreboard players operation 56e q = xe llm
scoreboard players operation 56s q = xs llm
scoreboard players operation xb llm = 57b q
scoreboard players operation xe llm = 57e q
scoreboard players operation xs llm = 57s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 57b q = xb llm
scoreboard players operation 57e q = xe llm
scoreboard players operation 57s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -1
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 58b q
scoreboard players operation t0e llm = 58e q
scoreboard players operation t0s llm = 58s q
scoreboard players operation xb llm = 58b q
scoreboard players operation xe llm = 58e q
scoreboard players operation xs llm = 58s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 59b q
scoreboard players operation xe llm = 59e q
scoreboard players operation xs llm = 59s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 58b q = xb llm
scoreboard players operation 58e q = xe llm
scoreboard players operation 58s q = xs llm
scoreboard players operation xb llm = 59b q
scoreboard players operation xe llm = 59e q
scoreboard players operation xs llm = 59s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 59b q = xb llm
scoreboard players operation 59e q = xe llm
scoreboard players operation 59s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -2
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 60b q
scoreboard players operation t0e llm = 60e q
scoreboard players operation t0s llm = 60s q
scoreboard players operation xb llm = 60b q
scoreboard players operation xe llm = 60e q
scoreboard players operation xs llm = 60s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 61b q
scoreboard players operation xe llm = 61e q
scoreboard players operation xs llm = 61s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 60b q = xb llm
scoreboard players operation 60e q = xe llm
scoreboard players operation 60s q = xs llm
scoreboard players operation xb llm = 61b q
scoreboard players operation xe llm = 61e q
scoreboard players operation xs llm = 61s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 61b q = xb llm
scoreboard players operation 61e q = xe llm
scoreboard players operation 61s q = xs llm
scoreboard players set xb llm 10000000
scoreboard players set xe llm -3
scoreboard players set xs llm 1
scoreboard players operation yb llm = posb llm
scoreboard players operation ye llm = pose llm
scoreboard players operation ys llm = poss llm
function llm:mul
scoreboard players set yb llm 17453293
scoreboard players set ye llm -2
scoreboard players set ys llm 1
function llm:div
scoreboard players operation vb llm = xb llm
scoreboard players operation ve llm = xe llm
scoreboard players operation vs llm = xs llm
function llm:sin
scoreboard players operation fcib llm = xb llm
scoreboard players operation fcie llm = xe llm
scoreboard players operation fcis llm = xs llm
scoreboard players operation xb llm = vb llm
scoreboard players operation xe llm = ve llm
scoreboard players operation xs llm = vs llm
function llm:cos
scoreboard players operation fcrb llm = xb llm
scoreboard players operation fcre llm = xe llm
scoreboard players operation fcrs llm = xs llm
scoreboard players operation t0b llm = 62b q
scoreboard players operation t0e llm = 62e q
scoreboard players operation t0s llm = 62s q
scoreboard players operation xb llm = 62b q
scoreboard players operation xe llm = 62e q
scoreboard players operation xs llm = 62s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b llm = xb llm
scoreboard players operation t1e llm = xe llm
scoreboard players operation t1s llm = xs llm
scoreboard players operation xb llm = 63b q
scoreboard players operation xe llm = 63e q
scoreboard players operation xs llm = 63s q
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation xs llm *= -1 llm
scoreboard players operation yb llm = t1b llm
scoreboard players operation ye llm = t1e llm
scoreboard players operation ys llm = t1s llm
function llm:add
scoreboard players operation 62b q = xb llm
scoreboard players operation 62e q = xe llm
scoreboard players operation 62s q = xs llm
scoreboard players operation xb llm = 63b q
scoreboard players operation xe llm = 63e q
scoreboard players operation xs llm = 63s q
scoreboard players operation yb llm = fcrb llm
scoreboard players operation ye llm = fcre llm
scoreboard players operation ys llm = fcrs llm
function llm:mul
scoreboard players operation t1b q = xb llm
scoreboard players operation t1e q = xe llm
scoreboard players operation t1s q = xs llm
scoreboard players operation xb llm = t0b llm
scoreboard players operation xe llm = t0e llm
scoreboard players operation xs llm = t0s llm
scoreboard players operation yb llm = fcib llm
scoreboard players operation ye llm = fcie llm
scoreboard players operation ys llm = fcis llm
function llm:mul
scoreboard players operation yb llm = t1b q
scoreboard players operation ye llm = t1e q
scoreboard players operation ys llm = t1s q
function llm:add
scoreboard players operation 63b q = xb llm
scoreboard players operation 63e q = xe llm
scoreboard players operation 63s q = xs llm
