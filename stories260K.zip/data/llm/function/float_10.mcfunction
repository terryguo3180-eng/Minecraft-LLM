scoreboard players operation xb llm *= 1000 llm
scoreboard players remove xe llm 3
