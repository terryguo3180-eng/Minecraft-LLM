$scoreboard players operation $(i)b vc = xb llm
$scoreboard players operation $(i)e vc = xe llm
$scoreboard players operation $(i)s vc = xs llm
