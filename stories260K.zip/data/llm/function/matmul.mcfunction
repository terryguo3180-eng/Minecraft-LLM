scoreboard players set i llm 0
data modify storage llm args.i set value 0
scoreboard players set idx llm 0
data modify storage llm args.idx set value 0
function llm:matmul_1 with storage llm args
