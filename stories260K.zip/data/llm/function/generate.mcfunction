function llm:setup
scoreboard players set tok llm 1
scoreboard players set pos llm 0
data modify storage llm args.tokens set value []
$scoreboard players set steps llm $(s)
execute if score steps llm matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer!","color":"red"}
function llm:autoregressive
