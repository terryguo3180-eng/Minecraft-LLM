$scoreboard players set steps llm $(s)
$scoreboard players set temperature llm $(t)
execute if score steps llm matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer","color":"red"}
execute if score temperature llm matches ..-1 run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
execute if score temperature llm matches 101.. run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
data modify storage llm args.tokens set value []
data modify storage llm args.prompt_tokens set value []
$data modify storage llm args.prompt set value "$(i)"
execute unless data storage llm args{prompt:""} run function llm:encode
function llm:setup
scoreboard players set tok llm 1
scoreboard players set pos llm 0
scoreboard players operation xb llm = temperature llm
scoreboard players operation xb llm *= 2 llm
scoreboard players set xe llm 5
scoreboard players set xs llm 1
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation tb llm = xb llm
scoreboard players operation te llm = xe llm
scoreboard players operation ts llm = xs llm
function llm:autoregressive
