scoreboard players operation xb llm = pos llm
scoreboard players set xe llm 7
scoreboard players set xs llm 1
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation posb llm = xb llm
scoreboard players operation pose llm = xe llm
scoreboard players operation poss llm = xs llm
bossbar set progress max 49
bossbar set progress value 0
bossbar set progress name [{"text":"Inferencing, Step #","color":"green","bold":true},{"score":{"name":"pos","objective":"llm"}}]
bossbar set progress players @a
scoreboard players operation start llm = tok llm
scoreboard players operation start llm *= 64 llm
scoreboard players set i llm 0
data modify storage llm args.i set value 0
scoreboard players operation j llm = start llm
execute store result storage llm args.j int 1 run scoreboard players get j llm
function llm:copy_emb with storage llm args
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.0b
execute store result score 0e tx run data get storage llm params.att_w.0e
execute store result score 0s tx run data get storage llm params.att_w.0s
execute store result score 1b tx run data get storage llm params.att_w.1b
execute store result score 1e tx run data get storage llm params.att_w.1e
execute store result score 1s tx run data get storage llm params.att_w.1s
execute store result score 2b tx run data get storage llm params.att_w.2b
execute store result score 2e tx run data get storage llm params.att_w.2e
execute store result score 2s tx run data get storage llm params.att_w.2s
execute store result score 3b tx run data get storage llm params.att_w.3b
execute store result score 3e tx run data get storage llm params.att_w.3e
execute store result score 3s tx run data get storage llm params.att_w.3s
execute store result score 4b tx run data get storage llm params.att_w.4b
execute store result score 4e tx run data get storage llm params.att_w.4e
execute store result score 4s tx run data get storage llm params.att_w.4s
execute store result score 5b tx run data get storage llm params.att_w.5b
execute store result score 5e tx run data get storage llm params.att_w.5e
execute store result score 5s tx run data get storage llm params.att_w.5s
execute store result score 6b tx run data get storage llm params.att_w.6b
execute store result score 6e tx run data get storage llm params.att_w.6e
execute store result score 6s tx run data get storage llm params.att_w.6s
execute store result score 7b tx run data get storage llm params.att_w.7b
execute store result score 7e tx run data get storage llm params.att_w.7e
execute store result score 7s tx run data get storage llm params.att_w.7s
execute store result score 8b tx run data get storage llm params.att_w.8b
execute store result score 8e tx run data get storage llm params.att_w.8e
execute store result score 8s tx run data get storage llm params.att_w.8s
execute store result score 9b tx run data get storage llm params.att_w.9b
execute store result score 9e tx run data get storage llm params.att_w.9e
execute store result score 9s tx run data get storage llm params.att_w.9s
execute store result score 10b tx run data get storage llm params.att_w.10b
execute store result score 10e tx run data get storage llm params.att_w.10e
execute store result score 10s tx run data get storage llm params.att_w.10s
execute store result score 11b tx run data get storage llm params.att_w.11b
execute store result score 11e tx run data get storage llm params.att_w.11e
execute store result score 11s tx run data get storage llm params.att_w.11s
execute store result score 12b tx run data get storage llm params.att_w.12b
execute store result score 12e tx run data get storage llm params.att_w.12e
execute store result score 12s tx run data get storage llm params.att_w.12s
execute store result score 13b tx run data get storage llm params.att_w.13b
execute store result score 13e tx run data get storage llm params.att_w.13e
execute store result score 13s tx run data get storage llm params.att_w.13s
execute store result score 14b tx run data get storage llm params.att_w.14b
execute store result score 14e tx run data get storage llm params.att_w.14e
execute store result score 14s tx run data get storage llm params.att_w.14s
execute store result score 15b tx run data get storage llm params.att_w.15b
execute store result score 15e tx run data get storage llm params.att_w.15e
execute store result score 15s tx run data get storage llm params.att_w.15s
execute store result score 16b tx run data get storage llm params.att_w.16b
execute store result score 16e tx run data get storage llm params.att_w.16e
execute store result score 16s tx run data get storage llm params.att_w.16s
execute store result score 17b tx run data get storage llm params.att_w.17b
execute store result score 17e tx run data get storage llm params.att_w.17e
execute store result score 17s tx run data get storage llm params.att_w.17s
execute store result score 18b tx run data get storage llm params.att_w.18b
execute store result score 18e tx run data get storage llm params.att_w.18e
execute store result score 18s tx run data get storage llm params.att_w.18s
execute store result score 19b tx run data get storage llm params.att_w.19b
execute store result score 19e tx run data get storage llm params.att_w.19e
execute store result score 19s tx run data get storage llm params.att_w.19s
execute store result score 20b tx run data get storage llm params.att_w.20b
execute store result score 20e tx run data get storage llm params.att_w.20e
execute store result score 20s tx run data get storage llm params.att_w.20s
execute store result score 21b tx run data get storage llm params.att_w.21b
execute store result score 21e tx run data get storage llm params.att_w.21e
execute store result score 21s tx run data get storage llm params.att_w.21s
execute store result score 22b tx run data get storage llm params.att_w.22b
execute store result score 22e tx run data get storage llm params.att_w.22e
execute store result score 22s tx run data get storage llm params.att_w.22s
execute store result score 23b tx run data get storage llm params.att_w.23b
execute store result score 23e tx run data get storage llm params.att_w.23e
execute store result score 23s tx run data get storage llm params.att_w.23s
execute store result score 24b tx run data get storage llm params.att_w.24b
execute store result score 24e tx run data get storage llm params.att_w.24e
execute store result score 24s tx run data get storage llm params.att_w.24s
execute store result score 25b tx run data get storage llm params.att_w.25b
execute store result score 25e tx run data get storage llm params.att_w.25e
execute store result score 25s tx run data get storage llm params.att_w.25s
execute store result score 26b tx run data get storage llm params.att_w.26b
execute store result score 26e tx run data get storage llm params.att_w.26e
execute store result score 26s tx run data get storage llm params.att_w.26s
execute store result score 27b tx run data get storage llm params.att_w.27b
execute store result score 27e tx run data get storage llm params.att_w.27e
execute store result score 27s tx run data get storage llm params.att_w.27s
execute store result score 28b tx run data get storage llm params.att_w.28b
execute store result score 28e tx run data get storage llm params.att_w.28e
execute store result score 28s tx run data get storage llm params.att_w.28s
execute store result score 29b tx run data get storage llm params.att_w.29b
execute store result score 29e tx run data get storage llm params.att_w.29e
execute store result score 29s tx run data get storage llm params.att_w.29s
execute store result score 30b tx run data get storage llm params.att_w.30b
execute store result score 30e tx run data get storage llm params.att_w.30e
execute store result score 30s tx run data get storage llm params.att_w.30s
execute store result score 31b tx run data get storage llm params.att_w.31b
execute store result score 31e tx run data get storage llm params.att_w.31e
execute store result score 31s tx run data get storage llm params.att_w.31s
execute store result score 32b tx run data get storage llm params.att_w.32b
execute store result score 32e tx run data get storage llm params.att_w.32e
execute store result score 32s tx run data get storage llm params.att_w.32s
execute store result score 33b tx run data get storage llm params.att_w.33b
execute store result score 33e tx run data get storage llm params.att_w.33e
execute store result score 33s tx run data get storage llm params.att_w.33s
execute store result score 34b tx run data get storage llm params.att_w.34b
execute store result score 34e tx run data get storage llm params.att_w.34e
execute store result score 34s tx run data get storage llm params.att_w.34s
execute store result score 35b tx run data get storage llm params.att_w.35b
execute store result score 35e tx run data get storage llm params.att_w.35e
execute store result score 35s tx run data get storage llm params.att_w.35s
execute store result score 36b tx run data get storage llm params.att_w.36b
execute store result score 36e tx run data get storage llm params.att_w.36e
execute store result score 36s tx run data get storage llm params.att_w.36s
execute store result score 37b tx run data get storage llm params.att_w.37b
execute store result score 37e tx run data get storage llm params.att_w.37e
execute store result score 37s tx run data get storage llm params.att_w.37s
execute store result score 38b tx run data get storage llm params.att_w.38b
execute store result score 38e tx run data get storage llm params.att_w.38e
execute store result score 38s tx run data get storage llm params.att_w.38s
execute store result score 39b tx run data get storage llm params.att_w.39b
execute store result score 39e tx run data get storage llm params.att_w.39e
execute store result score 39s tx run data get storage llm params.att_w.39s
execute store result score 40b tx run data get storage llm params.att_w.40b
execute store result score 40e tx run data get storage llm params.att_w.40e
execute store result score 40s tx run data get storage llm params.att_w.40s
execute store result score 41b tx run data get storage llm params.att_w.41b
execute store result score 41e tx run data get storage llm params.att_w.41e
execute store result score 41s tx run data get storage llm params.att_w.41s
execute store result score 42b tx run data get storage llm params.att_w.42b
execute store result score 42e tx run data get storage llm params.att_w.42e
execute store result score 42s tx run data get storage llm params.att_w.42s
execute store result score 43b tx run data get storage llm params.att_w.43b
execute store result score 43e tx run data get storage llm params.att_w.43e
execute store result score 43s tx run data get storage llm params.att_w.43s
execute store result score 44b tx run data get storage llm params.att_w.44b
execute store result score 44e tx run data get storage llm params.att_w.44e
execute store result score 44s tx run data get storage llm params.att_w.44s
execute store result score 45b tx run data get storage llm params.att_w.45b
execute store result score 45e tx run data get storage llm params.att_w.45e
execute store result score 45s tx run data get storage llm params.att_w.45s
execute store result score 46b tx run data get storage llm params.att_w.46b
execute store result score 46e tx run data get storage llm params.att_w.46e
execute store result score 46s tx run data get storage llm params.att_w.46s
execute store result score 47b tx run data get storage llm params.att_w.47b
execute store result score 47e tx run data get storage llm params.att_w.47e
execute store result score 47s tx run data get storage llm params.att_w.47s
execute store result score 48b tx run data get storage llm params.att_w.48b
execute store result score 48e tx run data get storage llm params.att_w.48e
execute store result score 48s tx run data get storage llm params.att_w.48s
execute store result score 49b tx run data get storage llm params.att_w.49b
execute store result score 49e tx run data get storage llm params.att_w.49e
execute store result score 49s tx run data get storage llm params.att_w.49s
execute store result score 50b tx run data get storage llm params.att_w.50b
execute store result score 50e tx run data get storage llm params.att_w.50e
execute store result score 50s tx run data get storage llm params.att_w.50s
execute store result score 51b tx run data get storage llm params.att_w.51b
execute store result score 51e tx run data get storage llm params.att_w.51e
execute store result score 51s tx run data get storage llm params.att_w.51s
execute store result score 52b tx run data get storage llm params.att_w.52b
execute store result score 52e tx run data get storage llm params.att_w.52e
execute store result score 52s tx run data get storage llm params.att_w.52s
execute store result score 53b tx run data get storage llm params.att_w.53b
execute store result score 53e tx run data get storage llm params.att_w.53e
execute store result score 53s tx run data get storage llm params.att_w.53s
execute store result score 54b tx run data get storage llm params.att_w.54b
execute store result score 54e tx run data get storage llm params.att_w.54e
execute store result score 54s tx run data get storage llm params.att_w.54s
execute store result score 55b tx run data get storage llm params.att_w.55b
execute store result score 55e tx run data get storage llm params.att_w.55e
execute store result score 55s tx run data get storage llm params.att_w.55s
execute store result score 56b tx run data get storage llm params.att_w.56b
execute store result score 56e tx run data get storage llm params.att_w.56e
execute store result score 56s tx run data get storage llm params.att_w.56s
execute store result score 57b tx run data get storage llm params.att_w.57b
execute store result score 57e tx run data get storage llm params.att_w.57e
execute store result score 57s tx run data get storage llm params.att_w.57s
execute store result score 58b tx run data get storage llm params.att_w.58b
execute store result score 58e tx run data get storage llm params.att_w.58e
execute store result score 58s tx run data get storage llm params.att_w.58s
execute store result score 59b tx run data get storage llm params.att_w.59b
execute store result score 59e tx run data get storage llm params.att_w.59e
execute store result score 59s tx run data get storage llm params.att_w.59s
execute store result score 60b tx run data get storage llm params.att_w.60b
execute store result score 60e tx run data get storage llm params.att_w.60e
execute store result score 60s tx run data get storage llm params.att_w.60s
execute store result score 61b tx run data get storage llm params.att_w.61b
execute store result score 61e tx run data get storage llm params.att_w.61e
execute store result score 61s tx run data get storage llm params.att_w.61s
execute store result score 62b tx run data get storage llm params.att_w.62b
execute store result score 62e tx run data get storage llm params.att_w.62e
execute store result score 62s tx run data get storage llm params.att_w.62s
execute store result score 63b tx run data get storage llm params.att_w.63b
execute store result score 63e tx run data get storage llm params.att_w.63e
execute store result score 63s tx run data get storage llm params.att_w.63s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_0"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_0"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 2
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_0"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 3
function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 0
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 1
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 2
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 3
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 4
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 5
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 6
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 7
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 8
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 9
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 10
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 11
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 12
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 13
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 14
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 15
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 16
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 17
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 18
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 19
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 20
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 21
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 22
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 23
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 24
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 25
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 26
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 27
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 28
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 29
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 30
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 31
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:ctxwindow
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_0_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_0_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_0_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_0_3
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_0_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_1_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_1_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_1_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_1_3
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_1_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_2_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_2_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_2_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_2_3
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_2_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_3_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_3_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_3_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_3_3
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_3_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_4_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_4_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_4_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_4_3
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_4_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_5_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_5_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_5_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_5_3
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_5_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_6_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_6_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_6_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_6_3
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_6_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_7_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_0_7_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_7_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_0_7_3
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_0_7_4
bossbar set progress value 4
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_0"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 5
scoreboard players operation xb llm = 0b tx2
scoreboard players operation xe llm = 0e tx2
scoreboard players operation xs llm = 0s tx2
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx2
scoreboard players operation xe llm = 1e tx2
scoreboard players operation xs llm = 1s tx2
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx2
scoreboard players operation xe llm = 2e tx2
scoreboard players operation xs llm = 2s tx2
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx2
scoreboard players operation xe llm = 3e tx2
scoreboard players operation xs llm = 3s tx2
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx2
scoreboard players operation xe llm = 4e tx2
scoreboard players operation xs llm = 4s tx2
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx2
scoreboard players operation xe llm = 5e tx2
scoreboard players operation xs llm = 5s tx2
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx2
scoreboard players operation xe llm = 6e tx2
scoreboard players operation xs llm = 6s tx2
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx2
scoreboard players operation xe llm = 7e tx2
scoreboard players operation xs llm = 7s tx2
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx2
scoreboard players operation xe llm = 8e tx2
scoreboard players operation xs llm = 8s tx2
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx2
scoreboard players operation xe llm = 9e tx2
scoreboard players operation xs llm = 9s tx2
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx2
scoreboard players operation xe llm = 10e tx2
scoreboard players operation xs llm = 10s tx2
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx2
scoreboard players operation xe llm = 11e tx2
scoreboard players operation xs llm = 11s tx2
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx2
scoreboard players operation xe llm = 12e tx2
scoreboard players operation xs llm = 12s tx2
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx2
scoreboard players operation xe llm = 13e tx2
scoreboard players operation xs llm = 13s tx2
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx2
scoreboard players operation xe llm = 14e tx2
scoreboard players operation xs llm = 14s tx2
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx2
scoreboard players operation xe llm = 15e tx2
scoreboard players operation xs llm = 15s tx2
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx2
scoreboard players operation xe llm = 16e tx2
scoreboard players operation xs llm = 16s tx2
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx2
scoreboard players operation xe llm = 17e tx2
scoreboard players operation xs llm = 17s tx2
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx2
scoreboard players operation xe llm = 18e tx2
scoreboard players operation xs llm = 18s tx2
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx2
scoreboard players operation xe llm = 19e tx2
scoreboard players operation xs llm = 19s tx2
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx2
scoreboard players operation xe llm = 20e tx2
scoreboard players operation xs llm = 20s tx2
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx2
scoreboard players operation xe llm = 21e tx2
scoreboard players operation xs llm = 21s tx2
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx2
scoreboard players operation xe llm = 22e tx2
scoreboard players operation xs llm = 22s tx2
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx2
scoreboard players operation xe llm = 23e tx2
scoreboard players operation xs llm = 23s tx2
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx2
scoreboard players operation xe llm = 24e tx2
scoreboard players operation xs llm = 24s tx2
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx2
scoreboard players operation xe llm = 25e tx2
scoreboard players operation xs llm = 25s tx2
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx2
scoreboard players operation xe llm = 26e tx2
scoreboard players operation xs llm = 26s tx2
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx2
scoreboard players operation xe llm = 27e tx2
scoreboard players operation xs llm = 27s tx2
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx2
scoreboard players operation xe llm = 28e tx2
scoreboard players operation xs llm = 28s tx2
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx2
scoreboard players operation xe llm = 29e tx2
scoreboard players operation xs llm = 29s tx2
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx2
scoreboard players operation xe llm = 30e tx2
scoreboard players operation xs llm = 30s tx2
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx2
scoreboard players operation xe llm = 31e tx2
scoreboard players operation xs llm = 31s tx2
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx2
scoreboard players operation xe llm = 32e tx2
scoreboard players operation xs llm = 32s tx2
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx2
scoreboard players operation xe llm = 33e tx2
scoreboard players operation xs llm = 33s tx2
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx2
scoreboard players operation xe llm = 34e tx2
scoreboard players operation xs llm = 34s tx2
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx2
scoreboard players operation xe llm = 35e tx2
scoreboard players operation xs llm = 35s tx2
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx2
scoreboard players operation xe llm = 36e tx2
scoreboard players operation xs llm = 36s tx2
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx2
scoreboard players operation xe llm = 37e tx2
scoreboard players operation xs llm = 37s tx2
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx2
scoreboard players operation xe llm = 38e tx2
scoreboard players operation xs llm = 38s tx2
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx2
scoreboard players operation xe llm = 39e tx2
scoreboard players operation xs llm = 39s tx2
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx2
scoreboard players operation xe llm = 40e tx2
scoreboard players operation xs llm = 40s tx2
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx2
scoreboard players operation xe llm = 41e tx2
scoreboard players operation xs llm = 41s tx2
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx2
scoreboard players operation xe llm = 42e tx2
scoreboard players operation xs llm = 42s tx2
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx2
scoreboard players operation xe llm = 43e tx2
scoreboard players operation xs llm = 43s tx2
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx2
scoreboard players operation xe llm = 44e tx2
scoreboard players operation xs llm = 44s tx2
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx2
scoreboard players operation xe llm = 45e tx2
scoreboard players operation xs llm = 45s tx2
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx2
scoreboard players operation xe llm = 46e tx2
scoreboard players operation xs llm = 46s tx2
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx2
scoreboard players operation xe llm = 47e tx2
scoreboard players operation xs llm = 47s tx2
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx2
scoreboard players operation xe llm = 48e tx2
scoreboard players operation xs llm = 48s tx2
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx2
scoreboard players operation xe llm = 49e tx2
scoreboard players operation xs llm = 49s tx2
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx2
scoreboard players operation xe llm = 50e tx2
scoreboard players operation xs llm = 50s tx2
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx2
scoreboard players operation xe llm = 51e tx2
scoreboard players operation xs llm = 51s tx2
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx2
scoreboard players operation xe llm = 52e tx2
scoreboard players operation xs llm = 52s tx2
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx2
scoreboard players operation xe llm = 53e tx2
scoreboard players operation xs llm = 53s tx2
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx2
scoreboard players operation xe llm = 54e tx2
scoreboard players operation xs llm = 54s tx2
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx2
scoreboard players operation xe llm = 55e tx2
scoreboard players operation xs llm = 55s tx2
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx2
scoreboard players operation xe llm = 56e tx2
scoreboard players operation xs llm = 56s tx2
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx2
scoreboard players operation xe llm = 57e tx2
scoreboard players operation xs llm = 57s tx2
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx2
scoreboard players operation xe llm = 58e tx2
scoreboard players operation xs llm = 58s tx2
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx2
scoreboard players operation xe llm = 59e tx2
scoreboard players operation xs llm = 59s tx2
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx2
scoreboard players operation xe llm = 60e tx2
scoreboard players operation xs llm = 60s tx2
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx2
scoreboard players operation xe llm = 61e tx2
scoreboard players operation xs llm = 61s tx2
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx2
scoreboard players operation xe llm = 62e tx2
scoreboard players operation xs llm = 62s tx2
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx2
scoreboard players operation xe llm = 63e tx2
scoreboard players operation xs llm = 63s tx2
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.ffn_w.0b
execute store result score 0e tx run data get storage llm params.ffn_w.0e
execute store result score 0s tx run data get storage llm params.ffn_w.0s
execute store result score 1b tx run data get storage llm params.ffn_w.1b
execute store result score 1e tx run data get storage llm params.ffn_w.1e
execute store result score 1s tx run data get storage llm params.ffn_w.1s
execute store result score 2b tx run data get storage llm params.ffn_w.2b
execute store result score 2e tx run data get storage llm params.ffn_w.2e
execute store result score 2s tx run data get storage llm params.ffn_w.2s
execute store result score 3b tx run data get storage llm params.ffn_w.3b
execute store result score 3e tx run data get storage llm params.ffn_w.3e
execute store result score 3s tx run data get storage llm params.ffn_w.3s
execute store result score 4b tx run data get storage llm params.ffn_w.4b
execute store result score 4e tx run data get storage llm params.ffn_w.4e
execute store result score 4s tx run data get storage llm params.ffn_w.4s
execute store result score 5b tx run data get storage llm params.ffn_w.5b
execute store result score 5e tx run data get storage llm params.ffn_w.5e
execute store result score 5s tx run data get storage llm params.ffn_w.5s
execute store result score 6b tx run data get storage llm params.ffn_w.6b
execute store result score 6e tx run data get storage llm params.ffn_w.6e
execute store result score 6s tx run data get storage llm params.ffn_w.6s
execute store result score 7b tx run data get storage llm params.ffn_w.7b
execute store result score 7e tx run data get storage llm params.ffn_w.7e
execute store result score 7s tx run data get storage llm params.ffn_w.7s
execute store result score 8b tx run data get storage llm params.ffn_w.8b
execute store result score 8e tx run data get storage llm params.ffn_w.8e
execute store result score 8s tx run data get storage llm params.ffn_w.8s
execute store result score 9b tx run data get storage llm params.ffn_w.9b
execute store result score 9e tx run data get storage llm params.ffn_w.9e
execute store result score 9s tx run data get storage llm params.ffn_w.9s
execute store result score 10b tx run data get storage llm params.ffn_w.10b
execute store result score 10e tx run data get storage llm params.ffn_w.10e
execute store result score 10s tx run data get storage llm params.ffn_w.10s
execute store result score 11b tx run data get storage llm params.ffn_w.11b
execute store result score 11e tx run data get storage llm params.ffn_w.11e
execute store result score 11s tx run data get storage llm params.ffn_w.11s
execute store result score 12b tx run data get storage llm params.ffn_w.12b
execute store result score 12e tx run data get storage llm params.ffn_w.12e
execute store result score 12s tx run data get storage llm params.ffn_w.12s
execute store result score 13b tx run data get storage llm params.ffn_w.13b
execute store result score 13e tx run data get storage llm params.ffn_w.13e
execute store result score 13s tx run data get storage llm params.ffn_w.13s
execute store result score 14b tx run data get storage llm params.ffn_w.14b
execute store result score 14e tx run data get storage llm params.ffn_w.14e
execute store result score 14s tx run data get storage llm params.ffn_w.14s
execute store result score 15b tx run data get storage llm params.ffn_w.15b
execute store result score 15e tx run data get storage llm params.ffn_w.15e
execute store result score 15s tx run data get storage llm params.ffn_w.15s
execute store result score 16b tx run data get storage llm params.ffn_w.16b
execute store result score 16e tx run data get storage llm params.ffn_w.16e
execute store result score 16s tx run data get storage llm params.ffn_w.16s
execute store result score 17b tx run data get storage llm params.ffn_w.17b
execute store result score 17e tx run data get storage llm params.ffn_w.17e
execute store result score 17s tx run data get storage llm params.ffn_w.17s
execute store result score 18b tx run data get storage llm params.ffn_w.18b
execute store result score 18e tx run data get storage llm params.ffn_w.18e
execute store result score 18s tx run data get storage llm params.ffn_w.18s
execute store result score 19b tx run data get storage llm params.ffn_w.19b
execute store result score 19e tx run data get storage llm params.ffn_w.19e
execute store result score 19s tx run data get storage llm params.ffn_w.19s
execute store result score 20b tx run data get storage llm params.ffn_w.20b
execute store result score 20e tx run data get storage llm params.ffn_w.20e
execute store result score 20s tx run data get storage llm params.ffn_w.20s
execute store result score 21b tx run data get storage llm params.ffn_w.21b
execute store result score 21e tx run data get storage llm params.ffn_w.21e
execute store result score 21s tx run data get storage llm params.ffn_w.21s
execute store result score 22b tx run data get storage llm params.ffn_w.22b
execute store result score 22e tx run data get storage llm params.ffn_w.22e
execute store result score 22s tx run data get storage llm params.ffn_w.22s
execute store result score 23b tx run data get storage llm params.ffn_w.23b
execute store result score 23e tx run data get storage llm params.ffn_w.23e
execute store result score 23s tx run data get storage llm params.ffn_w.23s
execute store result score 24b tx run data get storage llm params.ffn_w.24b
execute store result score 24e tx run data get storage llm params.ffn_w.24e
execute store result score 24s tx run data get storage llm params.ffn_w.24s
execute store result score 25b tx run data get storage llm params.ffn_w.25b
execute store result score 25e tx run data get storage llm params.ffn_w.25e
execute store result score 25s tx run data get storage llm params.ffn_w.25s
execute store result score 26b tx run data get storage llm params.ffn_w.26b
execute store result score 26e tx run data get storage llm params.ffn_w.26e
execute store result score 26s tx run data get storage llm params.ffn_w.26s
execute store result score 27b tx run data get storage llm params.ffn_w.27b
execute store result score 27e tx run data get storage llm params.ffn_w.27e
execute store result score 27s tx run data get storage llm params.ffn_w.27s
execute store result score 28b tx run data get storage llm params.ffn_w.28b
execute store result score 28e tx run data get storage llm params.ffn_w.28e
execute store result score 28s tx run data get storage llm params.ffn_w.28s
execute store result score 29b tx run data get storage llm params.ffn_w.29b
execute store result score 29e tx run data get storage llm params.ffn_w.29e
execute store result score 29s tx run data get storage llm params.ffn_w.29s
execute store result score 30b tx run data get storage llm params.ffn_w.30b
execute store result score 30e tx run data get storage llm params.ffn_w.30e
execute store result score 30s tx run data get storage llm params.ffn_w.30s
execute store result score 31b tx run data get storage llm params.ffn_w.31b
execute store result score 31e tx run data get storage llm params.ffn_w.31e
execute store result score 31s tx run data get storage llm params.ffn_w.31s
execute store result score 32b tx run data get storage llm params.ffn_w.32b
execute store result score 32e tx run data get storage llm params.ffn_w.32e
execute store result score 32s tx run data get storage llm params.ffn_w.32s
execute store result score 33b tx run data get storage llm params.ffn_w.33b
execute store result score 33e tx run data get storage llm params.ffn_w.33e
execute store result score 33s tx run data get storage llm params.ffn_w.33s
execute store result score 34b tx run data get storage llm params.ffn_w.34b
execute store result score 34e tx run data get storage llm params.ffn_w.34e
execute store result score 34s tx run data get storage llm params.ffn_w.34s
execute store result score 35b tx run data get storage llm params.ffn_w.35b
execute store result score 35e tx run data get storage llm params.ffn_w.35e
execute store result score 35s tx run data get storage llm params.ffn_w.35s
execute store result score 36b tx run data get storage llm params.ffn_w.36b
execute store result score 36e tx run data get storage llm params.ffn_w.36e
execute store result score 36s tx run data get storage llm params.ffn_w.36s
execute store result score 37b tx run data get storage llm params.ffn_w.37b
execute store result score 37e tx run data get storage llm params.ffn_w.37e
execute store result score 37s tx run data get storage llm params.ffn_w.37s
execute store result score 38b tx run data get storage llm params.ffn_w.38b
execute store result score 38e tx run data get storage llm params.ffn_w.38e
execute store result score 38s tx run data get storage llm params.ffn_w.38s
execute store result score 39b tx run data get storage llm params.ffn_w.39b
execute store result score 39e tx run data get storage llm params.ffn_w.39e
execute store result score 39s tx run data get storage llm params.ffn_w.39s
execute store result score 40b tx run data get storage llm params.ffn_w.40b
execute store result score 40e tx run data get storage llm params.ffn_w.40e
execute store result score 40s tx run data get storage llm params.ffn_w.40s
execute store result score 41b tx run data get storage llm params.ffn_w.41b
execute store result score 41e tx run data get storage llm params.ffn_w.41e
execute store result score 41s tx run data get storage llm params.ffn_w.41s
execute store result score 42b tx run data get storage llm params.ffn_w.42b
execute store result score 42e tx run data get storage llm params.ffn_w.42e
execute store result score 42s tx run data get storage llm params.ffn_w.42s
execute store result score 43b tx run data get storage llm params.ffn_w.43b
execute store result score 43e tx run data get storage llm params.ffn_w.43e
execute store result score 43s tx run data get storage llm params.ffn_w.43s
execute store result score 44b tx run data get storage llm params.ffn_w.44b
execute store result score 44e tx run data get storage llm params.ffn_w.44e
execute store result score 44s tx run data get storage llm params.ffn_w.44s
execute store result score 45b tx run data get storage llm params.ffn_w.45b
execute store result score 45e tx run data get storage llm params.ffn_w.45e
execute store result score 45s tx run data get storage llm params.ffn_w.45s
execute store result score 46b tx run data get storage llm params.ffn_w.46b
execute store result score 46e tx run data get storage llm params.ffn_w.46e
execute store result score 46s tx run data get storage llm params.ffn_w.46s
execute store result score 47b tx run data get storage llm params.ffn_w.47b
execute store result score 47e tx run data get storage llm params.ffn_w.47e
execute store result score 47s tx run data get storage llm params.ffn_w.47s
execute store result score 48b tx run data get storage llm params.ffn_w.48b
execute store result score 48e tx run data get storage llm params.ffn_w.48e
execute store result score 48s tx run data get storage llm params.ffn_w.48s
execute store result score 49b tx run data get storage llm params.ffn_w.49b
execute store result score 49e tx run data get storage llm params.ffn_w.49e
execute store result score 49s tx run data get storage llm params.ffn_w.49s
execute store result score 50b tx run data get storage llm params.ffn_w.50b
execute store result score 50e tx run data get storage llm params.ffn_w.50e
execute store result score 50s tx run data get storage llm params.ffn_w.50s
execute store result score 51b tx run data get storage llm params.ffn_w.51b
execute store result score 51e tx run data get storage llm params.ffn_w.51e
execute store result score 51s tx run data get storage llm params.ffn_w.51s
execute store result score 52b tx run data get storage llm params.ffn_w.52b
execute store result score 52e tx run data get storage llm params.ffn_w.52e
execute store result score 52s tx run data get storage llm params.ffn_w.52s
execute store result score 53b tx run data get storage llm params.ffn_w.53b
execute store result score 53e tx run data get storage llm params.ffn_w.53e
execute store result score 53s tx run data get storage llm params.ffn_w.53s
execute store result score 54b tx run data get storage llm params.ffn_w.54b
execute store result score 54e tx run data get storage llm params.ffn_w.54e
execute store result score 54s tx run data get storage llm params.ffn_w.54s
execute store result score 55b tx run data get storage llm params.ffn_w.55b
execute store result score 55e tx run data get storage llm params.ffn_w.55e
execute store result score 55s tx run data get storage llm params.ffn_w.55s
execute store result score 56b tx run data get storage llm params.ffn_w.56b
execute store result score 56e tx run data get storage llm params.ffn_w.56e
execute store result score 56s tx run data get storage llm params.ffn_w.56s
execute store result score 57b tx run data get storage llm params.ffn_w.57b
execute store result score 57e tx run data get storage llm params.ffn_w.57e
execute store result score 57s tx run data get storage llm params.ffn_w.57s
execute store result score 58b tx run data get storage llm params.ffn_w.58b
execute store result score 58e tx run data get storage llm params.ffn_w.58e
execute store result score 58s tx run data get storage llm params.ffn_w.58s
execute store result score 59b tx run data get storage llm params.ffn_w.59b
execute store result score 59e tx run data get storage llm params.ffn_w.59e
execute store result score 59s tx run data get storage llm params.ffn_w.59s
execute store result score 60b tx run data get storage llm params.ffn_w.60b
execute store result score 60e tx run data get storage llm params.ffn_w.60e
execute store result score 60s tx run data get storage llm params.ffn_w.60s
execute store result score 61b tx run data get storage llm params.ffn_w.61b
execute store result score 61e tx run data get storage llm params.ffn_w.61e
execute store result score 61s tx run data get storage llm params.ffn_w.61s
execute store result score 62b tx run data get storage llm params.ffn_w.62b
execute store result score 62e tx run data get storage llm params.ffn_w.62e
execute store result score 62s tx run data get storage llm params.ffn_w.62s
execute store result score 63b tx run data get storage llm params.ffn_w.63b
execute store result score 63e tx run data get storage llm params.ffn_w.63e
execute store result score 63s tx run data get storage llm params.ffn_w.63s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th"
data modify storage llm args.m set value "w1_0"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 6
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_0"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 7
function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_0"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 8
scoreboard players operation xb llm = 0b tx
scoreboard players operation xe llm = 0e tx
scoreboard players operation xs llm = 0s tx
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx
scoreboard players operation xe llm = 1e tx
scoreboard players operation xs llm = 1s tx
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx
scoreboard players operation xe llm = 2e tx
scoreboard players operation xs llm = 2s tx
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx
scoreboard players operation xe llm = 3e tx
scoreboard players operation xs llm = 3s tx
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx
scoreboard players operation xe llm = 4e tx
scoreboard players operation xs llm = 4s tx
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx
scoreboard players operation xe llm = 5e tx
scoreboard players operation xs llm = 5s tx
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx
scoreboard players operation xe llm = 6e tx
scoreboard players operation xs llm = 6s tx
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx
scoreboard players operation xe llm = 7e tx
scoreboard players operation xs llm = 7s tx
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx
scoreboard players operation xe llm = 8e tx
scoreboard players operation xs llm = 8s tx
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx
scoreboard players operation xe llm = 9e tx
scoreboard players operation xs llm = 9s tx
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx
scoreboard players operation xe llm = 10e tx
scoreboard players operation xs llm = 10s tx
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx
scoreboard players operation xe llm = 11e tx
scoreboard players operation xs llm = 11s tx
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx
scoreboard players operation xe llm = 12e tx
scoreboard players operation xs llm = 12s tx
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx
scoreboard players operation xe llm = 13e tx
scoreboard players operation xs llm = 13s tx
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx
scoreboard players operation xe llm = 14e tx
scoreboard players operation xs llm = 14s tx
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx
scoreboard players operation xe llm = 15e tx
scoreboard players operation xs llm = 15s tx
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx
scoreboard players operation xe llm = 16e tx
scoreboard players operation xs llm = 16s tx
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx
scoreboard players operation xe llm = 17e tx
scoreboard players operation xs llm = 17s tx
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx
scoreboard players operation xe llm = 18e tx
scoreboard players operation xs llm = 18s tx
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx
scoreboard players operation xe llm = 19e tx
scoreboard players operation xs llm = 19s tx
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx
scoreboard players operation xe llm = 20e tx
scoreboard players operation xs llm = 20s tx
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx
scoreboard players operation xe llm = 21e tx
scoreboard players operation xs llm = 21s tx
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx
scoreboard players operation xe llm = 22e tx
scoreboard players operation xs llm = 22s tx
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx
scoreboard players operation xe llm = 23e tx
scoreboard players operation xs llm = 23s tx
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx
scoreboard players operation xe llm = 24e tx
scoreboard players operation xs llm = 24s tx
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx
scoreboard players operation xe llm = 25e tx
scoreboard players operation xs llm = 25s tx
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx
scoreboard players operation xe llm = 26e tx
scoreboard players operation xs llm = 26s tx
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx
scoreboard players operation xe llm = 27e tx
scoreboard players operation xs llm = 27s tx
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx
scoreboard players operation xe llm = 28e tx
scoreboard players operation xs llm = 28s tx
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx
scoreboard players operation xe llm = 29e tx
scoreboard players operation xs llm = 29s tx
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx
scoreboard players operation xe llm = 30e tx
scoreboard players operation xs llm = 30s tx
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx
scoreboard players operation xe llm = 31e tx
scoreboard players operation xs llm = 31s tx
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx
scoreboard players operation xe llm = 32e tx
scoreboard players operation xs llm = 32s tx
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx
scoreboard players operation xe llm = 33e tx
scoreboard players operation xs llm = 33s tx
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx
scoreboard players operation xe llm = 34e tx
scoreboard players operation xs llm = 34s tx
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx
scoreboard players operation xe llm = 35e tx
scoreboard players operation xs llm = 35s tx
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx
scoreboard players operation xe llm = 36e tx
scoreboard players operation xs llm = 36s tx
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx
scoreboard players operation xe llm = 37e tx
scoreboard players operation xs llm = 37s tx
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx
scoreboard players operation xe llm = 38e tx
scoreboard players operation xs llm = 38s tx
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx
scoreboard players operation xe llm = 39e tx
scoreboard players operation xs llm = 39s tx
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx
scoreboard players operation xe llm = 40e tx
scoreboard players operation xs llm = 40s tx
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx
scoreboard players operation xe llm = 41e tx
scoreboard players operation xs llm = 41s tx
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx
scoreboard players operation xe llm = 42e tx
scoreboard players operation xs llm = 42s tx
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx
scoreboard players operation xe llm = 43e tx
scoreboard players operation xs llm = 43s tx
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx
scoreboard players operation xe llm = 44e tx
scoreboard players operation xs llm = 44s tx
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx
scoreboard players operation xe llm = 45e tx
scoreboard players operation xs llm = 45s tx
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx
scoreboard players operation xe llm = 46e tx
scoreboard players operation xs llm = 46s tx
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx
scoreboard players operation xe llm = 47e tx
scoreboard players operation xs llm = 47s tx
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx
scoreboard players operation xe llm = 48e tx
scoreboard players operation xs llm = 48s tx
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx
scoreboard players operation xe llm = 49e tx
scoreboard players operation xs llm = 49s tx
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx
scoreboard players operation xe llm = 50e tx
scoreboard players operation xs llm = 50s tx
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx
scoreboard players operation xe llm = 51e tx
scoreboard players operation xs llm = 51s tx
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx
scoreboard players operation xe llm = 52e tx
scoreboard players operation xs llm = 52s tx
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx
scoreboard players operation xe llm = 53e tx
scoreboard players operation xs llm = 53s tx
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx
scoreboard players operation xe llm = 54e tx
scoreboard players operation xs llm = 54s tx
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx
scoreboard players operation xe llm = 55e tx
scoreboard players operation xs llm = 55s tx
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx
scoreboard players operation xe llm = 56e tx
scoreboard players operation xs llm = 56s tx
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx
scoreboard players operation xe llm = 57e tx
scoreboard players operation xs llm = 57s tx
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx
scoreboard players operation xe llm = 58e tx
scoreboard players operation xs llm = 58s tx
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx
scoreboard players operation xe llm = 59e tx
scoreboard players operation xs llm = 59s tx
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx
scoreboard players operation xe llm = 60e tx
scoreboard players operation xs llm = 60s tx
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx
scoreboard players operation xe llm = 61e tx
scoreboard players operation xs llm = 61s tx
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx
scoreboard players operation xe llm = 62e tx
scoreboard players operation xs llm = 62s tx
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx
scoreboard players operation xe llm = 63e tx
scoreboard players operation xs llm = 63s tx
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.64b
execute store result score 0e tx run data get storage llm params.att_w.64e
execute store result score 0s tx run data get storage llm params.att_w.64s
execute store result score 1b tx run data get storage llm params.att_w.65b
execute store result score 1e tx run data get storage llm params.att_w.65e
execute store result score 1s tx run data get storage llm params.att_w.65s
execute store result score 2b tx run data get storage llm params.att_w.66b
execute store result score 2e tx run data get storage llm params.att_w.66e
execute store result score 2s tx run data get storage llm params.att_w.66s
execute store result score 3b tx run data get storage llm params.att_w.67b
execute store result score 3e tx run data get storage llm params.att_w.67e
execute store result score 3s tx run data get storage llm params.att_w.67s
execute store result score 4b tx run data get storage llm params.att_w.68b
execute store result score 4e tx run data get storage llm params.att_w.68e
execute store result score 4s tx run data get storage llm params.att_w.68s
execute store result score 5b tx run data get storage llm params.att_w.69b
execute store result score 5e tx run data get storage llm params.att_w.69e
execute store result score 5s tx run data get storage llm params.att_w.69s
execute store result score 6b tx run data get storage llm params.att_w.70b
execute store result score 6e tx run data get storage llm params.att_w.70e
execute store result score 6s tx run data get storage llm params.att_w.70s
execute store result score 7b tx run data get storage llm params.att_w.71b
execute store result score 7e tx run data get storage llm params.att_w.71e
execute store result score 7s tx run data get storage llm params.att_w.71s
execute store result score 8b tx run data get storage llm params.att_w.72b
execute store result score 8e tx run data get storage llm params.att_w.72e
execute store result score 8s tx run data get storage llm params.att_w.72s
execute store result score 9b tx run data get storage llm params.att_w.73b
execute store result score 9e tx run data get storage llm params.att_w.73e
execute store result score 9s tx run data get storage llm params.att_w.73s
execute store result score 10b tx run data get storage llm params.att_w.74b
execute store result score 10e tx run data get storage llm params.att_w.74e
execute store result score 10s tx run data get storage llm params.att_w.74s
execute store result score 11b tx run data get storage llm params.att_w.75b
execute store result score 11e tx run data get storage llm params.att_w.75e
execute store result score 11s tx run data get storage llm params.att_w.75s
execute store result score 12b tx run data get storage llm params.att_w.76b
execute store result score 12e tx run data get storage llm params.att_w.76e
execute store result score 12s tx run data get storage llm params.att_w.76s
execute store result score 13b tx run data get storage llm params.att_w.77b
execute store result score 13e tx run data get storage llm params.att_w.77e
execute store result score 13s tx run data get storage llm params.att_w.77s
execute store result score 14b tx run data get storage llm params.att_w.78b
execute store result score 14e tx run data get storage llm params.att_w.78e
execute store result score 14s tx run data get storage llm params.att_w.78s
execute store result score 15b tx run data get storage llm params.att_w.79b
execute store result score 15e tx run data get storage llm params.att_w.79e
execute store result score 15s tx run data get storage llm params.att_w.79s
execute store result score 16b tx run data get storage llm params.att_w.80b
execute store result score 16e tx run data get storage llm params.att_w.80e
execute store result score 16s tx run data get storage llm params.att_w.80s
execute store result score 17b tx run data get storage llm params.att_w.81b
execute store result score 17e tx run data get storage llm params.att_w.81e
execute store result score 17s tx run data get storage llm params.att_w.81s
execute store result score 18b tx run data get storage llm params.att_w.82b
execute store result score 18e tx run data get storage llm params.att_w.82e
execute store result score 18s tx run data get storage llm params.att_w.82s
execute store result score 19b tx run data get storage llm params.att_w.83b
execute store result score 19e tx run data get storage llm params.att_w.83e
execute store result score 19s tx run data get storage llm params.att_w.83s
execute store result score 20b tx run data get storage llm params.att_w.84b
execute store result score 20e tx run data get storage llm params.att_w.84e
execute store result score 20s tx run data get storage llm params.att_w.84s
execute store result score 21b tx run data get storage llm params.att_w.85b
execute store result score 21e tx run data get storage llm params.att_w.85e
execute store result score 21s tx run data get storage llm params.att_w.85s
execute store result score 22b tx run data get storage llm params.att_w.86b
execute store result score 22e tx run data get storage llm params.att_w.86e
execute store result score 22s tx run data get storage llm params.att_w.86s
execute store result score 23b tx run data get storage llm params.att_w.87b
execute store result score 23e tx run data get storage llm params.att_w.87e
execute store result score 23s tx run data get storage llm params.att_w.87s
execute store result score 24b tx run data get storage llm params.att_w.88b
execute store result score 24e tx run data get storage llm params.att_w.88e
execute store result score 24s tx run data get storage llm params.att_w.88s
execute store result score 25b tx run data get storage llm params.att_w.89b
execute store result score 25e tx run data get storage llm params.att_w.89e
execute store result score 25s tx run data get storage llm params.att_w.89s
execute store result score 26b tx run data get storage llm params.att_w.90b
execute store result score 26e tx run data get storage llm params.att_w.90e
execute store result score 26s tx run data get storage llm params.att_w.90s
execute store result score 27b tx run data get storage llm params.att_w.91b
execute store result score 27e tx run data get storage llm params.att_w.91e
execute store result score 27s tx run data get storage llm params.att_w.91s
execute store result score 28b tx run data get storage llm params.att_w.92b
execute store result score 28e tx run data get storage llm params.att_w.92e
execute store result score 28s tx run data get storage llm params.att_w.92s
execute store result score 29b tx run data get storage llm params.att_w.93b
execute store result score 29e tx run data get storage llm params.att_w.93e
execute store result score 29s tx run data get storage llm params.att_w.93s
execute store result score 30b tx run data get storage llm params.att_w.94b
execute store result score 30e tx run data get storage llm params.att_w.94e
execute store result score 30s tx run data get storage llm params.att_w.94s
execute store result score 31b tx run data get storage llm params.att_w.95b
execute store result score 31e tx run data get storage llm params.att_w.95e
execute store result score 31s tx run data get storage llm params.att_w.95s
execute store result score 32b tx run data get storage llm params.att_w.96b
execute store result score 32e tx run data get storage llm params.att_w.96e
execute store result score 32s tx run data get storage llm params.att_w.96s
execute store result score 33b tx run data get storage llm params.att_w.97b
execute store result score 33e tx run data get storage llm params.att_w.97e
execute store result score 33s tx run data get storage llm params.att_w.97s
execute store result score 34b tx run data get storage llm params.att_w.98b
execute store result score 34e tx run data get storage llm params.att_w.98e
execute store result score 34s tx run data get storage llm params.att_w.98s
execute store result score 35b tx run data get storage llm params.att_w.99b
execute store result score 35e tx run data get storage llm params.att_w.99e
execute store result score 35s tx run data get storage llm params.att_w.99s
execute store result score 36b tx run data get storage llm params.att_w.100b
execute store result score 36e tx run data get storage llm params.att_w.100e
execute store result score 36s tx run data get storage llm params.att_w.100s
execute store result score 37b tx run data get storage llm params.att_w.101b
execute store result score 37e tx run data get storage llm params.att_w.101e
execute store result score 37s tx run data get storage llm params.att_w.101s
execute store result score 38b tx run data get storage llm params.att_w.102b
execute store result score 38e tx run data get storage llm params.att_w.102e
execute store result score 38s tx run data get storage llm params.att_w.102s
execute store result score 39b tx run data get storage llm params.att_w.103b
execute store result score 39e tx run data get storage llm params.att_w.103e
execute store result score 39s tx run data get storage llm params.att_w.103s
execute store result score 40b tx run data get storage llm params.att_w.104b
execute store result score 40e tx run data get storage llm params.att_w.104e
execute store result score 40s tx run data get storage llm params.att_w.104s
execute store result score 41b tx run data get storage llm params.att_w.105b
execute store result score 41e tx run data get storage llm params.att_w.105e
execute store result score 41s tx run data get storage llm params.att_w.105s
execute store result score 42b tx run data get storage llm params.att_w.106b
execute store result score 42e tx run data get storage llm params.att_w.106e
execute store result score 42s tx run data get storage llm params.att_w.106s
execute store result score 43b tx run data get storage llm params.att_w.107b
execute store result score 43e tx run data get storage llm params.att_w.107e
execute store result score 43s tx run data get storage llm params.att_w.107s
execute store result score 44b tx run data get storage llm params.att_w.108b
execute store result score 44e tx run data get storage llm params.att_w.108e
execute store result score 44s tx run data get storage llm params.att_w.108s
execute store result score 45b tx run data get storage llm params.att_w.109b
execute store result score 45e tx run data get storage llm params.att_w.109e
execute store result score 45s tx run data get storage llm params.att_w.109s
execute store result score 46b tx run data get storage llm params.att_w.110b
execute store result score 46e tx run data get storage llm params.att_w.110e
execute store result score 46s tx run data get storage llm params.att_w.110s
execute store result score 47b tx run data get storage llm params.att_w.111b
execute store result score 47e tx run data get storage llm params.att_w.111e
execute store result score 47s tx run data get storage llm params.att_w.111s
execute store result score 48b tx run data get storage llm params.att_w.112b
execute store result score 48e tx run data get storage llm params.att_w.112e
execute store result score 48s tx run data get storage llm params.att_w.112s
execute store result score 49b tx run data get storage llm params.att_w.113b
execute store result score 49e tx run data get storage llm params.att_w.113e
execute store result score 49s tx run data get storage llm params.att_w.113s
execute store result score 50b tx run data get storage llm params.att_w.114b
execute store result score 50e tx run data get storage llm params.att_w.114e
execute store result score 50s tx run data get storage llm params.att_w.114s
execute store result score 51b tx run data get storage llm params.att_w.115b
execute store result score 51e tx run data get storage llm params.att_w.115e
execute store result score 51s tx run data get storage llm params.att_w.115s
execute store result score 52b tx run data get storage llm params.att_w.116b
execute store result score 52e tx run data get storage llm params.att_w.116e
execute store result score 52s tx run data get storage llm params.att_w.116s
execute store result score 53b tx run data get storage llm params.att_w.117b
execute store result score 53e tx run data get storage llm params.att_w.117e
execute store result score 53s tx run data get storage llm params.att_w.117s
execute store result score 54b tx run data get storage llm params.att_w.118b
execute store result score 54e tx run data get storage llm params.att_w.118e
execute store result score 54s tx run data get storage llm params.att_w.118s
execute store result score 55b tx run data get storage llm params.att_w.119b
execute store result score 55e tx run data get storage llm params.att_w.119e
execute store result score 55s tx run data get storage llm params.att_w.119s
execute store result score 56b tx run data get storage llm params.att_w.120b
execute store result score 56e tx run data get storage llm params.att_w.120e
execute store result score 56s tx run data get storage llm params.att_w.120s
execute store result score 57b tx run data get storage llm params.att_w.121b
execute store result score 57e tx run data get storage llm params.att_w.121e
execute store result score 57s tx run data get storage llm params.att_w.121s
execute store result score 58b tx run data get storage llm params.att_w.122b
execute store result score 58e tx run data get storage llm params.att_w.122e
execute store result score 58s tx run data get storage llm params.att_w.122s
execute store result score 59b tx run data get storage llm params.att_w.123b
execute store result score 59e tx run data get storage llm params.att_w.123e
execute store result score 59s tx run data get storage llm params.att_w.123s
execute store result score 60b tx run data get storage llm params.att_w.124b
execute store result score 60e tx run data get storage llm params.att_w.124e
execute store result score 60s tx run data get storage llm params.att_w.124s
execute store result score 61b tx run data get storage llm params.att_w.125b
execute store result score 61e tx run data get storage llm params.att_w.125e
execute store result score 61s tx run data get storage llm params.att_w.125s
execute store result score 62b tx run data get storage llm params.att_w.126b
execute store result score 62e tx run data get storage llm params.att_w.126e
execute store result score 62s tx run data get storage llm params.att_w.126s
execute store result score 63b tx run data get storage llm params.att_w.127b
execute store result score 63e tx run data get storage llm params.att_w.127e
execute store result score 63s tx run data get storage llm params.att_w.127s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_1"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 9
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_1"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 10
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_1"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 11
function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32768
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32769
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32770
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32771
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32772
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32773
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32774
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32775
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32776
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32777
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32778
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32779
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32780
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32781
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32782
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32783
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32784
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32785
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32786
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32787
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32788
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32789
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32790
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32791
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32792
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32793
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32794
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32795
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32796
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32797
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32798
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32799
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:ctxwindow
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_0_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_0_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_0_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_0_3
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_0_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_1_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_1_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_1_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_1_3
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_1_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_2_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_2_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_2_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_2_3
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_2_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_3_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_3_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_3_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_3_3
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_3_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_4_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_4_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_4_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_4_3
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_4_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_5_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_5_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_5_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_5_3
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_5_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_6_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_6_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_6_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_6_3
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_6_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_7_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_1_7_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_7_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_1_7_3
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_1_7_4
bossbar set progress value 12
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_1"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 13
scoreboard players operation xb llm = 0b tx2
scoreboard players operation xe llm = 0e tx2
scoreboard players operation xs llm = 0s tx2
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx2
scoreboard players operation xe llm = 1e tx2
scoreboard players operation xs llm = 1s tx2
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx2
scoreboard players operation xe llm = 2e tx2
scoreboard players operation xs llm = 2s tx2
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx2
scoreboard players operation xe llm = 3e tx2
scoreboard players operation xs llm = 3s tx2
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx2
scoreboard players operation xe llm = 4e tx2
scoreboard players operation xs llm = 4s tx2
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx2
scoreboard players operation xe llm = 5e tx2
scoreboard players operation xs llm = 5s tx2
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx2
scoreboard players operation xe llm = 6e tx2
scoreboard players operation xs llm = 6s tx2
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx2
scoreboard players operation xe llm = 7e tx2
scoreboard players operation xs llm = 7s tx2
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx2
scoreboard players operation xe llm = 8e tx2
scoreboard players operation xs llm = 8s tx2
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx2
scoreboard players operation xe llm = 9e tx2
scoreboard players operation xs llm = 9s tx2
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx2
scoreboard players operation xe llm = 10e tx2
scoreboard players operation xs llm = 10s tx2
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx2
scoreboard players operation xe llm = 11e tx2
scoreboard players operation xs llm = 11s tx2
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx2
scoreboard players operation xe llm = 12e tx2
scoreboard players operation xs llm = 12s tx2
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx2
scoreboard players operation xe llm = 13e tx2
scoreboard players operation xs llm = 13s tx2
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx2
scoreboard players operation xe llm = 14e tx2
scoreboard players operation xs llm = 14s tx2
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx2
scoreboard players operation xe llm = 15e tx2
scoreboard players operation xs llm = 15s tx2
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx2
scoreboard players operation xe llm = 16e tx2
scoreboard players operation xs llm = 16s tx2
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx2
scoreboard players operation xe llm = 17e tx2
scoreboard players operation xs llm = 17s tx2
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx2
scoreboard players operation xe llm = 18e tx2
scoreboard players operation xs llm = 18s tx2
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx2
scoreboard players operation xe llm = 19e tx2
scoreboard players operation xs llm = 19s tx2
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx2
scoreboard players operation xe llm = 20e tx2
scoreboard players operation xs llm = 20s tx2
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx2
scoreboard players operation xe llm = 21e tx2
scoreboard players operation xs llm = 21s tx2
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx2
scoreboard players operation xe llm = 22e tx2
scoreboard players operation xs llm = 22s tx2
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx2
scoreboard players operation xe llm = 23e tx2
scoreboard players operation xs llm = 23s tx2
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx2
scoreboard players operation xe llm = 24e tx2
scoreboard players operation xs llm = 24s tx2
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx2
scoreboard players operation xe llm = 25e tx2
scoreboard players operation xs llm = 25s tx2
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx2
scoreboard players operation xe llm = 26e tx2
scoreboard players operation xs llm = 26s tx2
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx2
scoreboard players operation xe llm = 27e tx2
scoreboard players operation xs llm = 27s tx2
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx2
scoreboard players operation xe llm = 28e tx2
scoreboard players operation xs llm = 28s tx2
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx2
scoreboard players operation xe llm = 29e tx2
scoreboard players operation xs llm = 29s tx2
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx2
scoreboard players operation xe llm = 30e tx2
scoreboard players operation xs llm = 30s tx2
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx2
scoreboard players operation xe llm = 31e tx2
scoreboard players operation xs llm = 31s tx2
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx2
scoreboard players operation xe llm = 32e tx2
scoreboard players operation xs llm = 32s tx2
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx2
scoreboard players operation xe llm = 33e tx2
scoreboard players operation xs llm = 33s tx2
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx2
scoreboard players operation xe llm = 34e tx2
scoreboard players operation xs llm = 34s tx2
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx2
scoreboard players operation xe llm = 35e tx2
scoreboard players operation xs llm = 35s tx2
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx2
scoreboard players operation xe llm = 36e tx2
scoreboard players operation xs llm = 36s tx2
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx2
scoreboard players operation xe llm = 37e tx2
scoreboard players operation xs llm = 37s tx2
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx2
scoreboard players operation xe llm = 38e tx2
scoreboard players operation xs llm = 38s tx2
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx2
scoreboard players operation xe llm = 39e tx2
scoreboard players operation xs llm = 39s tx2
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx2
scoreboard players operation xe llm = 40e tx2
scoreboard players operation xs llm = 40s tx2
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx2
scoreboard players operation xe llm = 41e tx2
scoreboard players operation xs llm = 41s tx2
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx2
scoreboard players operation xe llm = 42e tx2
scoreboard players operation xs llm = 42s tx2
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx2
scoreboard players operation xe llm = 43e tx2
scoreboard players operation xs llm = 43s tx2
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx2
scoreboard players operation xe llm = 44e tx2
scoreboard players operation xs llm = 44s tx2
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx2
scoreboard players operation xe llm = 45e tx2
scoreboard players operation xs llm = 45s tx2
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx2
scoreboard players operation xe llm = 46e tx2
scoreboard players operation xs llm = 46s tx2
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx2
scoreboard players operation xe llm = 47e tx2
scoreboard players operation xs llm = 47s tx2
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx2
scoreboard players operation xe llm = 48e tx2
scoreboard players operation xs llm = 48s tx2
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx2
scoreboard players operation xe llm = 49e tx2
scoreboard players operation xs llm = 49s tx2
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx2
scoreboard players operation xe llm = 50e tx2
scoreboard players operation xs llm = 50s tx2
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx2
scoreboard players operation xe llm = 51e tx2
scoreboard players operation xs llm = 51s tx2
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx2
scoreboard players operation xe llm = 52e tx2
scoreboard players operation xs llm = 52s tx2
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx2
scoreboard players operation xe llm = 53e tx2
scoreboard players operation xs llm = 53s tx2
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx2
scoreboard players operation xe llm = 54e tx2
scoreboard players operation xs llm = 54s tx2
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx2
scoreboard players operation xe llm = 55e tx2
scoreboard players operation xs llm = 55s tx2
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx2
scoreboard players operation xe llm = 56e tx2
scoreboard players operation xs llm = 56s tx2
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx2
scoreboard players operation xe llm = 57e tx2
scoreboard players operation xs llm = 57s tx2
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx2
scoreboard players operation xe llm = 58e tx2
scoreboard players operation xs llm = 58s tx2
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx2
scoreboard players operation xe llm = 59e tx2
scoreboard players operation xs llm = 59s tx2
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx2
scoreboard players operation xe llm = 60e tx2
scoreboard players operation xs llm = 60s tx2
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx2
scoreboard players operation xe llm = 61e tx2
scoreboard players operation xs llm = 61s tx2
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx2
scoreboard players operation xe llm = 62e tx2
scoreboard players operation xs llm = 62s tx2
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx2
scoreboard players operation xe llm = 63e tx2
scoreboard players operation xs llm = 63s tx2
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.ffn_w.64b
execute store result score 0e tx run data get storage llm params.ffn_w.64e
execute store result score 0s tx run data get storage llm params.ffn_w.64s
execute store result score 1b tx run data get storage llm params.ffn_w.65b
execute store result score 1e tx run data get storage llm params.ffn_w.65e
execute store result score 1s tx run data get storage llm params.ffn_w.65s
execute store result score 2b tx run data get storage llm params.ffn_w.66b
execute store result score 2e tx run data get storage llm params.ffn_w.66e
execute store result score 2s tx run data get storage llm params.ffn_w.66s
execute store result score 3b tx run data get storage llm params.ffn_w.67b
execute store result score 3e tx run data get storage llm params.ffn_w.67e
execute store result score 3s tx run data get storage llm params.ffn_w.67s
execute store result score 4b tx run data get storage llm params.ffn_w.68b
execute store result score 4e tx run data get storage llm params.ffn_w.68e
execute store result score 4s tx run data get storage llm params.ffn_w.68s
execute store result score 5b tx run data get storage llm params.ffn_w.69b
execute store result score 5e tx run data get storage llm params.ffn_w.69e
execute store result score 5s tx run data get storage llm params.ffn_w.69s
execute store result score 6b tx run data get storage llm params.ffn_w.70b
execute store result score 6e tx run data get storage llm params.ffn_w.70e
execute store result score 6s tx run data get storage llm params.ffn_w.70s
execute store result score 7b tx run data get storage llm params.ffn_w.71b
execute store result score 7e tx run data get storage llm params.ffn_w.71e
execute store result score 7s tx run data get storage llm params.ffn_w.71s
execute store result score 8b tx run data get storage llm params.ffn_w.72b
execute store result score 8e tx run data get storage llm params.ffn_w.72e
execute store result score 8s tx run data get storage llm params.ffn_w.72s
execute store result score 9b tx run data get storage llm params.ffn_w.73b
execute store result score 9e tx run data get storage llm params.ffn_w.73e
execute store result score 9s tx run data get storage llm params.ffn_w.73s
execute store result score 10b tx run data get storage llm params.ffn_w.74b
execute store result score 10e tx run data get storage llm params.ffn_w.74e
execute store result score 10s tx run data get storage llm params.ffn_w.74s
execute store result score 11b tx run data get storage llm params.ffn_w.75b
execute store result score 11e tx run data get storage llm params.ffn_w.75e
execute store result score 11s tx run data get storage llm params.ffn_w.75s
execute store result score 12b tx run data get storage llm params.ffn_w.76b
execute store result score 12e tx run data get storage llm params.ffn_w.76e
execute store result score 12s tx run data get storage llm params.ffn_w.76s
execute store result score 13b tx run data get storage llm params.ffn_w.77b
execute store result score 13e tx run data get storage llm params.ffn_w.77e
execute store result score 13s tx run data get storage llm params.ffn_w.77s
execute store result score 14b tx run data get storage llm params.ffn_w.78b
execute store result score 14e tx run data get storage llm params.ffn_w.78e
execute store result score 14s tx run data get storage llm params.ffn_w.78s
execute store result score 15b tx run data get storage llm params.ffn_w.79b
execute store result score 15e tx run data get storage llm params.ffn_w.79e
execute store result score 15s tx run data get storage llm params.ffn_w.79s
execute store result score 16b tx run data get storage llm params.ffn_w.80b
execute store result score 16e tx run data get storage llm params.ffn_w.80e
execute store result score 16s tx run data get storage llm params.ffn_w.80s
execute store result score 17b tx run data get storage llm params.ffn_w.81b
execute store result score 17e tx run data get storage llm params.ffn_w.81e
execute store result score 17s tx run data get storage llm params.ffn_w.81s
execute store result score 18b tx run data get storage llm params.ffn_w.82b
execute store result score 18e tx run data get storage llm params.ffn_w.82e
execute store result score 18s tx run data get storage llm params.ffn_w.82s
execute store result score 19b tx run data get storage llm params.ffn_w.83b
execute store result score 19e tx run data get storage llm params.ffn_w.83e
execute store result score 19s tx run data get storage llm params.ffn_w.83s
execute store result score 20b tx run data get storage llm params.ffn_w.84b
execute store result score 20e tx run data get storage llm params.ffn_w.84e
execute store result score 20s tx run data get storage llm params.ffn_w.84s
execute store result score 21b tx run data get storage llm params.ffn_w.85b
execute store result score 21e tx run data get storage llm params.ffn_w.85e
execute store result score 21s tx run data get storage llm params.ffn_w.85s
execute store result score 22b tx run data get storage llm params.ffn_w.86b
execute store result score 22e tx run data get storage llm params.ffn_w.86e
execute store result score 22s tx run data get storage llm params.ffn_w.86s
execute store result score 23b tx run data get storage llm params.ffn_w.87b
execute store result score 23e tx run data get storage llm params.ffn_w.87e
execute store result score 23s tx run data get storage llm params.ffn_w.87s
execute store result score 24b tx run data get storage llm params.ffn_w.88b
execute store result score 24e tx run data get storage llm params.ffn_w.88e
execute store result score 24s tx run data get storage llm params.ffn_w.88s
execute store result score 25b tx run data get storage llm params.ffn_w.89b
execute store result score 25e tx run data get storage llm params.ffn_w.89e
execute store result score 25s tx run data get storage llm params.ffn_w.89s
execute store result score 26b tx run data get storage llm params.ffn_w.90b
execute store result score 26e tx run data get storage llm params.ffn_w.90e
execute store result score 26s tx run data get storage llm params.ffn_w.90s
execute store result score 27b tx run data get storage llm params.ffn_w.91b
execute store result score 27e tx run data get storage llm params.ffn_w.91e
execute store result score 27s tx run data get storage llm params.ffn_w.91s
execute store result score 28b tx run data get storage llm params.ffn_w.92b
execute store result score 28e tx run data get storage llm params.ffn_w.92e
execute store result score 28s tx run data get storage llm params.ffn_w.92s
execute store result score 29b tx run data get storage llm params.ffn_w.93b
execute store result score 29e tx run data get storage llm params.ffn_w.93e
execute store result score 29s tx run data get storage llm params.ffn_w.93s
execute store result score 30b tx run data get storage llm params.ffn_w.94b
execute store result score 30e tx run data get storage llm params.ffn_w.94e
execute store result score 30s tx run data get storage llm params.ffn_w.94s
execute store result score 31b tx run data get storage llm params.ffn_w.95b
execute store result score 31e tx run data get storage llm params.ffn_w.95e
execute store result score 31s tx run data get storage llm params.ffn_w.95s
execute store result score 32b tx run data get storage llm params.ffn_w.96b
execute store result score 32e tx run data get storage llm params.ffn_w.96e
execute store result score 32s tx run data get storage llm params.ffn_w.96s
execute store result score 33b tx run data get storage llm params.ffn_w.97b
execute store result score 33e tx run data get storage llm params.ffn_w.97e
execute store result score 33s tx run data get storage llm params.ffn_w.97s
execute store result score 34b tx run data get storage llm params.ffn_w.98b
execute store result score 34e tx run data get storage llm params.ffn_w.98e
execute store result score 34s tx run data get storage llm params.ffn_w.98s
execute store result score 35b tx run data get storage llm params.ffn_w.99b
execute store result score 35e tx run data get storage llm params.ffn_w.99e
execute store result score 35s tx run data get storage llm params.ffn_w.99s
execute store result score 36b tx run data get storage llm params.ffn_w.100b
execute store result score 36e tx run data get storage llm params.ffn_w.100e
execute store result score 36s tx run data get storage llm params.ffn_w.100s
execute store result score 37b tx run data get storage llm params.ffn_w.101b
execute store result score 37e tx run data get storage llm params.ffn_w.101e
execute store result score 37s tx run data get storage llm params.ffn_w.101s
execute store result score 38b tx run data get storage llm params.ffn_w.102b
execute store result score 38e tx run data get storage llm params.ffn_w.102e
execute store result score 38s tx run data get storage llm params.ffn_w.102s
execute store result score 39b tx run data get storage llm params.ffn_w.103b
execute store result score 39e tx run data get storage llm params.ffn_w.103e
execute store result score 39s tx run data get storage llm params.ffn_w.103s
execute store result score 40b tx run data get storage llm params.ffn_w.104b
execute store result score 40e tx run data get storage llm params.ffn_w.104e
execute store result score 40s tx run data get storage llm params.ffn_w.104s
execute store result score 41b tx run data get storage llm params.ffn_w.105b
execute store result score 41e tx run data get storage llm params.ffn_w.105e
execute store result score 41s tx run data get storage llm params.ffn_w.105s
execute store result score 42b tx run data get storage llm params.ffn_w.106b
execute store result score 42e tx run data get storage llm params.ffn_w.106e
execute store result score 42s tx run data get storage llm params.ffn_w.106s
execute store result score 43b tx run data get storage llm params.ffn_w.107b
execute store result score 43e tx run data get storage llm params.ffn_w.107e
execute store result score 43s tx run data get storage llm params.ffn_w.107s
execute store result score 44b tx run data get storage llm params.ffn_w.108b
execute store result score 44e tx run data get storage llm params.ffn_w.108e
execute store result score 44s tx run data get storage llm params.ffn_w.108s
execute store result score 45b tx run data get storage llm params.ffn_w.109b
execute store result score 45e tx run data get storage llm params.ffn_w.109e
execute store result score 45s tx run data get storage llm params.ffn_w.109s
execute store result score 46b tx run data get storage llm params.ffn_w.110b
execute store result score 46e tx run data get storage llm params.ffn_w.110e
execute store result score 46s tx run data get storage llm params.ffn_w.110s
execute store result score 47b tx run data get storage llm params.ffn_w.111b
execute store result score 47e tx run data get storage llm params.ffn_w.111e
execute store result score 47s tx run data get storage llm params.ffn_w.111s
execute store result score 48b tx run data get storage llm params.ffn_w.112b
execute store result score 48e tx run data get storage llm params.ffn_w.112e
execute store result score 48s tx run data get storage llm params.ffn_w.112s
execute store result score 49b tx run data get storage llm params.ffn_w.113b
execute store result score 49e tx run data get storage llm params.ffn_w.113e
execute store result score 49s tx run data get storage llm params.ffn_w.113s
execute store result score 50b tx run data get storage llm params.ffn_w.114b
execute store result score 50e tx run data get storage llm params.ffn_w.114e
execute store result score 50s tx run data get storage llm params.ffn_w.114s
execute store result score 51b tx run data get storage llm params.ffn_w.115b
execute store result score 51e tx run data get storage llm params.ffn_w.115e
execute store result score 51s tx run data get storage llm params.ffn_w.115s
execute store result score 52b tx run data get storage llm params.ffn_w.116b
execute store result score 52e tx run data get storage llm params.ffn_w.116e
execute store result score 52s tx run data get storage llm params.ffn_w.116s
execute store result score 53b tx run data get storage llm params.ffn_w.117b
execute store result score 53e tx run data get storage llm params.ffn_w.117e
execute store result score 53s tx run data get storage llm params.ffn_w.117s
execute store result score 54b tx run data get storage llm params.ffn_w.118b
execute store result score 54e tx run data get storage llm params.ffn_w.118e
execute store result score 54s tx run data get storage llm params.ffn_w.118s
execute store result score 55b tx run data get storage llm params.ffn_w.119b
execute store result score 55e tx run data get storage llm params.ffn_w.119e
execute store result score 55s tx run data get storage llm params.ffn_w.119s
execute store result score 56b tx run data get storage llm params.ffn_w.120b
execute store result score 56e tx run data get storage llm params.ffn_w.120e
execute store result score 56s tx run data get storage llm params.ffn_w.120s
execute store result score 57b tx run data get storage llm params.ffn_w.121b
execute store result score 57e tx run data get storage llm params.ffn_w.121e
execute store result score 57s tx run data get storage llm params.ffn_w.121s
execute store result score 58b tx run data get storage llm params.ffn_w.122b
execute store result score 58e tx run data get storage llm params.ffn_w.122e
execute store result score 58s tx run data get storage llm params.ffn_w.122s
execute store result score 59b tx run data get storage llm params.ffn_w.123b
execute store result score 59e tx run data get storage llm params.ffn_w.123e
execute store result score 59s tx run data get storage llm params.ffn_w.123s
execute store result score 60b tx run data get storage llm params.ffn_w.124b
execute store result score 60e tx run data get storage llm params.ffn_w.124e
execute store result score 60s tx run data get storage llm params.ffn_w.124s
execute store result score 61b tx run data get storage llm params.ffn_w.125b
execute store result score 61e tx run data get storage llm params.ffn_w.125e
execute store result score 61s tx run data get storage llm params.ffn_w.125s
execute store result score 62b tx run data get storage llm params.ffn_w.126b
execute store result score 62e tx run data get storage llm params.ffn_w.126e
execute store result score 62s tx run data get storage llm params.ffn_w.126s
execute store result score 63b tx run data get storage llm params.ffn_w.127b
execute store result score 63e tx run data get storage llm params.ffn_w.127e
execute store result score 63s tx run data get storage llm params.ffn_w.127s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th"
data modify storage llm args.m set value "w1_1"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 14
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_1"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 15
function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_1"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 16
scoreboard players operation xb llm = 0b tx
scoreboard players operation xe llm = 0e tx
scoreboard players operation xs llm = 0s tx
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx
scoreboard players operation xe llm = 1e tx
scoreboard players operation xs llm = 1s tx
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx
scoreboard players operation xe llm = 2e tx
scoreboard players operation xs llm = 2s tx
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx
scoreboard players operation xe llm = 3e tx
scoreboard players operation xs llm = 3s tx
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx
scoreboard players operation xe llm = 4e tx
scoreboard players operation xs llm = 4s tx
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx
scoreboard players operation xe llm = 5e tx
scoreboard players operation xs llm = 5s tx
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx
scoreboard players operation xe llm = 6e tx
scoreboard players operation xs llm = 6s tx
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx
scoreboard players operation xe llm = 7e tx
scoreboard players operation xs llm = 7s tx
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx
scoreboard players operation xe llm = 8e tx
scoreboard players operation xs llm = 8s tx
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx
scoreboard players operation xe llm = 9e tx
scoreboard players operation xs llm = 9s tx
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx
scoreboard players operation xe llm = 10e tx
scoreboard players operation xs llm = 10s tx
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx
scoreboard players operation xe llm = 11e tx
scoreboard players operation xs llm = 11s tx
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx
scoreboard players operation xe llm = 12e tx
scoreboard players operation xs llm = 12s tx
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx
scoreboard players operation xe llm = 13e tx
scoreboard players operation xs llm = 13s tx
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx
scoreboard players operation xe llm = 14e tx
scoreboard players operation xs llm = 14s tx
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx
scoreboard players operation xe llm = 15e tx
scoreboard players operation xs llm = 15s tx
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx
scoreboard players operation xe llm = 16e tx
scoreboard players operation xs llm = 16s tx
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx
scoreboard players operation xe llm = 17e tx
scoreboard players operation xs llm = 17s tx
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx
scoreboard players operation xe llm = 18e tx
scoreboard players operation xs llm = 18s tx
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx
scoreboard players operation xe llm = 19e tx
scoreboard players operation xs llm = 19s tx
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx
scoreboard players operation xe llm = 20e tx
scoreboard players operation xs llm = 20s tx
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx
scoreboard players operation xe llm = 21e tx
scoreboard players operation xs llm = 21s tx
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx
scoreboard players operation xe llm = 22e tx
scoreboard players operation xs llm = 22s tx
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx
scoreboard players operation xe llm = 23e tx
scoreboard players operation xs llm = 23s tx
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx
scoreboard players operation xe llm = 24e tx
scoreboard players operation xs llm = 24s tx
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx
scoreboard players operation xe llm = 25e tx
scoreboard players operation xs llm = 25s tx
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx
scoreboard players operation xe llm = 26e tx
scoreboard players operation xs llm = 26s tx
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx
scoreboard players operation xe llm = 27e tx
scoreboard players operation xs llm = 27s tx
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx
scoreboard players operation xe llm = 28e tx
scoreboard players operation xs llm = 28s tx
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx
scoreboard players operation xe llm = 29e tx
scoreboard players operation xs llm = 29s tx
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx
scoreboard players operation xe llm = 30e tx
scoreboard players operation xs llm = 30s tx
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx
scoreboard players operation xe llm = 31e tx
scoreboard players operation xs llm = 31s tx
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx
scoreboard players operation xe llm = 32e tx
scoreboard players operation xs llm = 32s tx
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx
scoreboard players operation xe llm = 33e tx
scoreboard players operation xs llm = 33s tx
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx
scoreboard players operation xe llm = 34e tx
scoreboard players operation xs llm = 34s tx
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx
scoreboard players operation xe llm = 35e tx
scoreboard players operation xs llm = 35s tx
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx
scoreboard players operation xe llm = 36e tx
scoreboard players operation xs llm = 36s tx
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx
scoreboard players operation xe llm = 37e tx
scoreboard players operation xs llm = 37s tx
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx
scoreboard players operation xe llm = 38e tx
scoreboard players operation xs llm = 38s tx
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx
scoreboard players operation xe llm = 39e tx
scoreboard players operation xs llm = 39s tx
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx
scoreboard players operation xe llm = 40e tx
scoreboard players operation xs llm = 40s tx
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx
scoreboard players operation xe llm = 41e tx
scoreboard players operation xs llm = 41s tx
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx
scoreboard players operation xe llm = 42e tx
scoreboard players operation xs llm = 42s tx
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx
scoreboard players operation xe llm = 43e tx
scoreboard players operation xs llm = 43s tx
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx
scoreboard players operation xe llm = 44e tx
scoreboard players operation xs llm = 44s tx
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx
scoreboard players operation xe llm = 45e tx
scoreboard players operation xs llm = 45s tx
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx
scoreboard players operation xe llm = 46e tx
scoreboard players operation xs llm = 46s tx
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx
scoreboard players operation xe llm = 47e tx
scoreboard players operation xs llm = 47s tx
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx
scoreboard players operation xe llm = 48e tx
scoreboard players operation xs llm = 48s tx
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx
scoreboard players operation xe llm = 49e tx
scoreboard players operation xs llm = 49s tx
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx
scoreboard players operation xe llm = 50e tx
scoreboard players operation xs llm = 50s tx
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx
scoreboard players operation xe llm = 51e tx
scoreboard players operation xs llm = 51s tx
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx
scoreboard players operation xe llm = 52e tx
scoreboard players operation xs llm = 52s tx
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx
scoreboard players operation xe llm = 53e tx
scoreboard players operation xs llm = 53s tx
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx
scoreboard players operation xe llm = 54e tx
scoreboard players operation xs llm = 54s tx
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx
scoreboard players operation xe llm = 55e tx
scoreboard players operation xs llm = 55s tx
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx
scoreboard players operation xe llm = 56e tx
scoreboard players operation xs llm = 56s tx
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx
scoreboard players operation xe llm = 57e tx
scoreboard players operation xs llm = 57s tx
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx
scoreboard players operation xe llm = 58e tx
scoreboard players operation xs llm = 58s tx
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx
scoreboard players operation xe llm = 59e tx
scoreboard players operation xs llm = 59s tx
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx
scoreboard players operation xe llm = 60e tx
scoreboard players operation xs llm = 60s tx
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx
scoreboard players operation xe llm = 61e tx
scoreboard players operation xs llm = 61s tx
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx
scoreboard players operation xe llm = 62e tx
scoreboard players operation xs llm = 62s tx
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx
scoreboard players operation xe llm = 63e tx
scoreboard players operation xs llm = 63s tx
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.128b
execute store result score 0e tx run data get storage llm params.att_w.128e
execute store result score 0s tx run data get storage llm params.att_w.128s
execute store result score 1b tx run data get storage llm params.att_w.129b
execute store result score 1e tx run data get storage llm params.att_w.129e
execute store result score 1s tx run data get storage llm params.att_w.129s
execute store result score 2b tx run data get storage llm params.att_w.130b
execute store result score 2e tx run data get storage llm params.att_w.130e
execute store result score 2s tx run data get storage llm params.att_w.130s
execute store result score 3b tx run data get storage llm params.att_w.131b
execute store result score 3e tx run data get storage llm params.att_w.131e
execute store result score 3s tx run data get storage llm params.att_w.131s
execute store result score 4b tx run data get storage llm params.att_w.132b
execute store result score 4e tx run data get storage llm params.att_w.132e
execute store result score 4s tx run data get storage llm params.att_w.132s
execute store result score 5b tx run data get storage llm params.att_w.133b
execute store result score 5e tx run data get storage llm params.att_w.133e
execute store result score 5s tx run data get storage llm params.att_w.133s
execute store result score 6b tx run data get storage llm params.att_w.134b
execute store result score 6e tx run data get storage llm params.att_w.134e
execute store result score 6s tx run data get storage llm params.att_w.134s
execute store result score 7b tx run data get storage llm params.att_w.135b
execute store result score 7e tx run data get storage llm params.att_w.135e
execute store result score 7s tx run data get storage llm params.att_w.135s
execute store result score 8b tx run data get storage llm params.att_w.136b
execute store result score 8e tx run data get storage llm params.att_w.136e
execute store result score 8s tx run data get storage llm params.att_w.136s
execute store result score 9b tx run data get storage llm params.att_w.137b
execute store result score 9e tx run data get storage llm params.att_w.137e
execute store result score 9s tx run data get storage llm params.att_w.137s
execute store result score 10b tx run data get storage llm params.att_w.138b
execute store result score 10e tx run data get storage llm params.att_w.138e
execute store result score 10s tx run data get storage llm params.att_w.138s
execute store result score 11b tx run data get storage llm params.att_w.139b
execute store result score 11e tx run data get storage llm params.att_w.139e
execute store result score 11s tx run data get storage llm params.att_w.139s
execute store result score 12b tx run data get storage llm params.att_w.140b
execute store result score 12e tx run data get storage llm params.att_w.140e
execute store result score 12s tx run data get storage llm params.att_w.140s
execute store result score 13b tx run data get storage llm params.att_w.141b
execute store result score 13e tx run data get storage llm params.att_w.141e
execute store result score 13s tx run data get storage llm params.att_w.141s
execute store result score 14b tx run data get storage llm params.att_w.142b
execute store result score 14e tx run data get storage llm params.att_w.142e
execute store result score 14s tx run data get storage llm params.att_w.142s
execute store result score 15b tx run data get storage llm params.att_w.143b
execute store result score 15e tx run data get storage llm params.att_w.143e
execute store result score 15s tx run data get storage llm params.att_w.143s
execute store result score 16b tx run data get storage llm params.att_w.144b
execute store result score 16e tx run data get storage llm params.att_w.144e
execute store result score 16s tx run data get storage llm params.att_w.144s
execute store result score 17b tx run data get storage llm params.att_w.145b
execute store result score 17e tx run data get storage llm params.att_w.145e
execute store result score 17s tx run data get storage llm params.att_w.145s
execute store result score 18b tx run data get storage llm params.att_w.146b
execute store result score 18e tx run data get storage llm params.att_w.146e
execute store result score 18s tx run data get storage llm params.att_w.146s
execute store result score 19b tx run data get storage llm params.att_w.147b
execute store result score 19e tx run data get storage llm params.att_w.147e
execute store result score 19s tx run data get storage llm params.att_w.147s
execute store result score 20b tx run data get storage llm params.att_w.148b
execute store result score 20e tx run data get storage llm params.att_w.148e
execute store result score 20s tx run data get storage llm params.att_w.148s
execute store result score 21b tx run data get storage llm params.att_w.149b
execute store result score 21e tx run data get storage llm params.att_w.149e
execute store result score 21s tx run data get storage llm params.att_w.149s
execute store result score 22b tx run data get storage llm params.att_w.150b
execute store result score 22e tx run data get storage llm params.att_w.150e
execute store result score 22s tx run data get storage llm params.att_w.150s
execute store result score 23b tx run data get storage llm params.att_w.151b
execute store result score 23e tx run data get storage llm params.att_w.151e
execute store result score 23s tx run data get storage llm params.att_w.151s
execute store result score 24b tx run data get storage llm params.att_w.152b
execute store result score 24e tx run data get storage llm params.att_w.152e
execute store result score 24s tx run data get storage llm params.att_w.152s
execute store result score 25b tx run data get storage llm params.att_w.153b
execute store result score 25e tx run data get storage llm params.att_w.153e
execute store result score 25s tx run data get storage llm params.att_w.153s
execute store result score 26b tx run data get storage llm params.att_w.154b
execute store result score 26e tx run data get storage llm params.att_w.154e
execute store result score 26s tx run data get storage llm params.att_w.154s
execute store result score 27b tx run data get storage llm params.att_w.155b
execute store result score 27e tx run data get storage llm params.att_w.155e
execute store result score 27s tx run data get storage llm params.att_w.155s
execute store result score 28b tx run data get storage llm params.att_w.156b
execute store result score 28e tx run data get storage llm params.att_w.156e
execute store result score 28s tx run data get storage llm params.att_w.156s
execute store result score 29b tx run data get storage llm params.att_w.157b
execute store result score 29e tx run data get storage llm params.att_w.157e
execute store result score 29s tx run data get storage llm params.att_w.157s
execute store result score 30b tx run data get storage llm params.att_w.158b
execute store result score 30e tx run data get storage llm params.att_w.158e
execute store result score 30s tx run data get storage llm params.att_w.158s
execute store result score 31b tx run data get storage llm params.att_w.159b
execute store result score 31e tx run data get storage llm params.att_w.159e
execute store result score 31s tx run data get storage llm params.att_w.159s
execute store result score 32b tx run data get storage llm params.att_w.160b
execute store result score 32e tx run data get storage llm params.att_w.160e
execute store result score 32s tx run data get storage llm params.att_w.160s
execute store result score 33b tx run data get storage llm params.att_w.161b
execute store result score 33e tx run data get storage llm params.att_w.161e
execute store result score 33s tx run data get storage llm params.att_w.161s
execute store result score 34b tx run data get storage llm params.att_w.162b
execute store result score 34e tx run data get storage llm params.att_w.162e
execute store result score 34s tx run data get storage llm params.att_w.162s
execute store result score 35b tx run data get storage llm params.att_w.163b
execute store result score 35e tx run data get storage llm params.att_w.163e
execute store result score 35s tx run data get storage llm params.att_w.163s
execute store result score 36b tx run data get storage llm params.att_w.164b
execute store result score 36e tx run data get storage llm params.att_w.164e
execute store result score 36s tx run data get storage llm params.att_w.164s
execute store result score 37b tx run data get storage llm params.att_w.165b
execute store result score 37e tx run data get storage llm params.att_w.165e
execute store result score 37s tx run data get storage llm params.att_w.165s
execute store result score 38b tx run data get storage llm params.att_w.166b
execute store result score 38e tx run data get storage llm params.att_w.166e
execute store result score 38s tx run data get storage llm params.att_w.166s
execute store result score 39b tx run data get storage llm params.att_w.167b
execute store result score 39e tx run data get storage llm params.att_w.167e
execute store result score 39s tx run data get storage llm params.att_w.167s
execute store result score 40b tx run data get storage llm params.att_w.168b
execute store result score 40e tx run data get storage llm params.att_w.168e
execute store result score 40s tx run data get storage llm params.att_w.168s
execute store result score 41b tx run data get storage llm params.att_w.169b
execute store result score 41e tx run data get storage llm params.att_w.169e
execute store result score 41s tx run data get storage llm params.att_w.169s
execute store result score 42b tx run data get storage llm params.att_w.170b
execute store result score 42e tx run data get storage llm params.att_w.170e
execute store result score 42s tx run data get storage llm params.att_w.170s
execute store result score 43b tx run data get storage llm params.att_w.171b
execute store result score 43e tx run data get storage llm params.att_w.171e
execute store result score 43s tx run data get storage llm params.att_w.171s
execute store result score 44b tx run data get storage llm params.att_w.172b
execute store result score 44e tx run data get storage llm params.att_w.172e
execute store result score 44s tx run data get storage llm params.att_w.172s
execute store result score 45b tx run data get storage llm params.att_w.173b
execute store result score 45e tx run data get storage llm params.att_w.173e
execute store result score 45s tx run data get storage llm params.att_w.173s
execute store result score 46b tx run data get storage llm params.att_w.174b
execute store result score 46e tx run data get storage llm params.att_w.174e
execute store result score 46s tx run data get storage llm params.att_w.174s
execute store result score 47b tx run data get storage llm params.att_w.175b
execute store result score 47e tx run data get storage llm params.att_w.175e
execute store result score 47s tx run data get storage llm params.att_w.175s
execute store result score 48b tx run data get storage llm params.att_w.176b
execute store result score 48e tx run data get storage llm params.att_w.176e
execute store result score 48s tx run data get storage llm params.att_w.176s
execute store result score 49b tx run data get storage llm params.att_w.177b
execute store result score 49e tx run data get storage llm params.att_w.177e
execute store result score 49s tx run data get storage llm params.att_w.177s
execute store result score 50b tx run data get storage llm params.att_w.178b
execute store result score 50e tx run data get storage llm params.att_w.178e
execute store result score 50s tx run data get storage llm params.att_w.178s
execute store result score 51b tx run data get storage llm params.att_w.179b
execute store result score 51e tx run data get storage llm params.att_w.179e
execute store result score 51s tx run data get storage llm params.att_w.179s
execute store result score 52b tx run data get storage llm params.att_w.180b
execute store result score 52e tx run data get storage llm params.att_w.180e
execute store result score 52s tx run data get storage llm params.att_w.180s
execute store result score 53b tx run data get storage llm params.att_w.181b
execute store result score 53e tx run data get storage llm params.att_w.181e
execute store result score 53s tx run data get storage llm params.att_w.181s
execute store result score 54b tx run data get storage llm params.att_w.182b
execute store result score 54e tx run data get storage llm params.att_w.182e
execute store result score 54s tx run data get storage llm params.att_w.182s
execute store result score 55b tx run data get storage llm params.att_w.183b
execute store result score 55e tx run data get storage llm params.att_w.183e
execute store result score 55s tx run data get storage llm params.att_w.183s
execute store result score 56b tx run data get storage llm params.att_w.184b
execute store result score 56e tx run data get storage llm params.att_w.184e
execute store result score 56s tx run data get storage llm params.att_w.184s
execute store result score 57b tx run data get storage llm params.att_w.185b
execute store result score 57e tx run data get storage llm params.att_w.185e
execute store result score 57s tx run data get storage llm params.att_w.185s
execute store result score 58b tx run data get storage llm params.att_w.186b
execute store result score 58e tx run data get storage llm params.att_w.186e
execute store result score 58s tx run data get storage llm params.att_w.186s
execute store result score 59b tx run data get storage llm params.att_w.187b
execute store result score 59e tx run data get storage llm params.att_w.187e
execute store result score 59s tx run data get storage llm params.att_w.187s
execute store result score 60b tx run data get storage llm params.att_w.188b
execute store result score 60e tx run data get storage llm params.att_w.188e
execute store result score 60s tx run data get storage llm params.att_w.188s
execute store result score 61b tx run data get storage llm params.att_w.189b
execute store result score 61e tx run data get storage llm params.att_w.189e
execute store result score 61s tx run data get storage llm params.att_w.189s
execute store result score 62b tx run data get storage llm params.att_w.190b
execute store result score 62e tx run data get storage llm params.att_w.190e
execute store result score 62s tx run data get storage llm params.att_w.190s
execute store result score 63b tx run data get storage llm params.att_w.191b
execute store result score 63e tx run data get storage llm params.att_w.191e
execute store result score 63s tx run data get storage llm params.att_w.191s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_2"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 17
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_2"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 18
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_2"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 19
function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65536
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65537
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65538
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65539
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65540
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65541
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65542
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65543
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65544
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65545
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65546
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65547
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65548
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65549
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65550
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65551
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65552
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65553
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65554
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65555
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65556
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65557
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65558
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65559
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65560
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65561
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65562
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65563
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65564
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65565
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65566
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 65567
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:ctxwindow
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_0_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_0_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_0_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_0_3
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_0_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_1_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_1_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_1_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_1_3
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_1_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_2_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_2_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_2_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_2_3
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_2_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_3_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_3_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_3_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_3_3
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_3_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_4_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_4_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_4_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_4_3
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_4_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_5_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_5_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_5_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_5_3
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_5_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_6_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_6_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_6_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_6_3
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_6_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_7_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_2_7_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_7_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_2_7_3
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_2_7_4
bossbar set progress value 20
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_2"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 21
scoreboard players operation xb llm = 0b tx2
scoreboard players operation xe llm = 0e tx2
scoreboard players operation xs llm = 0s tx2
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx2
scoreboard players operation xe llm = 1e tx2
scoreboard players operation xs llm = 1s tx2
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx2
scoreboard players operation xe llm = 2e tx2
scoreboard players operation xs llm = 2s tx2
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx2
scoreboard players operation xe llm = 3e tx2
scoreboard players operation xs llm = 3s tx2
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx2
scoreboard players operation xe llm = 4e tx2
scoreboard players operation xs llm = 4s tx2
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx2
scoreboard players operation xe llm = 5e tx2
scoreboard players operation xs llm = 5s tx2
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx2
scoreboard players operation xe llm = 6e tx2
scoreboard players operation xs llm = 6s tx2
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx2
scoreboard players operation xe llm = 7e tx2
scoreboard players operation xs llm = 7s tx2
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx2
scoreboard players operation xe llm = 8e tx2
scoreboard players operation xs llm = 8s tx2
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx2
scoreboard players operation xe llm = 9e tx2
scoreboard players operation xs llm = 9s tx2
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx2
scoreboard players operation xe llm = 10e tx2
scoreboard players operation xs llm = 10s tx2
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx2
scoreboard players operation xe llm = 11e tx2
scoreboard players operation xs llm = 11s tx2
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx2
scoreboard players operation xe llm = 12e tx2
scoreboard players operation xs llm = 12s tx2
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx2
scoreboard players operation xe llm = 13e tx2
scoreboard players operation xs llm = 13s tx2
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx2
scoreboard players operation xe llm = 14e tx2
scoreboard players operation xs llm = 14s tx2
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx2
scoreboard players operation xe llm = 15e tx2
scoreboard players operation xs llm = 15s tx2
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx2
scoreboard players operation xe llm = 16e tx2
scoreboard players operation xs llm = 16s tx2
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx2
scoreboard players operation xe llm = 17e tx2
scoreboard players operation xs llm = 17s tx2
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx2
scoreboard players operation xe llm = 18e tx2
scoreboard players operation xs llm = 18s tx2
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx2
scoreboard players operation xe llm = 19e tx2
scoreboard players operation xs llm = 19s tx2
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx2
scoreboard players operation xe llm = 20e tx2
scoreboard players operation xs llm = 20s tx2
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx2
scoreboard players operation xe llm = 21e tx2
scoreboard players operation xs llm = 21s tx2
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx2
scoreboard players operation xe llm = 22e tx2
scoreboard players operation xs llm = 22s tx2
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx2
scoreboard players operation xe llm = 23e tx2
scoreboard players operation xs llm = 23s tx2
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx2
scoreboard players operation xe llm = 24e tx2
scoreboard players operation xs llm = 24s tx2
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx2
scoreboard players operation xe llm = 25e tx2
scoreboard players operation xs llm = 25s tx2
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx2
scoreboard players operation xe llm = 26e tx2
scoreboard players operation xs llm = 26s tx2
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx2
scoreboard players operation xe llm = 27e tx2
scoreboard players operation xs llm = 27s tx2
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx2
scoreboard players operation xe llm = 28e tx2
scoreboard players operation xs llm = 28s tx2
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx2
scoreboard players operation xe llm = 29e tx2
scoreboard players operation xs llm = 29s tx2
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx2
scoreboard players operation xe llm = 30e tx2
scoreboard players operation xs llm = 30s tx2
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx2
scoreboard players operation xe llm = 31e tx2
scoreboard players operation xs llm = 31s tx2
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx2
scoreboard players operation xe llm = 32e tx2
scoreboard players operation xs llm = 32s tx2
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx2
scoreboard players operation xe llm = 33e tx2
scoreboard players operation xs llm = 33s tx2
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx2
scoreboard players operation xe llm = 34e tx2
scoreboard players operation xs llm = 34s tx2
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx2
scoreboard players operation xe llm = 35e tx2
scoreboard players operation xs llm = 35s tx2
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx2
scoreboard players operation xe llm = 36e tx2
scoreboard players operation xs llm = 36s tx2
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx2
scoreboard players operation xe llm = 37e tx2
scoreboard players operation xs llm = 37s tx2
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx2
scoreboard players operation xe llm = 38e tx2
scoreboard players operation xs llm = 38s tx2
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx2
scoreboard players operation xe llm = 39e tx2
scoreboard players operation xs llm = 39s tx2
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx2
scoreboard players operation xe llm = 40e tx2
scoreboard players operation xs llm = 40s tx2
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx2
scoreboard players operation xe llm = 41e tx2
scoreboard players operation xs llm = 41s tx2
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx2
scoreboard players operation xe llm = 42e tx2
scoreboard players operation xs llm = 42s tx2
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx2
scoreboard players operation xe llm = 43e tx2
scoreboard players operation xs llm = 43s tx2
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx2
scoreboard players operation xe llm = 44e tx2
scoreboard players operation xs llm = 44s tx2
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx2
scoreboard players operation xe llm = 45e tx2
scoreboard players operation xs llm = 45s tx2
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx2
scoreboard players operation xe llm = 46e tx2
scoreboard players operation xs llm = 46s tx2
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx2
scoreboard players operation xe llm = 47e tx2
scoreboard players operation xs llm = 47s tx2
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx2
scoreboard players operation xe llm = 48e tx2
scoreboard players operation xs llm = 48s tx2
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx2
scoreboard players operation xe llm = 49e tx2
scoreboard players operation xs llm = 49s tx2
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx2
scoreboard players operation xe llm = 50e tx2
scoreboard players operation xs llm = 50s tx2
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx2
scoreboard players operation xe llm = 51e tx2
scoreboard players operation xs llm = 51s tx2
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx2
scoreboard players operation xe llm = 52e tx2
scoreboard players operation xs llm = 52s tx2
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx2
scoreboard players operation xe llm = 53e tx2
scoreboard players operation xs llm = 53s tx2
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx2
scoreboard players operation xe llm = 54e tx2
scoreboard players operation xs llm = 54s tx2
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx2
scoreboard players operation xe llm = 55e tx2
scoreboard players operation xs llm = 55s tx2
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx2
scoreboard players operation xe llm = 56e tx2
scoreboard players operation xs llm = 56s tx2
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx2
scoreboard players operation xe llm = 57e tx2
scoreboard players operation xs llm = 57s tx2
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx2
scoreboard players operation xe llm = 58e tx2
scoreboard players operation xs llm = 58s tx2
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx2
scoreboard players operation xe llm = 59e tx2
scoreboard players operation xs llm = 59s tx2
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx2
scoreboard players operation xe llm = 60e tx2
scoreboard players operation xs llm = 60s tx2
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx2
scoreboard players operation xe llm = 61e tx2
scoreboard players operation xs llm = 61s tx2
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx2
scoreboard players operation xe llm = 62e tx2
scoreboard players operation xs llm = 62s tx2
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx2
scoreboard players operation xe llm = 63e tx2
scoreboard players operation xs llm = 63s tx2
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.ffn_w.128b
execute store result score 0e tx run data get storage llm params.ffn_w.128e
execute store result score 0s tx run data get storage llm params.ffn_w.128s
execute store result score 1b tx run data get storage llm params.ffn_w.129b
execute store result score 1e tx run data get storage llm params.ffn_w.129e
execute store result score 1s tx run data get storage llm params.ffn_w.129s
execute store result score 2b tx run data get storage llm params.ffn_w.130b
execute store result score 2e tx run data get storage llm params.ffn_w.130e
execute store result score 2s tx run data get storage llm params.ffn_w.130s
execute store result score 3b tx run data get storage llm params.ffn_w.131b
execute store result score 3e tx run data get storage llm params.ffn_w.131e
execute store result score 3s tx run data get storage llm params.ffn_w.131s
execute store result score 4b tx run data get storage llm params.ffn_w.132b
execute store result score 4e tx run data get storage llm params.ffn_w.132e
execute store result score 4s tx run data get storage llm params.ffn_w.132s
execute store result score 5b tx run data get storage llm params.ffn_w.133b
execute store result score 5e tx run data get storage llm params.ffn_w.133e
execute store result score 5s tx run data get storage llm params.ffn_w.133s
execute store result score 6b tx run data get storage llm params.ffn_w.134b
execute store result score 6e tx run data get storage llm params.ffn_w.134e
execute store result score 6s tx run data get storage llm params.ffn_w.134s
execute store result score 7b tx run data get storage llm params.ffn_w.135b
execute store result score 7e tx run data get storage llm params.ffn_w.135e
execute store result score 7s tx run data get storage llm params.ffn_w.135s
execute store result score 8b tx run data get storage llm params.ffn_w.136b
execute store result score 8e tx run data get storage llm params.ffn_w.136e
execute store result score 8s tx run data get storage llm params.ffn_w.136s
execute store result score 9b tx run data get storage llm params.ffn_w.137b
execute store result score 9e tx run data get storage llm params.ffn_w.137e
execute store result score 9s tx run data get storage llm params.ffn_w.137s
execute store result score 10b tx run data get storage llm params.ffn_w.138b
execute store result score 10e tx run data get storage llm params.ffn_w.138e
execute store result score 10s tx run data get storage llm params.ffn_w.138s
execute store result score 11b tx run data get storage llm params.ffn_w.139b
execute store result score 11e tx run data get storage llm params.ffn_w.139e
execute store result score 11s tx run data get storage llm params.ffn_w.139s
execute store result score 12b tx run data get storage llm params.ffn_w.140b
execute store result score 12e tx run data get storage llm params.ffn_w.140e
execute store result score 12s tx run data get storage llm params.ffn_w.140s
execute store result score 13b tx run data get storage llm params.ffn_w.141b
execute store result score 13e tx run data get storage llm params.ffn_w.141e
execute store result score 13s tx run data get storage llm params.ffn_w.141s
execute store result score 14b tx run data get storage llm params.ffn_w.142b
execute store result score 14e tx run data get storage llm params.ffn_w.142e
execute store result score 14s tx run data get storage llm params.ffn_w.142s
execute store result score 15b tx run data get storage llm params.ffn_w.143b
execute store result score 15e tx run data get storage llm params.ffn_w.143e
execute store result score 15s tx run data get storage llm params.ffn_w.143s
execute store result score 16b tx run data get storage llm params.ffn_w.144b
execute store result score 16e tx run data get storage llm params.ffn_w.144e
execute store result score 16s tx run data get storage llm params.ffn_w.144s
execute store result score 17b tx run data get storage llm params.ffn_w.145b
execute store result score 17e tx run data get storage llm params.ffn_w.145e
execute store result score 17s tx run data get storage llm params.ffn_w.145s
execute store result score 18b tx run data get storage llm params.ffn_w.146b
execute store result score 18e tx run data get storage llm params.ffn_w.146e
execute store result score 18s tx run data get storage llm params.ffn_w.146s
execute store result score 19b tx run data get storage llm params.ffn_w.147b
execute store result score 19e tx run data get storage llm params.ffn_w.147e
execute store result score 19s tx run data get storage llm params.ffn_w.147s
execute store result score 20b tx run data get storage llm params.ffn_w.148b
execute store result score 20e tx run data get storage llm params.ffn_w.148e
execute store result score 20s tx run data get storage llm params.ffn_w.148s
execute store result score 21b tx run data get storage llm params.ffn_w.149b
execute store result score 21e tx run data get storage llm params.ffn_w.149e
execute store result score 21s tx run data get storage llm params.ffn_w.149s
execute store result score 22b tx run data get storage llm params.ffn_w.150b
execute store result score 22e tx run data get storage llm params.ffn_w.150e
execute store result score 22s tx run data get storage llm params.ffn_w.150s
execute store result score 23b tx run data get storage llm params.ffn_w.151b
execute store result score 23e tx run data get storage llm params.ffn_w.151e
execute store result score 23s tx run data get storage llm params.ffn_w.151s
execute store result score 24b tx run data get storage llm params.ffn_w.152b
execute store result score 24e tx run data get storage llm params.ffn_w.152e
execute store result score 24s tx run data get storage llm params.ffn_w.152s
execute store result score 25b tx run data get storage llm params.ffn_w.153b
execute store result score 25e tx run data get storage llm params.ffn_w.153e
execute store result score 25s tx run data get storage llm params.ffn_w.153s
execute store result score 26b tx run data get storage llm params.ffn_w.154b
execute store result score 26e tx run data get storage llm params.ffn_w.154e
execute store result score 26s tx run data get storage llm params.ffn_w.154s
execute store result score 27b tx run data get storage llm params.ffn_w.155b
execute store result score 27e tx run data get storage llm params.ffn_w.155e
execute store result score 27s tx run data get storage llm params.ffn_w.155s
execute store result score 28b tx run data get storage llm params.ffn_w.156b
execute store result score 28e tx run data get storage llm params.ffn_w.156e
execute store result score 28s tx run data get storage llm params.ffn_w.156s
execute store result score 29b tx run data get storage llm params.ffn_w.157b
execute store result score 29e tx run data get storage llm params.ffn_w.157e
execute store result score 29s tx run data get storage llm params.ffn_w.157s
execute store result score 30b tx run data get storage llm params.ffn_w.158b
execute store result score 30e tx run data get storage llm params.ffn_w.158e
execute store result score 30s tx run data get storage llm params.ffn_w.158s
execute store result score 31b tx run data get storage llm params.ffn_w.159b
execute store result score 31e tx run data get storage llm params.ffn_w.159e
execute store result score 31s tx run data get storage llm params.ffn_w.159s
execute store result score 32b tx run data get storage llm params.ffn_w.160b
execute store result score 32e tx run data get storage llm params.ffn_w.160e
execute store result score 32s tx run data get storage llm params.ffn_w.160s
execute store result score 33b tx run data get storage llm params.ffn_w.161b
execute store result score 33e tx run data get storage llm params.ffn_w.161e
execute store result score 33s tx run data get storage llm params.ffn_w.161s
execute store result score 34b tx run data get storage llm params.ffn_w.162b
execute store result score 34e tx run data get storage llm params.ffn_w.162e
execute store result score 34s tx run data get storage llm params.ffn_w.162s
execute store result score 35b tx run data get storage llm params.ffn_w.163b
execute store result score 35e tx run data get storage llm params.ffn_w.163e
execute store result score 35s tx run data get storage llm params.ffn_w.163s
execute store result score 36b tx run data get storage llm params.ffn_w.164b
execute store result score 36e tx run data get storage llm params.ffn_w.164e
execute store result score 36s tx run data get storage llm params.ffn_w.164s
execute store result score 37b tx run data get storage llm params.ffn_w.165b
execute store result score 37e tx run data get storage llm params.ffn_w.165e
execute store result score 37s tx run data get storage llm params.ffn_w.165s
execute store result score 38b tx run data get storage llm params.ffn_w.166b
execute store result score 38e tx run data get storage llm params.ffn_w.166e
execute store result score 38s tx run data get storage llm params.ffn_w.166s
execute store result score 39b tx run data get storage llm params.ffn_w.167b
execute store result score 39e tx run data get storage llm params.ffn_w.167e
execute store result score 39s tx run data get storage llm params.ffn_w.167s
execute store result score 40b tx run data get storage llm params.ffn_w.168b
execute store result score 40e tx run data get storage llm params.ffn_w.168e
execute store result score 40s tx run data get storage llm params.ffn_w.168s
execute store result score 41b tx run data get storage llm params.ffn_w.169b
execute store result score 41e tx run data get storage llm params.ffn_w.169e
execute store result score 41s tx run data get storage llm params.ffn_w.169s
execute store result score 42b tx run data get storage llm params.ffn_w.170b
execute store result score 42e tx run data get storage llm params.ffn_w.170e
execute store result score 42s tx run data get storage llm params.ffn_w.170s
execute store result score 43b tx run data get storage llm params.ffn_w.171b
execute store result score 43e tx run data get storage llm params.ffn_w.171e
execute store result score 43s tx run data get storage llm params.ffn_w.171s
execute store result score 44b tx run data get storage llm params.ffn_w.172b
execute store result score 44e tx run data get storage llm params.ffn_w.172e
execute store result score 44s tx run data get storage llm params.ffn_w.172s
execute store result score 45b tx run data get storage llm params.ffn_w.173b
execute store result score 45e tx run data get storage llm params.ffn_w.173e
execute store result score 45s tx run data get storage llm params.ffn_w.173s
execute store result score 46b tx run data get storage llm params.ffn_w.174b
execute store result score 46e tx run data get storage llm params.ffn_w.174e
execute store result score 46s tx run data get storage llm params.ffn_w.174s
execute store result score 47b tx run data get storage llm params.ffn_w.175b
execute store result score 47e tx run data get storage llm params.ffn_w.175e
execute store result score 47s tx run data get storage llm params.ffn_w.175s
execute store result score 48b tx run data get storage llm params.ffn_w.176b
execute store result score 48e tx run data get storage llm params.ffn_w.176e
execute store result score 48s tx run data get storage llm params.ffn_w.176s
execute store result score 49b tx run data get storage llm params.ffn_w.177b
execute store result score 49e tx run data get storage llm params.ffn_w.177e
execute store result score 49s tx run data get storage llm params.ffn_w.177s
execute store result score 50b tx run data get storage llm params.ffn_w.178b
execute store result score 50e tx run data get storage llm params.ffn_w.178e
execute store result score 50s tx run data get storage llm params.ffn_w.178s
execute store result score 51b tx run data get storage llm params.ffn_w.179b
execute store result score 51e tx run data get storage llm params.ffn_w.179e
execute store result score 51s tx run data get storage llm params.ffn_w.179s
execute store result score 52b tx run data get storage llm params.ffn_w.180b
execute store result score 52e tx run data get storage llm params.ffn_w.180e
execute store result score 52s tx run data get storage llm params.ffn_w.180s
execute store result score 53b tx run data get storage llm params.ffn_w.181b
execute store result score 53e tx run data get storage llm params.ffn_w.181e
execute store result score 53s tx run data get storage llm params.ffn_w.181s
execute store result score 54b tx run data get storage llm params.ffn_w.182b
execute store result score 54e tx run data get storage llm params.ffn_w.182e
execute store result score 54s tx run data get storage llm params.ffn_w.182s
execute store result score 55b tx run data get storage llm params.ffn_w.183b
execute store result score 55e tx run data get storage llm params.ffn_w.183e
execute store result score 55s tx run data get storage llm params.ffn_w.183s
execute store result score 56b tx run data get storage llm params.ffn_w.184b
execute store result score 56e tx run data get storage llm params.ffn_w.184e
execute store result score 56s tx run data get storage llm params.ffn_w.184s
execute store result score 57b tx run data get storage llm params.ffn_w.185b
execute store result score 57e tx run data get storage llm params.ffn_w.185e
execute store result score 57s tx run data get storage llm params.ffn_w.185s
execute store result score 58b tx run data get storage llm params.ffn_w.186b
execute store result score 58e tx run data get storage llm params.ffn_w.186e
execute store result score 58s tx run data get storage llm params.ffn_w.186s
execute store result score 59b tx run data get storage llm params.ffn_w.187b
execute store result score 59e tx run data get storage llm params.ffn_w.187e
execute store result score 59s tx run data get storage llm params.ffn_w.187s
execute store result score 60b tx run data get storage llm params.ffn_w.188b
execute store result score 60e tx run data get storage llm params.ffn_w.188e
execute store result score 60s tx run data get storage llm params.ffn_w.188s
execute store result score 61b tx run data get storage llm params.ffn_w.189b
execute store result score 61e tx run data get storage llm params.ffn_w.189e
execute store result score 61s tx run data get storage llm params.ffn_w.189s
execute store result score 62b tx run data get storage llm params.ffn_w.190b
execute store result score 62e tx run data get storage llm params.ffn_w.190e
execute store result score 62s tx run data get storage llm params.ffn_w.190s
execute store result score 63b tx run data get storage llm params.ffn_w.191b
execute store result score 63e tx run data get storage llm params.ffn_w.191e
execute store result score 63s tx run data get storage llm params.ffn_w.191s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th"
data modify storage llm args.m set value "w1_2"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 22
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_2"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 23
function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_2"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 24
scoreboard players operation xb llm = 0b tx
scoreboard players operation xe llm = 0e tx
scoreboard players operation xs llm = 0s tx
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx
scoreboard players operation xe llm = 1e tx
scoreboard players operation xs llm = 1s tx
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx
scoreboard players operation xe llm = 2e tx
scoreboard players operation xs llm = 2s tx
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx
scoreboard players operation xe llm = 3e tx
scoreboard players operation xs llm = 3s tx
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx
scoreboard players operation xe llm = 4e tx
scoreboard players operation xs llm = 4s tx
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx
scoreboard players operation xe llm = 5e tx
scoreboard players operation xs llm = 5s tx
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx
scoreboard players operation xe llm = 6e tx
scoreboard players operation xs llm = 6s tx
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx
scoreboard players operation xe llm = 7e tx
scoreboard players operation xs llm = 7s tx
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx
scoreboard players operation xe llm = 8e tx
scoreboard players operation xs llm = 8s tx
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx
scoreboard players operation xe llm = 9e tx
scoreboard players operation xs llm = 9s tx
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx
scoreboard players operation xe llm = 10e tx
scoreboard players operation xs llm = 10s tx
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx
scoreboard players operation xe llm = 11e tx
scoreboard players operation xs llm = 11s tx
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx
scoreboard players operation xe llm = 12e tx
scoreboard players operation xs llm = 12s tx
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx
scoreboard players operation xe llm = 13e tx
scoreboard players operation xs llm = 13s tx
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx
scoreboard players operation xe llm = 14e tx
scoreboard players operation xs llm = 14s tx
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx
scoreboard players operation xe llm = 15e tx
scoreboard players operation xs llm = 15s tx
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx
scoreboard players operation xe llm = 16e tx
scoreboard players operation xs llm = 16s tx
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx
scoreboard players operation xe llm = 17e tx
scoreboard players operation xs llm = 17s tx
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx
scoreboard players operation xe llm = 18e tx
scoreboard players operation xs llm = 18s tx
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx
scoreboard players operation xe llm = 19e tx
scoreboard players operation xs llm = 19s tx
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx
scoreboard players operation xe llm = 20e tx
scoreboard players operation xs llm = 20s tx
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx
scoreboard players operation xe llm = 21e tx
scoreboard players operation xs llm = 21s tx
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx
scoreboard players operation xe llm = 22e tx
scoreboard players operation xs llm = 22s tx
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx
scoreboard players operation xe llm = 23e tx
scoreboard players operation xs llm = 23s tx
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx
scoreboard players operation xe llm = 24e tx
scoreboard players operation xs llm = 24s tx
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx
scoreboard players operation xe llm = 25e tx
scoreboard players operation xs llm = 25s tx
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx
scoreboard players operation xe llm = 26e tx
scoreboard players operation xs llm = 26s tx
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx
scoreboard players operation xe llm = 27e tx
scoreboard players operation xs llm = 27s tx
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx
scoreboard players operation xe llm = 28e tx
scoreboard players operation xs llm = 28s tx
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx
scoreboard players operation xe llm = 29e tx
scoreboard players operation xs llm = 29s tx
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx
scoreboard players operation xe llm = 30e tx
scoreboard players operation xs llm = 30s tx
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx
scoreboard players operation xe llm = 31e tx
scoreboard players operation xs llm = 31s tx
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx
scoreboard players operation xe llm = 32e tx
scoreboard players operation xs llm = 32s tx
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx
scoreboard players operation xe llm = 33e tx
scoreboard players operation xs llm = 33s tx
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx
scoreboard players operation xe llm = 34e tx
scoreboard players operation xs llm = 34s tx
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx
scoreboard players operation xe llm = 35e tx
scoreboard players operation xs llm = 35s tx
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx
scoreboard players operation xe llm = 36e tx
scoreboard players operation xs llm = 36s tx
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx
scoreboard players operation xe llm = 37e tx
scoreboard players operation xs llm = 37s tx
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx
scoreboard players operation xe llm = 38e tx
scoreboard players operation xs llm = 38s tx
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx
scoreboard players operation xe llm = 39e tx
scoreboard players operation xs llm = 39s tx
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx
scoreboard players operation xe llm = 40e tx
scoreboard players operation xs llm = 40s tx
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx
scoreboard players operation xe llm = 41e tx
scoreboard players operation xs llm = 41s tx
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx
scoreboard players operation xe llm = 42e tx
scoreboard players operation xs llm = 42s tx
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx
scoreboard players operation xe llm = 43e tx
scoreboard players operation xs llm = 43s tx
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx
scoreboard players operation xe llm = 44e tx
scoreboard players operation xs llm = 44s tx
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx
scoreboard players operation xe llm = 45e tx
scoreboard players operation xs llm = 45s tx
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx
scoreboard players operation xe llm = 46e tx
scoreboard players operation xs llm = 46s tx
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx
scoreboard players operation xe llm = 47e tx
scoreboard players operation xs llm = 47s tx
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx
scoreboard players operation xe llm = 48e tx
scoreboard players operation xs llm = 48s tx
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx
scoreboard players operation xe llm = 49e tx
scoreboard players operation xs llm = 49s tx
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx
scoreboard players operation xe llm = 50e tx
scoreboard players operation xs llm = 50s tx
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx
scoreboard players operation xe llm = 51e tx
scoreboard players operation xs llm = 51s tx
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx
scoreboard players operation xe llm = 52e tx
scoreboard players operation xs llm = 52s tx
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx
scoreboard players operation xe llm = 53e tx
scoreboard players operation xs llm = 53s tx
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx
scoreboard players operation xe llm = 54e tx
scoreboard players operation xs llm = 54s tx
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx
scoreboard players operation xe llm = 55e tx
scoreboard players operation xs llm = 55s tx
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx
scoreboard players operation xe llm = 56e tx
scoreboard players operation xs llm = 56s tx
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx
scoreboard players operation xe llm = 57e tx
scoreboard players operation xs llm = 57s tx
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx
scoreboard players operation xe llm = 58e tx
scoreboard players operation xs llm = 58s tx
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx
scoreboard players operation xe llm = 59e tx
scoreboard players operation xs llm = 59s tx
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx
scoreboard players operation xe llm = 60e tx
scoreboard players operation xs llm = 60s tx
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx
scoreboard players operation xe llm = 61e tx
scoreboard players operation xs llm = 61s tx
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx
scoreboard players operation xe llm = 62e tx
scoreboard players operation xs llm = 62s tx
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx
scoreboard players operation xe llm = 63e tx
scoreboard players operation xs llm = 63s tx
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.192b
execute store result score 0e tx run data get storage llm params.att_w.192e
execute store result score 0s tx run data get storage llm params.att_w.192s
execute store result score 1b tx run data get storage llm params.att_w.193b
execute store result score 1e tx run data get storage llm params.att_w.193e
execute store result score 1s tx run data get storage llm params.att_w.193s
execute store result score 2b tx run data get storage llm params.att_w.194b
execute store result score 2e tx run data get storage llm params.att_w.194e
execute store result score 2s tx run data get storage llm params.att_w.194s
execute store result score 3b tx run data get storage llm params.att_w.195b
execute store result score 3e tx run data get storage llm params.att_w.195e
execute store result score 3s tx run data get storage llm params.att_w.195s
execute store result score 4b tx run data get storage llm params.att_w.196b
execute store result score 4e tx run data get storage llm params.att_w.196e
execute store result score 4s tx run data get storage llm params.att_w.196s
execute store result score 5b tx run data get storage llm params.att_w.197b
execute store result score 5e tx run data get storage llm params.att_w.197e
execute store result score 5s tx run data get storage llm params.att_w.197s
execute store result score 6b tx run data get storage llm params.att_w.198b
execute store result score 6e tx run data get storage llm params.att_w.198e
execute store result score 6s tx run data get storage llm params.att_w.198s
execute store result score 7b tx run data get storage llm params.att_w.199b
execute store result score 7e tx run data get storage llm params.att_w.199e
execute store result score 7s tx run data get storage llm params.att_w.199s
execute store result score 8b tx run data get storage llm params.att_w.200b
execute store result score 8e tx run data get storage llm params.att_w.200e
execute store result score 8s tx run data get storage llm params.att_w.200s
execute store result score 9b tx run data get storage llm params.att_w.201b
execute store result score 9e tx run data get storage llm params.att_w.201e
execute store result score 9s tx run data get storage llm params.att_w.201s
execute store result score 10b tx run data get storage llm params.att_w.202b
execute store result score 10e tx run data get storage llm params.att_w.202e
execute store result score 10s tx run data get storage llm params.att_w.202s
execute store result score 11b tx run data get storage llm params.att_w.203b
execute store result score 11e tx run data get storage llm params.att_w.203e
execute store result score 11s tx run data get storage llm params.att_w.203s
execute store result score 12b tx run data get storage llm params.att_w.204b
execute store result score 12e tx run data get storage llm params.att_w.204e
execute store result score 12s tx run data get storage llm params.att_w.204s
execute store result score 13b tx run data get storage llm params.att_w.205b
execute store result score 13e tx run data get storage llm params.att_w.205e
execute store result score 13s tx run data get storage llm params.att_w.205s
execute store result score 14b tx run data get storage llm params.att_w.206b
execute store result score 14e tx run data get storage llm params.att_w.206e
execute store result score 14s tx run data get storage llm params.att_w.206s
execute store result score 15b tx run data get storage llm params.att_w.207b
execute store result score 15e tx run data get storage llm params.att_w.207e
execute store result score 15s tx run data get storage llm params.att_w.207s
execute store result score 16b tx run data get storage llm params.att_w.208b
execute store result score 16e tx run data get storage llm params.att_w.208e
execute store result score 16s tx run data get storage llm params.att_w.208s
execute store result score 17b tx run data get storage llm params.att_w.209b
execute store result score 17e tx run data get storage llm params.att_w.209e
execute store result score 17s tx run data get storage llm params.att_w.209s
execute store result score 18b tx run data get storage llm params.att_w.210b
execute store result score 18e tx run data get storage llm params.att_w.210e
execute store result score 18s tx run data get storage llm params.att_w.210s
execute store result score 19b tx run data get storage llm params.att_w.211b
execute store result score 19e tx run data get storage llm params.att_w.211e
execute store result score 19s tx run data get storage llm params.att_w.211s
execute store result score 20b tx run data get storage llm params.att_w.212b
execute store result score 20e tx run data get storage llm params.att_w.212e
execute store result score 20s tx run data get storage llm params.att_w.212s
execute store result score 21b tx run data get storage llm params.att_w.213b
execute store result score 21e tx run data get storage llm params.att_w.213e
execute store result score 21s tx run data get storage llm params.att_w.213s
execute store result score 22b tx run data get storage llm params.att_w.214b
execute store result score 22e tx run data get storage llm params.att_w.214e
execute store result score 22s tx run data get storage llm params.att_w.214s
execute store result score 23b tx run data get storage llm params.att_w.215b
execute store result score 23e tx run data get storage llm params.att_w.215e
execute store result score 23s tx run data get storage llm params.att_w.215s
execute store result score 24b tx run data get storage llm params.att_w.216b
execute store result score 24e tx run data get storage llm params.att_w.216e
execute store result score 24s tx run data get storage llm params.att_w.216s
execute store result score 25b tx run data get storage llm params.att_w.217b
execute store result score 25e tx run data get storage llm params.att_w.217e
execute store result score 25s tx run data get storage llm params.att_w.217s
execute store result score 26b tx run data get storage llm params.att_w.218b
execute store result score 26e tx run data get storage llm params.att_w.218e
execute store result score 26s tx run data get storage llm params.att_w.218s
execute store result score 27b tx run data get storage llm params.att_w.219b
execute store result score 27e tx run data get storage llm params.att_w.219e
execute store result score 27s tx run data get storage llm params.att_w.219s
execute store result score 28b tx run data get storage llm params.att_w.220b
execute store result score 28e tx run data get storage llm params.att_w.220e
execute store result score 28s tx run data get storage llm params.att_w.220s
execute store result score 29b tx run data get storage llm params.att_w.221b
execute store result score 29e tx run data get storage llm params.att_w.221e
execute store result score 29s tx run data get storage llm params.att_w.221s
execute store result score 30b tx run data get storage llm params.att_w.222b
execute store result score 30e tx run data get storage llm params.att_w.222e
execute store result score 30s tx run data get storage llm params.att_w.222s
execute store result score 31b tx run data get storage llm params.att_w.223b
execute store result score 31e tx run data get storage llm params.att_w.223e
execute store result score 31s tx run data get storage llm params.att_w.223s
execute store result score 32b tx run data get storage llm params.att_w.224b
execute store result score 32e tx run data get storage llm params.att_w.224e
execute store result score 32s tx run data get storage llm params.att_w.224s
execute store result score 33b tx run data get storage llm params.att_w.225b
execute store result score 33e tx run data get storage llm params.att_w.225e
execute store result score 33s tx run data get storage llm params.att_w.225s
execute store result score 34b tx run data get storage llm params.att_w.226b
execute store result score 34e tx run data get storage llm params.att_w.226e
execute store result score 34s tx run data get storage llm params.att_w.226s
execute store result score 35b tx run data get storage llm params.att_w.227b
execute store result score 35e tx run data get storage llm params.att_w.227e
execute store result score 35s tx run data get storage llm params.att_w.227s
execute store result score 36b tx run data get storage llm params.att_w.228b
execute store result score 36e tx run data get storage llm params.att_w.228e
execute store result score 36s tx run data get storage llm params.att_w.228s
execute store result score 37b tx run data get storage llm params.att_w.229b
execute store result score 37e tx run data get storage llm params.att_w.229e
execute store result score 37s tx run data get storage llm params.att_w.229s
execute store result score 38b tx run data get storage llm params.att_w.230b
execute store result score 38e tx run data get storage llm params.att_w.230e
execute store result score 38s tx run data get storage llm params.att_w.230s
execute store result score 39b tx run data get storage llm params.att_w.231b
execute store result score 39e tx run data get storage llm params.att_w.231e
execute store result score 39s tx run data get storage llm params.att_w.231s
execute store result score 40b tx run data get storage llm params.att_w.232b
execute store result score 40e tx run data get storage llm params.att_w.232e
execute store result score 40s tx run data get storage llm params.att_w.232s
execute store result score 41b tx run data get storage llm params.att_w.233b
execute store result score 41e tx run data get storage llm params.att_w.233e
execute store result score 41s tx run data get storage llm params.att_w.233s
execute store result score 42b tx run data get storage llm params.att_w.234b
execute store result score 42e tx run data get storage llm params.att_w.234e
execute store result score 42s tx run data get storage llm params.att_w.234s
execute store result score 43b tx run data get storage llm params.att_w.235b
execute store result score 43e tx run data get storage llm params.att_w.235e
execute store result score 43s tx run data get storage llm params.att_w.235s
execute store result score 44b tx run data get storage llm params.att_w.236b
execute store result score 44e tx run data get storage llm params.att_w.236e
execute store result score 44s tx run data get storage llm params.att_w.236s
execute store result score 45b tx run data get storage llm params.att_w.237b
execute store result score 45e tx run data get storage llm params.att_w.237e
execute store result score 45s tx run data get storage llm params.att_w.237s
execute store result score 46b tx run data get storage llm params.att_w.238b
execute store result score 46e tx run data get storage llm params.att_w.238e
execute store result score 46s tx run data get storage llm params.att_w.238s
execute store result score 47b tx run data get storage llm params.att_w.239b
execute store result score 47e tx run data get storage llm params.att_w.239e
execute store result score 47s tx run data get storage llm params.att_w.239s
execute store result score 48b tx run data get storage llm params.att_w.240b
execute store result score 48e tx run data get storage llm params.att_w.240e
execute store result score 48s tx run data get storage llm params.att_w.240s
execute store result score 49b tx run data get storage llm params.att_w.241b
execute store result score 49e tx run data get storage llm params.att_w.241e
execute store result score 49s tx run data get storage llm params.att_w.241s
execute store result score 50b tx run data get storage llm params.att_w.242b
execute store result score 50e tx run data get storage llm params.att_w.242e
execute store result score 50s tx run data get storage llm params.att_w.242s
execute store result score 51b tx run data get storage llm params.att_w.243b
execute store result score 51e tx run data get storage llm params.att_w.243e
execute store result score 51s tx run data get storage llm params.att_w.243s
execute store result score 52b tx run data get storage llm params.att_w.244b
execute store result score 52e tx run data get storage llm params.att_w.244e
execute store result score 52s tx run data get storage llm params.att_w.244s
execute store result score 53b tx run data get storage llm params.att_w.245b
execute store result score 53e tx run data get storage llm params.att_w.245e
execute store result score 53s tx run data get storage llm params.att_w.245s
execute store result score 54b tx run data get storage llm params.att_w.246b
execute store result score 54e tx run data get storage llm params.att_w.246e
execute store result score 54s tx run data get storage llm params.att_w.246s
execute store result score 55b tx run data get storage llm params.att_w.247b
execute store result score 55e tx run data get storage llm params.att_w.247e
execute store result score 55s tx run data get storage llm params.att_w.247s
execute store result score 56b tx run data get storage llm params.att_w.248b
execute store result score 56e tx run data get storage llm params.att_w.248e
execute store result score 56s tx run data get storage llm params.att_w.248s
execute store result score 57b tx run data get storage llm params.att_w.249b
execute store result score 57e tx run data get storage llm params.att_w.249e
execute store result score 57s tx run data get storage llm params.att_w.249s
execute store result score 58b tx run data get storage llm params.att_w.250b
execute store result score 58e tx run data get storage llm params.att_w.250e
execute store result score 58s tx run data get storage llm params.att_w.250s
execute store result score 59b tx run data get storage llm params.att_w.251b
execute store result score 59e tx run data get storage llm params.att_w.251e
execute store result score 59s tx run data get storage llm params.att_w.251s
execute store result score 60b tx run data get storage llm params.att_w.252b
execute store result score 60e tx run data get storage llm params.att_w.252e
execute store result score 60s tx run data get storage llm params.att_w.252s
execute store result score 61b tx run data get storage llm params.att_w.253b
execute store result score 61e tx run data get storage llm params.att_w.253e
execute store result score 61s tx run data get storage llm params.att_w.253s
execute store result score 62b tx run data get storage llm params.att_w.254b
execute store result score 62e tx run data get storage llm params.att_w.254e
execute store result score 62s tx run data get storage llm params.att_w.254s
execute store result score 63b tx run data get storage llm params.att_w.255b
execute store result score 63e tx run data get storage llm params.att_w.255e
execute store result score 63s tx run data get storage llm params.att_w.255s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_3"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 25
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_3"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 26
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_3"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 27
function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98304
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98305
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98306
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98307
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98308
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98309
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98310
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98311
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98312
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98313
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98314
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98315
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98316
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98317
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98318
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98319
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98320
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98321
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98322
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98323
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98324
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98325
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98326
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98327
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98328
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98329
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98330
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98331
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98332
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98333
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98334
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 98335
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:ctxwindow
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_0_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_0_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_0_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_0_3
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_0_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_1_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_1_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_1_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_1_3
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_1_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_2_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_2_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_2_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_2_3
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_2_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_3_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_3_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_3_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_3_3
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_3_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_4_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_4_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_4_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_4_3
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_4_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_5_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_5_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_5_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_5_3
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_5_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_6_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_6_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_6_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_6_3
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_6_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_7_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_3_7_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_7_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_3_7_3
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_3_7_4
bossbar set progress value 28
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_3"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 29
scoreboard players operation xb llm = 0b tx2
scoreboard players operation xe llm = 0e tx2
scoreboard players operation xs llm = 0s tx2
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx2
scoreboard players operation xe llm = 1e tx2
scoreboard players operation xs llm = 1s tx2
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx2
scoreboard players operation xe llm = 2e tx2
scoreboard players operation xs llm = 2s tx2
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx2
scoreboard players operation xe llm = 3e tx2
scoreboard players operation xs llm = 3s tx2
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx2
scoreboard players operation xe llm = 4e tx2
scoreboard players operation xs llm = 4s tx2
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx2
scoreboard players operation xe llm = 5e tx2
scoreboard players operation xs llm = 5s tx2
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx2
scoreboard players operation xe llm = 6e tx2
scoreboard players operation xs llm = 6s tx2
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx2
scoreboard players operation xe llm = 7e tx2
scoreboard players operation xs llm = 7s tx2
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx2
scoreboard players operation xe llm = 8e tx2
scoreboard players operation xs llm = 8s tx2
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx2
scoreboard players operation xe llm = 9e tx2
scoreboard players operation xs llm = 9s tx2
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx2
scoreboard players operation xe llm = 10e tx2
scoreboard players operation xs llm = 10s tx2
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx2
scoreboard players operation xe llm = 11e tx2
scoreboard players operation xs llm = 11s tx2
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx2
scoreboard players operation xe llm = 12e tx2
scoreboard players operation xs llm = 12s tx2
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx2
scoreboard players operation xe llm = 13e tx2
scoreboard players operation xs llm = 13s tx2
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx2
scoreboard players operation xe llm = 14e tx2
scoreboard players operation xs llm = 14s tx2
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx2
scoreboard players operation xe llm = 15e tx2
scoreboard players operation xs llm = 15s tx2
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx2
scoreboard players operation xe llm = 16e tx2
scoreboard players operation xs llm = 16s tx2
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx2
scoreboard players operation xe llm = 17e tx2
scoreboard players operation xs llm = 17s tx2
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx2
scoreboard players operation xe llm = 18e tx2
scoreboard players operation xs llm = 18s tx2
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx2
scoreboard players operation xe llm = 19e tx2
scoreboard players operation xs llm = 19s tx2
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx2
scoreboard players operation xe llm = 20e tx2
scoreboard players operation xs llm = 20s tx2
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx2
scoreboard players operation xe llm = 21e tx2
scoreboard players operation xs llm = 21s tx2
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx2
scoreboard players operation xe llm = 22e tx2
scoreboard players operation xs llm = 22s tx2
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx2
scoreboard players operation xe llm = 23e tx2
scoreboard players operation xs llm = 23s tx2
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx2
scoreboard players operation xe llm = 24e tx2
scoreboard players operation xs llm = 24s tx2
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx2
scoreboard players operation xe llm = 25e tx2
scoreboard players operation xs llm = 25s tx2
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx2
scoreboard players operation xe llm = 26e tx2
scoreboard players operation xs llm = 26s tx2
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx2
scoreboard players operation xe llm = 27e tx2
scoreboard players operation xs llm = 27s tx2
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx2
scoreboard players operation xe llm = 28e tx2
scoreboard players operation xs llm = 28s tx2
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx2
scoreboard players operation xe llm = 29e tx2
scoreboard players operation xs llm = 29s tx2
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx2
scoreboard players operation xe llm = 30e tx2
scoreboard players operation xs llm = 30s tx2
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx2
scoreboard players operation xe llm = 31e tx2
scoreboard players operation xs llm = 31s tx2
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx2
scoreboard players operation xe llm = 32e tx2
scoreboard players operation xs llm = 32s tx2
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx2
scoreboard players operation xe llm = 33e tx2
scoreboard players operation xs llm = 33s tx2
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx2
scoreboard players operation xe llm = 34e tx2
scoreboard players operation xs llm = 34s tx2
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx2
scoreboard players operation xe llm = 35e tx2
scoreboard players operation xs llm = 35s tx2
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx2
scoreboard players operation xe llm = 36e tx2
scoreboard players operation xs llm = 36s tx2
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx2
scoreboard players operation xe llm = 37e tx2
scoreboard players operation xs llm = 37s tx2
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx2
scoreboard players operation xe llm = 38e tx2
scoreboard players operation xs llm = 38s tx2
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx2
scoreboard players operation xe llm = 39e tx2
scoreboard players operation xs llm = 39s tx2
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx2
scoreboard players operation xe llm = 40e tx2
scoreboard players operation xs llm = 40s tx2
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx2
scoreboard players operation xe llm = 41e tx2
scoreboard players operation xs llm = 41s tx2
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx2
scoreboard players operation xe llm = 42e tx2
scoreboard players operation xs llm = 42s tx2
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx2
scoreboard players operation xe llm = 43e tx2
scoreboard players operation xs llm = 43s tx2
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx2
scoreboard players operation xe llm = 44e tx2
scoreboard players operation xs llm = 44s tx2
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx2
scoreboard players operation xe llm = 45e tx2
scoreboard players operation xs llm = 45s tx2
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx2
scoreboard players operation xe llm = 46e tx2
scoreboard players operation xs llm = 46s tx2
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx2
scoreboard players operation xe llm = 47e tx2
scoreboard players operation xs llm = 47s tx2
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx2
scoreboard players operation xe llm = 48e tx2
scoreboard players operation xs llm = 48s tx2
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx2
scoreboard players operation xe llm = 49e tx2
scoreboard players operation xs llm = 49s tx2
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx2
scoreboard players operation xe llm = 50e tx2
scoreboard players operation xs llm = 50s tx2
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx2
scoreboard players operation xe llm = 51e tx2
scoreboard players operation xs llm = 51s tx2
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx2
scoreboard players operation xe llm = 52e tx2
scoreboard players operation xs llm = 52s tx2
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx2
scoreboard players operation xe llm = 53e tx2
scoreboard players operation xs llm = 53s tx2
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx2
scoreboard players operation xe llm = 54e tx2
scoreboard players operation xs llm = 54s tx2
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx2
scoreboard players operation xe llm = 55e tx2
scoreboard players operation xs llm = 55s tx2
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx2
scoreboard players operation xe llm = 56e tx2
scoreboard players operation xs llm = 56s tx2
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx2
scoreboard players operation xe llm = 57e tx2
scoreboard players operation xs llm = 57s tx2
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx2
scoreboard players operation xe llm = 58e tx2
scoreboard players operation xs llm = 58s tx2
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx2
scoreboard players operation xe llm = 59e tx2
scoreboard players operation xs llm = 59s tx2
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx2
scoreboard players operation xe llm = 60e tx2
scoreboard players operation xs llm = 60s tx2
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx2
scoreboard players operation xe llm = 61e tx2
scoreboard players operation xs llm = 61s tx2
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx2
scoreboard players operation xe llm = 62e tx2
scoreboard players operation xs llm = 62s tx2
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx2
scoreboard players operation xe llm = 63e tx2
scoreboard players operation xs llm = 63s tx2
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.ffn_w.192b
execute store result score 0e tx run data get storage llm params.ffn_w.192e
execute store result score 0s tx run data get storage llm params.ffn_w.192s
execute store result score 1b tx run data get storage llm params.ffn_w.193b
execute store result score 1e tx run data get storage llm params.ffn_w.193e
execute store result score 1s tx run data get storage llm params.ffn_w.193s
execute store result score 2b tx run data get storage llm params.ffn_w.194b
execute store result score 2e tx run data get storage llm params.ffn_w.194e
execute store result score 2s tx run data get storage llm params.ffn_w.194s
execute store result score 3b tx run data get storage llm params.ffn_w.195b
execute store result score 3e tx run data get storage llm params.ffn_w.195e
execute store result score 3s tx run data get storage llm params.ffn_w.195s
execute store result score 4b tx run data get storage llm params.ffn_w.196b
execute store result score 4e tx run data get storage llm params.ffn_w.196e
execute store result score 4s tx run data get storage llm params.ffn_w.196s
execute store result score 5b tx run data get storage llm params.ffn_w.197b
execute store result score 5e tx run data get storage llm params.ffn_w.197e
execute store result score 5s tx run data get storage llm params.ffn_w.197s
execute store result score 6b tx run data get storage llm params.ffn_w.198b
execute store result score 6e tx run data get storage llm params.ffn_w.198e
execute store result score 6s tx run data get storage llm params.ffn_w.198s
execute store result score 7b tx run data get storage llm params.ffn_w.199b
execute store result score 7e tx run data get storage llm params.ffn_w.199e
execute store result score 7s tx run data get storage llm params.ffn_w.199s
execute store result score 8b tx run data get storage llm params.ffn_w.200b
execute store result score 8e tx run data get storage llm params.ffn_w.200e
execute store result score 8s tx run data get storage llm params.ffn_w.200s
execute store result score 9b tx run data get storage llm params.ffn_w.201b
execute store result score 9e tx run data get storage llm params.ffn_w.201e
execute store result score 9s tx run data get storage llm params.ffn_w.201s
execute store result score 10b tx run data get storage llm params.ffn_w.202b
execute store result score 10e tx run data get storage llm params.ffn_w.202e
execute store result score 10s tx run data get storage llm params.ffn_w.202s
execute store result score 11b tx run data get storage llm params.ffn_w.203b
execute store result score 11e tx run data get storage llm params.ffn_w.203e
execute store result score 11s tx run data get storage llm params.ffn_w.203s
execute store result score 12b tx run data get storage llm params.ffn_w.204b
execute store result score 12e tx run data get storage llm params.ffn_w.204e
execute store result score 12s tx run data get storage llm params.ffn_w.204s
execute store result score 13b tx run data get storage llm params.ffn_w.205b
execute store result score 13e tx run data get storage llm params.ffn_w.205e
execute store result score 13s tx run data get storage llm params.ffn_w.205s
execute store result score 14b tx run data get storage llm params.ffn_w.206b
execute store result score 14e tx run data get storage llm params.ffn_w.206e
execute store result score 14s tx run data get storage llm params.ffn_w.206s
execute store result score 15b tx run data get storage llm params.ffn_w.207b
execute store result score 15e tx run data get storage llm params.ffn_w.207e
execute store result score 15s tx run data get storage llm params.ffn_w.207s
execute store result score 16b tx run data get storage llm params.ffn_w.208b
execute store result score 16e tx run data get storage llm params.ffn_w.208e
execute store result score 16s tx run data get storage llm params.ffn_w.208s
execute store result score 17b tx run data get storage llm params.ffn_w.209b
execute store result score 17e tx run data get storage llm params.ffn_w.209e
execute store result score 17s tx run data get storage llm params.ffn_w.209s
execute store result score 18b tx run data get storage llm params.ffn_w.210b
execute store result score 18e tx run data get storage llm params.ffn_w.210e
execute store result score 18s tx run data get storage llm params.ffn_w.210s
execute store result score 19b tx run data get storage llm params.ffn_w.211b
execute store result score 19e tx run data get storage llm params.ffn_w.211e
execute store result score 19s tx run data get storage llm params.ffn_w.211s
execute store result score 20b tx run data get storage llm params.ffn_w.212b
execute store result score 20e tx run data get storage llm params.ffn_w.212e
execute store result score 20s tx run data get storage llm params.ffn_w.212s
execute store result score 21b tx run data get storage llm params.ffn_w.213b
execute store result score 21e tx run data get storage llm params.ffn_w.213e
execute store result score 21s tx run data get storage llm params.ffn_w.213s
execute store result score 22b tx run data get storage llm params.ffn_w.214b
execute store result score 22e tx run data get storage llm params.ffn_w.214e
execute store result score 22s tx run data get storage llm params.ffn_w.214s
execute store result score 23b tx run data get storage llm params.ffn_w.215b
execute store result score 23e tx run data get storage llm params.ffn_w.215e
execute store result score 23s tx run data get storage llm params.ffn_w.215s
execute store result score 24b tx run data get storage llm params.ffn_w.216b
execute store result score 24e tx run data get storage llm params.ffn_w.216e
execute store result score 24s tx run data get storage llm params.ffn_w.216s
execute store result score 25b tx run data get storage llm params.ffn_w.217b
execute store result score 25e tx run data get storage llm params.ffn_w.217e
execute store result score 25s tx run data get storage llm params.ffn_w.217s
execute store result score 26b tx run data get storage llm params.ffn_w.218b
execute store result score 26e tx run data get storage llm params.ffn_w.218e
execute store result score 26s tx run data get storage llm params.ffn_w.218s
execute store result score 27b tx run data get storage llm params.ffn_w.219b
execute store result score 27e tx run data get storage llm params.ffn_w.219e
execute store result score 27s tx run data get storage llm params.ffn_w.219s
execute store result score 28b tx run data get storage llm params.ffn_w.220b
execute store result score 28e tx run data get storage llm params.ffn_w.220e
execute store result score 28s tx run data get storage llm params.ffn_w.220s
execute store result score 29b tx run data get storage llm params.ffn_w.221b
execute store result score 29e tx run data get storage llm params.ffn_w.221e
execute store result score 29s tx run data get storage llm params.ffn_w.221s
execute store result score 30b tx run data get storage llm params.ffn_w.222b
execute store result score 30e tx run data get storage llm params.ffn_w.222e
execute store result score 30s tx run data get storage llm params.ffn_w.222s
execute store result score 31b tx run data get storage llm params.ffn_w.223b
execute store result score 31e tx run data get storage llm params.ffn_w.223e
execute store result score 31s tx run data get storage llm params.ffn_w.223s
execute store result score 32b tx run data get storage llm params.ffn_w.224b
execute store result score 32e tx run data get storage llm params.ffn_w.224e
execute store result score 32s tx run data get storage llm params.ffn_w.224s
execute store result score 33b tx run data get storage llm params.ffn_w.225b
execute store result score 33e tx run data get storage llm params.ffn_w.225e
execute store result score 33s tx run data get storage llm params.ffn_w.225s
execute store result score 34b tx run data get storage llm params.ffn_w.226b
execute store result score 34e tx run data get storage llm params.ffn_w.226e
execute store result score 34s tx run data get storage llm params.ffn_w.226s
execute store result score 35b tx run data get storage llm params.ffn_w.227b
execute store result score 35e tx run data get storage llm params.ffn_w.227e
execute store result score 35s tx run data get storage llm params.ffn_w.227s
execute store result score 36b tx run data get storage llm params.ffn_w.228b
execute store result score 36e tx run data get storage llm params.ffn_w.228e
execute store result score 36s tx run data get storage llm params.ffn_w.228s
execute store result score 37b tx run data get storage llm params.ffn_w.229b
execute store result score 37e tx run data get storage llm params.ffn_w.229e
execute store result score 37s tx run data get storage llm params.ffn_w.229s
execute store result score 38b tx run data get storage llm params.ffn_w.230b
execute store result score 38e tx run data get storage llm params.ffn_w.230e
execute store result score 38s tx run data get storage llm params.ffn_w.230s
execute store result score 39b tx run data get storage llm params.ffn_w.231b
execute store result score 39e tx run data get storage llm params.ffn_w.231e
execute store result score 39s tx run data get storage llm params.ffn_w.231s
execute store result score 40b tx run data get storage llm params.ffn_w.232b
execute store result score 40e tx run data get storage llm params.ffn_w.232e
execute store result score 40s tx run data get storage llm params.ffn_w.232s
execute store result score 41b tx run data get storage llm params.ffn_w.233b
execute store result score 41e tx run data get storage llm params.ffn_w.233e
execute store result score 41s tx run data get storage llm params.ffn_w.233s
execute store result score 42b tx run data get storage llm params.ffn_w.234b
execute store result score 42e tx run data get storage llm params.ffn_w.234e
execute store result score 42s tx run data get storage llm params.ffn_w.234s
execute store result score 43b tx run data get storage llm params.ffn_w.235b
execute store result score 43e tx run data get storage llm params.ffn_w.235e
execute store result score 43s tx run data get storage llm params.ffn_w.235s
execute store result score 44b tx run data get storage llm params.ffn_w.236b
execute store result score 44e tx run data get storage llm params.ffn_w.236e
execute store result score 44s tx run data get storage llm params.ffn_w.236s
execute store result score 45b tx run data get storage llm params.ffn_w.237b
execute store result score 45e tx run data get storage llm params.ffn_w.237e
execute store result score 45s tx run data get storage llm params.ffn_w.237s
execute store result score 46b tx run data get storage llm params.ffn_w.238b
execute store result score 46e tx run data get storage llm params.ffn_w.238e
execute store result score 46s tx run data get storage llm params.ffn_w.238s
execute store result score 47b tx run data get storage llm params.ffn_w.239b
execute store result score 47e tx run data get storage llm params.ffn_w.239e
execute store result score 47s tx run data get storage llm params.ffn_w.239s
execute store result score 48b tx run data get storage llm params.ffn_w.240b
execute store result score 48e tx run data get storage llm params.ffn_w.240e
execute store result score 48s tx run data get storage llm params.ffn_w.240s
execute store result score 49b tx run data get storage llm params.ffn_w.241b
execute store result score 49e tx run data get storage llm params.ffn_w.241e
execute store result score 49s tx run data get storage llm params.ffn_w.241s
execute store result score 50b tx run data get storage llm params.ffn_w.242b
execute store result score 50e tx run data get storage llm params.ffn_w.242e
execute store result score 50s tx run data get storage llm params.ffn_w.242s
execute store result score 51b tx run data get storage llm params.ffn_w.243b
execute store result score 51e tx run data get storage llm params.ffn_w.243e
execute store result score 51s tx run data get storage llm params.ffn_w.243s
execute store result score 52b tx run data get storage llm params.ffn_w.244b
execute store result score 52e tx run data get storage llm params.ffn_w.244e
execute store result score 52s tx run data get storage llm params.ffn_w.244s
execute store result score 53b tx run data get storage llm params.ffn_w.245b
execute store result score 53e tx run data get storage llm params.ffn_w.245e
execute store result score 53s tx run data get storage llm params.ffn_w.245s
execute store result score 54b tx run data get storage llm params.ffn_w.246b
execute store result score 54e tx run data get storage llm params.ffn_w.246e
execute store result score 54s tx run data get storage llm params.ffn_w.246s
execute store result score 55b tx run data get storage llm params.ffn_w.247b
execute store result score 55e tx run data get storage llm params.ffn_w.247e
execute store result score 55s tx run data get storage llm params.ffn_w.247s
execute store result score 56b tx run data get storage llm params.ffn_w.248b
execute store result score 56e tx run data get storage llm params.ffn_w.248e
execute store result score 56s tx run data get storage llm params.ffn_w.248s
execute store result score 57b tx run data get storage llm params.ffn_w.249b
execute store result score 57e tx run data get storage llm params.ffn_w.249e
execute store result score 57s tx run data get storage llm params.ffn_w.249s
execute store result score 58b tx run data get storage llm params.ffn_w.250b
execute store result score 58e tx run data get storage llm params.ffn_w.250e
execute store result score 58s tx run data get storage llm params.ffn_w.250s
execute store result score 59b tx run data get storage llm params.ffn_w.251b
execute store result score 59e tx run data get storage llm params.ffn_w.251e
execute store result score 59s tx run data get storage llm params.ffn_w.251s
execute store result score 60b tx run data get storage llm params.ffn_w.252b
execute store result score 60e tx run data get storage llm params.ffn_w.252e
execute store result score 60s tx run data get storage llm params.ffn_w.252s
execute store result score 61b tx run data get storage llm params.ffn_w.253b
execute store result score 61e tx run data get storage llm params.ffn_w.253e
execute store result score 61s tx run data get storage llm params.ffn_w.253s
execute store result score 62b tx run data get storage llm params.ffn_w.254b
execute store result score 62e tx run data get storage llm params.ffn_w.254e
execute store result score 62s tx run data get storage llm params.ffn_w.254s
execute store result score 63b tx run data get storage llm params.ffn_w.255b
execute store result score 63e tx run data get storage llm params.ffn_w.255e
execute store result score 63s tx run data get storage llm params.ffn_w.255s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th"
data modify storage llm args.m set value "w1_3"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 30
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_3"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 31
function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_3"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 32
scoreboard players operation xb llm = 0b tx
scoreboard players operation xe llm = 0e tx
scoreboard players operation xs llm = 0s tx
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx
scoreboard players operation xe llm = 1e tx
scoreboard players operation xs llm = 1s tx
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx
scoreboard players operation xe llm = 2e tx
scoreboard players operation xs llm = 2s tx
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx
scoreboard players operation xe llm = 3e tx
scoreboard players operation xs llm = 3s tx
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx
scoreboard players operation xe llm = 4e tx
scoreboard players operation xs llm = 4s tx
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx
scoreboard players operation xe llm = 5e tx
scoreboard players operation xs llm = 5s tx
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx
scoreboard players operation xe llm = 6e tx
scoreboard players operation xs llm = 6s tx
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx
scoreboard players operation xe llm = 7e tx
scoreboard players operation xs llm = 7s tx
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx
scoreboard players operation xe llm = 8e tx
scoreboard players operation xs llm = 8s tx
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx
scoreboard players operation xe llm = 9e tx
scoreboard players operation xs llm = 9s tx
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx
scoreboard players operation xe llm = 10e tx
scoreboard players operation xs llm = 10s tx
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx
scoreboard players operation xe llm = 11e tx
scoreboard players operation xs llm = 11s tx
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx
scoreboard players operation xe llm = 12e tx
scoreboard players operation xs llm = 12s tx
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx
scoreboard players operation xe llm = 13e tx
scoreboard players operation xs llm = 13s tx
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx
scoreboard players operation xe llm = 14e tx
scoreboard players operation xs llm = 14s tx
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx
scoreboard players operation xe llm = 15e tx
scoreboard players operation xs llm = 15s tx
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx
scoreboard players operation xe llm = 16e tx
scoreboard players operation xs llm = 16s tx
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx
scoreboard players operation xe llm = 17e tx
scoreboard players operation xs llm = 17s tx
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx
scoreboard players operation xe llm = 18e tx
scoreboard players operation xs llm = 18s tx
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx
scoreboard players operation xe llm = 19e tx
scoreboard players operation xs llm = 19s tx
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx
scoreboard players operation xe llm = 20e tx
scoreboard players operation xs llm = 20s tx
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx
scoreboard players operation xe llm = 21e tx
scoreboard players operation xs llm = 21s tx
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx
scoreboard players operation xe llm = 22e tx
scoreboard players operation xs llm = 22s tx
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx
scoreboard players operation xe llm = 23e tx
scoreboard players operation xs llm = 23s tx
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx
scoreboard players operation xe llm = 24e tx
scoreboard players operation xs llm = 24s tx
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx
scoreboard players operation xe llm = 25e tx
scoreboard players operation xs llm = 25s tx
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx
scoreboard players operation xe llm = 26e tx
scoreboard players operation xs llm = 26s tx
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx
scoreboard players operation xe llm = 27e tx
scoreboard players operation xs llm = 27s tx
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx
scoreboard players operation xe llm = 28e tx
scoreboard players operation xs llm = 28s tx
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx
scoreboard players operation xe llm = 29e tx
scoreboard players operation xs llm = 29s tx
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx
scoreboard players operation xe llm = 30e tx
scoreboard players operation xs llm = 30s tx
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx
scoreboard players operation xe llm = 31e tx
scoreboard players operation xs llm = 31s tx
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx
scoreboard players operation xe llm = 32e tx
scoreboard players operation xs llm = 32s tx
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx
scoreboard players operation xe llm = 33e tx
scoreboard players operation xs llm = 33s tx
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx
scoreboard players operation xe llm = 34e tx
scoreboard players operation xs llm = 34s tx
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx
scoreboard players operation xe llm = 35e tx
scoreboard players operation xs llm = 35s tx
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx
scoreboard players operation xe llm = 36e tx
scoreboard players operation xs llm = 36s tx
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx
scoreboard players operation xe llm = 37e tx
scoreboard players operation xs llm = 37s tx
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx
scoreboard players operation xe llm = 38e tx
scoreboard players operation xs llm = 38s tx
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx
scoreboard players operation xe llm = 39e tx
scoreboard players operation xs llm = 39s tx
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx
scoreboard players operation xe llm = 40e tx
scoreboard players operation xs llm = 40s tx
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx
scoreboard players operation xe llm = 41e tx
scoreboard players operation xs llm = 41s tx
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx
scoreboard players operation xe llm = 42e tx
scoreboard players operation xs llm = 42s tx
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx
scoreboard players operation xe llm = 43e tx
scoreboard players operation xs llm = 43s tx
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx
scoreboard players operation xe llm = 44e tx
scoreboard players operation xs llm = 44s tx
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx
scoreboard players operation xe llm = 45e tx
scoreboard players operation xs llm = 45s tx
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx
scoreboard players operation xe llm = 46e tx
scoreboard players operation xs llm = 46s tx
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx
scoreboard players operation xe llm = 47e tx
scoreboard players operation xs llm = 47s tx
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx
scoreboard players operation xe llm = 48e tx
scoreboard players operation xs llm = 48s tx
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx
scoreboard players operation xe llm = 49e tx
scoreboard players operation xs llm = 49s tx
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx
scoreboard players operation xe llm = 50e tx
scoreboard players operation xs llm = 50s tx
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx
scoreboard players operation xe llm = 51e tx
scoreboard players operation xs llm = 51s tx
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx
scoreboard players operation xe llm = 52e tx
scoreboard players operation xs llm = 52s tx
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx
scoreboard players operation xe llm = 53e tx
scoreboard players operation xs llm = 53s tx
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx
scoreboard players operation xe llm = 54e tx
scoreboard players operation xs llm = 54s tx
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx
scoreboard players operation xe llm = 55e tx
scoreboard players operation xs llm = 55s tx
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx
scoreboard players operation xe llm = 56e tx
scoreboard players operation xs llm = 56s tx
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx
scoreboard players operation xe llm = 57e tx
scoreboard players operation xs llm = 57s tx
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx
scoreboard players operation xe llm = 58e tx
scoreboard players operation xs llm = 58s tx
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx
scoreboard players operation xe llm = 59e tx
scoreboard players operation xs llm = 59s tx
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx
scoreboard players operation xe llm = 60e tx
scoreboard players operation xs llm = 60s tx
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx
scoreboard players operation xe llm = 61e tx
scoreboard players operation xs llm = 61s tx
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx
scoreboard players operation xe llm = 62e tx
scoreboard players operation xs llm = 62s tx
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx
scoreboard players operation xe llm = 63e tx
scoreboard players operation xs llm = 63s tx
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.256b
execute store result score 0e tx run data get storage llm params.att_w.256e
execute store result score 0s tx run data get storage llm params.att_w.256s
execute store result score 1b tx run data get storage llm params.att_w.257b
execute store result score 1e tx run data get storage llm params.att_w.257e
execute store result score 1s tx run data get storage llm params.att_w.257s
execute store result score 2b tx run data get storage llm params.att_w.258b
execute store result score 2e tx run data get storage llm params.att_w.258e
execute store result score 2s tx run data get storage llm params.att_w.258s
execute store result score 3b tx run data get storage llm params.att_w.259b
execute store result score 3e tx run data get storage llm params.att_w.259e
execute store result score 3s tx run data get storage llm params.att_w.259s
execute store result score 4b tx run data get storage llm params.att_w.260b
execute store result score 4e tx run data get storage llm params.att_w.260e
execute store result score 4s tx run data get storage llm params.att_w.260s
execute store result score 5b tx run data get storage llm params.att_w.261b
execute store result score 5e tx run data get storage llm params.att_w.261e
execute store result score 5s tx run data get storage llm params.att_w.261s
execute store result score 6b tx run data get storage llm params.att_w.262b
execute store result score 6e tx run data get storage llm params.att_w.262e
execute store result score 6s tx run data get storage llm params.att_w.262s
execute store result score 7b tx run data get storage llm params.att_w.263b
execute store result score 7e tx run data get storage llm params.att_w.263e
execute store result score 7s tx run data get storage llm params.att_w.263s
execute store result score 8b tx run data get storage llm params.att_w.264b
execute store result score 8e tx run data get storage llm params.att_w.264e
execute store result score 8s tx run data get storage llm params.att_w.264s
execute store result score 9b tx run data get storage llm params.att_w.265b
execute store result score 9e tx run data get storage llm params.att_w.265e
execute store result score 9s tx run data get storage llm params.att_w.265s
execute store result score 10b tx run data get storage llm params.att_w.266b
execute store result score 10e tx run data get storage llm params.att_w.266e
execute store result score 10s tx run data get storage llm params.att_w.266s
execute store result score 11b tx run data get storage llm params.att_w.267b
execute store result score 11e tx run data get storage llm params.att_w.267e
execute store result score 11s tx run data get storage llm params.att_w.267s
execute store result score 12b tx run data get storage llm params.att_w.268b
execute store result score 12e tx run data get storage llm params.att_w.268e
execute store result score 12s tx run data get storage llm params.att_w.268s
execute store result score 13b tx run data get storage llm params.att_w.269b
execute store result score 13e tx run data get storage llm params.att_w.269e
execute store result score 13s tx run data get storage llm params.att_w.269s
execute store result score 14b tx run data get storage llm params.att_w.270b
execute store result score 14e tx run data get storage llm params.att_w.270e
execute store result score 14s tx run data get storage llm params.att_w.270s
execute store result score 15b tx run data get storage llm params.att_w.271b
execute store result score 15e tx run data get storage llm params.att_w.271e
execute store result score 15s tx run data get storage llm params.att_w.271s
execute store result score 16b tx run data get storage llm params.att_w.272b
execute store result score 16e tx run data get storage llm params.att_w.272e
execute store result score 16s tx run data get storage llm params.att_w.272s
execute store result score 17b tx run data get storage llm params.att_w.273b
execute store result score 17e tx run data get storage llm params.att_w.273e
execute store result score 17s tx run data get storage llm params.att_w.273s
execute store result score 18b tx run data get storage llm params.att_w.274b
execute store result score 18e tx run data get storage llm params.att_w.274e
execute store result score 18s tx run data get storage llm params.att_w.274s
execute store result score 19b tx run data get storage llm params.att_w.275b
execute store result score 19e tx run data get storage llm params.att_w.275e
execute store result score 19s tx run data get storage llm params.att_w.275s
execute store result score 20b tx run data get storage llm params.att_w.276b
execute store result score 20e tx run data get storage llm params.att_w.276e
execute store result score 20s tx run data get storage llm params.att_w.276s
execute store result score 21b tx run data get storage llm params.att_w.277b
execute store result score 21e tx run data get storage llm params.att_w.277e
execute store result score 21s tx run data get storage llm params.att_w.277s
execute store result score 22b tx run data get storage llm params.att_w.278b
execute store result score 22e tx run data get storage llm params.att_w.278e
execute store result score 22s tx run data get storage llm params.att_w.278s
execute store result score 23b tx run data get storage llm params.att_w.279b
execute store result score 23e tx run data get storage llm params.att_w.279e
execute store result score 23s tx run data get storage llm params.att_w.279s
execute store result score 24b tx run data get storage llm params.att_w.280b
execute store result score 24e tx run data get storage llm params.att_w.280e
execute store result score 24s tx run data get storage llm params.att_w.280s
execute store result score 25b tx run data get storage llm params.att_w.281b
execute store result score 25e tx run data get storage llm params.att_w.281e
execute store result score 25s tx run data get storage llm params.att_w.281s
execute store result score 26b tx run data get storage llm params.att_w.282b
execute store result score 26e tx run data get storage llm params.att_w.282e
execute store result score 26s tx run data get storage llm params.att_w.282s
execute store result score 27b tx run data get storage llm params.att_w.283b
execute store result score 27e tx run data get storage llm params.att_w.283e
execute store result score 27s tx run data get storage llm params.att_w.283s
execute store result score 28b tx run data get storage llm params.att_w.284b
execute store result score 28e tx run data get storage llm params.att_w.284e
execute store result score 28s tx run data get storage llm params.att_w.284s
execute store result score 29b tx run data get storage llm params.att_w.285b
execute store result score 29e tx run data get storage llm params.att_w.285e
execute store result score 29s tx run data get storage llm params.att_w.285s
execute store result score 30b tx run data get storage llm params.att_w.286b
execute store result score 30e tx run data get storage llm params.att_w.286e
execute store result score 30s tx run data get storage llm params.att_w.286s
execute store result score 31b tx run data get storage llm params.att_w.287b
execute store result score 31e tx run data get storage llm params.att_w.287e
execute store result score 31s tx run data get storage llm params.att_w.287s
execute store result score 32b tx run data get storage llm params.att_w.288b
execute store result score 32e tx run data get storage llm params.att_w.288e
execute store result score 32s tx run data get storage llm params.att_w.288s
execute store result score 33b tx run data get storage llm params.att_w.289b
execute store result score 33e tx run data get storage llm params.att_w.289e
execute store result score 33s tx run data get storage llm params.att_w.289s
execute store result score 34b tx run data get storage llm params.att_w.290b
execute store result score 34e tx run data get storage llm params.att_w.290e
execute store result score 34s tx run data get storage llm params.att_w.290s
execute store result score 35b tx run data get storage llm params.att_w.291b
execute store result score 35e tx run data get storage llm params.att_w.291e
execute store result score 35s tx run data get storage llm params.att_w.291s
execute store result score 36b tx run data get storage llm params.att_w.292b
execute store result score 36e tx run data get storage llm params.att_w.292e
execute store result score 36s tx run data get storage llm params.att_w.292s
execute store result score 37b tx run data get storage llm params.att_w.293b
execute store result score 37e tx run data get storage llm params.att_w.293e
execute store result score 37s tx run data get storage llm params.att_w.293s
execute store result score 38b tx run data get storage llm params.att_w.294b
execute store result score 38e tx run data get storage llm params.att_w.294e
execute store result score 38s tx run data get storage llm params.att_w.294s
execute store result score 39b tx run data get storage llm params.att_w.295b
execute store result score 39e tx run data get storage llm params.att_w.295e
execute store result score 39s tx run data get storage llm params.att_w.295s
execute store result score 40b tx run data get storage llm params.att_w.296b
execute store result score 40e tx run data get storage llm params.att_w.296e
execute store result score 40s tx run data get storage llm params.att_w.296s
execute store result score 41b tx run data get storage llm params.att_w.297b
execute store result score 41e tx run data get storage llm params.att_w.297e
execute store result score 41s tx run data get storage llm params.att_w.297s
execute store result score 42b tx run data get storage llm params.att_w.298b
execute store result score 42e tx run data get storage llm params.att_w.298e
execute store result score 42s tx run data get storage llm params.att_w.298s
execute store result score 43b tx run data get storage llm params.att_w.299b
execute store result score 43e tx run data get storage llm params.att_w.299e
execute store result score 43s tx run data get storage llm params.att_w.299s
execute store result score 44b tx run data get storage llm params.att_w.300b
execute store result score 44e tx run data get storage llm params.att_w.300e
execute store result score 44s tx run data get storage llm params.att_w.300s
execute store result score 45b tx run data get storage llm params.att_w.301b
execute store result score 45e tx run data get storage llm params.att_w.301e
execute store result score 45s tx run data get storage llm params.att_w.301s
execute store result score 46b tx run data get storage llm params.att_w.302b
execute store result score 46e tx run data get storage llm params.att_w.302e
execute store result score 46s tx run data get storage llm params.att_w.302s
execute store result score 47b tx run data get storage llm params.att_w.303b
execute store result score 47e tx run data get storage llm params.att_w.303e
execute store result score 47s tx run data get storage llm params.att_w.303s
execute store result score 48b tx run data get storage llm params.att_w.304b
execute store result score 48e tx run data get storage llm params.att_w.304e
execute store result score 48s tx run data get storage llm params.att_w.304s
execute store result score 49b tx run data get storage llm params.att_w.305b
execute store result score 49e tx run data get storage llm params.att_w.305e
execute store result score 49s tx run data get storage llm params.att_w.305s
execute store result score 50b tx run data get storage llm params.att_w.306b
execute store result score 50e tx run data get storage llm params.att_w.306e
execute store result score 50s tx run data get storage llm params.att_w.306s
execute store result score 51b tx run data get storage llm params.att_w.307b
execute store result score 51e tx run data get storage llm params.att_w.307e
execute store result score 51s tx run data get storage llm params.att_w.307s
execute store result score 52b tx run data get storage llm params.att_w.308b
execute store result score 52e tx run data get storage llm params.att_w.308e
execute store result score 52s tx run data get storage llm params.att_w.308s
execute store result score 53b tx run data get storage llm params.att_w.309b
execute store result score 53e tx run data get storage llm params.att_w.309e
execute store result score 53s tx run data get storage llm params.att_w.309s
execute store result score 54b tx run data get storage llm params.att_w.310b
execute store result score 54e tx run data get storage llm params.att_w.310e
execute store result score 54s tx run data get storage llm params.att_w.310s
execute store result score 55b tx run data get storage llm params.att_w.311b
execute store result score 55e tx run data get storage llm params.att_w.311e
execute store result score 55s tx run data get storage llm params.att_w.311s
execute store result score 56b tx run data get storage llm params.att_w.312b
execute store result score 56e tx run data get storage llm params.att_w.312e
execute store result score 56s tx run data get storage llm params.att_w.312s
execute store result score 57b tx run data get storage llm params.att_w.313b
execute store result score 57e tx run data get storage llm params.att_w.313e
execute store result score 57s tx run data get storage llm params.att_w.313s
execute store result score 58b tx run data get storage llm params.att_w.314b
execute store result score 58e tx run data get storage llm params.att_w.314e
execute store result score 58s tx run data get storage llm params.att_w.314s
execute store result score 59b tx run data get storage llm params.att_w.315b
execute store result score 59e tx run data get storage llm params.att_w.315e
execute store result score 59s tx run data get storage llm params.att_w.315s
execute store result score 60b tx run data get storage llm params.att_w.316b
execute store result score 60e tx run data get storage llm params.att_w.316e
execute store result score 60s tx run data get storage llm params.att_w.316s
execute store result score 61b tx run data get storage llm params.att_w.317b
execute store result score 61e tx run data get storage llm params.att_w.317e
execute store result score 61s tx run data get storage llm params.att_w.317s
execute store result score 62b tx run data get storage llm params.att_w.318b
execute store result score 62e tx run data get storage llm params.att_w.318e
execute store result score 62s tx run data get storage llm params.att_w.318s
execute store result score 63b tx run data get storage llm params.att_w.319b
execute store result score 63e tx run data get storage llm params.att_w.319e
execute store result score 63s tx run data get storage llm params.att_w.319s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_4"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 33
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_4"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 34
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_4"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 35
function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131072
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131073
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131074
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131075
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131076
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131077
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131078
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131079
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131080
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131081
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131082
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131083
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131084
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131085
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131086
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131087
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131088
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131089
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131090
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131091
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131092
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131093
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131094
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131095
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131096
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131097
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131098
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131099
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131100
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131101
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131102
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 131103
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:ctxwindow
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_0_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_0_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_0_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_0_3
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_0_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_1_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_1_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_1_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_1_3
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_1_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_2_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_2_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_2_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_2_3
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_2_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_3_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_3_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_3_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_3_3
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_3_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_4_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_4_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_4_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_4_3
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_4_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_5_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_5_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_5_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_5_3
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_5_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_6_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_6_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_6_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_6_3
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_6_4
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_7_0
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:att_4_7_1
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_7_2
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:att_4_7_3
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:att_4_7_4
bossbar set progress value 36
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_4"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 37
scoreboard players operation xb llm = 0b tx2
scoreboard players operation xe llm = 0e tx2
scoreboard players operation xs llm = 0s tx2
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx2
scoreboard players operation xe llm = 1e tx2
scoreboard players operation xs llm = 1s tx2
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx2
scoreboard players operation xe llm = 2e tx2
scoreboard players operation xs llm = 2s tx2
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx2
scoreboard players operation xe llm = 3e tx2
scoreboard players operation xs llm = 3s tx2
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx2
scoreboard players operation xe llm = 4e tx2
scoreboard players operation xs llm = 4s tx2
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx2
scoreboard players operation xe llm = 5e tx2
scoreboard players operation xs llm = 5s tx2
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx2
scoreboard players operation xe llm = 6e tx2
scoreboard players operation xs llm = 6s tx2
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx2
scoreboard players operation xe llm = 7e tx2
scoreboard players operation xs llm = 7s tx2
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx2
scoreboard players operation xe llm = 8e tx2
scoreboard players operation xs llm = 8s tx2
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx2
scoreboard players operation xe llm = 9e tx2
scoreboard players operation xs llm = 9s tx2
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx2
scoreboard players operation xe llm = 10e tx2
scoreboard players operation xs llm = 10s tx2
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx2
scoreboard players operation xe llm = 11e tx2
scoreboard players operation xs llm = 11s tx2
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx2
scoreboard players operation xe llm = 12e tx2
scoreboard players operation xs llm = 12s tx2
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx2
scoreboard players operation xe llm = 13e tx2
scoreboard players operation xs llm = 13s tx2
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx2
scoreboard players operation xe llm = 14e tx2
scoreboard players operation xs llm = 14s tx2
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx2
scoreboard players operation xe llm = 15e tx2
scoreboard players operation xs llm = 15s tx2
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx2
scoreboard players operation xe llm = 16e tx2
scoreboard players operation xs llm = 16s tx2
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx2
scoreboard players operation xe llm = 17e tx2
scoreboard players operation xs llm = 17s tx2
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx2
scoreboard players operation xe llm = 18e tx2
scoreboard players operation xs llm = 18s tx2
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx2
scoreboard players operation xe llm = 19e tx2
scoreboard players operation xs llm = 19s tx2
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx2
scoreboard players operation xe llm = 20e tx2
scoreboard players operation xs llm = 20s tx2
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx2
scoreboard players operation xe llm = 21e tx2
scoreboard players operation xs llm = 21s tx2
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx2
scoreboard players operation xe llm = 22e tx2
scoreboard players operation xs llm = 22s tx2
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx2
scoreboard players operation xe llm = 23e tx2
scoreboard players operation xs llm = 23s tx2
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx2
scoreboard players operation xe llm = 24e tx2
scoreboard players operation xs llm = 24s tx2
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx2
scoreboard players operation xe llm = 25e tx2
scoreboard players operation xs llm = 25s tx2
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx2
scoreboard players operation xe llm = 26e tx2
scoreboard players operation xs llm = 26s tx2
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx2
scoreboard players operation xe llm = 27e tx2
scoreboard players operation xs llm = 27s tx2
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx2
scoreboard players operation xe llm = 28e tx2
scoreboard players operation xs llm = 28s tx2
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx2
scoreboard players operation xe llm = 29e tx2
scoreboard players operation xs llm = 29s tx2
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx2
scoreboard players operation xe llm = 30e tx2
scoreboard players operation xs llm = 30s tx2
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx2
scoreboard players operation xe llm = 31e tx2
scoreboard players operation xs llm = 31s tx2
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx2
scoreboard players operation xe llm = 32e tx2
scoreboard players operation xs llm = 32s tx2
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx2
scoreboard players operation xe llm = 33e tx2
scoreboard players operation xs llm = 33s tx2
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx2
scoreboard players operation xe llm = 34e tx2
scoreboard players operation xs llm = 34s tx2
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx2
scoreboard players operation xe llm = 35e tx2
scoreboard players operation xs llm = 35s tx2
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx2
scoreboard players operation xe llm = 36e tx2
scoreboard players operation xs llm = 36s tx2
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx2
scoreboard players operation xe llm = 37e tx2
scoreboard players operation xs llm = 37s tx2
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx2
scoreboard players operation xe llm = 38e tx2
scoreboard players operation xs llm = 38s tx2
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx2
scoreboard players operation xe llm = 39e tx2
scoreboard players operation xs llm = 39s tx2
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx2
scoreboard players operation xe llm = 40e tx2
scoreboard players operation xs llm = 40s tx2
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx2
scoreboard players operation xe llm = 41e tx2
scoreboard players operation xs llm = 41s tx2
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx2
scoreboard players operation xe llm = 42e tx2
scoreboard players operation xs llm = 42s tx2
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx2
scoreboard players operation xe llm = 43e tx2
scoreboard players operation xs llm = 43s tx2
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx2
scoreboard players operation xe llm = 44e tx2
scoreboard players operation xs llm = 44s tx2
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx2
scoreboard players operation xe llm = 45e tx2
scoreboard players operation xs llm = 45s tx2
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx2
scoreboard players operation xe llm = 46e tx2
scoreboard players operation xs llm = 46s tx2
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx2
scoreboard players operation xe llm = 47e tx2
scoreboard players operation xs llm = 47s tx2
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx2
scoreboard players operation xe llm = 48e tx2
scoreboard players operation xs llm = 48s tx2
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx2
scoreboard players operation xe llm = 49e tx2
scoreboard players operation xs llm = 49s tx2
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx2
scoreboard players operation xe llm = 50e tx2
scoreboard players operation xs llm = 50s tx2
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx2
scoreboard players operation xe llm = 51e tx2
scoreboard players operation xs llm = 51s tx2
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx2
scoreboard players operation xe llm = 52e tx2
scoreboard players operation xs llm = 52s tx2
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx2
scoreboard players operation xe llm = 53e tx2
scoreboard players operation xs llm = 53s tx2
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx2
scoreboard players operation xe llm = 54e tx2
scoreboard players operation xs llm = 54s tx2
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx2
scoreboard players operation xe llm = 55e tx2
scoreboard players operation xs llm = 55s tx2
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx2
scoreboard players operation xe llm = 56e tx2
scoreboard players operation xs llm = 56s tx2
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx2
scoreboard players operation xe llm = 57e tx2
scoreboard players operation xs llm = 57s tx2
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx2
scoreboard players operation xe llm = 58e tx2
scoreboard players operation xs llm = 58s tx2
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx2
scoreboard players operation xe llm = 59e tx2
scoreboard players operation xs llm = 59s tx2
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx2
scoreboard players operation xe llm = 60e tx2
scoreboard players operation xs llm = 60s tx2
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx2
scoreboard players operation xe llm = 61e tx2
scoreboard players operation xs llm = 61s tx2
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx2
scoreboard players operation xe llm = 62e tx2
scoreboard players operation xs llm = 62s tx2
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx2
scoreboard players operation xe llm = 63e tx2
scoreboard players operation xs llm = 63s tx2
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.ffn_w.256b
execute store result score 0e tx run data get storage llm params.ffn_w.256e
execute store result score 0s tx run data get storage llm params.ffn_w.256s
execute store result score 1b tx run data get storage llm params.ffn_w.257b
execute store result score 1e tx run data get storage llm params.ffn_w.257e
execute store result score 1s tx run data get storage llm params.ffn_w.257s
execute store result score 2b tx run data get storage llm params.ffn_w.258b
execute store result score 2e tx run data get storage llm params.ffn_w.258e
execute store result score 2s tx run data get storage llm params.ffn_w.258s
execute store result score 3b tx run data get storage llm params.ffn_w.259b
execute store result score 3e tx run data get storage llm params.ffn_w.259e
execute store result score 3s tx run data get storage llm params.ffn_w.259s
execute store result score 4b tx run data get storage llm params.ffn_w.260b
execute store result score 4e tx run data get storage llm params.ffn_w.260e
execute store result score 4s tx run data get storage llm params.ffn_w.260s
execute store result score 5b tx run data get storage llm params.ffn_w.261b
execute store result score 5e tx run data get storage llm params.ffn_w.261e
execute store result score 5s tx run data get storage llm params.ffn_w.261s
execute store result score 6b tx run data get storage llm params.ffn_w.262b
execute store result score 6e tx run data get storage llm params.ffn_w.262e
execute store result score 6s tx run data get storage llm params.ffn_w.262s
execute store result score 7b tx run data get storage llm params.ffn_w.263b
execute store result score 7e tx run data get storage llm params.ffn_w.263e
execute store result score 7s tx run data get storage llm params.ffn_w.263s
execute store result score 8b tx run data get storage llm params.ffn_w.264b
execute store result score 8e tx run data get storage llm params.ffn_w.264e
execute store result score 8s tx run data get storage llm params.ffn_w.264s
execute store result score 9b tx run data get storage llm params.ffn_w.265b
execute store result score 9e tx run data get storage llm params.ffn_w.265e
execute store result score 9s tx run data get storage llm params.ffn_w.265s
execute store result score 10b tx run data get storage llm params.ffn_w.266b
execute store result score 10e tx run data get storage llm params.ffn_w.266e
execute store result score 10s tx run data get storage llm params.ffn_w.266s
execute store result score 11b tx run data get storage llm params.ffn_w.267b
execute store result score 11e tx run data get storage llm params.ffn_w.267e
execute store result score 11s tx run data get storage llm params.ffn_w.267s
execute store result score 12b tx run data get storage llm params.ffn_w.268b
execute store result score 12e tx run data get storage llm params.ffn_w.268e
execute store result score 12s tx run data get storage llm params.ffn_w.268s
execute store result score 13b tx run data get storage llm params.ffn_w.269b
execute store result score 13e tx run data get storage llm params.ffn_w.269e
execute store result score 13s tx run data get storage llm params.ffn_w.269s
execute store result score 14b tx run data get storage llm params.ffn_w.270b
execute store result score 14e tx run data get storage llm params.ffn_w.270e
execute store result score 14s tx run data get storage llm params.ffn_w.270s
execute store result score 15b tx run data get storage llm params.ffn_w.271b
execute store result score 15e tx run data get storage llm params.ffn_w.271e
execute store result score 15s tx run data get storage llm params.ffn_w.271s
execute store result score 16b tx run data get storage llm params.ffn_w.272b
execute store result score 16e tx run data get storage llm params.ffn_w.272e
execute store result score 16s tx run data get storage llm params.ffn_w.272s
execute store result score 17b tx run data get storage llm params.ffn_w.273b
execute store result score 17e tx run data get storage llm params.ffn_w.273e
execute store result score 17s tx run data get storage llm params.ffn_w.273s
execute store result score 18b tx run data get storage llm params.ffn_w.274b
execute store result score 18e tx run data get storage llm params.ffn_w.274e
execute store result score 18s tx run data get storage llm params.ffn_w.274s
execute store result score 19b tx run data get storage llm params.ffn_w.275b
execute store result score 19e tx run data get storage llm params.ffn_w.275e
execute store result score 19s tx run data get storage llm params.ffn_w.275s
execute store result score 20b tx run data get storage llm params.ffn_w.276b
execute store result score 20e tx run data get storage llm params.ffn_w.276e
execute store result score 20s tx run data get storage llm params.ffn_w.276s
execute store result score 21b tx run data get storage llm params.ffn_w.277b
execute store result score 21e tx run data get storage llm params.ffn_w.277e
execute store result score 21s tx run data get storage llm params.ffn_w.277s
execute store result score 22b tx run data get storage llm params.ffn_w.278b
execute store result score 22e tx run data get storage llm params.ffn_w.278e
execute store result score 22s tx run data get storage llm params.ffn_w.278s
execute store result score 23b tx run data get storage llm params.ffn_w.279b
execute store result score 23e tx run data get storage llm params.ffn_w.279e
execute store result score 23s tx run data get storage llm params.ffn_w.279s
execute store result score 24b tx run data get storage llm params.ffn_w.280b
execute store result score 24e tx run data get storage llm params.ffn_w.280e
execute store result score 24s tx run data get storage llm params.ffn_w.280s
execute store result score 25b tx run data get storage llm params.ffn_w.281b
execute store result score 25e tx run data get storage llm params.ffn_w.281e
execute store result score 25s tx run data get storage llm params.ffn_w.281s
execute store result score 26b tx run data get storage llm params.ffn_w.282b
execute store result score 26e tx run data get storage llm params.ffn_w.282e
execute store result score 26s tx run data get storage llm params.ffn_w.282s
execute store result score 27b tx run data get storage llm params.ffn_w.283b
execute store result score 27e tx run data get storage llm params.ffn_w.283e
execute store result score 27s tx run data get storage llm params.ffn_w.283s
execute store result score 28b tx run data get storage llm params.ffn_w.284b
execute store result score 28e tx run data get storage llm params.ffn_w.284e
execute store result score 28s tx run data get storage llm params.ffn_w.284s
execute store result score 29b tx run data get storage llm params.ffn_w.285b
execute store result score 29e tx run data get storage llm params.ffn_w.285e
execute store result score 29s tx run data get storage llm params.ffn_w.285s
execute store result score 30b tx run data get storage llm params.ffn_w.286b
execute store result score 30e tx run data get storage llm params.ffn_w.286e
execute store result score 30s tx run data get storage llm params.ffn_w.286s
execute store result score 31b tx run data get storage llm params.ffn_w.287b
execute store result score 31e tx run data get storage llm params.ffn_w.287e
execute store result score 31s tx run data get storage llm params.ffn_w.287s
execute store result score 32b tx run data get storage llm params.ffn_w.288b
execute store result score 32e tx run data get storage llm params.ffn_w.288e
execute store result score 32s tx run data get storage llm params.ffn_w.288s
execute store result score 33b tx run data get storage llm params.ffn_w.289b
execute store result score 33e tx run data get storage llm params.ffn_w.289e
execute store result score 33s tx run data get storage llm params.ffn_w.289s
execute store result score 34b tx run data get storage llm params.ffn_w.290b
execute store result score 34e tx run data get storage llm params.ffn_w.290e
execute store result score 34s tx run data get storage llm params.ffn_w.290s
execute store result score 35b tx run data get storage llm params.ffn_w.291b
execute store result score 35e tx run data get storage llm params.ffn_w.291e
execute store result score 35s tx run data get storage llm params.ffn_w.291s
execute store result score 36b tx run data get storage llm params.ffn_w.292b
execute store result score 36e tx run data get storage llm params.ffn_w.292e
execute store result score 36s tx run data get storage llm params.ffn_w.292s
execute store result score 37b tx run data get storage llm params.ffn_w.293b
execute store result score 37e tx run data get storage llm params.ffn_w.293e
execute store result score 37s tx run data get storage llm params.ffn_w.293s
execute store result score 38b tx run data get storage llm params.ffn_w.294b
execute store result score 38e tx run data get storage llm params.ffn_w.294e
execute store result score 38s tx run data get storage llm params.ffn_w.294s
execute store result score 39b tx run data get storage llm params.ffn_w.295b
execute store result score 39e tx run data get storage llm params.ffn_w.295e
execute store result score 39s tx run data get storage llm params.ffn_w.295s
execute store result score 40b tx run data get storage llm params.ffn_w.296b
execute store result score 40e tx run data get storage llm params.ffn_w.296e
execute store result score 40s tx run data get storage llm params.ffn_w.296s
execute store result score 41b tx run data get storage llm params.ffn_w.297b
execute store result score 41e tx run data get storage llm params.ffn_w.297e
execute store result score 41s tx run data get storage llm params.ffn_w.297s
execute store result score 42b tx run data get storage llm params.ffn_w.298b
execute store result score 42e tx run data get storage llm params.ffn_w.298e
execute store result score 42s tx run data get storage llm params.ffn_w.298s
execute store result score 43b tx run data get storage llm params.ffn_w.299b
execute store result score 43e tx run data get storage llm params.ffn_w.299e
execute store result score 43s tx run data get storage llm params.ffn_w.299s
execute store result score 44b tx run data get storage llm params.ffn_w.300b
execute store result score 44e tx run data get storage llm params.ffn_w.300e
execute store result score 44s tx run data get storage llm params.ffn_w.300s
execute store result score 45b tx run data get storage llm params.ffn_w.301b
execute store result score 45e tx run data get storage llm params.ffn_w.301e
execute store result score 45s tx run data get storage llm params.ffn_w.301s
execute store result score 46b tx run data get storage llm params.ffn_w.302b
execute store result score 46e tx run data get storage llm params.ffn_w.302e
execute store result score 46s tx run data get storage llm params.ffn_w.302s
execute store result score 47b tx run data get storage llm params.ffn_w.303b
execute store result score 47e tx run data get storage llm params.ffn_w.303e
execute store result score 47s tx run data get storage llm params.ffn_w.303s
execute store result score 48b tx run data get storage llm params.ffn_w.304b
execute store result score 48e tx run data get storage llm params.ffn_w.304e
execute store result score 48s tx run data get storage llm params.ffn_w.304s
execute store result score 49b tx run data get storage llm params.ffn_w.305b
execute store result score 49e tx run data get storage llm params.ffn_w.305e
execute store result score 49s tx run data get storage llm params.ffn_w.305s
execute store result score 50b tx run data get storage llm params.ffn_w.306b
execute store result score 50e tx run data get storage llm params.ffn_w.306e
execute store result score 50s tx run data get storage llm params.ffn_w.306s
execute store result score 51b tx run data get storage llm params.ffn_w.307b
execute store result score 51e tx run data get storage llm params.ffn_w.307e
execute store result score 51s tx run data get storage llm params.ffn_w.307s
execute store result score 52b tx run data get storage llm params.ffn_w.308b
execute store result score 52e tx run data get storage llm params.ffn_w.308e
execute store result score 52s tx run data get storage llm params.ffn_w.308s
execute store result score 53b tx run data get storage llm params.ffn_w.309b
execute store result score 53e tx run data get storage llm params.ffn_w.309e
execute store result score 53s tx run data get storage llm params.ffn_w.309s
execute store result score 54b tx run data get storage llm params.ffn_w.310b
execute store result score 54e tx run data get storage llm params.ffn_w.310e
execute store result score 54s tx run data get storage llm params.ffn_w.310s
execute store result score 55b tx run data get storage llm params.ffn_w.311b
execute store result score 55e tx run data get storage llm params.ffn_w.311e
execute store result score 55s tx run data get storage llm params.ffn_w.311s
execute store result score 56b tx run data get storage llm params.ffn_w.312b
execute store result score 56e tx run data get storage llm params.ffn_w.312e
execute store result score 56s tx run data get storage llm params.ffn_w.312s
execute store result score 57b tx run data get storage llm params.ffn_w.313b
execute store result score 57e tx run data get storage llm params.ffn_w.313e
execute store result score 57s tx run data get storage llm params.ffn_w.313s
execute store result score 58b tx run data get storage llm params.ffn_w.314b
execute store result score 58e tx run data get storage llm params.ffn_w.314e
execute store result score 58s tx run data get storage llm params.ffn_w.314s
execute store result score 59b tx run data get storage llm params.ffn_w.315b
execute store result score 59e tx run data get storage llm params.ffn_w.315e
execute store result score 59s tx run data get storage llm params.ffn_w.315s
execute store result score 60b tx run data get storage llm params.ffn_w.316b
execute store result score 60e tx run data get storage llm params.ffn_w.316e
execute store result score 60s tx run data get storage llm params.ffn_w.316s
execute store result score 61b tx run data get storage llm params.ffn_w.317b
execute store result score 61e tx run data get storage llm params.ffn_w.317e
execute store result score 61s tx run data get storage llm params.ffn_w.317s
execute store result score 62b tx run data get storage llm params.ffn_w.318b
execute store result score 62e tx run data get storage llm params.ffn_w.318e
execute store result score 62s tx run data get storage llm params.ffn_w.318s
execute store result score 63b tx run data get storage llm params.ffn_w.319b
execute store result score 63e tx run data get storage llm params.ffn_w.319e
execute store result score 63s tx run data get storage llm params.ffn_w.319s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th"
data modify storage llm args.m set value "w1_4"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 38
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_4"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 39
function llm:silu
data modify storage llm args.in set value "th"
data modify storage llm args.out set value "tx"
data modify storage llm args.m set value "w2_4"
scoreboard players set s1 llm 64
scoreboard players set s2 llm 172
function llm:matmul
bossbar set progress value 40
scoreboard players operation xb llm = 0b tx
scoreboard players operation xe llm = 0e tx
scoreboard players operation xs llm = 0s tx
scoreboard players operation yb llm = 0b x
scoreboard players operation ye llm = 0e x
scoreboard players operation ys llm = 0s x
function llm:add
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b tx
scoreboard players operation xe llm = 1e tx
scoreboard players operation xs llm = 1s tx
scoreboard players operation yb llm = 1b x
scoreboard players operation ye llm = 1e x
scoreboard players operation ys llm = 1s x
function llm:add
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b tx
scoreboard players operation xe llm = 2e tx
scoreboard players operation xs llm = 2s tx
scoreboard players operation yb llm = 2b x
scoreboard players operation ye llm = 2e x
scoreboard players operation ys llm = 2s x
function llm:add
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b tx
scoreboard players operation xe llm = 3e tx
scoreboard players operation xs llm = 3s tx
scoreboard players operation yb llm = 3b x
scoreboard players operation ye llm = 3e x
scoreboard players operation ys llm = 3s x
function llm:add
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b tx
scoreboard players operation xe llm = 4e tx
scoreboard players operation xs llm = 4s tx
scoreboard players operation yb llm = 4b x
scoreboard players operation ye llm = 4e x
scoreboard players operation ys llm = 4s x
function llm:add
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b tx
scoreboard players operation xe llm = 5e tx
scoreboard players operation xs llm = 5s tx
scoreboard players operation yb llm = 5b x
scoreboard players operation ye llm = 5e x
scoreboard players operation ys llm = 5s x
function llm:add
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b tx
scoreboard players operation xe llm = 6e tx
scoreboard players operation xs llm = 6s tx
scoreboard players operation yb llm = 6b x
scoreboard players operation ye llm = 6e x
scoreboard players operation ys llm = 6s x
function llm:add
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b tx
scoreboard players operation xe llm = 7e tx
scoreboard players operation xs llm = 7s tx
scoreboard players operation yb llm = 7b x
scoreboard players operation ye llm = 7e x
scoreboard players operation ys llm = 7s x
function llm:add
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b tx
scoreboard players operation xe llm = 8e tx
scoreboard players operation xs llm = 8s tx
scoreboard players operation yb llm = 8b x
scoreboard players operation ye llm = 8e x
scoreboard players operation ys llm = 8s x
function llm:add
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b tx
scoreboard players operation xe llm = 9e tx
scoreboard players operation xs llm = 9s tx
scoreboard players operation yb llm = 9b x
scoreboard players operation ye llm = 9e x
scoreboard players operation ys llm = 9s x
function llm:add
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b tx
scoreboard players operation xe llm = 10e tx
scoreboard players operation xs llm = 10s tx
scoreboard players operation yb llm = 10b x
scoreboard players operation ye llm = 10e x
scoreboard players operation ys llm = 10s x
function llm:add
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b tx
scoreboard players operation xe llm = 11e tx
scoreboard players operation xs llm = 11s tx
scoreboard players operation yb llm = 11b x
scoreboard players operation ye llm = 11e x
scoreboard players operation ys llm = 11s x
function llm:add
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b tx
scoreboard players operation xe llm = 12e tx
scoreboard players operation xs llm = 12s tx
scoreboard players operation yb llm = 12b x
scoreboard players operation ye llm = 12e x
scoreboard players operation ys llm = 12s x
function llm:add
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b tx
scoreboard players operation xe llm = 13e tx
scoreboard players operation xs llm = 13s tx
scoreboard players operation yb llm = 13b x
scoreboard players operation ye llm = 13e x
scoreboard players operation ys llm = 13s x
function llm:add
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b tx
scoreboard players operation xe llm = 14e tx
scoreboard players operation xs llm = 14s tx
scoreboard players operation yb llm = 14b x
scoreboard players operation ye llm = 14e x
scoreboard players operation ys llm = 14s x
function llm:add
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b tx
scoreboard players operation xe llm = 15e tx
scoreboard players operation xs llm = 15s tx
scoreboard players operation yb llm = 15b x
scoreboard players operation ye llm = 15e x
scoreboard players operation ys llm = 15s x
function llm:add
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b tx
scoreboard players operation xe llm = 16e tx
scoreboard players operation xs llm = 16s tx
scoreboard players operation yb llm = 16b x
scoreboard players operation ye llm = 16e x
scoreboard players operation ys llm = 16s x
function llm:add
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b tx
scoreboard players operation xe llm = 17e tx
scoreboard players operation xs llm = 17s tx
scoreboard players operation yb llm = 17b x
scoreboard players operation ye llm = 17e x
scoreboard players operation ys llm = 17s x
function llm:add
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b tx
scoreboard players operation xe llm = 18e tx
scoreboard players operation xs llm = 18s tx
scoreboard players operation yb llm = 18b x
scoreboard players operation ye llm = 18e x
scoreboard players operation ys llm = 18s x
function llm:add
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b tx
scoreboard players operation xe llm = 19e tx
scoreboard players operation xs llm = 19s tx
scoreboard players operation yb llm = 19b x
scoreboard players operation ye llm = 19e x
scoreboard players operation ys llm = 19s x
function llm:add
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b tx
scoreboard players operation xe llm = 20e tx
scoreboard players operation xs llm = 20s tx
scoreboard players operation yb llm = 20b x
scoreboard players operation ye llm = 20e x
scoreboard players operation ys llm = 20s x
function llm:add
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b tx
scoreboard players operation xe llm = 21e tx
scoreboard players operation xs llm = 21s tx
scoreboard players operation yb llm = 21b x
scoreboard players operation ye llm = 21e x
scoreboard players operation ys llm = 21s x
function llm:add
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b tx
scoreboard players operation xe llm = 22e tx
scoreboard players operation xs llm = 22s tx
scoreboard players operation yb llm = 22b x
scoreboard players operation ye llm = 22e x
scoreboard players operation ys llm = 22s x
function llm:add
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b tx
scoreboard players operation xe llm = 23e tx
scoreboard players operation xs llm = 23s tx
scoreboard players operation yb llm = 23b x
scoreboard players operation ye llm = 23e x
scoreboard players operation ys llm = 23s x
function llm:add
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b tx
scoreboard players operation xe llm = 24e tx
scoreboard players operation xs llm = 24s tx
scoreboard players operation yb llm = 24b x
scoreboard players operation ye llm = 24e x
scoreboard players operation ys llm = 24s x
function llm:add
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b tx
scoreboard players operation xe llm = 25e tx
scoreboard players operation xs llm = 25s tx
scoreboard players operation yb llm = 25b x
scoreboard players operation ye llm = 25e x
scoreboard players operation ys llm = 25s x
function llm:add
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b tx
scoreboard players operation xe llm = 26e tx
scoreboard players operation xs llm = 26s tx
scoreboard players operation yb llm = 26b x
scoreboard players operation ye llm = 26e x
scoreboard players operation ys llm = 26s x
function llm:add
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b tx
scoreboard players operation xe llm = 27e tx
scoreboard players operation xs llm = 27s tx
scoreboard players operation yb llm = 27b x
scoreboard players operation ye llm = 27e x
scoreboard players operation ys llm = 27s x
function llm:add
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b tx
scoreboard players operation xe llm = 28e tx
scoreboard players operation xs llm = 28s tx
scoreboard players operation yb llm = 28b x
scoreboard players operation ye llm = 28e x
scoreboard players operation ys llm = 28s x
function llm:add
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b tx
scoreboard players operation xe llm = 29e tx
scoreboard players operation xs llm = 29s tx
scoreboard players operation yb llm = 29b x
scoreboard players operation ye llm = 29e x
scoreboard players operation ys llm = 29s x
function llm:add
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b tx
scoreboard players operation xe llm = 30e tx
scoreboard players operation xs llm = 30s tx
scoreboard players operation yb llm = 30b x
scoreboard players operation ye llm = 30e x
scoreboard players operation ys llm = 30s x
function llm:add
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b tx
scoreboard players operation xe llm = 31e tx
scoreboard players operation xs llm = 31s tx
scoreboard players operation yb llm = 31b x
scoreboard players operation ye llm = 31e x
scoreboard players operation ys llm = 31s x
function llm:add
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b tx
scoreboard players operation xe llm = 32e tx
scoreboard players operation xs llm = 32s tx
scoreboard players operation yb llm = 32b x
scoreboard players operation ye llm = 32e x
scoreboard players operation ys llm = 32s x
function llm:add
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b tx
scoreboard players operation xe llm = 33e tx
scoreboard players operation xs llm = 33s tx
scoreboard players operation yb llm = 33b x
scoreboard players operation ye llm = 33e x
scoreboard players operation ys llm = 33s x
function llm:add
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b tx
scoreboard players operation xe llm = 34e tx
scoreboard players operation xs llm = 34s tx
scoreboard players operation yb llm = 34b x
scoreboard players operation ye llm = 34e x
scoreboard players operation ys llm = 34s x
function llm:add
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b tx
scoreboard players operation xe llm = 35e tx
scoreboard players operation xs llm = 35s tx
scoreboard players operation yb llm = 35b x
scoreboard players operation ye llm = 35e x
scoreboard players operation ys llm = 35s x
function llm:add
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b tx
scoreboard players operation xe llm = 36e tx
scoreboard players operation xs llm = 36s tx
scoreboard players operation yb llm = 36b x
scoreboard players operation ye llm = 36e x
scoreboard players operation ys llm = 36s x
function llm:add
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b tx
scoreboard players operation xe llm = 37e tx
scoreboard players operation xs llm = 37s tx
scoreboard players operation yb llm = 37b x
scoreboard players operation ye llm = 37e x
scoreboard players operation ys llm = 37s x
function llm:add
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b tx
scoreboard players operation xe llm = 38e tx
scoreboard players operation xs llm = 38s tx
scoreboard players operation yb llm = 38b x
scoreboard players operation ye llm = 38e x
scoreboard players operation ys llm = 38s x
function llm:add
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b tx
scoreboard players operation xe llm = 39e tx
scoreboard players operation xs llm = 39s tx
scoreboard players operation yb llm = 39b x
scoreboard players operation ye llm = 39e x
scoreboard players operation ys llm = 39s x
function llm:add
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b tx
scoreboard players operation xe llm = 40e tx
scoreboard players operation xs llm = 40s tx
scoreboard players operation yb llm = 40b x
scoreboard players operation ye llm = 40e x
scoreboard players operation ys llm = 40s x
function llm:add
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b tx
scoreboard players operation xe llm = 41e tx
scoreboard players operation xs llm = 41s tx
scoreboard players operation yb llm = 41b x
scoreboard players operation ye llm = 41e x
scoreboard players operation ys llm = 41s x
function llm:add
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b tx
scoreboard players operation xe llm = 42e tx
scoreboard players operation xs llm = 42s tx
scoreboard players operation yb llm = 42b x
scoreboard players operation ye llm = 42e x
scoreboard players operation ys llm = 42s x
function llm:add
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b tx
scoreboard players operation xe llm = 43e tx
scoreboard players operation xs llm = 43s tx
scoreboard players operation yb llm = 43b x
scoreboard players operation ye llm = 43e x
scoreboard players operation ys llm = 43s x
function llm:add
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b tx
scoreboard players operation xe llm = 44e tx
scoreboard players operation xs llm = 44s tx
scoreboard players operation yb llm = 44b x
scoreboard players operation ye llm = 44e x
scoreboard players operation ys llm = 44s x
function llm:add
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b tx
scoreboard players operation xe llm = 45e tx
scoreboard players operation xs llm = 45s tx
scoreboard players operation yb llm = 45b x
scoreboard players operation ye llm = 45e x
scoreboard players operation ys llm = 45s x
function llm:add
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b tx
scoreboard players operation xe llm = 46e tx
scoreboard players operation xs llm = 46s tx
scoreboard players operation yb llm = 46b x
scoreboard players operation ye llm = 46e x
scoreboard players operation ys llm = 46s x
function llm:add
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b tx
scoreboard players operation xe llm = 47e tx
scoreboard players operation xs llm = 47s tx
scoreboard players operation yb llm = 47b x
scoreboard players operation ye llm = 47e x
scoreboard players operation ys llm = 47s x
function llm:add
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b tx
scoreboard players operation xe llm = 48e tx
scoreboard players operation xs llm = 48s tx
scoreboard players operation yb llm = 48b x
scoreboard players operation ye llm = 48e x
scoreboard players operation ys llm = 48s x
function llm:add
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b tx
scoreboard players operation xe llm = 49e tx
scoreboard players operation xs llm = 49s tx
scoreboard players operation yb llm = 49b x
scoreboard players operation ye llm = 49e x
scoreboard players operation ys llm = 49s x
function llm:add
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b tx
scoreboard players operation xe llm = 50e tx
scoreboard players operation xs llm = 50s tx
scoreboard players operation yb llm = 50b x
scoreboard players operation ye llm = 50e x
scoreboard players operation ys llm = 50s x
function llm:add
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b tx
scoreboard players operation xe llm = 51e tx
scoreboard players operation xs llm = 51s tx
scoreboard players operation yb llm = 51b x
scoreboard players operation ye llm = 51e x
scoreboard players operation ys llm = 51s x
function llm:add
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b tx
scoreboard players operation xe llm = 52e tx
scoreboard players operation xs llm = 52s tx
scoreboard players operation yb llm = 52b x
scoreboard players operation ye llm = 52e x
scoreboard players operation ys llm = 52s x
function llm:add
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b tx
scoreboard players operation xe llm = 53e tx
scoreboard players operation xs llm = 53s tx
scoreboard players operation yb llm = 53b x
scoreboard players operation ye llm = 53e x
scoreboard players operation ys llm = 53s x
function llm:add
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b tx
scoreboard players operation xe llm = 54e tx
scoreboard players operation xs llm = 54s tx
scoreboard players operation yb llm = 54b x
scoreboard players operation ye llm = 54e x
scoreboard players operation ys llm = 54s x
function llm:add
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b tx
scoreboard players operation xe llm = 55e tx
scoreboard players operation xs llm = 55s tx
scoreboard players operation yb llm = 55b x
scoreboard players operation ye llm = 55e x
scoreboard players operation ys llm = 55s x
function llm:add
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b tx
scoreboard players operation xe llm = 56e tx
scoreboard players operation xs llm = 56s tx
scoreboard players operation yb llm = 56b x
scoreboard players operation ye llm = 56e x
scoreboard players operation ys llm = 56s x
function llm:add
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b tx
scoreboard players operation xe llm = 57e tx
scoreboard players operation xs llm = 57s tx
scoreboard players operation yb llm = 57b x
scoreboard players operation ye llm = 57e x
scoreboard players operation ys llm = 57s x
function llm:add
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b tx
scoreboard players operation xe llm = 58e tx
scoreboard players operation xs llm = 58s tx
scoreboard players operation yb llm = 58b x
scoreboard players operation ye llm = 58e x
scoreboard players operation ys llm = 58s x
function llm:add
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b tx
scoreboard players operation xe llm = 59e tx
scoreboard players operation xs llm = 59s tx
scoreboard players operation yb llm = 59b x
scoreboard players operation ye llm = 59e x
scoreboard players operation ys llm = 59s x
function llm:add
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b tx
scoreboard players operation xe llm = 60e tx
scoreboard players operation xs llm = 60s tx
scoreboard players operation yb llm = 60b x
scoreboard players operation ye llm = 60e x
scoreboard players operation ys llm = 60s x
function llm:add
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b tx
scoreboard players operation xe llm = 61e tx
scoreboard players operation xs llm = 61s tx
scoreboard players operation yb llm = 61b x
scoreboard players operation ye llm = 61e x
scoreboard players operation ys llm = 61s x
function llm:add
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b tx
scoreboard players operation xe llm = 62e tx
scoreboard players operation xs llm = 62s tx
scoreboard players operation yb llm = 62b x
scoreboard players operation ye llm = 62e x
scoreboard players operation ys llm = 62s x
function llm:add
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b tx
scoreboard players operation xe llm = 63e tx
scoreboard players operation xs llm = 63s tx
scoreboard players operation yb llm = 63b x
scoreboard players operation ye llm = 63e x
scoreboard players operation ys llm = 63s x
function llm:add
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:rmsnorm_0
scoreboard players operation xb llm = 0b x
scoreboard players operation xe llm = 0e x
scoreboard players operation xs llm = 0s x
scoreboard players set yb llm 24583089
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 0b x = xb llm
scoreboard players operation 0e x = xe llm
scoreboard players operation 0s x = xs llm
scoreboard players operation xb llm = 1b x
scoreboard players operation xe llm = 1e x
scoreboard players operation xs llm = 1s x
scoreboard players set yb llm 13673227
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 1b x = xb llm
scoreboard players operation 1e x = xe llm
scoreboard players operation 1s x = xs llm
scoreboard players operation xb llm = 2b x
scoreboard players operation xe llm = 2e x
scoreboard players operation xs llm = 2s x
scoreboard players set yb llm 17504382
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 2b x = xb llm
scoreboard players operation 2e x = xe llm
scoreboard players operation 2s x = xs llm
scoreboard players operation xb llm = 3b x
scoreboard players operation xe llm = 3e x
scoreboard players operation xs llm = 3s x
scoreboard players set yb llm 11078318
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 3b x = xb llm
scoreboard players operation 3e x = xe llm
scoreboard players operation 3s x = xs llm
scoreboard players operation xb llm = 4b x
scoreboard players operation xe llm = 4e x
scoreboard players operation xs llm = 4s x
scoreboard players set yb llm 14840457
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 4b x = xb llm
scoreboard players operation 4e x = xe llm
scoreboard players operation 4s x = xs llm
scoreboard players operation xb llm = 5b x
scoreboard players operation xe llm = 5e x
scoreboard players operation xs llm = 5s x
scoreboard players set yb llm 44250941
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 5b x = xb llm
scoreboard players operation 5e x = xe llm
scoreboard players operation 5s x = xs llm
scoreboard players operation xb llm = 6b x
scoreboard players operation xe llm = 6e x
scoreboard players operation xs llm = 6s x
scoreboard players set yb llm 16743193
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 6b x = xb llm
scoreboard players operation 6e x = xe llm
scoreboard players operation 6s x = xs llm
scoreboard players operation xb llm = 7b x
scoreboard players operation xe llm = 7e x
scoreboard players operation xs llm = 7s x
scoreboard players set yb llm 15204191
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 7b x = xb llm
scoreboard players operation 7e x = xe llm
scoreboard players operation 7s x = xs llm
scoreboard players operation xb llm = 8b x
scoreboard players operation xe llm = 8e x
scoreboard players operation xs llm = 8s x
scoreboard players set yb llm 19353532
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 8b x = xb llm
scoreboard players operation 8e x = xe llm
scoreboard players operation 8s x = xs llm
scoreboard players operation xb llm = 9b x
scoreboard players operation xe llm = 9e x
scoreboard players operation xs llm = 9s x
scoreboard players set yb llm 18381100
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 9b x = xb llm
scoreboard players operation 9e x = xe llm
scoreboard players operation 9s x = xs llm
scoreboard players operation xb llm = 10b x
scoreboard players operation xe llm = 10e x
scoreboard players operation xs llm = 10s x
scoreboard players set yb llm 15329392
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 10b x = xb llm
scoreboard players operation 10e x = xe llm
scoreboard players operation 10s x = xs llm
scoreboard players operation xb llm = 11b x
scoreboard players operation xe llm = 11e x
scoreboard players operation xs llm = 11s x
scoreboard players set yb llm 15324423
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 11b x = xb llm
scoreboard players operation 11e x = xe llm
scoreboard players operation 11s x = xs llm
scoreboard players operation xb llm = 12b x
scoreboard players operation xe llm = 12e x
scoreboard players operation xs llm = 12s x
scoreboard players set yb llm 16811218
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 12b x = xb llm
scoreboard players operation 12e x = xe llm
scoreboard players operation 12s x = xs llm
scoreboard players operation xb llm = 13b x
scoreboard players operation xe llm = 13e x
scoreboard players operation xs llm = 13s x
scoreboard players set yb llm 13867575
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 13b x = xb llm
scoreboard players operation 13e x = xe llm
scoreboard players operation 13s x = xs llm
scoreboard players operation xb llm = 14b x
scoreboard players operation xe llm = 14e x
scoreboard players operation xs llm = 14s x
scoreboard players set yb llm 21763520
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 14b x = xb llm
scoreboard players operation 14e x = xe llm
scoreboard players operation 14s x = xs llm
scoreboard players operation xb llm = 15b x
scoreboard players operation xe llm = 15e x
scoreboard players operation xs llm = 15s x
scoreboard players set yb llm 26189833
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 15b x = xb llm
scoreboard players operation 15e x = xe llm
scoreboard players operation 15s x = xs llm
scoreboard players operation xb llm = 16b x
scoreboard players operation xe llm = 16e x
scoreboard players operation xs llm = 16s x
scoreboard players set yb llm 18949711
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 16b x = xb llm
scoreboard players operation 16e x = xe llm
scoreboard players operation 16s x = xs llm
scoreboard players operation xb llm = 17b x
scoreboard players operation xe llm = 17e x
scoreboard players operation xs llm = 17s x
scoreboard players set yb llm 25378916
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 17b x = xb llm
scoreboard players operation 17e x = xe llm
scoreboard players operation 17s x = xs llm
scoreboard players operation xb llm = 18b x
scoreboard players operation xe llm = 18e x
scoreboard players operation xs llm = 18s x
scoreboard players set yb llm 12839134
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 18b x = xb llm
scoreboard players operation 18e x = xe llm
scoreboard players operation 18s x = xs llm
scoreboard players operation xb llm = 19b x
scoreboard players operation xe llm = 19e x
scoreboard players operation xs llm = 19s x
scoreboard players set yb llm 15506765
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 19b x = xb llm
scoreboard players operation 19e x = xe llm
scoreboard players operation 19s x = xs llm
scoreboard players operation xb llm = 20b x
scoreboard players operation xe llm = 20e x
scoreboard players operation xs llm = 20s x
scoreboard players set yb llm 13185338
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 20b x = xb llm
scoreboard players operation 20e x = xe llm
scoreboard players operation 20s x = xs llm
scoreboard players operation xb llm = 21b x
scoreboard players operation xe llm = 21e x
scoreboard players operation xs llm = 21s x
scoreboard players set yb llm 20146048
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 21b x = xb llm
scoreboard players operation 21e x = xe llm
scoreboard players operation 21s x = xs llm
scoreboard players operation xb llm = 22b x
scoreboard players operation xe llm = 22e x
scoreboard players operation xs llm = 22s x
scoreboard players set yb llm 16434079
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 22b x = xb llm
scoreboard players operation 22e x = xe llm
scoreboard players operation 22s x = xs llm
scoreboard players operation xb llm = 23b x
scoreboard players operation xe llm = 23e x
scoreboard players operation xs llm = 23s x
scoreboard players set yb llm 26970017
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 23b x = xb llm
scoreboard players operation 23e x = xe llm
scoreboard players operation 23s x = xs llm
scoreboard players operation xb llm = 24b x
scoreboard players operation xe llm = 24e x
scoreboard players operation xs llm = 24s x
scoreboard players set yb llm 17330426
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 24b x = xb llm
scoreboard players operation 24e x = xe llm
scoreboard players operation 24s x = xs llm
scoreboard players operation xb llm = 25b x
scoreboard players operation xe llm = 25e x
scoreboard players operation xs llm = 25s x
scoreboard players set yb llm 14055369
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 25b x = xb llm
scoreboard players operation 25e x = xe llm
scoreboard players operation 25s x = xs llm
scoreboard players operation xb llm = 26b x
scoreboard players operation xe llm = 26e x
scoreboard players operation xs llm = 26s x
scoreboard players set yb llm 23391402
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 26b x = xb llm
scoreboard players operation 26e x = xe llm
scoreboard players operation 26s x = xs llm
scoreboard players operation xb llm = 27b x
scoreboard players operation xe llm = 27e x
scoreboard players operation xs llm = 27s x
scoreboard players set yb llm 18733059
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 27b x = xb llm
scoreboard players operation 27e x = xe llm
scoreboard players operation 27s x = xs llm
scoreboard players operation xb llm = 28b x
scoreboard players operation xe llm = 28e x
scoreboard players operation xs llm = 28s x
scoreboard players set yb llm 11588085
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 28b x = xb llm
scoreboard players operation 28e x = xe llm
scoreboard players operation 28s x = xs llm
scoreboard players operation xb llm = 29b x
scoreboard players operation xe llm = 29e x
scoreboard players operation xs llm = 29s x
scoreboard players set yb llm 15791907
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 29b x = xb llm
scoreboard players operation 29e x = xe llm
scoreboard players operation 29s x = xs llm
scoreboard players operation xb llm = 30b x
scoreboard players operation xe llm = 30e x
scoreboard players operation xs llm = 30s x
scoreboard players set yb llm 12902747
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 30b x = xb llm
scoreboard players operation 30e x = xe llm
scoreboard players operation 30s x = xs llm
scoreboard players operation xb llm = 31b x
scoreboard players operation xe llm = 31e x
scoreboard players operation xs llm = 31s x
scoreboard players set yb llm 31819742
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 31b x = xb llm
scoreboard players operation 31e x = xe llm
scoreboard players operation 31s x = xs llm
scoreboard players operation xb llm = 32b x
scoreboard players operation xe llm = 32e x
scoreboard players operation xs llm = 32s x
scoreboard players set yb llm 19418539
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 32b x = xb llm
scoreboard players operation 32e x = xe llm
scoreboard players operation 32s x = xs llm
scoreboard players operation xb llm = 33b x
scoreboard players operation xe llm = 33e x
scoreboard players operation xs llm = 33s x
scoreboard players set yb llm 12282383
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 33b x = xb llm
scoreboard players operation 33e x = xe llm
scoreboard players operation 33s x = xs llm
scoreboard players operation xb llm = 34b x
scoreboard players operation xe llm = 34e x
scoreboard players operation xs llm = 34s x
scoreboard players set yb llm 14699891
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 34b x = xb llm
scoreboard players operation 34e x = xe llm
scoreboard players operation 34s x = xs llm
scoreboard players operation xb llm = 35b x
scoreboard players operation xe llm = 35e x
scoreboard players operation xs llm = 35s x
scoreboard players set yb llm 21156664
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 35b x = xb llm
scoreboard players operation 35e x = xe llm
scoreboard players operation 35s x = xs llm
scoreboard players operation xb llm = 36b x
scoreboard players operation xe llm = 36e x
scoreboard players operation xs llm = 36s x
scoreboard players set yb llm 16925602
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 36b x = xb llm
scoreboard players operation 36e x = xe llm
scoreboard players operation 36s x = xs llm
scoreboard players operation xb llm = 37b x
scoreboard players operation xe llm = 37e x
scoreboard players operation xs llm = 37s x
scoreboard players set yb llm 33886461
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 37b x = xb llm
scoreboard players operation 37e x = xe llm
scoreboard players operation 37s x = xs llm
scoreboard players operation xb llm = 38b x
scoreboard players operation xe llm = 38e x
scoreboard players operation xs llm = 38s x
scoreboard players set yb llm 12709773
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 38b x = xb llm
scoreboard players operation 38e x = xe llm
scoreboard players operation 38s x = xs llm
scoreboard players operation xb llm = 39b x
scoreboard players operation xe llm = 39e x
scoreboard players operation xs llm = 39s x
scoreboard players set yb llm 24227686
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 39b x = xb llm
scoreboard players operation 39e x = xe llm
scoreboard players operation 39s x = xs llm
scoreboard players operation xb llm = 40b x
scoreboard players operation xe llm = 40e x
scoreboard players operation xs llm = 40s x
scoreboard players set yb llm 19202864
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 40b x = xb llm
scoreboard players operation 40e x = xe llm
scoreboard players operation 40s x = xs llm
scoreboard players operation xb llm = 41b x
scoreboard players operation xe llm = 41e x
scoreboard players operation xs llm = 41s x
scoreboard players set yb llm 17946631
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 41b x = xb llm
scoreboard players operation 41e x = xe llm
scoreboard players operation 41s x = xs llm
scoreboard players operation xb llm = 42b x
scoreboard players operation xe llm = 42e x
scoreboard players operation xs llm = 42s x
scoreboard players set yb llm 11313292
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 42b x = xb llm
scoreboard players operation 42e x = xe llm
scoreboard players operation 42s x = xs llm
scoreboard players operation xb llm = 43b x
scoreboard players operation xe llm = 43e x
scoreboard players operation xs llm = 43s x
scoreboard players set yb llm 16754479
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 43b x = xb llm
scoreboard players operation 43e x = xe llm
scoreboard players operation 43s x = xs llm
scoreboard players operation xb llm = 44b x
scoreboard players operation xe llm = 44e x
scoreboard players operation xs llm = 44s x
scoreboard players set yb llm 13792142
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 44b x = xb llm
scoreboard players operation 44e x = xe llm
scoreboard players operation 44s x = xs llm
scoreboard players operation xb llm = 45b x
scoreboard players operation xe llm = 45e x
scoreboard players operation xs llm = 45s x
scoreboard players set yb llm 12172118
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 45b x = xb llm
scoreboard players operation 45e x = xe llm
scoreboard players operation 45s x = xs llm
scoreboard players operation xb llm = 46b x
scoreboard players operation xe llm = 46e x
scoreboard players operation xs llm = 46s x
scoreboard players set yb llm 13975564
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 46b x = xb llm
scoreboard players operation 46e x = xe llm
scoreboard players operation 46s x = xs llm
scoreboard players operation xb llm = 47b x
scoreboard players operation xe llm = 47e x
scoreboard players operation xs llm = 47s x
scoreboard players set yb llm 15128528
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 47b x = xb llm
scoreboard players operation 47e x = xe llm
scoreboard players operation 47s x = xs llm
scoreboard players operation xb llm = 48b x
scoreboard players operation xe llm = 48e x
scoreboard players operation xs llm = 48s x
scoreboard players set yb llm 18040856
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 48b x = xb llm
scoreboard players operation 48e x = xe llm
scoreboard players operation 48s x = xs llm
scoreboard players operation xb llm = 49b x
scoreboard players operation xe llm = 49e x
scoreboard players operation xs llm = 49s x
scoreboard players set yb llm 18138452
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 49b x = xb llm
scoreboard players operation 49e x = xe llm
scoreboard players operation 49s x = xs llm
scoreboard players operation xb llm = 50b x
scoreboard players operation xe llm = 50e x
scoreboard players operation xs llm = 50s x
scoreboard players set yb llm 19154131
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 50b x = xb llm
scoreboard players operation 50e x = xe llm
scoreboard players operation 50s x = xs llm
scoreboard players operation xb llm = 51b x
scoreboard players operation xe llm = 51e x
scoreboard players operation xs llm = 51s x
scoreboard players set yb llm 11676961
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 51b x = xb llm
scoreboard players operation 51e x = xe llm
scoreboard players operation 51s x = xs llm
scoreboard players operation xb llm = 52b x
scoreboard players operation xe llm = 52e x
scoreboard players operation xs llm = 52s x
scoreboard players set yb llm 23573880
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 52b x = xb llm
scoreboard players operation 52e x = xe llm
scoreboard players operation 52s x = xs llm
scoreboard players operation xb llm = 53b x
scoreboard players operation xe llm = 53e x
scoreboard players operation xs llm = 53s x
scoreboard players set yb llm 16348422
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 53b x = xb llm
scoreboard players operation 53e x = xe llm
scoreboard players operation 53s x = xs llm
scoreboard players operation xb llm = 54b x
scoreboard players operation xe llm = 54e x
scoreboard players operation xs llm = 54s x
scoreboard players set yb llm 20924938
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 54b x = xb llm
scoreboard players operation 54e x = xe llm
scoreboard players operation 54s x = xs llm
scoreboard players operation xb llm = 55b x
scoreboard players operation xe llm = 55e x
scoreboard players operation xs llm = 55s x
scoreboard players set yb llm 18415017
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 55b x = xb llm
scoreboard players operation 55e x = xe llm
scoreboard players operation 55s x = xs llm
scoreboard players operation xb llm = 56b x
scoreboard players operation xe llm = 56e x
scoreboard players operation xs llm = 56s x
scoreboard players set yb llm 23340414
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 56b x = xb llm
scoreboard players operation 56e x = xe llm
scoreboard players operation 56s x = xs llm
scoreboard players operation xb llm = 57b x
scoreboard players operation xe llm = 57e x
scoreboard players operation xs llm = 57s x
scoreboard players set yb llm 18213681
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 57b x = xb llm
scoreboard players operation 57e x = xe llm
scoreboard players operation 57s x = xs llm
scoreboard players operation xb llm = 58b x
scoreboard players operation xe llm = 58e x
scoreboard players operation xs llm = 58s x
scoreboard players set yb llm 18475415
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 58b x = xb llm
scoreboard players operation 58e x = xe llm
scoreboard players operation 58s x = xs llm
scoreboard players operation xb llm = 59b x
scoreboard players operation xe llm = 59e x
scoreboard players operation xs llm = 59s x
scoreboard players set yb llm 19169949
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 59b x = xb llm
scoreboard players operation 59e x = xe llm
scoreboard players operation 59s x = xs llm
scoreboard players operation xb llm = 60b x
scoreboard players operation xe llm = 60e x
scoreboard players operation xs llm = 60s x
scoreboard players set yb llm 17217220
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 60b x = xb llm
scoreboard players operation 60e x = xe llm
scoreboard players operation 60s x = xs llm
scoreboard players operation xb llm = 61b x
scoreboard players operation xe llm = 61e x
scoreboard players operation xs llm = 61s x
scoreboard players set yb llm 97203809
scoreboard players set ye llm -1
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 61b x = xb llm
scoreboard players operation 61e x = xe llm
scoreboard players operation 61s x = xs llm
scoreboard players operation xb llm = 62b x
scoreboard players operation xe llm = 62e x
scoreboard players operation xs llm = 62s x
scoreboard players set yb llm 14526384
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 62b x = xb llm
scoreboard players operation 62e x = xe llm
scoreboard players operation 62s x = xs llm
scoreboard players operation xb llm = 63b x
scoreboard players operation xe llm = 63e x
scoreboard players operation xs llm = 63s x
scoreboard players set yb llm 17077769
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:mul
scoreboard players operation yb llm = ssb llm
scoreboard players operation ye llm = sse llm
scoreboard players operation ys llm = sss llm
function llm:mul
scoreboard players operation 63b x = xb llm
scoreboard players operation 63e x = xe llm
scoreboard players operation 63s x = xs llm
function llm:matmul_logits
bossbar set progress value 49
bossbar set progress players
