scoreboard players operation xb llm = pos llm
scoreboard players set xe llm 7
scoreboard players set xs llm 1
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation posb llm = xb llm
scoreboard players operation pose llm = xe llm
scoreboard players operation poss llm = xs llm
bossbar set progress max 48
bossbar set progress value 0
bossbar set progress name [{"text":"Inferring, Step #","color":"green","bold":true},{"score":{"name":"pos","objective":"llm"}}]
bossbar set progress players @a
scoreboard players operation start llm = tok llm
scoreboard players operation start llm *= 64 llm
scoreboard players set i llm 0
data modify storage llm args.i set value 0
scoreboard players operation j llm = start llm
execute store result storage llm args.j int 1 run scoreboard players get j llm
function llm:copy_embedding_row with storage llm args
function llm:rmsnorm_0
execute store result score 0b tx run data get storage llm params.att_w.0b
execute store result score 0e tx run data get storage llm params.att_w.0e
execute store result score 0s tx run data get storage llm params.att_w.0s
execute store result score 1b tx run data get storage llm params.att_w.1b
execute store result score 1e tx run data get storage llm params.att_w.1e
execute store result score 1s tx run data get storage llm params.att_w.1s
execute store result score 2b tx run data get storage llm params.att_w.2b
execute store result score 2e tx run data get storage llm params.att_w.2e
execute store result score 2s tx run data get storage llm params.att_w.2s
execute store result score 3b tx run data get storage llm params.att_w.3b
execute store result score 3e tx run data get storage llm params.att_w.3e
execute store result score 3s tx run data get storage llm params.att_w.3s
execute store result score 4b tx run data get storage llm params.att_w.4b
execute store result score 4e tx run data get storage llm params.att_w.4e
execute store result score 4s tx run data get storage llm params.att_w.4s
execute store result score 5b tx run data get storage llm params.att_w.5b
execute store result score 5e tx run data get storage llm params.att_w.5e
execute store result score 5s tx run data get storage llm params.att_w.5s
execute store result score 6b tx run data get storage llm params.att_w.6b
execute store result score 6e tx run data get storage llm params.att_w.6e
execute store result score 6s tx run data get storage llm params.att_w.6s
execute store result score 7b tx run data get storage llm params.att_w.7b
execute store result score 7e tx run data get storage llm params.att_w.7e
execute store result score 7s tx run data get storage llm params.att_w.7s
execute store result score 8b tx run data get storage llm params.att_w.8b
execute store result score 8e tx run data get storage llm params.att_w.8e
execute store result score 8s tx run data get storage llm params.att_w.8s
execute store result score 9b tx run data get storage llm params.att_w.9b
execute store result score 9e tx run data get storage llm params.att_w.9e
execute store result score 9s tx run data get storage llm params.att_w.9s
execute store result score 10b tx run data get storage llm params.att_w.10b
execute store result score 10e tx run data get storage llm params.att_w.10e
execute store result score 10s tx run data get storage llm params.att_w.10s
execute store result score 11b tx run data get storage llm params.att_w.11b
execute store result score 11e tx run data get storage llm params.att_w.11e
execute store result score 11s tx run data get storage llm params.att_w.11s
execute store result score 12b tx run data get storage llm params.att_w.12b
execute store result score 12e tx run data get storage llm params.att_w.12e
execute store result score 12s tx run data get storage llm params.att_w.12s
execute store result score 13b tx run data get storage llm params.att_w.13b
execute store result score 13e tx run data get storage llm params.att_w.13e
execute store result score 13s tx run data get storage llm params.att_w.13s
execute store result score 14b tx run data get storage llm params.att_w.14b
execute store result score 14e tx run data get storage llm params.att_w.14e
execute store result score 14s tx run data get storage llm params.att_w.14s
execute store result score 15b tx run data get storage llm params.att_w.15b
execute store result score 15e tx run data get storage llm params.att_w.15e
execute store result score 15s tx run data get storage llm params.att_w.15s
execute store result score 16b tx run data get storage llm params.att_w.16b
execute store result score 16e tx run data get storage llm params.att_w.16e
execute store result score 16s tx run data get storage llm params.att_w.16s
execute store result score 17b tx run data get storage llm params.att_w.17b
execute store result score 17e tx run data get storage llm params.att_w.17e
execute store result score 17s tx run data get storage llm params.att_w.17s
execute store result score 18b tx run data get storage llm params.att_w.18b
execute store result score 18e tx run data get storage llm params.att_w.18e
execute store result score 18s tx run data get storage llm params.att_w.18s
execute store result score 19b tx run data get storage llm params.att_w.19b
execute store result score 19e tx run data get storage llm params.att_w.19e
execute store result score 19s tx run data get storage llm params.att_w.19s
execute store result score 20b tx run data get storage llm params.att_w.20b
execute store result score 20e tx run data get storage llm params.att_w.20e
execute store result score 20s tx run data get storage llm params.att_w.20s
execute store result score 21b tx run data get storage llm params.att_w.21b
execute store result score 21e tx run data get storage llm params.att_w.21e
execute store result score 21s tx run data get storage llm params.att_w.21s
execute store result score 22b tx run data get storage llm params.att_w.22b
execute store result score 22e tx run data get storage llm params.att_w.22e
execute store result score 22s tx run data get storage llm params.att_w.22s
execute store result score 23b tx run data get storage llm params.att_w.23b
execute store result score 23e tx run data get storage llm params.att_w.23e
execute store result score 23s tx run data get storage llm params.att_w.23s
execute store result score 24b tx run data get storage llm params.att_w.24b
execute store result score 24e tx run data get storage llm params.att_w.24e
execute store result score 24s tx run data get storage llm params.att_w.24s
execute store result score 25b tx run data get storage llm params.att_w.25b
execute store result score 25e tx run data get storage llm params.att_w.25e
execute store result score 25s tx run data get storage llm params.att_w.25s
execute store result score 26b tx run data get storage llm params.att_w.26b
execute store result score 26e tx run data get storage llm params.att_w.26e
execute store result score 26s tx run data get storage llm params.att_w.26s
execute store result score 27b tx run data get storage llm params.att_w.27b
execute store result score 27e tx run data get storage llm params.att_w.27e
execute store result score 27s tx run data get storage llm params.att_w.27s
execute store result score 28b tx run data get storage llm params.att_w.28b
execute store result score 28e tx run data get storage llm params.att_w.28e
execute store result score 28s tx run data get storage llm params.att_w.28s
execute store result score 29b tx run data get storage llm params.att_w.29b
execute store result score 29e tx run data get storage llm params.att_w.29e
execute store result score 29s tx run data get storage llm params.att_w.29s
execute store result score 30b tx run data get storage llm params.att_w.30b
execute store result score 30e tx run data get storage llm params.att_w.30e
execute store result score 30s tx run data get storage llm params.att_w.30s
execute store result score 31b tx run data get storage llm params.att_w.31b
execute store result score 31e tx run data get storage llm params.att_w.31e
execute store result score 31s tx run data get storage llm params.att_w.31s
execute store result score 32b tx run data get storage llm params.att_w.32b
execute store result score 32e tx run data get storage llm params.att_w.32e
execute store result score 32s tx run data get storage llm params.att_w.32s
execute store result score 33b tx run data get storage llm params.att_w.33b
execute store result score 33e tx run data get storage llm params.att_w.33e
execute store result score 33s tx run data get storage llm params.att_w.33s
execute store result score 34b tx run data get storage llm params.att_w.34b
execute store result score 34e tx run data get storage llm params.att_w.34e
execute store result score 34s tx run data get storage llm params.att_w.34s
execute store result score 35b tx run data get storage llm params.att_w.35b
execute store result score 35e tx run data get storage llm params.att_w.35e
execute store result score 35s tx run data get storage llm params.att_w.35s
execute store result score 36b tx run data get storage llm params.att_w.36b
execute store result score 36e tx run data get storage llm params.att_w.36e
execute store result score 36s tx run data get storage llm params.att_w.36s
execute store result score 37b tx run data get storage llm params.att_w.37b
execute store result score 37e tx run data get storage llm params.att_w.37e
execute store result score 37s tx run data get storage llm params.att_w.37s
execute store result score 38b tx run data get storage llm params.att_w.38b
execute store result score 38e tx run data get storage llm params.att_w.38e
execute store result score 38s tx run data get storage llm params.att_w.38s
execute store result score 39b tx run data get storage llm params.att_w.39b
execute store result score 39e tx run data get storage llm params.att_w.39e
execute store result score 39s tx run data get storage llm params.att_w.39s
execute store result score 40b tx run data get storage llm params.att_w.40b
execute store result score 40e tx run data get storage llm params.att_w.40e
execute store result score 40s tx run data get storage llm params.att_w.40s
execute store result score 41b tx run data get storage llm params.att_w.41b
execute store result score 41e tx run data get storage llm params.att_w.41e
execute store result score 41s tx run data get storage llm params.att_w.41s
execute store result score 42b tx run data get storage llm params.att_w.42b
execute store result score 42e tx run data get storage llm params.att_w.42e
execute store result score 42s tx run data get storage llm params.att_w.42s
execute store result score 43b tx run data get storage llm params.att_w.43b
execute store result score 43e tx run data get storage llm params.att_w.43e
execute store result score 43s tx run data get storage llm params.att_w.43s
execute store result score 44b tx run data get storage llm params.att_w.44b
execute store result score 44e tx run data get storage llm params.att_w.44e
execute store result score 44s tx run data get storage llm params.att_w.44s
execute store result score 45b tx run data get storage llm params.att_w.45b
execute store result score 45e tx run data get storage llm params.att_w.45e
execute store result score 45s tx run data get storage llm params.att_w.45s
execute store result score 46b tx run data get storage llm params.att_w.46b
execute store result score 46e tx run data get storage llm params.att_w.46e
execute store result score 46s tx run data get storage llm params.att_w.46s
execute store result score 47b tx run data get storage llm params.att_w.47b
execute store result score 47e tx run data get storage llm params.att_w.47e
execute store result score 47s tx run data get storage llm params.att_w.47s
execute store result score 48b tx run data get storage llm params.att_w.48b
execute store result score 48e tx run data get storage llm params.att_w.48e
execute store result score 48s tx run data get storage llm params.att_w.48s
execute store result score 49b tx run data get storage llm params.att_w.49b
execute store result score 49e tx run data get storage llm params.att_w.49e
execute store result score 49s tx run data get storage llm params.att_w.49s
execute store result score 50b tx run data get storage llm params.att_w.50b
execute store result score 50e tx run data get storage llm params.att_w.50e
execute store result score 50s tx run data get storage llm params.att_w.50s
execute store result score 51b tx run data get storage llm params.att_w.51b
execute store result score 51e tx run data get storage llm params.att_w.51e
execute store result score 51s tx run data get storage llm params.att_w.51s
execute store result score 52b tx run data get storage llm params.att_w.52b
execute store result score 52e tx run data get storage llm params.att_w.52e
execute store result score 52s tx run data get storage llm params.att_w.52s
execute store result score 53b tx run data get storage llm params.att_w.53b
execute store result score 53e tx run data get storage llm params.att_w.53e
execute store result score 53s tx run data get storage llm params.att_w.53s
execute store result score 54b tx run data get storage llm params.att_w.54b
execute store result score 54e tx run data get storage llm params.att_w.54e
execute store result score 54s tx run data get storage llm params.att_w.54s
execute store result score 55b tx run data get storage llm params.att_w.55b
execute store result score 55e tx run data get storage llm params.att_w.55e
execute store result score 55s tx run data get storage llm params.att_w.55s
execute store result score 56b tx run data get storage llm params.att_w.56b
execute store result score 56e tx run data get storage llm params.att_w.56e
execute store result score 56s tx run data get storage llm params.att_w.56s
execute store result score 57b tx run data get storage llm params.att_w.57b
execute store result score 57e tx run data get storage llm params.att_w.57e
execute store result score 57s tx run data get storage llm params.att_w.57s
execute store result score 58b tx run data get storage llm params.att_w.58b
execute store result score 58e tx run data get storage llm params.att_w.58e
execute store result score 58s tx run data get storage llm params.att_w.58s
execute store result score 59b tx run data get storage llm params.att_w.59b
execute store result score 59e tx run data get storage llm params.att_w.59e
execute store result score 59s tx run data get storage llm params.att_w.59s
execute store result score 60b tx run data get storage llm params.att_w.60b
execute store result score 60e tx run data get storage llm params.att_w.60e
execute store result score 60s tx run data get storage llm params.att_w.60s
execute store result score 61b tx run data get storage llm params.att_w.61b
execute store result score 61e tx run data get storage llm params.att_w.61e
execute store result score 61s tx run data get storage llm params.att_w.61s
execute store result score 62b tx run data get storage llm params.att_w.62b
execute store result score 62e tx run data get storage llm params.att_w.62e
execute store result score 62s tx run data get storage llm params.att_w.62s
execute store result score 63b tx run data get storage llm params.att_w.63b
execute store result score 63e tx run data get storage llm params.att_w.63e
execute store result score 63s tx run data get storage llm params.att_w.63s
function llm:rmsnorm_1
data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "q"
data modify storage llm args.m set value "wq_0"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 1
schedule function llm:forward_0 1t
