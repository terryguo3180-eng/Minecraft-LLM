scoreboard players operation xb llm *= 100000 llm
scoreboard players remove xe llm 5
