function llm:get_vocab_score
execute if score bs llm >= score llm run return 0
scoreboard players operation bs llm = score llm
scoreboard players operation bt llm = tok llm
scoreboard players operation bi llm = i llm
