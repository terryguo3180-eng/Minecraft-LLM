scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t1 llm = yb llm
scoreboard players operation t2 llm = t1 llm
scoreboard players operation t1 llm /= 25 llm
scoreboard players operation t2 llm %= 25 llm
scoreboard players operation t3 llm = xb llm
scoreboard players operation xb llm /= t1 llm
scoreboard players operation xb llm *= 40 llm
scoreboard players operation t3 llm %= t1 llm
scoreboard players operation t3 llm *= 40 llm
scoreboard players operation t0 llm = t3 llm
scoreboard players operation t3 llm /= t1 llm
scoreboard players operation xb llm += t3 llm
scoreboard players operation t0 llm %= t1 llm
scoreboard players operation t0 llm *= 25 llm
scoreboard players operation t4 llm = t2 llm
scoreboard players operation t4 llm *= xb llm
scoreboard players operation t0 llm -= t4 llm
scoreboard players operation t0 llm *= 10 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t0 llm /= t1 llm
scoreboard players operation t0 llm *= 40 llm
scoreboard players operation t3 llm %= t1 llm
scoreboard players operation t3 llm *= 40 llm
scoreboard players operation t3 llm /= t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xs llm *= ys llm
scoreboard players operation xe llm -= ye llm
scoreboard players remove xe llm 1
execute if score xs llm matches 0 run scoreboard players set xe llm 0
execute if score xb llm matches 100000.. run return 0
scoreboard players operation xb llm *= 10000 llm
scoreboard players operation xb llm += t0 llm
execute if score xb llm matches 100000000.. run function llm:float_15
