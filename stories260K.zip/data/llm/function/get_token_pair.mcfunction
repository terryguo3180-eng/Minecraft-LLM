$execute store result score tok llm run data get storage llm args.prompt_tokens[$(i)]
function llm:get_token
data modify storage llm args.tok0 set from storage llm args.tok
$execute store result score tok llm run data get storage llm args.prompt_tokens[$(j)]
function llm:get_token
data modify storage llm args.tok1 set from storage llm args.tok
