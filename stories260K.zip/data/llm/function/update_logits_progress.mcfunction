execute store result score progress llm run bossbar get progress value
execute store result bossbar progress value run scoreboard players add progress llm 1
execute run scoreboard players set n llm 0
