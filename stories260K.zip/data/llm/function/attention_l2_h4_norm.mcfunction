execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:get_av with storage llm args
scoreboard players operation yb llm = expsumb llm
scoreboard players operation ye llm = expsume llm
scoreboard players operation ys llm = expsums llm
function llm:div
function llm:set_av with storage llm args
scoreboard players add i llm 1
execute if score i llm < window_len llm run function llm:attention_l2_h4_norm
