scoreboard players operation xb llm /= 10 llm
scoreboard players add xe llm 1
