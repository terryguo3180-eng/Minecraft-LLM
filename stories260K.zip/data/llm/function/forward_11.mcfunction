data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "tx2"
data modify storage llm args.m set value "wo_1"
execute store result score s1 llm run scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 13
schedule function llm:forward_12 1t
