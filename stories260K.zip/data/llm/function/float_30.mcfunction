scoreboard players add r llm 1
scoreboard players operation r llm *= -1 llm
function llm:float_31
execute if score xb llm matches 100000000.. run function llm:float_15
execute if score xs llm matches 0 run scoreboard players set xs llm -1
