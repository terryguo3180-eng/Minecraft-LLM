scoreboard players remove t0 llm 1
scoreboard players operation t1 llm = t0 llm
scoreboard players operation t1 llm *= t0 llm
