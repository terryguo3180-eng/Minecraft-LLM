execute if score xe llm matches 7.. run return run scoreboard players add xb llm 1
execute if score xe llm matches 6 run return run scoreboard players add xb llm 10
execute if score xe llm matches 5 run return run scoreboard players add xb llm 100
execute if score xe llm matches 4 run return run scoreboard players add xb llm 1000
execute if score xe llm matches 3 run return run scoreboard players add xb llm 10000
execute if score xe llm matches 2 run return run scoreboard players add xb llm 100000
execute if score xe llm matches 1 run return run scoreboard players add xb llm 1000000
execute if score xe llm matches 0 run return run scoreboard players add xb llm 10000000
