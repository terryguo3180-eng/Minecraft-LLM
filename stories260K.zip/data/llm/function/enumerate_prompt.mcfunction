$data modify storage llm args.c set string storage llm args.prompt $(i) $(j)
function llm:lookup_vocab
execute if score tok llm matches -1 run return run tellraw @a [{"text":"Not a good prompt at position ","color":"red"},{"score":{"name":"i","objective":"llm"}}]
data modify storage llm args.prompt_tokens append value 0
execute store result storage llm args.prompt_tokens[-1] int 1 run scoreboard players get tok llm
execute store result storage llm args.i int 1 run scoreboard players add i llm 1
execute store result storage llm args.j int 1 run scoreboard players add j llm 1
execute if score i llm < len llm run function llm:enumerate_prompt with storage llm args
