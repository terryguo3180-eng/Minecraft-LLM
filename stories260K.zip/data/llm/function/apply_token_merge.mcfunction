$execute store result storage llm args.prompt_tokens[$(i)] int 1 run scoreboard players get bt llm
$data remove storage llm args.prompt_tokens[$(j)]
