scoreboard players operation xb llm /= 10000000 llm
scoreboard players operation r llm = xb llm
scoreboard players operation xb llm *= 10000000 llm
