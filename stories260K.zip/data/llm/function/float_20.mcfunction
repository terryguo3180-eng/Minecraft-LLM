$data modify entity @s Rotation[0] set value $(s)$(b)E$(e)f
execute at @s positioned 0. 0. 0. rotated ~ 0. run tp @s ^ ^ ^1.
execute store result score xb llm run data get entity @s Pos[0] -10000000
kill @s
