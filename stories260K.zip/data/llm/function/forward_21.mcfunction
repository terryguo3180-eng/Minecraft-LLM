data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "th2"
data modify storage llm args.m set value "w3_2"
scoreboard players set s1 llm 172
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 23
schedule function llm:forward_22 1t
