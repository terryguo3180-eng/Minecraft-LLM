data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "k"
data modify storage llm args.m set value "wk_2"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 18
schedule function llm:forward_17 1t
