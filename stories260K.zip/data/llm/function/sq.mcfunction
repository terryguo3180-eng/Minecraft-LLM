scoreboard players operation t0 llm = xb llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation t1 llm = t0 llm
scoreboard players operation t1 llm *= t0 llm
scoreboard players operation t1 llm /= 10000 llm
scoreboard players operation t0 llm *= xb llm
scoreboard players operation t0 llm *= 2 llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation xb llm *= xb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= xs llm
scoreboard players operation xe llm *= 2 llm
execute if score xb llm matches 100000000.. run function llm:float_15
