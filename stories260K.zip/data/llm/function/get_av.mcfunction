$scoreboard players operation xb llm = $(i)b av
$scoreboard players operation xe llm = $(i)e av
$scoreboard players operation xs llm = $(i)s av
