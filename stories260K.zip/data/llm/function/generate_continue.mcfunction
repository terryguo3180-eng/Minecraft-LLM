$scoreboard players set steps llm $(s)
scoreboard players operation steps llm += pos llm
execute if score steps llm matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer!","color":"red"}
function llm:autoregressive
