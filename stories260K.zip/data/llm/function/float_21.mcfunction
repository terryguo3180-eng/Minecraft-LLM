scoreboard players set xs llm -1
scoreboard players operation xb llm *= -1 llm
