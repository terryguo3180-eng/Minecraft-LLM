scoreboard players operation xb llm *= 1000000 llm
scoreboard players remove xe llm 6
