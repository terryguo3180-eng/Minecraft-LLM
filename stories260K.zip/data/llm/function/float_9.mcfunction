scoreboard players operation xb llm *= 10000000 llm
scoreboard players remove xe llm 7
