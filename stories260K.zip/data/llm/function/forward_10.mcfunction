function llm:rope
scoreboard players operation cache_idx llm = pos llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32768
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 0b k
scoreboard players operation xe llm = 0e k
scoreboard players operation xs llm = 0s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 0b v
scoreboard players operation xe llm = 0e v
scoreboard players operation xs llm = 0s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32769
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 1b k
scoreboard players operation xe llm = 1e k
scoreboard players operation xs llm = 1s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 1b v
scoreboard players operation xe llm = 1e v
scoreboard players operation xs llm = 1s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32770
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 2b k
scoreboard players operation xe llm = 2e k
scoreboard players operation xs llm = 2s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 2b v
scoreboard players operation xe llm = 2e v
scoreboard players operation xs llm = 2s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32771
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 3b k
scoreboard players operation xe llm = 3e k
scoreboard players operation xs llm = 3s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 3b v
scoreboard players operation xe llm = 3e v
scoreboard players operation xs llm = 3s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32772
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 4b k
scoreboard players operation xe llm = 4e k
scoreboard players operation xs llm = 4s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 4b v
scoreboard players operation xe llm = 4e v
scoreboard players operation xs llm = 4s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32773
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 5b k
scoreboard players operation xe llm = 5e k
scoreboard players operation xs llm = 5s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 5b v
scoreboard players operation xe llm = 5e v
scoreboard players operation xs llm = 5s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32774
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 6b k
scoreboard players operation xe llm = 6e k
scoreboard players operation xs llm = 6s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 6b v
scoreboard players operation xe llm = 6e v
scoreboard players operation xs llm = 6s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32775
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 7b k
scoreboard players operation xe llm = 7e k
scoreboard players operation xs llm = 7s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 7b v
scoreboard players operation xe llm = 7e v
scoreboard players operation xs llm = 7s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32776
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 8b k
scoreboard players operation xe llm = 8e k
scoreboard players operation xs llm = 8s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 8b v
scoreboard players operation xe llm = 8e v
scoreboard players operation xs llm = 8s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32777
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 9b k
scoreboard players operation xe llm = 9e k
scoreboard players operation xs llm = 9s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 9b v
scoreboard players operation xe llm = 9e v
scoreboard players operation xs llm = 9s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32778
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 10b k
scoreboard players operation xe llm = 10e k
scoreboard players operation xs llm = 10s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 10b v
scoreboard players operation xe llm = 10e v
scoreboard players operation xs llm = 10s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32779
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 11b k
scoreboard players operation xe llm = 11e k
scoreboard players operation xs llm = 11s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 11b v
scoreboard players operation xe llm = 11e v
scoreboard players operation xs llm = 11s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32780
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 12b k
scoreboard players operation xe llm = 12e k
scoreboard players operation xs llm = 12s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 12b v
scoreboard players operation xe llm = 12e v
scoreboard players operation xs llm = 12s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32781
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 13b k
scoreboard players operation xe llm = 13e k
scoreboard players operation xs llm = 13s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 13b v
scoreboard players operation xe llm = 13e v
scoreboard players operation xs llm = 13s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32782
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 14b k
scoreboard players operation xe llm = 14e k
scoreboard players operation xs llm = 14s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 14b v
scoreboard players operation xe llm = 14e v
scoreboard players operation xs llm = 14s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32783
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 15b k
scoreboard players operation xe llm = 15e k
scoreboard players operation xs llm = 15s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 15b v
scoreboard players operation xe llm = 15e v
scoreboard players operation xs llm = 15s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32784
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 16b k
scoreboard players operation xe llm = 16e k
scoreboard players operation xs llm = 16s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 16b v
scoreboard players operation xe llm = 16e v
scoreboard players operation xs llm = 16s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32785
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 17b k
scoreboard players operation xe llm = 17e k
scoreboard players operation xs llm = 17s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 17b v
scoreboard players operation xe llm = 17e v
scoreboard players operation xs llm = 17s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32786
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 18b k
scoreboard players operation xe llm = 18e k
scoreboard players operation xs llm = 18s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 18b v
scoreboard players operation xe llm = 18e v
scoreboard players operation xs llm = 18s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32787
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 19b k
scoreboard players operation xe llm = 19e k
scoreboard players operation xs llm = 19s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 19b v
scoreboard players operation xe llm = 19e v
scoreboard players operation xs llm = 19s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32788
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 20b k
scoreboard players operation xe llm = 20e k
scoreboard players operation xs llm = 20s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 20b v
scoreboard players operation xe llm = 20e v
scoreboard players operation xs llm = 20s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32789
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 21b k
scoreboard players operation xe llm = 21e k
scoreboard players operation xs llm = 21s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 21b v
scoreboard players operation xe llm = 21e v
scoreboard players operation xs llm = 21s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32790
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 22b k
scoreboard players operation xe llm = 22e k
scoreboard players operation xs llm = 22s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 22b v
scoreboard players operation xe llm = 22e v
scoreboard players operation xs llm = 22s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32791
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 23b k
scoreboard players operation xe llm = 23e k
scoreboard players operation xs llm = 23s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 23b v
scoreboard players operation xe llm = 23e v
scoreboard players operation xs llm = 23s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32792
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 24b k
scoreboard players operation xe llm = 24e k
scoreboard players operation xs llm = 24s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 24b v
scoreboard players operation xe llm = 24e v
scoreboard players operation xs llm = 24s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32793
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 25b k
scoreboard players operation xe llm = 25e k
scoreboard players operation xs llm = 25s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 25b v
scoreboard players operation xe llm = 25e v
scoreboard players operation xs llm = 25s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32794
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 26b k
scoreboard players operation xe llm = 26e k
scoreboard players operation xs llm = 26s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 26b v
scoreboard players operation xe llm = 26e v
scoreboard players operation xs llm = 26s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32795
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 27b k
scoreboard players operation xe llm = 27e k
scoreboard players operation xs llm = 27s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 27b v
scoreboard players operation xe llm = 27e v
scoreboard players operation xs llm = 27s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32796
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 28b k
scoreboard players operation xe llm = 28e k
scoreboard players operation xs llm = 28s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 28b v
scoreboard players operation xe llm = 28e v
scoreboard players operation xs llm = 28s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32797
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 29b k
scoreboard players operation xe llm = 29e k
scoreboard players operation xs llm = 29s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 29b v
scoreboard players operation xe llm = 29e v
scoreboard players operation xs llm = 29s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32798
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 30b k
scoreboard players operation xe llm = 30e k
scoreboard players operation xs llm = 30s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 30b v
scoreboard players operation xe llm = 30e v
scoreboard players operation xs llm = 30s v
function llm:set_vc with storage llm args
scoreboard players operation i llm = cache_idx llm
scoreboard players operation i llm *= 64 llm
scoreboard players add i llm 32799
execute store result storage llm args.i int 1 run scoreboard players get i llm
scoreboard players operation xb llm = 31b k
scoreboard players operation xe llm = 31e k
scoreboard players operation xs llm = 31s k
function llm:set_kc with storage llm args
scoreboard players operation xb llm = 31b v
scoreboard players operation xe llm = 31e v
scoreboard players operation xs llm = 31s v
function llm:set_vc with storage llm args
function llm:crop_context
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h0_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h0_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h0_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h0_norm
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l0_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h1_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h1_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h1_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h1_norm
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l1_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h2_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h2_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h2_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h2_norm
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l2_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h3_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h3_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h3_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h3_norm
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l3_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h4_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h4_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h4_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h4_norm
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l4_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h5_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h5_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h5_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h5_norm
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l5_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h6_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h6_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h6_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h6_norm
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l6_val
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_h7_score
scoreboard players operation maxb llm = 0b av
scoreboard players operation maxe llm = 0e av
scoreboard players operation maxs llm = 0s av
scoreboard players set i llm 1
execute if score i llm < window_len llm run function llm:attention_l1_h7_max
scoreboard players set expsumb llm 0
scoreboard players set expsume llm 0
scoreboard players set expsums llm 0
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h7_expsum
scoreboard players set i llm 0
execute if score i llm < window_len llm run function llm:attention_l1_h7_norm
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t llm = start llm
scoreboard players set i llm 0
execute if score t llm <= pos llm run function llm:attention_l1_l7_val
bossbar set progress value 12
schedule function llm:forward_11 1t
