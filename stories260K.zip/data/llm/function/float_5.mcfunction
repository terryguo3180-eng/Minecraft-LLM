execute if score xb llm matches 100000.. run return run function llm:float_6
execute if score xb llm matches 100..99999 run return run function llm:float_7
execute if score xb llm matches 1..9 run return run function llm:float_8
execute if score xb llm matches 10..99 run return run function llm:float_9
scoreboard players set xe llm 0
scoreboard players set xs llm 0
