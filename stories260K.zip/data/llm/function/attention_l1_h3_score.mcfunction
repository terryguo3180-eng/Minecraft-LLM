scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 32776
scoreboard players set scoreb llm 0
scoreboard players set scoree llm 0
scoreboard players set scores llm 0
scoreboard players operation yb llm = 24b q
scoreboard players operation ye llm = 24e q
scoreboard players operation ys llm = 24s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 25b q
scoreboard players operation ye llm = 25e q
scoreboard players operation ys llm = 25s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 26b q
scoreboard players operation ye llm = 26e q
scoreboard players operation ys llm = 26s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 27b q
scoreboard players operation ye llm = 27e q
scoreboard players operation ys llm = 27s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 28b q
scoreboard players operation ye llm = 28e q
scoreboard players operation ys llm = 28s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 29b q
scoreboard players operation ye llm = 29e q
scoreboard players operation ys llm = 29s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 30b q
scoreboard players operation ye llm = 30e q
scoreboard players operation ys llm = 30s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 31b q
scoreboard players operation ye llm = 31e q
scoreboard players operation ys llm = 31s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation xb llm = scoreb llm
scoreboard players operation xe llm = scoree llm
scoreboard players operation xs llm = scores llm
scoreboard players set yb llm 28284271
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:div
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:set_av with storage llm args
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:attention_l1_h3_score
