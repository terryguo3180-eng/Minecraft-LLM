execute store result score tok llm run data get storage llm args.prompt_tokens[0]
data remove storage llm args.prompt_tokens[0]
function llm:get_token
data modify storage llm args.tokens append from storage llm args.tok
tellraw @a ["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",{"storage":"llm","nbt":"args.tokens[]","separator":""}]
scoreboard players add pos llm 1
execute if score pos llm = steps llm run return 1
bossbar set progress players
function llm:autoregressive
