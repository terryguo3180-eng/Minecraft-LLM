$scoreboard players operation xb llm = $(i)b logits
$scoreboard players operation xe llm = $(i)e logits
$scoreboard players operation xs llm = $(i)s logits
function llm:cmp
execute if score r llm matches 1 run function llm:set_token
execute store result score t0 llm store result score t1 llm store result storage llm args.i int 1 run scoreboard players add i llm 1
scoreboard players operation t0 llm %= 100 llm
execute if score t0 llm matches 99 store result bossbar progress value run scoreboard players operation t1 llm /= 100 llm
execute if score i llm matches ..511 run function llm:argmax_loop with storage llm args
