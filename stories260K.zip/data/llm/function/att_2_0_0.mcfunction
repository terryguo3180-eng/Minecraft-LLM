scoreboard players operation cache_idx llm = t llm
scoreboard players operation cache_idx llm %= 512 llm
scoreboard players operation cache_idx llm *= 64 llm
scoreboard players add cache_idx llm 65536
scoreboard players set scoreb llm 0
scoreboard players set scoree llm 0
scoreboard players set scores llm 0
scoreboard players operation yb llm = 0b q
scoreboard players operation ye llm = 0e q
scoreboard players operation ys llm = 0s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 1b q
scoreboard players operation ye llm = 1e q
scoreboard players operation ys llm = 1s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 2b q
scoreboard players operation ye llm = 2e q
scoreboard players operation ys llm = 2s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 3b q
scoreboard players operation ye llm = 3e q
scoreboard players operation ys llm = 3s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 4b q
scoreboard players operation ye llm = 4e q
scoreboard players operation ys llm = 4s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 5b q
scoreboard players operation ye llm = 5e q
scoreboard players operation ys llm = 5s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 6b q
scoreboard players operation ye llm = 6e q
scoreboard players operation ys llm = 6s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation yb llm = 7b q
scoreboard players operation ye llm = 7e q
scoreboard players operation ys llm = 7s q
execute store result storage llm args.i int 1 run scoreboard players get cache_idx llm
function llm:get_kc with storage llm args
scoreboard players add cache_idx llm 1
function llm:mul
scoreboard players operation yb llm = scoreb llm
scoreboard players operation ye llm = scoree llm
scoreboard players operation ys llm = scores llm
function llm:add
scoreboard players operation scoreb llm = xb llm
scoreboard players operation scoree llm = xe llm
scoreboard players operation scores llm = xs llm
scoreboard players operation xb llm = scoreb llm
scoreboard players operation xe llm = scoree llm
scoreboard players operation xs llm = scores llm
scoreboard players set yb llm 28284271
scoreboard players set ye llm 0
scoreboard players set ys llm 1
function llm:div
execute store result storage llm args.i int 1 run scoreboard players get i llm
function llm:set_av with storage llm args
scoreboard players add t llm 1
scoreboard players add i llm 1
execute if score t llm <= pos llm run function llm:att_2_0_0
