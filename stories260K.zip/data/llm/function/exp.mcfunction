execute store result storage llm args.t int 4.3429448190325176 run scoreboard players get xb llm
execute store result score xb llm run data get storage llm args.t
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players remove xe llm 1
scoreboard players operation t4 llm = xb llm
scoreboard players operation t5 llm = xe llm
scoreboard players operation t6 llm = xs llm
function llm:floor
execute if score t6 llm matches -1 run function llm:float_30
scoreboard players operation yb llm = t4 llm
scoreboard players operation ye llm = t5 llm
scoreboard players operation ys llm = t6 llm
scoreboard players operation ys llm *= -1 llm
function llm:add
scoreboard players operation xs llm *= -1 llm
execute store result storage llm args.t int 2.3025850929940456840 run scoreboard players get xb llm
execute store result score xb llm run data get storage llm args.t
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation t4 llm = xb llm
scoreboard players operation t5 llm = xe llm
scoreboard players operation t6 llm = xs llm
execute store result storage llm args.t int 3.2546203518824833519 run scoreboard players get t4 llm
execute store result score xb llm run data get storage llm args.t
scoreboard players remove xe llm 4
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 19813115
scoreboard players set ye llm -3
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 35871171
scoreboard players set ye llm -3
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 54159899
scoreboard players set ye llm -2
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 14960666
scoreboard players set ye llm -1
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 51295916
scoreboard players set ye llm -1
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 99479042
scoreboard players set ye llm -1
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation yb llm = t4 llm
scoreboard players operation t0 llm = xb llm
scoreboard players operation t0 llm %= 10000 llm
scoreboard players operation xb llm /= 10000 llm
scoreboard players operation t1 llm = xb llm
scoreboard players operation t2 llm = yb llm
scoreboard players operation t2 llm %= 10000 llm
scoreboard players operation yb llm /= 10000 llm
scoreboard players operation t1 llm *= t2 llm
scoreboard players operation t3 llm = t0 llm
scoreboard players operation t3 llm *= yb llm
scoreboard players operation t3 llm /= 10000 llm
scoreboard players operation t0 llm *= yb llm
scoreboard players operation t0 llm += t1 llm
scoreboard players operation t0 llm += t3 llm
scoreboard players operation xb llm *= yb llm
scoreboard players operation xb llm *= 10 llm
scoreboard players operation t0 llm /= 1000 llm
scoreboard players operation xb llm += t0 llm
scoreboard players operation xs llm *= t6 llm
scoreboard players operation xe llm += t5 llm
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players set yb llm 10008708
scoreboard players set ye llm 0
scoreboard players set ys llm 1
scoreboard players operation t0 llm = ys llm
scoreboard players operation t0 llm *= xs llm
scoreboard players operation t2 llm = yb llm
function llm:float_0
scoreboard players operation t3 llm = xe llm
scoreboard players operation t3 llm -= ye llm
execute if score t1 llm matches 1 run function llm:float_1
scoreboard players operation t2 llm *= t0 llm
execute unless score t3 llm matches 0 run function llm:float_2
scoreboard players operation xb llm += t2 llm
function llm:float_5
execute if score xb llm matches 100000000.. run function llm:float_15
scoreboard players operation xe llm = r llm
