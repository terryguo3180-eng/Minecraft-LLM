gamerule max_command_sequence_length 2147483647
scoreboard objectives add llm dummy
scoreboard objectives add x dummy
scoreboard objectives add tx dummy
scoreboard objectives add tx2 dummy
scoreboard objectives add th dummy
scoreboard objectives add th2 dummy
scoreboard objectives add q dummy
scoreboard objectives add k dummy
scoreboard objectives add v dummy
scoreboard objectives add av dummy
scoreboard objectives add kc dummy
scoreboard objectives add vc dummy
scoreboard objectives add logits dummy
scoreboard players set -1 llm -1
scoreboard players set 2 llm 2
scoreboard players set 10 llm 10
scoreboard players set 25 llm 25
scoreboard players set 40 llm 40
scoreboard players set 64 llm 64
scoreboard players set 100 llm 100
scoreboard players set 500 llm 500
scoreboard players set 512 llm 512
scoreboard players set 1000 llm 1000
scoreboard players set 4750 llm 4750
scoreboard players set 10000 llm 10000
scoreboard players set 24703 llm 24703
scoreboard players set 79249 llm 79249
scoreboard players set 100000 llm 100000
scoreboard players set 1000000 llm 1000000
scoreboard players set 10000000 llm 10000000
scoreboard players set 100000000 llm 100000000
scoreboard players set 1000000000 llm 1000000000
bossbar add progress "Progress"
function llm:params
scoreboard players reset * kc
scoreboard players reset * vc
