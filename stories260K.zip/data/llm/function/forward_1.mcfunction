data modify storage llm args.in set value "tx"
data modify storage llm args.out set value "v"
data modify storage llm args.m set value "wv_0"
scoreboard players set s1 llm 32
scoreboard players set s2 llm 64
function llm:matmul
bossbar set progress value 3
schedule function llm:forward_2 1t
