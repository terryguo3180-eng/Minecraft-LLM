scoreboard players operation xb stories260k >< t2 stories260k
scoreboard players operation xe stories260k = ye stories260k
scoreboard players operation t3 stories260k *= -1 stories260k
scoreboard players operation xs stories260k = ys stories260k
