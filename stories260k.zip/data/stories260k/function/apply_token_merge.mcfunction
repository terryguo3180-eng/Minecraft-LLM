$execute store result storage stories260k args.prompt_tokens[$(i)] int 1 run scoreboard players get bt stories260k
$data remove storage stories260k args.prompt_tokens[$(j)]
