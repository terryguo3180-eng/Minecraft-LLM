scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation r stories260k = xb stories260k
scoreboard players operation xb stories260k *= 10000 stories260k
