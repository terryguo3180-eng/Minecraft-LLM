data modify storage stories260k args.s set value ""
execute if score xs stories260k matches -1 run data modify storage stories260k args.s set value "-"
scoreboard players operation t0 stories260k = xe stories260k
execute store result storage stories260k args.e int 1 run scoreboard players remove t0 stories260k 7
execute store result storage stories260k args.b int 1 run scoreboard players get xb stories260k
function stories260k:float_32 with storage stories260k args
