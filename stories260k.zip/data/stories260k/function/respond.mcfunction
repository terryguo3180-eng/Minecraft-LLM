bossbar set progress max 48
bossbar set progress value 0
bossbar set progress name [{"text":"Inferring, Step #","color":"green","bold":true},{"score":{"name":"pos","objective":"stories260k"}}]
bossbar set progress players @a
function stories260k:forward
schedule function stories260k:respond_0 52t
