$execute store result score xb stories260k run data get storage stories260k params.$(m).$(idx)b
$execute store result score xe stories260k run data get storage stories260k params.$(m).$(idx)e
$execute store result score xs stories260k run data get storage stories260k params.$(m).$(idx)s
$scoreboard players operation yb stories260k = $(j)b $(in)
$scoreboard players operation ye stories260k = $(j)e $(in)
$scoreboard players operation ys stories260k = $(j)s $(in)
function stories260k:mul
$scoreboard players operation yb stories260k = $(i)b $(out)
$scoreboard players operation ye stories260k = $(i)e $(out)
$scoreboard players operation ys stories260k = $(i)s $(out)
function stories260k:add
$scoreboard players operation $(i)b $(out) = xb stories260k
$scoreboard players operation $(i)e $(out) = xe stories260k
$scoreboard players operation $(i)s $(out) = xs stories260k
scoreboard players add j stories260k 1
execute store result storage stories260k args.idx int 1 run scoreboard players add idx stories260k 1
execute if score j stories260k = s2 stories260k run return 1
execute store result storage stories260k args.j int 1 run scoreboard players get j stories260k
function stories260k:matmul_j with storage stories260k args
