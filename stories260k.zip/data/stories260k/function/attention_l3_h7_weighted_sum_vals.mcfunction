scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 98328
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 56b tx
scoreboard players operation ye stories260k = 56e tx
scoreboard players operation ys stories260k = 56s tx
function stories260k:add
scoreboard players operation 56b tx = xb stories260k
scoreboard players operation 56e tx = xe stories260k
scoreboard players operation 56s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 57b tx
scoreboard players operation ye stories260k = 57e tx
scoreboard players operation ys stories260k = 57s tx
function stories260k:add
scoreboard players operation 57b tx = xb stories260k
scoreboard players operation 57e tx = xe stories260k
scoreboard players operation 57s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 58b tx
scoreboard players operation ye stories260k = 58e tx
scoreboard players operation ys stories260k = 58s tx
function stories260k:add
scoreboard players operation 58b tx = xb stories260k
scoreboard players operation 58e tx = xe stories260k
scoreboard players operation 58s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 59b tx
scoreboard players operation ye stories260k = 59e tx
scoreboard players operation ys stories260k = 59s tx
function stories260k:add
scoreboard players operation 59b tx = xb stories260k
scoreboard players operation 59e tx = xe stories260k
scoreboard players operation 59s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 60b tx
scoreboard players operation ye stories260k = 60e tx
scoreboard players operation ys stories260k = 60s tx
function stories260k:add
scoreboard players operation 60b tx = xb stories260k
scoreboard players operation 60e tx = xe stories260k
scoreboard players operation 60s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 61b tx
scoreboard players operation ye stories260k = 61e tx
scoreboard players operation ys stories260k = 61s tx
function stories260k:add
scoreboard players operation 61b tx = xb stories260k
scoreboard players operation 61e tx = xe stories260k
scoreboard players operation 61s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 62b tx
scoreboard players operation ye stories260k = 62e tx
scoreboard players operation ys stories260k = 62s tx
function stories260k:add
scoreboard players operation 62b tx = xb stories260k
scoreboard players operation 62e tx = xe stories260k
scoreboard players operation 62s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 63b tx
scoreboard players operation ye stories260k = 63e tx
scoreboard players operation ys stories260k = 63s tx
function stories260k:add
scoreboard players operation 63b tx = xb stories260k
scoreboard players operation 63e tx = xe stories260k
scoreboard players operation 63s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l3_h7_weighted_sum_vals
