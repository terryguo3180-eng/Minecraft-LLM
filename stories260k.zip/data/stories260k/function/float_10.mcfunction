scoreboard players operation xb stories260k *= 1000 stories260k
scoreboard players remove xe stories260k 3
