scoreboard players operation xb stories260k /= 10 stories260k
scoreboard players add xe stories260k 1
