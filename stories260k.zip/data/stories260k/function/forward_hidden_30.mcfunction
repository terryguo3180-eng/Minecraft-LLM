function stories260k:silu_activation
data modify storage stories260k args.in set value "th"
data modify storage stories260k args.out set value "tx"
data modify storage stories260k args.m set value "w2_3"
scoreboard players set s1 stories260k 64
scoreboard players set s2 stories260k 172
function stories260k:matmul
bossbar set progress value 32
schedule function stories260k:forward_hidden_31 1t
