scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players remove xe stories260k 1
