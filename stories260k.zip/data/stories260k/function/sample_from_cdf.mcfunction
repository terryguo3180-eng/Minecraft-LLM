$scoreboard players operation xb stories260k = $(i)b logits
$scoreboard players operation xe stories260k = $(i)e logits
$scoreboard players operation xs stories260k = $(i)s logits
scoreboard players operation yb stories260k = cdfb stories260k
scoreboard players operation ye stories260k = cdfe stories260k
scoreboard players operation ys stories260k = cdfs stories260k
function stories260k:add
scoreboard players operation cdfb stories260k = xb stories260k
scoreboard players operation cdfe stories260k = xe stories260k
scoreboard players operation cdfs stories260k = xs stories260k
scoreboard players operation yb stories260k = rb stories260k
scoreboard players operation ye stories260k = re stories260k
scoreboard players operation ys stories260k = rs stories260k
function stories260k:cmp
execute if score r stories260k matches 1 run return run scoreboard players operation tok stories260k = i stories260k
execute store result score t0 stories260k store result score t1 stories260k store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
scoreboard players operation t0 stories260k %= 100 stories260k
scoreboard players add t1 stories260k 2048
execute if score t0 stories260k matches 99 store result bossbar progress value run scoreboard players operation t1 stories260k /= 100 stories260k
execute if score i stories260k matches ..511 run function stories260k:sample_from_cdf with storage stories260k args
