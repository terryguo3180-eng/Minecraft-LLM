scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 32784
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 40b tx
scoreboard players operation ye stories260k = 40e tx
scoreboard players operation ys stories260k = 40s tx
function stories260k:add
scoreboard players operation 40b tx = xb stories260k
scoreboard players operation 40e tx = xe stories260k
scoreboard players operation 40s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 41b tx
scoreboard players operation ye stories260k = 41e tx
scoreboard players operation ys stories260k = 41s tx
function stories260k:add
scoreboard players operation 41b tx = xb stories260k
scoreboard players operation 41e tx = xe stories260k
scoreboard players operation 41s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 42b tx
scoreboard players operation ye stories260k = 42e tx
scoreboard players operation ys stories260k = 42s tx
function stories260k:add
scoreboard players operation 42b tx = xb stories260k
scoreboard players operation 42e tx = xe stories260k
scoreboard players operation 42s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 43b tx
scoreboard players operation ye stories260k = 43e tx
scoreboard players operation ys stories260k = 43s tx
function stories260k:add
scoreboard players operation 43b tx = xb stories260k
scoreboard players operation 43e tx = xe stories260k
scoreboard players operation 43s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 44b tx
scoreboard players operation ye stories260k = 44e tx
scoreboard players operation ys stories260k = 44s tx
function stories260k:add
scoreboard players operation 44b tx = xb stories260k
scoreboard players operation 44e tx = xe stories260k
scoreboard players operation 44s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 45b tx
scoreboard players operation ye stories260k = 45e tx
scoreboard players operation ys stories260k = 45s tx
function stories260k:add
scoreboard players operation 45b tx = xb stories260k
scoreboard players operation 45e tx = xe stories260k
scoreboard players operation 45s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 46b tx
scoreboard players operation ye stories260k = 46e tx
scoreboard players operation ys stories260k = 46s tx
function stories260k:add
scoreboard players operation 46b tx = xb stories260k
scoreboard players operation 46e tx = xe stories260k
scoreboard players operation 46s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 47b tx
scoreboard players operation ye stories260k = 47e tx
scoreboard players operation ys stories260k = 47s tx
function stories260k:add
scoreboard players operation 47b tx = xb stories260k
scoreboard players operation 47e tx = xe stories260k
scoreboard players operation 47s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h5_weighted_sum_vals
