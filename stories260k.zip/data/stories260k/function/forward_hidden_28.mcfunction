scoreboard players operation xb stories260k = 0b tx2
scoreboard players operation xe stories260k = 0e tx2
scoreboard players operation xs stories260k = 0s tx2
scoreboard players operation yb stories260k = 0b x
scoreboard players operation ye stories260k = 0e x
scoreboard players operation ys stories260k = 0s x
function stories260k:add
scoreboard players operation 0b x = xb stories260k
scoreboard players operation 0e x = xe stories260k
scoreboard players operation 0s x = xs stories260k
scoreboard players operation xb stories260k = 1b tx2
scoreboard players operation xe stories260k = 1e tx2
scoreboard players operation xs stories260k = 1s tx2
scoreboard players operation yb stories260k = 1b x
scoreboard players operation ye stories260k = 1e x
scoreboard players operation ys stories260k = 1s x
function stories260k:add
scoreboard players operation 1b x = xb stories260k
scoreboard players operation 1e x = xe stories260k
scoreboard players operation 1s x = xs stories260k
scoreboard players operation xb stories260k = 2b tx2
scoreboard players operation xe stories260k = 2e tx2
scoreboard players operation xs stories260k = 2s tx2
scoreboard players operation yb stories260k = 2b x
scoreboard players operation ye stories260k = 2e x
scoreboard players operation ys stories260k = 2s x
function stories260k:add
scoreboard players operation 2b x = xb stories260k
scoreboard players operation 2e x = xe stories260k
scoreboard players operation 2s x = xs stories260k
scoreboard players operation xb stories260k = 3b tx2
scoreboard players operation xe stories260k = 3e tx2
scoreboard players operation xs stories260k = 3s tx2
scoreboard players operation yb stories260k = 3b x
scoreboard players operation ye stories260k = 3e x
scoreboard players operation ys stories260k = 3s x
function stories260k:add
scoreboard players operation 3b x = xb stories260k
scoreboard players operation 3e x = xe stories260k
scoreboard players operation 3s x = xs stories260k
scoreboard players operation xb stories260k = 4b tx2
scoreboard players operation xe stories260k = 4e tx2
scoreboard players operation xs stories260k = 4s tx2
scoreboard players operation yb stories260k = 4b x
scoreboard players operation ye stories260k = 4e x
scoreboard players operation ys stories260k = 4s x
function stories260k:add
scoreboard players operation 4b x = xb stories260k
scoreboard players operation 4e x = xe stories260k
scoreboard players operation 4s x = xs stories260k
scoreboard players operation xb stories260k = 5b tx2
scoreboard players operation xe stories260k = 5e tx2
scoreboard players operation xs stories260k = 5s tx2
scoreboard players operation yb stories260k = 5b x
scoreboard players operation ye stories260k = 5e x
scoreboard players operation ys stories260k = 5s x
function stories260k:add
scoreboard players operation 5b x = xb stories260k
scoreboard players operation 5e x = xe stories260k
scoreboard players operation 5s x = xs stories260k
scoreboard players operation xb stories260k = 6b tx2
scoreboard players operation xe stories260k = 6e tx2
scoreboard players operation xs stories260k = 6s tx2
scoreboard players operation yb stories260k = 6b x
scoreboard players operation ye stories260k = 6e x
scoreboard players operation ys stories260k = 6s x
function stories260k:add
scoreboard players operation 6b x = xb stories260k
scoreboard players operation 6e x = xe stories260k
scoreboard players operation 6s x = xs stories260k
scoreboard players operation xb stories260k = 7b tx2
scoreboard players operation xe stories260k = 7e tx2
scoreboard players operation xs stories260k = 7s tx2
scoreboard players operation yb stories260k = 7b x
scoreboard players operation ye stories260k = 7e x
scoreboard players operation ys stories260k = 7s x
function stories260k:add
scoreboard players operation 7b x = xb stories260k
scoreboard players operation 7e x = xe stories260k
scoreboard players operation 7s x = xs stories260k
scoreboard players operation xb stories260k = 8b tx2
scoreboard players operation xe stories260k = 8e tx2
scoreboard players operation xs stories260k = 8s tx2
scoreboard players operation yb stories260k = 8b x
scoreboard players operation ye stories260k = 8e x
scoreboard players operation ys stories260k = 8s x
function stories260k:add
scoreboard players operation 8b x = xb stories260k
scoreboard players operation 8e x = xe stories260k
scoreboard players operation 8s x = xs stories260k
scoreboard players operation xb stories260k = 9b tx2
scoreboard players operation xe stories260k = 9e tx2
scoreboard players operation xs stories260k = 9s tx2
scoreboard players operation yb stories260k = 9b x
scoreboard players operation ye stories260k = 9e x
scoreboard players operation ys stories260k = 9s x
function stories260k:add
scoreboard players operation 9b x = xb stories260k
scoreboard players operation 9e x = xe stories260k
scoreboard players operation 9s x = xs stories260k
scoreboard players operation xb stories260k = 10b tx2
scoreboard players operation xe stories260k = 10e tx2
scoreboard players operation xs stories260k = 10s tx2
scoreboard players operation yb stories260k = 10b x
scoreboard players operation ye stories260k = 10e x
scoreboard players operation ys stories260k = 10s x
function stories260k:add
scoreboard players operation 10b x = xb stories260k
scoreboard players operation 10e x = xe stories260k
scoreboard players operation 10s x = xs stories260k
scoreboard players operation xb stories260k = 11b tx2
scoreboard players operation xe stories260k = 11e tx2
scoreboard players operation xs stories260k = 11s tx2
scoreboard players operation yb stories260k = 11b x
scoreboard players operation ye stories260k = 11e x
scoreboard players operation ys stories260k = 11s x
function stories260k:add
scoreboard players operation 11b x = xb stories260k
scoreboard players operation 11e x = xe stories260k
scoreboard players operation 11s x = xs stories260k
scoreboard players operation xb stories260k = 12b tx2
scoreboard players operation xe stories260k = 12e tx2
scoreboard players operation xs stories260k = 12s tx2
scoreboard players operation yb stories260k = 12b x
scoreboard players operation ye stories260k = 12e x
scoreboard players operation ys stories260k = 12s x
function stories260k:add
scoreboard players operation 12b x = xb stories260k
scoreboard players operation 12e x = xe stories260k
scoreboard players operation 12s x = xs stories260k
scoreboard players operation xb stories260k = 13b tx2
scoreboard players operation xe stories260k = 13e tx2
scoreboard players operation xs stories260k = 13s tx2
scoreboard players operation yb stories260k = 13b x
scoreboard players operation ye stories260k = 13e x
scoreboard players operation ys stories260k = 13s x
function stories260k:add
scoreboard players operation 13b x = xb stories260k
scoreboard players operation 13e x = xe stories260k
scoreboard players operation 13s x = xs stories260k
scoreboard players operation xb stories260k = 14b tx2
scoreboard players operation xe stories260k = 14e tx2
scoreboard players operation xs stories260k = 14s tx2
scoreboard players operation yb stories260k = 14b x
scoreboard players operation ye stories260k = 14e x
scoreboard players operation ys stories260k = 14s x
function stories260k:add
scoreboard players operation 14b x = xb stories260k
scoreboard players operation 14e x = xe stories260k
scoreboard players operation 14s x = xs stories260k
scoreboard players operation xb stories260k = 15b tx2
scoreboard players operation xe stories260k = 15e tx2
scoreboard players operation xs stories260k = 15s tx2
scoreboard players operation yb stories260k = 15b x
scoreboard players operation ye stories260k = 15e x
scoreboard players operation ys stories260k = 15s x
function stories260k:add
scoreboard players operation 15b x = xb stories260k
scoreboard players operation 15e x = xe stories260k
scoreboard players operation 15s x = xs stories260k
scoreboard players operation xb stories260k = 16b tx2
scoreboard players operation xe stories260k = 16e tx2
scoreboard players operation xs stories260k = 16s tx2
scoreboard players operation yb stories260k = 16b x
scoreboard players operation ye stories260k = 16e x
scoreboard players operation ys stories260k = 16s x
function stories260k:add
scoreboard players operation 16b x = xb stories260k
scoreboard players operation 16e x = xe stories260k
scoreboard players operation 16s x = xs stories260k
scoreboard players operation xb stories260k = 17b tx2
scoreboard players operation xe stories260k = 17e tx2
scoreboard players operation xs stories260k = 17s tx2
scoreboard players operation yb stories260k = 17b x
scoreboard players operation ye stories260k = 17e x
scoreboard players operation ys stories260k = 17s x
function stories260k:add
scoreboard players operation 17b x = xb stories260k
scoreboard players operation 17e x = xe stories260k
scoreboard players operation 17s x = xs stories260k
scoreboard players operation xb stories260k = 18b tx2
scoreboard players operation xe stories260k = 18e tx2
scoreboard players operation xs stories260k = 18s tx2
scoreboard players operation yb stories260k = 18b x
scoreboard players operation ye stories260k = 18e x
scoreboard players operation ys stories260k = 18s x
function stories260k:add
scoreboard players operation 18b x = xb stories260k
scoreboard players operation 18e x = xe stories260k
scoreboard players operation 18s x = xs stories260k
scoreboard players operation xb stories260k = 19b tx2
scoreboard players operation xe stories260k = 19e tx2
scoreboard players operation xs stories260k = 19s tx2
scoreboard players operation yb stories260k = 19b x
scoreboard players operation ye stories260k = 19e x
scoreboard players operation ys stories260k = 19s x
function stories260k:add
scoreboard players operation 19b x = xb stories260k
scoreboard players operation 19e x = xe stories260k
scoreboard players operation 19s x = xs stories260k
scoreboard players operation xb stories260k = 20b tx2
scoreboard players operation xe stories260k = 20e tx2
scoreboard players operation xs stories260k = 20s tx2
scoreboard players operation yb stories260k = 20b x
scoreboard players operation ye stories260k = 20e x
scoreboard players operation ys stories260k = 20s x
function stories260k:add
scoreboard players operation 20b x = xb stories260k
scoreboard players operation 20e x = xe stories260k
scoreboard players operation 20s x = xs stories260k
scoreboard players operation xb stories260k = 21b tx2
scoreboard players operation xe stories260k = 21e tx2
scoreboard players operation xs stories260k = 21s tx2
scoreboard players operation yb stories260k = 21b x
scoreboard players operation ye stories260k = 21e x
scoreboard players operation ys stories260k = 21s x
function stories260k:add
scoreboard players operation 21b x = xb stories260k
scoreboard players operation 21e x = xe stories260k
scoreboard players operation 21s x = xs stories260k
scoreboard players operation xb stories260k = 22b tx2
scoreboard players operation xe stories260k = 22e tx2
scoreboard players operation xs stories260k = 22s tx2
scoreboard players operation yb stories260k = 22b x
scoreboard players operation ye stories260k = 22e x
scoreboard players operation ys stories260k = 22s x
function stories260k:add
scoreboard players operation 22b x = xb stories260k
scoreboard players operation 22e x = xe stories260k
scoreboard players operation 22s x = xs stories260k
scoreboard players operation xb stories260k = 23b tx2
scoreboard players operation xe stories260k = 23e tx2
scoreboard players operation xs stories260k = 23s tx2
scoreboard players operation yb stories260k = 23b x
scoreboard players operation ye stories260k = 23e x
scoreboard players operation ys stories260k = 23s x
function stories260k:add
scoreboard players operation 23b x = xb stories260k
scoreboard players operation 23e x = xe stories260k
scoreboard players operation 23s x = xs stories260k
scoreboard players operation xb stories260k = 24b tx2
scoreboard players operation xe stories260k = 24e tx2
scoreboard players operation xs stories260k = 24s tx2
scoreboard players operation yb stories260k = 24b x
scoreboard players operation ye stories260k = 24e x
scoreboard players operation ys stories260k = 24s x
function stories260k:add
scoreboard players operation 24b x = xb stories260k
scoreboard players operation 24e x = xe stories260k
scoreboard players operation 24s x = xs stories260k
scoreboard players operation xb stories260k = 25b tx2
scoreboard players operation xe stories260k = 25e tx2
scoreboard players operation xs stories260k = 25s tx2
scoreboard players operation yb stories260k = 25b x
scoreboard players operation ye stories260k = 25e x
scoreboard players operation ys stories260k = 25s x
function stories260k:add
scoreboard players operation 25b x = xb stories260k
scoreboard players operation 25e x = xe stories260k
scoreboard players operation 25s x = xs stories260k
scoreboard players operation xb stories260k = 26b tx2
scoreboard players operation xe stories260k = 26e tx2
scoreboard players operation xs stories260k = 26s tx2
scoreboard players operation yb stories260k = 26b x
scoreboard players operation ye stories260k = 26e x
scoreboard players operation ys stories260k = 26s x
function stories260k:add
scoreboard players operation 26b x = xb stories260k
scoreboard players operation 26e x = xe stories260k
scoreboard players operation 26s x = xs stories260k
scoreboard players operation xb stories260k = 27b tx2
scoreboard players operation xe stories260k = 27e tx2
scoreboard players operation xs stories260k = 27s tx2
scoreboard players operation yb stories260k = 27b x
scoreboard players operation ye stories260k = 27e x
scoreboard players operation ys stories260k = 27s x
function stories260k:add
scoreboard players operation 27b x = xb stories260k
scoreboard players operation 27e x = xe stories260k
scoreboard players operation 27s x = xs stories260k
scoreboard players operation xb stories260k = 28b tx2
scoreboard players operation xe stories260k = 28e tx2
scoreboard players operation xs stories260k = 28s tx2
scoreboard players operation yb stories260k = 28b x
scoreboard players operation ye stories260k = 28e x
scoreboard players operation ys stories260k = 28s x
function stories260k:add
scoreboard players operation 28b x = xb stories260k
scoreboard players operation 28e x = xe stories260k
scoreboard players operation 28s x = xs stories260k
scoreboard players operation xb stories260k = 29b tx2
scoreboard players operation xe stories260k = 29e tx2
scoreboard players operation xs stories260k = 29s tx2
scoreboard players operation yb stories260k = 29b x
scoreboard players operation ye stories260k = 29e x
scoreboard players operation ys stories260k = 29s x
function stories260k:add
scoreboard players operation 29b x = xb stories260k
scoreboard players operation 29e x = xe stories260k
scoreboard players operation 29s x = xs stories260k
scoreboard players operation xb stories260k = 30b tx2
scoreboard players operation xe stories260k = 30e tx2
scoreboard players operation xs stories260k = 30s tx2
scoreboard players operation yb stories260k = 30b x
scoreboard players operation ye stories260k = 30e x
scoreboard players operation ys stories260k = 30s x
function stories260k:add
scoreboard players operation 30b x = xb stories260k
scoreboard players operation 30e x = xe stories260k
scoreboard players operation 30s x = xs stories260k
scoreboard players operation xb stories260k = 31b tx2
scoreboard players operation xe stories260k = 31e tx2
scoreboard players operation xs stories260k = 31s tx2
scoreboard players operation yb stories260k = 31b x
scoreboard players operation ye stories260k = 31e x
scoreboard players operation ys stories260k = 31s x
function stories260k:add
scoreboard players operation 31b x = xb stories260k
scoreboard players operation 31e x = xe stories260k
scoreboard players operation 31s x = xs stories260k
scoreboard players operation xb stories260k = 32b tx2
scoreboard players operation xe stories260k = 32e tx2
scoreboard players operation xs stories260k = 32s tx2
scoreboard players operation yb stories260k = 32b x
scoreboard players operation ye stories260k = 32e x
scoreboard players operation ys stories260k = 32s x
function stories260k:add
scoreboard players operation 32b x = xb stories260k
scoreboard players operation 32e x = xe stories260k
scoreboard players operation 32s x = xs stories260k
scoreboard players operation xb stories260k = 33b tx2
scoreboard players operation xe stories260k = 33e tx2
scoreboard players operation xs stories260k = 33s tx2
scoreboard players operation yb stories260k = 33b x
scoreboard players operation ye stories260k = 33e x
scoreboard players operation ys stories260k = 33s x
function stories260k:add
scoreboard players operation 33b x = xb stories260k
scoreboard players operation 33e x = xe stories260k
scoreboard players operation 33s x = xs stories260k
scoreboard players operation xb stories260k = 34b tx2
scoreboard players operation xe stories260k = 34e tx2
scoreboard players operation xs stories260k = 34s tx2
scoreboard players operation yb stories260k = 34b x
scoreboard players operation ye stories260k = 34e x
scoreboard players operation ys stories260k = 34s x
function stories260k:add
scoreboard players operation 34b x = xb stories260k
scoreboard players operation 34e x = xe stories260k
scoreboard players operation 34s x = xs stories260k
scoreboard players operation xb stories260k = 35b tx2
scoreboard players operation xe stories260k = 35e tx2
scoreboard players operation xs stories260k = 35s tx2
scoreboard players operation yb stories260k = 35b x
scoreboard players operation ye stories260k = 35e x
scoreboard players operation ys stories260k = 35s x
function stories260k:add
scoreboard players operation 35b x = xb stories260k
scoreboard players operation 35e x = xe stories260k
scoreboard players operation 35s x = xs stories260k
scoreboard players operation xb stories260k = 36b tx2
scoreboard players operation xe stories260k = 36e tx2
scoreboard players operation xs stories260k = 36s tx2
scoreboard players operation yb stories260k = 36b x
scoreboard players operation ye stories260k = 36e x
scoreboard players operation ys stories260k = 36s x
function stories260k:add
scoreboard players operation 36b x = xb stories260k
scoreboard players operation 36e x = xe stories260k
scoreboard players operation 36s x = xs stories260k
scoreboard players operation xb stories260k = 37b tx2
scoreboard players operation xe stories260k = 37e tx2
scoreboard players operation xs stories260k = 37s tx2
scoreboard players operation yb stories260k = 37b x
scoreboard players operation ye stories260k = 37e x
scoreboard players operation ys stories260k = 37s x
function stories260k:add
scoreboard players operation 37b x = xb stories260k
scoreboard players operation 37e x = xe stories260k
scoreboard players operation 37s x = xs stories260k
scoreboard players operation xb stories260k = 38b tx2
scoreboard players operation xe stories260k = 38e tx2
scoreboard players operation xs stories260k = 38s tx2
scoreboard players operation yb stories260k = 38b x
scoreboard players operation ye stories260k = 38e x
scoreboard players operation ys stories260k = 38s x
function stories260k:add
scoreboard players operation 38b x = xb stories260k
scoreboard players operation 38e x = xe stories260k
scoreboard players operation 38s x = xs stories260k
scoreboard players operation xb stories260k = 39b tx2
scoreboard players operation xe stories260k = 39e tx2
scoreboard players operation xs stories260k = 39s tx2
scoreboard players operation yb stories260k = 39b x
scoreboard players operation ye stories260k = 39e x
scoreboard players operation ys stories260k = 39s x
function stories260k:add
scoreboard players operation 39b x = xb stories260k
scoreboard players operation 39e x = xe stories260k
scoreboard players operation 39s x = xs stories260k
scoreboard players operation xb stories260k = 40b tx2
scoreboard players operation xe stories260k = 40e tx2
scoreboard players operation xs stories260k = 40s tx2
scoreboard players operation yb stories260k = 40b x
scoreboard players operation ye stories260k = 40e x
scoreboard players operation ys stories260k = 40s x
function stories260k:add
scoreboard players operation 40b x = xb stories260k
scoreboard players operation 40e x = xe stories260k
scoreboard players operation 40s x = xs stories260k
scoreboard players operation xb stories260k = 41b tx2
scoreboard players operation xe stories260k = 41e tx2
scoreboard players operation xs stories260k = 41s tx2
scoreboard players operation yb stories260k = 41b x
scoreboard players operation ye stories260k = 41e x
scoreboard players operation ys stories260k = 41s x
function stories260k:add
scoreboard players operation 41b x = xb stories260k
scoreboard players operation 41e x = xe stories260k
scoreboard players operation 41s x = xs stories260k
scoreboard players operation xb stories260k = 42b tx2
scoreboard players operation xe stories260k = 42e tx2
scoreboard players operation xs stories260k = 42s tx2
scoreboard players operation yb stories260k = 42b x
scoreboard players operation ye stories260k = 42e x
scoreboard players operation ys stories260k = 42s x
function stories260k:add
scoreboard players operation 42b x = xb stories260k
scoreboard players operation 42e x = xe stories260k
scoreboard players operation 42s x = xs stories260k
scoreboard players operation xb stories260k = 43b tx2
scoreboard players operation xe stories260k = 43e tx2
scoreboard players operation xs stories260k = 43s tx2
scoreboard players operation yb stories260k = 43b x
scoreboard players operation ye stories260k = 43e x
scoreboard players operation ys stories260k = 43s x
function stories260k:add
scoreboard players operation 43b x = xb stories260k
scoreboard players operation 43e x = xe stories260k
scoreboard players operation 43s x = xs stories260k
scoreboard players operation xb stories260k = 44b tx2
scoreboard players operation xe stories260k = 44e tx2
scoreboard players operation xs stories260k = 44s tx2
scoreboard players operation yb stories260k = 44b x
scoreboard players operation ye stories260k = 44e x
scoreboard players operation ys stories260k = 44s x
function stories260k:add
scoreboard players operation 44b x = xb stories260k
scoreboard players operation 44e x = xe stories260k
scoreboard players operation 44s x = xs stories260k
scoreboard players operation xb stories260k = 45b tx2
scoreboard players operation xe stories260k = 45e tx2
scoreboard players operation xs stories260k = 45s tx2
scoreboard players operation yb stories260k = 45b x
scoreboard players operation ye stories260k = 45e x
scoreboard players operation ys stories260k = 45s x
function stories260k:add
scoreboard players operation 45b x = xb stories260k
scoreboard players operation 45e x = xe stories260k
scoreboard players operation 45s x = xs stories260k
scoreboard players operation xb stories260k = 46b tx2
scoreboard players operation xe stories260k = 46e tx2
scoreboard players operation xs stories260k = 46s tx2
scoreboard players operation yb stories260k = 46b x
scoreboard players operation ye stories260k = 46e x
scoreboard players operation ys stories260k = 46s x
function stories260k:add
scoreboard players operation 46b x = xb stories260k
scoreboard players operation 46e x = xe stories260k
scoreboard players operation 46s x = xs stories260k
scoreboard players operation xb stories260k = 47b tx2
scoreboard players operation xe stories260k = 47e tx2
scoreboard players operation xs stories260k = 47s tx2
scoreboard players operation yb stories260k = 47b x
scoreboard players operation ye stories260k = 47e x
scoreboard players operation ys stories260k = 47s x
function stories260k:add
scoreboard players operation 47b x = xb stories260k
scoreboard players operation 47e x = xe stories260k
scoreboard players operation 47s x = xs stories260k
scoreboard players operation xb stories260k = 48b tx2
scoreboard players operation xe stories260k = 48e tx2
scoreboard players operation xs stories260k = 48s tx2
scoreboard players operation yb stories260k = 48b x
scoreboard players operation ye stories260k = 48e x
scoreboard players operation ys stories260k = 48s x
function stories260k:add
scoreboard players operation 48b x = xb stories260k
scoreboard players operation 48e x = xe stories260k
scoreboard players operation 48s x = xs stories260k
scoreboard players operation xb stories260k = 49b tx2
scoreboard players operation xe stories260k = 49e tx2
scoreboard players operation xs stories260k = 49s tx2
scoreboard players operation yb stories260k = 49b x
scoreboard players operation ye stories260k = 49e x
scoreboard players operation ys stories260k = 49s x
function stories260k:add
scoreboard players operation 49b x = xb stories260k
scoreboard players operation 49e x = xe stories260k
scoreboard players operation 49s x = xs stories260k
scoreboard players operation xb stories260k = 50b tx2
scoreboard players operation xe stories260k = 50e tx2
scoreboard players operation xs stories260k = 50s tx2
scoreboard players operation yb stories260k = 50b x
scoreboard players operation ye stories260k = 50e x
scoreboard players operation ys stories260k = 50s x
function stories260k:add
scoreboard players operation 50b x = xb stories260k
scoreboard players operation 50e x = xe stories260k
scoreboard players operation 50s x = xs stories260k
scoreboard players operation xb stories260k = 51b tx2
scoreboard players operation xe stories260k = 51e tx2
scoreboard players operation xs stories260k = 51s tx2
scoreboard players operation yb stories260k = 51b x
scoreboard players operation ye stories260k = 51e x
scoreboard players operation ys stories260k = 51s x
function stories260k:add
scoreboard players operation 51b x = xb stories260k
scoreboard players operation 51e x = xe stories260k
scoreboard players operation 51s x = xs stories260k
scoreboard players operation xb stories260k = 52b tx2
scoreboard players operation xe stories260k = 52e tx2
scoreboard players operation xs stories260k = 52s tx2
scoreboard players operation yb stories260k = 52b x
scoreboard players operation ye stories260k = 52e x
scoreboard players operation ys stories260k = 52s x
function stories260k:add
scoreboard players operation 52b x = xb stories260k
scoreboard players operation 52e x = xe stories260k
scoreboard players operation 52s x = xs stories260k
scoreboard players operation xb stories260k = 53b tx2
scoreboard players operation xe stories260k = 53e tx2
scoreboard players operation xs stories260k = 53s tx2
scoreboard players operation yb stories260k = 53b x
scoreboard players operation ye stories260k = 53e x
scoreboard players operation ys stories260k = 53s x
function stories260k:add
scoreboard players operation 53b x = xb stories260k
scoreboard players operation 53e x = xe stories260k
scoreboard players operation 53s x = xs stories260k
scoreboard players operation xb stories260k = 54b tx2
scoreboard players operation xe stories260k = 54e tx2
scoreboard players operation xs stories260k = 54s tx2
scoreboard players operation yb stories260k = 54b x
scoreboard players operation ye stories260k = 54e x
scoreboard players operation ys stories260k = 54s x
function stories260k:add
scoreboard players operation 54b x = xb stories260k
scoreboard players operation 54e x = xe stories260k
scoreboard players operation 54s x = xs stories260k
scoreboard players operation xb stories260k = 55b tx2
scoreboard players operation xe stories260k = 55e tx2
scoreboard players operation xs stories260k = 55s tx2
scoreboard players operation yb stories260k = 55b x
scoreboard players operation ye stories260k = 55e x
scoreboard players operation ys stories260k = 55s x
function stories260k:add
scoreboard players operation 55b x = xb stories260k
scoreboard players operation 55e x = xe stories260k
scoreboard players operation 55s x = xs stories260k
scoreboard players operation xb stories260k = 56b tx2
scoreboard players operation xe stories260k = 56e tx2
scoreboard players operation xs stories260k = 56s tx2
scoreboard players operation yb stories260k = 56b x
scoreboard players operation ye stories260k = 56e x
scoreboard players operation ys stories260k = 56s x
function stories260k:add
scoreboard players operation 56b x = xb stories260k
scoreboard players operation 56e x = xe stories260k
scoreboard players operation 56s x = xs stories260k
scoreboard players operation xb stories260k = 57b tx2
scoreboard players operation xe stories260k = 57e tx2
scoreboard players operation xs stories260k = 57s tx2
scoreboard players operation yb stories260k = 57b x
scoreboard players operation ye stories260k = 57e x
scoreboard players operation ys stories260k = 57s x
function stories260k:add
scoreboard players operation 57b x = xb stories260k
scoreboard players operation 57e x = xe stories260k
scoreboard players operation 57s x = xs stories260k
scoreboard players operation xb stories260k = 58b tx2
scoreboard players operation xe stories260k = 58e tx2
scoreboard players operation xs stories260k = 58s tx2
scoreboard players operation yb stories260k = 58b x
scoreboard players operation ye stories260k = 58e x
scoreboard players operation ys stories260k = 58s x
function stories260k:add
scoreboard players operation 58b x = xb stories260k
scoreboard players operation 58e x = xe stories260k
scoreboard players operation 58s x = xs stories260k
scoreboard players operation xb stories260k = 59b tx2
scoreboard players operation xe stories260k = 59e tx2
scoreboard players operation xs stories260k = 59s tx2
scoreboard players operation yb stories260k = 59b x
scoreboard players operation ye stories260k = 59e x
scoreboard players operation ys stories260k = 59s x
function stories260k:add
scoreboard players operation 59b x = xb stories260k
scoreboard players operation 59e x = xe stories260k
scoreboard players operation 59s x = xs stories260k
scoreboard players operation xb stories260k = 60b tx2
scoreboard players operation xe stories260k = 60e tx2
scoreboard players operation xs stories260k = 60s tx2
scoreboard players operation yb stories260k = 60b x
scoreboard players operation ye stories260k = 60e x
scoreboard players operation ys stories260k = 60s x
function stories260k:add
scoreboard players operation 60b x = xb stories260k
scoreboard players operation 60e x = xe stories260k
scoreboard players operation 60s x = xs stories260k
scoreboard players operation xb stories260k = 61b tx2
scoreboard players operation xe stories260k = 61e tx2
scoreboard players operation xs stories260k = 61s tx2
scoreboard players operation yb stories260k = 61b x
scoreboard players operation ye stories260k = 61e x
scoreboard players operation ys stories260k = 61s x
function stories260k:add
scoreboard players operation 61b x = xb stories260k
scoreboard players operation 61e x = xe stories260k
scoreboard players operation 61s x = xs stories260k
scoreboard players operation xb stories260k = 62b tx2
scoreboard players operation xe stories260k = 62e tx2
scoreboard players operation xs stories260k = 62s tx2
scoreboard players operation yb stories260k = 62b x
scoreboard players operation ye stories260k = 62e x
scoreboard players operation ys stories260k = 62s x
function stories260k:add
scoreboard players operation 62b x = xb stories260k
scoreboard players operation 62e x = xe stories260k
scoreboard players operation 62s x = xs stories260k
scoreboard players operation xb stories260k = 63b tx2
scoreboard players operation xe stories260k = 63e tx2
scoreboard players operation xs stories260k = 63s tx2
scoreboard players operation yb stories260k = 63b x
scoreboard players operation ye stories260k = 63e x
scoreboard players operation ys stories260k = 63s x
function stories260k:add
scoreboard players operation 63b x = xb stories260k
scoreboard players operation 63e x = xe stories260k
scoreboard players operation 63s x = xs stories260k
function stories260k:rmsnorm_sum_squares
execute store result score 0b tx run data get storage stories260k params.ffn_w.192b
execute store result score 0e tx run data get storage stories260k params.ffn_w.192e
execute store result score 0s tx run data get storage stories260k params.ffn_w.192s
execute store result score 1b tx run data get storage stories260k params.ffn_w.193b
execute store result score 1e tx run data get storage stories260k params.ffn_w.193e
execute store result score 1s tx run data get storage stories260k params.ffn_w.193s
execute store result score 2b tx run data get storage stories260k params.ffn_w.194b
execute store result score 2e tx run data get storage stories260k params.ffn_w.194e
execute store result score 2s tx run data get storage stories260k params.ffn_w.194s
execute store result score 3b tx run data get storage stories260k params.ffn_w.195b
execute store result score 3e tx run data get storage stories260k params.ffn_w.195e
execute store result score 3s tx run data get storage stories260k params.ffn_w.195s
execute store result score 4b tx run data get storage stories260k params.ffn_w.196b
execute store result score 4e tx run data get storage stories260k params.ffn_w.196e
execute store result score 4s tx run data get storage stories260k params.ffn_w.196s
execute store result score 5b tx run data get storage stories260k params.ffn_w.197b
execute store result score 5e tx run data get storage stories260k params.ffn_w.197e
execute store result score 5s tx run data get storage stories260k params.ffn_w.197s
execute store result score 6b tx run data get storage stories260k params.ffn_w.198b
execute store result score 6e tx run data get storage stories260k params.ffn_w.198e
execute store result score 6s tx run data get storage stories260k params.ffn_w.198s
execute store result score 7b tx run data get storage stories260k params.ffn_w.199b
execute store result score 7e tx run data get storage stories260k params.ffn_w.199e
execute store result score 7s tx run data get storage stories260k params.ffn_w.199s
execute store result score 8b tx run data get storage stories260k params.ffn_w.200b
execute store result score 8e tx run data get storage stories260k params.ffn_w.200e
execute store result score 8s tx run data get storage stories260k params.ffn_w.200s
execute store result score 9b tx run data get storage stories260k params.ffn_w.201b
execute store result score 9e tx run data get storage stories260k params.ffn_w.201e
execute store result score 9s tx run data get storage stories260k params.ffn_w.201s
execute store result score 10b tx run data get storage stories260k params.ffn_w.202b
execute store result score 10e tx run data get storage stories260k params.ffn_w.202e
execute store result score 10s tx run data get storage stories260k params.ffn_w.202s
execute store result score 11b tx run data get storage stories260k params.ffn_w.203b
execute store result score 11e tx run data get storage stories260k params.ffn_w.203e
execute store result score 11s tx run data get storage stories260k params.ffn_w.203s
execute store result score 12b tx run data get storage stories260k params.ffn_w.204b
execute store result score 12e tx run data get storage stories260k params.ffn_w.204e
execute store result score 12s tx run data get storage stories260k params.ffn_w.204s
execute store result score 13b tx run data get storage stories260k params.ffn_w.205b
execute store result score 13e tx run data get storage stories260k params.ffn_w.205e
execute store result score 13s tx run data get storage stories260k params.ffn_w.205s
execute store result score 14b tx run data get storage stories260k params.ffn_w.206b
execute store result score 14e tx run data get storage stories260k params.ffn_w.206e
execute store result score 14s tx run data get storage stories260k params.ffn_w.206s
execute store result score 15b tx run data get storage stories260k params.ffn_w.207b
execute store result score 15e tx run data get storage stories260k params.ffn_w.207e
execute store result score 15s tx run data get storage stories260k params.ffn_w.207s
execute store result score 16b tx run data get storage stories260k params.ffn_w.208b
execute store result score 16e tx run data get storage stories260k params.ffn_w.208e
execute store result score 16s tx run data get storage stories260k params.ffn_w.208s
execute store result score 17b tx run data get storage stories260k params.ffn_w.209b
execute store result score 17e tx run data get storage stories260k params.ffn_w.209e
execute store result score 17s tx run data get storage stories260k params.ffn_w.209s
execute store result score 18b tx run data get storage stories260k params.ffn_w.210b
execute store result score 18e tx run data get storage stories260k params.ffn_w.210e
execute store result score 18s tx run data get storage stories260k params.ffn_w.210s
execute store result score 19b tx run data get storage stories260k params.ffn_w.211b
execute store result score 19e tx run data get storage stories260k params.ffn_w.211e
execute store result score 19s tx run data get storage stories260k params.ffn_w.211s
execute store result score 20b tx run data get storage stories260k params.ffn_w.212b
execute store result score 20e tx run data get storage stories260k params.ffn_w.212e
execute store result score 20s tx run data get storage stories260k params.ffn_w.212s
execute store result score 21b tx run data get storage stories260k params.ffn_w.213b
execute store result score 21e tx run data get storage stories260k params.ffn_w.213e
execute store result score 21s tx run data get storage stories260k params.ffn_w.213s
execute store result score 22b tx run data get storage stories260k params.ffn_w.214b
execute store result score 22e tx run data get storage stories260k params.ffn_w.214e
execute store result score 22s tx run data get storage stories260k params.ffn_w.214s
execute store result score 23b tx run data get storage stories260k params.ffn_w.215b
execute store result score 23e tx run data get storage stories260k params.ffn_w.215e
execute store result score 23s tx run data get storage stories260k params.ffn_w.215s
execute store result score 24b tx run data get storage stories260k params.ffn_w.216b
execute store result score 24e tx run data get storage stories260k params.ffn_w.216e
execute store result score 24s tx run data get storage stories260k params.ffn_w.216s
execute store result score 25b tx run data get storage stories260k params.ffn_w.217b
execute store result score 25e tx run data get storage stories260k params.ffn_w.217e
execute store result score 25s tx run data get storage stories260k params.ffn_w.217s
execute store result score 26b tx run data get storage stories260k params.ffn_w.218b
execute store result score 26e tx run data get storage stories260k params.ffn_w.218e
execute store result score 26s tx run data get storage stories260k params.ffn_w.218s
execute store result score 27b tx run data get storage stories260k params.ffn_w.219b
execute store result score 27e tx run data get storage stories260k params.ffn_w.219e
execute store result score 27s tx run data get storage stories260k params.ffn_w.219s
execute store result score 28b tx run data get storage stories260k params.ffn_w.220b
execute store result score 28e tx run data get storage stories260k params.ffn_w.220e
execute store result score 28s tx run data get storage stories260k params.ffn_w.220s
execute store result score 29b tx run data get storage stories260k params.ffn_w.221b
execute store result score 29e tx run data get storage stories260k params.ffn_w.221e
execute store result score 29s tx run data get storage stories260k params.ffn_w.221s
execute store result score 30b tx run data get storage stories260k params.ffn_w.222b
execute store result score 30e tx run data get storage stories260k params.ffn_w.222e
execute store result score 30s tx run data get storage stories260k params.ffn_w.222s
execute store result score 31b tx run data get storage stories260k params.ffn_w.223b
execute store result score 31e tx run data get storage stories260k params.ffn_w.223e
execute store result score 31s tx run data get storage stories260k params.ffn_w.223s
execute store result score 32b tx run data get storage stories260k params.ffn_w.224b
execute store result score 32e tx run data get storage stories260k params.ffn_w.224e
execute store result score 32s tx run data get storage stories260k params.ffn_w.224s
execute store result score 33b tx run data get storage stories260k params.ffn_w.225b
execute store result score 33e tx run data get storage stories260k params.ffn_w.225e
execute store result score 33s tx run data get storage stories260k params.ffn_w.225s
execute store result score 34b tx run data get storage stories260k params.ffn_w.226b
execute store result score 34e tx run data get storage stories260k params.ffn_w.226e
execute store result score 34s tx run data get storage stories260k params.ffn_w.226s
execute store result score 35b tx run data get storage stories260k params.ffn_w.227b
execute store result score 35e tx run data get storage stories260k params.ffn_w.227e
execute store result score 35s tx run data get storage stories260k params.ffn_w.227s
execute store result score 36b tx run data get storage stories260k params.ffn_w.228b
execute store result score 36e tx run data get storage stories260k params.ffn_w.228e
execute store result score 36s tx run data get storage stories260k params.ffn_w.228s
execute store result score 37b tx run data get storage stories260k params.ffn_w.229b
execute store result score 37e tx run data get storage stories260k params.ffn_w.229e
execute store result score 37s tx run data get storage stories260k params.ffn_w.229s
execute store result score 38b tx run data get storage stories260k params.ffn_w.230b
execute store result score 38e tx run data get storage stories260k params.ffn_w.230e
execute store result score 38s tx run data get storage stories260k params.ffn_w.230s
execute store result score 39b tx run data get storage stories260k params.ffn_w.231b
execute store result score 39e tx run data get storage stories260k params.ffn_w.231e
execute store result score 39s tx run data get storage stories260k params.ffn_w.231s
execute store result score 40b tx run data get storage stories260k params.ffn_w.232b
execute store result score 40e tx run data get storage stories260k params.ffn_w.232e
execute store result score 40s tx run data get storage stories260k params.ffn_w.232s
execute store result score 41b tx run data get storage stories260k params.ffn_w.233b
execute store result score 41e tx run data get storage stories260k params.ffn_w.233e
execute store result score 41s tx run data get storage stories260k params.ffn_w.233s
execute store result score 42b tx run data get storage stories260k params.ffn_w.234b
execute store result score 42e tx run data get storage stories260k params.ffn_w.234e
execute store result score 42s tx run data get storage stories260k params.ffn_w.234s
execute store result score 43b tx run data get storage stories260k params.ffn_w.235b
execute store result score 43e tx run data get storage stories260k params.ffn_w.235e
execute store result score 43s tx run data get storage stories260k params.ffn_w.235s
execute store result score 44b tx run data get storage stories260k params.ffn_w.236b
execute store result score 44e tx run data get storage stories260k params.ffn_w.236e
execute store result score 44s tx run data get storage stories260k params.ffn_w.236s
execute store result score 45b tx run data get storage stories260k params.ffn_w.237b
execute store result score 45e tx run data get storage stories260k params.ffn_w.237e
execute store result score 45s tx run data get storage stories260k params.ffn_w.237s
execute store result score 46b tx run data get storage stories260k params.ffn_w.238b
execute store result score 46e tx run data get storage stories260k params.ffn_w.238e
execute store result score 46s tx run data get storage stories260k params.ffn_w.238s
execute store result score 47b tx run data get storage stories260k params.ffn_w.239b
execute store result score 47e tx run data get storage stories260k params.ffn_w.239e
execute store result score 47s tx run data get storage stories260k params.ffn_w.239s
execute store result score 48b tx run data get storage stories260k params.ffn_w.240b
execute store result score 48e tx run data get storage stories260k params.ffn_w.240e
execute store result score 48s tx run data get storage stories260k params.ffn_w.240s
execute store result score 49b tx run data get storage stories260k params.ffn_w.241b
execute store result score 49e tx run data get storage stories260k params.ffn_w.241e
execute store result score 49s tx run data get storage stories260k params.ffn_w.241s
execute store result score 50b tx run data get storage stories260k params.ffn_w.242b
execute store result score 50e tx run data get storage stories260k params.ffn_w.242e
execute store result score 50s tx run data get storage stories260k params.ffn_w.242s
execute store result score 51b tx run data get storage stories260k params.ffn_w.243b
execute store result score 51e tx run data get storage stories260k params.ffn_w.243e
execute store result score 51s tx run data get storage stories260k params.ffn_w.243s
execute store result score 52b tx run data get storage stories260k params.ffn_w.244b
execute store result score 52e tx run data get storage stories260k params.ffn_w.244e
execute store result score 52s tx run data get storage stories260k params.ffn_w.244s
execute store result score 53b tx run data get storage stories260k params.ffn_w.245b
execute store result score 53e tx run data get storage stories260k params.ffn_w.245e
execute store result score 53s tx run data get storage stories260k params.ffn_w.245s
execute store result score 54b tx run data get storage stories260k params.ffn_w.246b
execute store result score 54e tx run data get storage stories260k params.ffn_w.246e
execute store result score 54s tx run data get storage stories260k params.ffn_w.246s
execute store result score 55b tx run data get storage stories260k params.ffn_w.247b
execute store result score 55e tx run data get storage stories260k params.ffn_w.247e
execute store result score 55s tx run data get storage stories260k params.ffn_w.247s
execute store result score 56b tx run data get storage stories260k params.ffn_w.248b
execute store result score 56e tx run data get storage stories260k params.ffn_w.248e
execute store result score 56s tx run data get storage stories260k params.ffn_w.248s
execute store result score 57b tx run data get storage stories260k params.ffn_w.249b
execute store result score 57e tx run data get storage stories260k params.ffn_w.249e
execute store result score 57s tx run data get storage stories260k params.ffn_w.249s
execute store result score 58b tx run data get storage stories260k params.ffn_w.250b
execute store result score 58e tx run data get storage stories260k params.ffn_w.250e
execute store result score 58s tx run data get storage stories260k params.ffn_w.250s
execute store result score 59b tx run data get storage stories260k params.ffn_w.251b
execute store result score 59e tx run data get storage stories260k params.ffn_w.251e
execute store result score 59s tx run data get storage stories260k params.ffn_w.251s
execute store result score 60b tx run data get storage stories260k params.ffn_w.252b
execute store result score 60e tx run data get storage stories260k params.ffn_w.252e
execute store result score 60s tx run data get storage stories260k params.ffn_w.252s
execute store result score 61b tx run data get storage stories260k params.ffn_w.253b
execute store result score 61e tx run data get storage stories260k params.ffn_w.253e
execute store result score 61s tx run data get storage stories260k params.ffn_w.253s
execute store result score 62b tx run data get storage stories260k params.ffn_w.254b
execute store result score 62e tx run data get storage stories260k params.ffn_w.254e
execute store result score 62s tx run data get storage stories260k params.ffn_w.254s
execute store result score 63b tx run data get storage stories260k params.ffn_w.255b
execute store result score 63e tx run data get storage stories260k params.ffn_w.255e
execute store result score 63s tx run data get storage stories260k params.ffn_w.255s
function stories260k:rmsnorm_apply
data modify storage stories260k args.in set value "tx"
data modify storage stories260k args.out set value "th"
data modify storage stories260k args.m set value "w1_3"
scoreboard players set s1 stories260k 172
scoreboard players set s2 stories260k 64
function stories260k:matmul
bossbar set progress value 30
schedule function stories260k:forward_hidden_29 1t
