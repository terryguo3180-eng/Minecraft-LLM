scoreboard players add r stories260k 1
scoreboard players operation r stories260k *= -1 stories260k
function stories260k:float_31
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
execute if score xs stories260k matches 0 run scoreboard players set xs stories260k -1
