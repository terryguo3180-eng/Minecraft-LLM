execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation yb stories260k = maxb stories260k
scoreboard players operation ye stories260k = maxe stories260k
scoreboard players operation ys stories260k = maxs stories260k
function stories260k:cmp
execute if score r stories260k matches 1 run scoreboard players operation maxb stories260k = xb stories260k
execute if score r stories260k matches 1 run scoreboard players operation maxe stories260k = xe stories260k
execute if score r stories260k matches 1 run scoreboard players operation maxs stories260k = xs stories260k
scoreboard players add i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l4_h4_find_max
