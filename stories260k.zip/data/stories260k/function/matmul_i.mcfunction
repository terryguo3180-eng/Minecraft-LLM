$scoreboard players set $(i)b $(out) 0
$scoreboard players set $(i)e $(out) 0
$scoreboard players set $(i)s $(out) 0
scoreboard players set j stories260k 0
data modify storage stories260k args.j set value 0
function stories260k:matmul_j with storage stories260k args
scoreboard players add i stories260k 1
execute if score i stories260k = s1 stories260k run return 1
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:matmul_i with storage stories260k args
