scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 65560
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 48b tx
scoreboard players operation ye stories260k = 48e tx
scoreboard players operation ys stories260k = 48s tx
function stories260k:add
scoreboard players operation 48b tx = xb stories260k
scoreboard players operation 48e tx = xe stories260k
scoreboard players operation 48s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 49b tx
scoreboard players operation ye stories260k = 49e tx
scoreboard players operation ys stories260k = 49s tx
function stories260k:add
scoreboard players operation 49b tx = xb stories260k
scoreboard players operation 49e tx = xe stories260k
scoreboard players operation 49s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 50b tx
scoreboard players operation ye stories260k = 50e tx
scoreboard players operation ys stories260k = 50s tx
function stories260k:add
scoreboard players operation 50b tx = xb stories260k
scoreboard players operation 50e tx = xe stories260k
scoreboard players operation 50s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 51b tx
scoreboard players operation ye stories260k = 51e tx
scoreboard players operation ys stories260k = 51s tx
function stories260k:add
scoreboard players operation 51b tx = xb stories260k
scoreboard players operation 51e tx = xe stories260k
scoreboard players operation 51s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 52b tx
scoreboard players operation ye stories260k = 52e tx
scoreboard players operation ys stories260k = 52s tx
function stories260k:add
scoreboard players operation 52b tx = xb stories260k
scoreboard players operation 52e tx = xe stories260k
scoreboard players operation 52s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 53b tx
scoreboard players operation ye stories260k = 53e tx
scoreboard players operation ys stories260k = 53s tx
function stories260k:add
scoreboard players operation 53b tx = xb stories260k
scoreboard players operation 53e tx = xe stories260k
scoreboard players operation 53s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 54b tx
scoreboard players operation ye stories260k = 54e tx
scoreboard players operation ys stories260k = 54s tx
function stories260k:add
scoreboard players operation 54b tx = xb stories260k
scoreboard players operation 54e tx = xe stories260k
scoreboard players operation 54s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 55b tx
scoreboard players operation ye stories260k = 55e tx
scoreboard players operation ys stories260k = 55s tx
function stories260k:add
scoreboard players operation 55b tx = xb stories260k
scoreboard players operation 55e tx = xe stories260k
scoreboard players operation 55s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l2_h6_weighted_sum_vals
