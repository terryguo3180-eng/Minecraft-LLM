execute store result score tok stories260k run data get storage stories260k args.prompt_tokens[0]
data remove storage stories260k args.prompt_tokens[0]
bossbar set progress players
function stories260k:token_to_string
data modify storage stories260k args.output append from storage stories260k args.tok
tellraw @a ["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",{"storage":"stories260k","nbt":"args.output[]","separator":""}]
scoreboard players add pos stories260k 1
execute if score pos stories260k = steps stories260k run return 1
function stories260k:autoregressive
