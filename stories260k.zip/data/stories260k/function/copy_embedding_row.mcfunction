$execute store result score $(i)b x run data get storage stories260k params.emb.$(j)b
$execute store result score $(i)e x run data get storage stories260k params.emb.$(j)e
$execute store result score $(i)s x run data get storage stories260k params.emb.$(j)s
execute if score i stories260k matches 64 run return 0
execute store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
execute store result storage stories260k args.j int 1 run scoreboard players add j stories260k 1
function stories260k:copy_embedding_row with storage stories260k args
