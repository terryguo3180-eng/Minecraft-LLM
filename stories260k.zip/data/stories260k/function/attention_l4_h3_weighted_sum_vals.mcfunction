scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 131080
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 24b tx
scoreboard players operation ye stories260k = 24e tx
scoreboard players operation ys stories260k = 24s tx
function stories260k:add
scoreboard players operation 24b tx = xb stories260k
scoreboard players operation 24e tx = xe stories260k
scoreboard players operation 24s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 25b tx
scoreboard players operation ye stories260k = 25e tx
scoreboard players operation ys stories260k = 25s tx
function stories260k:add
scoreboard players operation 25b tx = xb stories260k
scoreboard players operation 25e tx = xe stories260k
scoreboard players operation 25s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 26b tx
scoreboard players operation ye stories260k = 26e tx
scoreboard players operation ys stories260k = 26s tx
function stories260k:add
scoreboard players operation 26b tx = xb stories260k
scoreboard players operation 26e tx = xe stories260k
scoreboard players operation 26s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 27b tx
scoreboard players operation ye stories260k = 27e tx
scoreboard players operation ys stories260k = 27s tx
function stories260k:add
scoreboard players operation 27b tx = xb stories260k
scoreboard players operation 27e tx = xe stories260k
scoreboard players operation 27s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 28b tx
scoreboard players operation ye stories260k = 28e tx
scoreboard players operation ys stories260k = 28s tx
function stories260k:add
scoreboard players operation 28b tx = xb stories260k
scoreboard players operation 28e tx = xe stories260k
scoreboard players operation 28s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 29b tx
scoreboard players operation ye stories260k = 29e tx
scoreboard players operation ys stories260k = 29s tx
function stories260k:add
scoreboard players operation 29b tx = xb stories260k
scoreboard players operation 29e tx = xe stories260k
scoreboard players operation 29s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 30b tx
scoreboard players operation ye stories260k = 30e tx
scoreboard players operation ys stories260k = 30s tx
function stories260k:add
scoreboard players operation 30b tx = xb stories260k
scoreboard players operation 30e tx = xe stories260k
scoreboard players operation 30s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 31b tx
scoreboard players operation ye stories260k = 31e tx
scoreboard players operation ys stories260k = 31s tx
function stories260k:add
scoreboard players operation 31b tx = xb stories260k
scoreboard players operation 31e tx = xe stories260k
scoreboard players operation 31s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l4_h3_weighted_sum_vals
