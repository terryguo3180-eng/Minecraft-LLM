data modify storage stories260k args.in set value "tx"
data modify storage stories260k args.out set value "th2"
data modify storage stories260k args.m set value "w3_1"
scoreboard players set s1 stories260k 172
scoreboard players set s2 stories260k 64
function stories260k:matmul
bossbar set progress value 15
schedule function stories260k:forward_hidden_14 1t
