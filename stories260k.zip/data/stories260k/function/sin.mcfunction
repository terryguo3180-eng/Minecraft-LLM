data modify storage stories260k args.s set value ""
execute if score xs stories260k matches -1 run data modify storage stories260k args.s set value "-"
execute store result storage stories260k args.e int 1 run scoreboard players remove xe stories260k 7
execute store result storage stories260k args.b int 1 run scoreboard players get xb stories260k
execute summon marker run function stories260k:float_20 with storage stories260k args
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
execute if score xb stories260k matches ..-1 run function stories260k:float_21
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
