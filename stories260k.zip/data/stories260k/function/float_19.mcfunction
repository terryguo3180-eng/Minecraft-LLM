scoreboard players remove t0 stories260k 1
scoreboard players operation t1 stories260k = t0 stories260k
scoreboard players operation t1 stories260k *= t0 stories260k
