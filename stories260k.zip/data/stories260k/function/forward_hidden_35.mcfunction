data modify storage stories260k args.in set value "tx"
data modify storage stories260k args.out set value "tx2"
data modify storage stories260k args.m set value "wo_4"
execute store result score s1 stories260k run scoreboard players set s2 stories260k 64
function stories260k:matmul
bossbar set progress value 37
schedule function stories260k:forward_hidden_36 1t
