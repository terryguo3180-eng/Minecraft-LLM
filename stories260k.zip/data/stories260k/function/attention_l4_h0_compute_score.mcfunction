scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 131072
scoreboard players set scoreb stories260k 0
scoreboard players set scoree stories260k 0
scoreboard players set scores stories260k 0
scoreboard players operation yb stories260k = 0b q
scoreboard players operation ye stories260k = 0e q
scoreboard players operation ys stories260k = 0s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 1b q
scoreboard players operation ye stories260k = 1e q
scoreboard players operation ys stories260k = 1s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 2b q
scoreboard players operation ye stories260k = 2e q
scoreboard players operation ys stories260k = 2s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 3b q
scoreboard players operation ye stories260k = 3e q
scoreboard players operation ys stories260k = 3s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 4b q
scoreboard players operation ye stories260k = 4e q
scoreboard players operation ys stories260k = 4s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 5b q
scoreboard players operation ye stories260k = 5e q
scoreboard players operation ys stories260k = 5s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 6b q
scoreboard players operation ye stories260k = 6e q
scoreboard players operation ys stories260k = 6s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 7b q
scoreboard players operation ye stories260k = 7e q
scoreboard players operation ys stories260k = 7s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation xb stories260k = scoreb stories260k
scoreboard players operation xe stories260k = scoree stories260k
scoreboard players operation xs stories260k = scores stories260k
scoreboard players set yb stories260k 28284271
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:div
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:set_av with storage stories260k args
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l4_h0_compute_score
