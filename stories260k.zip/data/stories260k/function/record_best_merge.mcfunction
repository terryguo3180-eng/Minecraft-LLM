function stories260k:lookup_token_score
execute if score bs stories260k >= score stories260k run return 0
scoreboard players operation bs stories260k = score stories260k
scoreboard players operation bt stories260k = tok stories260k
scoreboard players operation bi stories260k = i stories260k
