$scoreboard players operation xb stories260k = $(i)b vc
$scoreboard players operation xe stories260k = $(i)e vc
$scoreboard players operation xs stories260k = $(i)s vc
