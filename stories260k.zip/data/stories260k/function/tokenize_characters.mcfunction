$data modify storage stories260k args.c set string storage stories260k args.prompt $(i) $(j)
function stories260k:string_to_token
execute if score tok stories260k matches -1 run return run tellraw @a [{"text":"Not a good prompt at position ","color":"red"},{"score":{"name":"i","objective":"stories260k"}}]
data modify storage stories260k args.prompt_tokens append value 0
execute store result storage stories260k args.prompt_tokens[-1] int 1 run scoreboard players get tok stories260k
execute store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
execute store result storage stories260k args.j int 1 run scoreboard players add j stories260k 1
execute if score i stories260k < len stories260k run function stories260k:tokenize_characters with storage stories260k args
