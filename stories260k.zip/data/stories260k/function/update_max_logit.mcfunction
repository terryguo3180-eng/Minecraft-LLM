scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
