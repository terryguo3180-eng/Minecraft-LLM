execute store result score tok stories260k run data get storage stories260k args.prompt_tokens[0]
data remove storage stories260k args.prompt_tokens[0]
bossbar set progress max 40
bossbar set progress value 0
bossbar set progress name [{"text":"Processing prompt token #","color":"gold","bold":true},{"score":{"name":"pos","objective":"stories260k"}}]
bossbar set progress players @a
function stories260k:forward_hidden
schedule function stories260k:chat_process_input_0 41t
