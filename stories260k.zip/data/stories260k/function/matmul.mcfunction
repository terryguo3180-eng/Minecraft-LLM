scoreboard players set i stories260k 0
data modify storage stories260k args.i set value 0
scoreboard players set idx stories260k 0
data modify storage stories260k args.idx set value 0
function stories260k:matmul_i with storage stories260k args
