$scoreboard players operation xb stories260k = $(i)b av
$scoreboard players operation xe stories260k = $(i)e av
$scoreboard players operation xs stories260k = $(i)s av
