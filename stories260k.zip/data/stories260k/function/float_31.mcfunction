execute if score xe stories260k matches 7.. run return run scoreboard players add xb stories260k 1
execute if score xe stories260k matches 6 run return run scoreboard players add xb stories260k 10
execute if score xe stories260k matches 5 run return run scoreboard players add xb stories260k 100
execute if score xe stories260k matches 4 run return run scoreboard players add xb stories260k 1000
execute if score xe stories260k matches 3 run return run scoreboard players add xb stories260k 10000
execute if score xe stories260k matches 2 run return run scoreboard players add xb stories260k 100000
execute if score xe stories260k matches 1 run return run scoreboard players add xb stories260k 1000000
execute if score xe stories260k matches 0 run return run scoreboard players add xb stories260k 10000000
