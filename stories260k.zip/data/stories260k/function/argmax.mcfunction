scoreboard players set yb stories260k 99999999
scoreboard players set ye stories260k 99999999
scoreboard players set ys stories260k -1
bossbar set progress max 6
bossbar set progress value 0
bossbar set progress name [{"text":"Sampling","color":"gray","bold":true}]
bossbar set progress players @a
scoreboard players set i stories260k 0
function stories260k:argmax_scan {i:0}
