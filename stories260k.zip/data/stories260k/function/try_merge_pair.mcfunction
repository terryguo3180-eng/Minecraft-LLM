$data modify storage stories260k args.c set value "$(tok0)$(tok1)"
function stories260k:string_to_token with storage stories260k args
execute unless score tok stories260k matches -1 run function stories260k:record_best_merge
execute store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
execute store result storage stories260k args.j int 1 run scoreboard players add j stories260k 1
function stories260k:fetch_token_pair with storage stories260k args
execute if score i stories260k < len stories260k run function stories260k:try_merge_pair with storage stories260k args
