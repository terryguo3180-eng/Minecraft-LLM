scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 16
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 32b tx
scoreboard players operation ye stories260k = 32e tx
scoreboard players operation ys stories260k = 32s tx
function stories260k:add
scoreboard players operation 32b tx = xb stories260k
scoreboard players operation 32e tx = xe stories260k
scoreboard players operation 32s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 33b tx
scoreboard players operation ye stories260k = 33e tx
scoreboard players operation ys stories260k = 33s tx
function stories260k:add
scoreboard players operation 33b tx = xb stories260k
scoreboard players operation 33e tx = xe stories260k
scoreboard players operation 33s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 34b tx
scoreboard players operation ye stories260k = 34e tx
scoreboard players operation ys stories260k = 34s tx
function stories260k:add
scoreboard players operation 34b tx = xb stories260k
scoreboard players operation 34e tx = xe stories260k
scoreboard players operation 34s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 35b tx
scoreboard players operation ye stories260k = 35e tx
scoreboard players operation ys stories260k = 35s tx
function stories260k:add
scoreboard players operation 35b tx = xb stories260k
scoreboard players operation 35e tx = xe stories260k
scoreboard players operation 35s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 36b tx
scoreboard players operation ye stories260k = 36e tx
scoreboard players operation ys stories260k = 36s tx
function stories260k:add
scoreboard players operation 36b tx = xb stories260k
scoreboard players operation 36e tx = xe stories260k
scoreboard players operation 36s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 37b tx
scoreboard players operation ye stories260k = 37e tx
scoreboard players operation ys stories260k = 37s tx
function stories260k:add
scoreboard players operation 37b tx = xb stories260k
scoreboard players operation 37e tx = xe stories260k
scoreboard players operation 37s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 38b tx
scoreboard players operation ye stories260k = 38e tx
scoreboard players operation ys stories260k = 38s tx
function stories260k:add
scoreboard players operation 38b tx = xb stories260k
scoreboard players operation 38e tx = xe stories260k
scoreboard players operation 38s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 39b tx
scoreboard players operation ye stories260k = 39e tx
scoreboard players operation ys stories260k = 39s tx
function stories260k:add
scoreboard players operation 39b tx = xb stories260k
scoreboard players operation 39e tx = xe stories260k
scoreboard players operation 39s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l0_h4_weighted_sum_vals
