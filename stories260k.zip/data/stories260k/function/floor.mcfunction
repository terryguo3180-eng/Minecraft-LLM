execute if score xe stories260k matches 7.. run return run scoreboard players operation r stories260k = xb stories260k
execute if score xe stories260k matches 6 run return run function stories260k:float_23
execute if score xe stories260k matches 5 run return run function stories260k:float_24
execute if score xe stories260k matches 4 run return run function stories260k:float_25
execute if score xe stories260k matches 3 run return run function stories260k:float_26
execute if score xe stories260k matches 2 run return run function stories260k:float_27
execute if score xe stories260k matches 1 run return run function stories260k:float_28
execute if score xe stories260k matches 0 run return run function stories260k:float_29
scoreboard players set xb stories260k 0
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 0
scoreboard players set r stories260k 0
