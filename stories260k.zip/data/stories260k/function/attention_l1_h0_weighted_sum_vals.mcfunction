scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 32768
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 0b tx
scoreboard players operation ye stories260k = 0e tx
scoreboard players operation ys stories260k = 0s tx
function stories260k:add
scoreboard players operation 0b tx = xb stories260k
scoreboard players operation 0e tx = xe stories260k
scoreboard players operation 0s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 1b tx
scoreboard players operation ye stories260k = 1e tx
scoreboard players operation ys stories260k = 1s tx
function stories260k:add
scoreboard players operation 1b tx = xb stories260k
scoreboard players operation 1e tx = xe stories260k
scoreboard players operation 1s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 2b tx
scoreboard players operation ye stories260k = 2e tx
scoreboard players operation ys stories260k = 2s tx
function stories260k:add
scoreboard players operation 2b tx = xb stories260k
scoreboard players operation 2e tx = xe stories260k
scoreboard players operation 2s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 3b tx
scoreboard players operation ye stories260k = 3e tx
scoreboard players operation ys stories260k = 3s tx
function stories260k:add
scoreboard players operation 3b tx = xb stories260k
scoreboard players operation 3e tx = xe stories260k
scoreboard players operation 3s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 4b tx
scoreboard players operation ye stories260k = 4e tx
scoreboard players operation ys stories260k = 4s tx
function stories260k:add
scoreboard players operation 4b tx = xb stories260k
scoreboard players operation 4e tx = xe stories260k
scoreboard players operation 4s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 5b tx
scoreboard players operation ye stories260k = 5e tx
scoreboard players operation ys stories260k = 5s tx
function stories260k:add
scoreboard players operation 5b tx = xb stories260k
scoreboard players operation 5e tx = xe stories260k
scoreboard players operation 5s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 6b tx
scoreboard players operation ye stories260k = 6e tx
scoreboard players operation ys stories260k = 6s tx
function stories260k:add
scoreboard players operation 6b tx = xb stories260k
scoreboard players operation 6e tx = xe stories260k
scoreboard players operation 6s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 7b tx
scoreboard players operation ye stories260k = 7e tx
scoreboard players operation ys stories260k = 7s tx
function stories260k:add
scoreboard players operation 7b tx = xb stories260k
scoreboard players operation 7e tx = xe stories260k
scoreboard players operation 7s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h0_weighted_sum_vals
