scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 131080
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 16b tx
scoreboard players operation ye stories260k = 16e tx
scoreboard players operation ys stories260k = 16s tx
function stories260k:add
scoreboard players operation 16b tx = xb stories260k
scoreboard players operation 16e tx = xe stories260k
scoreboard players operation 16s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 17b tx
scoreboard players operation ye stories260k = 17e tx
scoreboard players operation ys stories260k = 17s tx
function stories260k:add
scoreboard players operation 17b tx = xb stories260k
scoreboard players operation 17e tx = xe stories260k
scoreboard players operation 17s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 18b tx
scoreboard players operation ye stories260k = 18e tx
scoreboard players operation ys stories260k = 18s tx
function stories260k:add
scoreboard players operation 18b tx = xb stories260k
scoreboard players operation 18e tx = xe stories260k
scoreboard players operation 18s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 19b tx
scoreboard players operation ye stories260k = 19e tx
scoreboard players operation ys stories260k = 19s tx
function stories260k:add
scoreboard players operation 19b tx = xb stories260k
scoreboard players operation 19e tx = xe stories260k
scoreboard players operation 19s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 20b tx
scoreboard players operation ye stories260k = 20e tx
scoreboard players operation ys stories260k = 20s tx
function stories260k:add
scoreboard players operation 20b tx = xb stories260k
scoreboard players operation 20e tx = xe stories260k
scoreboard players operation 20s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 21b tx
scoreboard players operation ye stories260k = 21e tx
scoreboard players operation ys stories260k = 21s tx
function stories260k:add
scoreboard players operation 21b tx = xb stories260k
scoreboard players operation 21e tx = xe stories260k
scoreboard players operation 21s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 22b tx
scoreboard players operation ye stories260k = 22e tx
scoreboard players operation ys stories260k = 22s tx
function stories260k:add
scoreboard players operation 22b tx = xb stories260k
scoreboard players operation 22e tx = xe stories260k
scoreboard players operation 22s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 23b tx
scoreboard players operation ye stories260k = 23e tx
scoreboard players operation ys stories260k = 23s tx
function stories260k:add
scoreboard players operation 23b tx = xb stories260k
scoreboard players operation 23e tx = xe stories260k
scoreboard players operation 23s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l4_h2_weighted_sum_vals
