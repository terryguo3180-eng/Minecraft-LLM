execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:matmul_logits_i with storage stories260k args
