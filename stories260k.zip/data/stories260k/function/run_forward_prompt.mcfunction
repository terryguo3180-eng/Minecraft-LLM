bossbar set progress max 40
bossbar set progress value 0
bossbar set progress name [{"text":"Processing prompt token #","color":"gold","bold":true},{"score":{"name":"pos","objective":"stories260k"}}]
bossbar set progress players @a
function stories260k:forward_hidden
