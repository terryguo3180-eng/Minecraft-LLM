scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 0b q
scoreboard players operation t0e stories260k = 0e q
scoreboard players operation t0s stories260k = 0s q
scoreboard players operation xb stories260k = 0b q
scoreboard players operation xe stories260k = 0e q
scoreboard players operation xs stories260k = 0s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 1b q
scoreboard players operation xe stories260k = 1e q
scoreboard players operation xs stories260k = 1s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 0b q = xb stories260k
scoreboard players operation 0e q = xe stories260k
scoreboard players operation 0s q = xs stories260k
scoreboard players operation xb stories260k = 1b q
scoreboard players operation xe stories260k = 1e q
scoreboard players operation xs stories260k = 1s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 1b q = xb stories260k
scoreboard players operation 1e q = xe stories260k
scoreboard players operation 1s q = xs stories260k
scoreboard players operation t0b stories260k = 0b k
scoreboard players operation t0e stories260k = 0e k
scoreboard players operation t0s stories260k = 0s k
scoreboard players operation xb stories260k = 0b k
scoreboard players operation xe stories260k = 0e k
scoreboard players operation xs stories260k = 0s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 1b k
scoreboard players operation xe stories260k = 1e k
scoreboard players operation xs stories260k = 1s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 0b k = xb stories260k
scoreboard players operation 0e k = xe stories260k
scoreboard players operation 0s k = xs stories260k
scoreboard players operation xb stories260k = 1b k
scoreboard players operation xe stories260k = 1e k
scoreboard players operation xs stories260k = 1s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 1b k = xb stories260k
scoreboard players operation 1e k = xe stories260k
scoreboard players operation 1s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 2b q
scoreboard players operation t0e stories260k = 2e q
scoreboard players operation t0s stories260k = 2s q
scoreboard players operation xb stories260k = 2b q
scoreboard players operation xe stories260k = 2e q
scoreboard players operation xs stories260k = 2s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 3b q
scoreboard players operation xe stories260k = 3e q
scoreboard players operation xs stories260k = 3s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 2b q = xb stories260k
scoreboard players operation 2e q = xe stories260k
scoreboard players operation 2s q = xs stories260k
scoreboard players operation xb stories260k = 3b q
scoreboard players operation xe stories260k = 3e q
scoreboard players operation xs stories260k = 3s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 3b q = xb stories260k
scoreboard players operation 3e q = xe stories260k
scoreboard players operation 3s q = xs stories260k
scoreboard players operation t0b stories260k = 2b k
scoreboard players operation t0e stories260k = 2e k
scoreboard players operation t0s stories260k = 2s k
scoreboard players operation xb stories260k = 2b k
scoreboard players operation xe stories260k = 2e k
scoreboard players operation xs stories260k = 2s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 3b k
scoreboard players operation xe stories260k = 3e k
scoreboard players operation xs stories260k = 3s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 2b k = xb stories260k
scoreboard players operation 2e k = xe stories260k
scoreboard players operation 2s k = xs stories260k
scoreboard players operation xb stories260k = 3b k
scoreboard players operation xe stories260k = 3e k
scoreboard players operation xs stories260k = 3s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 3b k = xb stories260k
scoreboard players operation 3e k = xe stories260k
scoreboard players operation 3s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 4b q
scoreboard players operation t0e stories260k = 4e q
scoreboard players operation t0s stories260k = 4s q
scoreboard players operation xb stories260k = 4b q
scoreboard players operation xe stories260k = 4e q
scoreboard players operation xs stories260k = 4s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 5b q
scoreboard players operation xe stories260k = 5e q
scoreboard players operation xs stories260k = 5s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 4b q = xb stories260k
scoreboard players operation 4e q = xe stories260k
scoreboard players operation 4s q = xs stories260k
scoreboard players operation xb stories260k = 5b q
scoreboard players operation xe stories260k = 5e q
scoreboard players operation xs stories260k = 5s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 5b q = xb stories260k
scoreboard players operation 5e q = xe stories260k
scoreboard players operation 5s q = xs stories260k
scoreboard players operation t0b stories260k = 4b k
scoreboard players operation t0e stories260k = 4e k
scoreboard players operation t0s stories260k = 4s k
scoreboard players operation xb stories260k = 4b k
scoreboard players operation xe stories260k = 4e k
scoreboard players operation xs stories260k = 4s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 5b k
scoreboard players operation xe stories260k = 5e k
scoreboard players operation xs stories260k = 5s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 4b k = xb stories260k
scoreboard players operation 4e k = xe stories260k
scoreboard players operation 4s k = xs stories260k
scoreboard players operation xb stories260k = 5b k
scoreboard players operation xe stories260k = 5e k
scoreboard players operation xs stories260k = 5s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 5b k = xb stories260k
scoreboard players operation 5e k = xe stories260k
scoreboard players operation 5s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 6b q
scoreboard players operation t0e stories260k = 6e q
scoreboard players operation t0s stories260k = 6s q
scoreboard players operation xb stories260k = 6b q
scoreboard players operation xe stories260k = 6e q
scoreboard players operation xs stories260k = 6s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 7b q
scoreboard players operation xe stories260k = 7e q
scoreboard players operation xs stories260k = 7s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 6b q = xb stories260k
scoreboard players operation 6e q = xe stories260k
scoreboard players operation 6s q = xs stories260k
scoreboard players operation xb stories260k = 7b q
scoreboard players operation xe stories260k = 7e q
scoreboard players operation xs stories260k = 7s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 7b q = xb stories260k
scoreboard players operation 7e q = xe stories260k
scoreboard players operation 7s q = xs stories260k
scoreboard players operation t0b stories260k = 6b k
scoreboard players operation t0e stories260k = 6e k
scoreboard players operation t0s stories260k = 6s k
scoreboard players operation xb stories260k = 6b k
scoreboard players operation xe stories260k = 6e k
scoreboard players operation xs stories260k = 6s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 7b k
scoreboard players operation xe stories260k = 7e k
scoreboard players operation xs stories260k = 7s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 6b k = xb stories260k
scoreboard players operation 6e k = xe stories260k
scoreboard players operation 6s k = xs stories260k
scoreboard players operation xb stories260k = 7b k
scoreboard players operation xe stories260k = 7e k
scoreboard players operation xs stories260k = 7s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 7b k = xb stories260k
scoreboard players operation 7e k = xe stories260k
scoreboard players operation 7s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 8b q
scoreboard players operation t0e stories260k = 8e q
scoreboard players operation t0s stories260k = 8s q
scoreboard players operation xb stories260k = 8b q
scoreboard players operation xe stories260k = 8e q
scoreboard players operation xs stories260k = 8s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 9b q
scoreboard players operation xe stories260k = 9e q
scoreboard players operation xs stories260k = 9s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 8b q = xb stories260k
scoreboard players operation 8e q = xe stories260k
scoreboard players operation 8s q = xs stories260k
scoreboard players operation xb stories260k = 9b q
scoreboard players operation xe stories260k = 9e q
scoreboard players operation xs stories260k = 9s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 9b q = xb stories260k
scoreboard players operation 9e q = xe stories260k
scoreboard players operation 9s q = xs stories260k
scoreboard players operation t0b stories260k = 8b k
scoreboard players operation t0e stories260k = 8e k
scoreboard players operation t0s stories260k = 8s k
scoreboard players operation xb stories260k = 8b k
scoreboard players operation xe stories260k = 8e k
scoreboard players operation xs stories260k = 8s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 9b k
scoreboard players operation xe stories260k = 9e k
scoreboard players operation xs stories260k = 9s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 8b k = xb stories260k
scoreboard players operation 8e k = xe stories260k
scoreboard players operation 8s k = xs stories260k
scoreboard players operation xb stories260k = 9b k
scoreboard players operation xe stories260k = 9e k
scoreboard players operation xs stories260k = 9s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 9b k = xb stories260k
scoreboard players operation 9e k = xe stories260k
scoreboard players operation 9s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 10b q
scoreboard players operation t0e stories260k = 10e q
scoreboard players operation t0s stories260k = 10s q
scoreboard players operation xb stories260k = 10b q
scoreboard players operation xe stories260k = 10e q
scoreboard players operation xs stories260k = 10s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 11b q
scoreboard players operation xe stories260k = 11e q
scoreboard players operation xs stories260k = 11s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 10b q = xb stories260k
scoreboard players operation 10e q = xe stories260k
scoreboard players operation 10s q = xs stories260k
scoreboard players operation xb stories260k = 11b q
scoreboard players operation xe stories260k = 11e q
scoreboard players operation xs stories260k = 11s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 11b q = xb stories260k
scoreboard players operation 11e q = xe stories260k
scoreboard players operation 11s q = xs stories260k
scoreboard players operation t0b stories260k = 10b k
scoreboard players operation t0e stories260k = 10e k
scoreboard players operation t0s stories260k = 10s k
scoreboard players operation xb stories260k = 10b k
scoreboard players operation xe stories260k = 10e k
scoreboard players operation xs stories260k = 10s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 11b k
scoreboard players operation xe stories260k = 11e k
scoreboard players operation xs stories260k = 11s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 10b k = xb stories260k
scoreboard players operation 10e k = xe stories260k
scoreboard players operation 10s k = xs stories260k
scoreboard players operation xb stories260k = 11b k
scoreboard players operation xe stories260k = 11e k
scoreboard players operation xs stories260k = 11s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 11b k = xb stories260k
scoreboard players operation 11e k = xe stories260k
scoreboard players operation 11s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 12b q
scoreboard players operation t0e stories260k = 12e q
scoreboard players operation t0s stories260k = 12s q
scoreboard players operation xb stories260k = 12b q
scoreboard players operation xe stories260k = 12e q
scoreboard players operation xs stories260k = 12s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 13b q
scoreboard players operation xe stories260k = 13e q
scoreboard players operation xs stories260k = 13s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 12b q = xb stories260k
scoreboard players operation 12e q = xe stories260k
scoreboard players operation 12s q = xs stories260k
scoreboard players operation xb stories260k = 13b q
scoreboard players operation xe stories260k = 13e q
scoreboard players operation xs stories260k = 13s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 13b q = xb stories260k
scoreboard players operation 13e q = xe stories260k
scoreboard players operation 13s q = xs stories260k
scoreboard players operation t0b stories260k = 12b k
scoreboard players operation t0e stories260k = 12e k
scoreboard players operation t0s stories260k = 12s k
scoreboard players operation xb stories260k = 12b k
scoreboard players operation xe stories260k = 12e k
scoreboard players operation xs stories260k = 12s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 13b k
scoreboard players operation xe stories260k = 13e k
scoreboard players operation xs stories260k = 13s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 12b k = xb stories260k
scoreboard players operation 12e k = xe stories260k
scoreboard players operation 12s k = xs stories260k
scoreboard players operation xb stories260k = 13b k
scoreboard players operation xe stories260k = 13e k
scoreboard players operation xs stories260k = 13s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 13b k = xb stories260k
scoreboard players operation 13e k = xe stories260k
scoreboard players operation 13s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 14b q
scoreboard players operation t0e stories260k = 14e q
scoreboard players operation t0s stories260k = 14s q
scoreboard players operation xb stories260k = 14b q
scoreboard players operation xe stories260k = 14e q
scoreboard players operation xs stories260k = 14s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 15b q
scoreboard players operation xe stories260k = 15e q
scoreboard players operation xs stories260k = 15s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 14b q = xb stories260k
scoreboard players operation 14e q = xe stories260k
scoreboard players operation 14s q = xs stories260k
scoreboard players operation xb stories260k = 15b q
scoreboard players operation xe stories260k = 15e q
scoreboard players operation xs stories260k = 15s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 15b q = xb stories260k
scoreboard players operation 15e q = xe stories260k
scoreboard players operation 15s q = xs stories260k
scoreboard players operation t0b stories260k = 14b k
scoreboard players operation t0e stories260k = 14e k
scoreboard players operation t0s stories260k = 14s k
scoreboard players operation xb stories260k = 14b k
scoreboard players operation xe stories260k = 14e k
scoreboard players operation xs stories260k = 14s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 15b k
scoreboard players operation xe stories260k = 15e k
scoreboard players operation xs stories260k = 15s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 14b k = xb stories260k
scoreboard players operation 14e k = xe stories260k
scoreboard players operation 14s k = xs stories260k
scoreboard players operation xb stories260k = 15b k
scoreboard players operation xe stories260k = 15e k
scoreboard players operation xs stories260k = 15s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 15b k = xb stories260k
scoreboard players operation 15e k = xe stories260k
scoreboard players operation 15s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 16b q
scoreboard players operation t0e stories260k = 16e q
scoreboard players operation t0s stories260k = 16s q
scoreboard players operation xb stories260k = 16b q
scoreboard players operation xe stories260k = 16e q
scoreboard players operation xs stories260k = 16s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 17b q
scoreboard players operation xe stories260k = 17e q
scoreboard players operation xs stories260k = 17s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 16b q = xb stories260k
scoreboard players operation 16e q = xe stories260k
scoreboard players operation 16s q = xs stories260k
scoreboard players operation xb stories260k = 17b q
scoreboard players operation xe stories260k = 17e q
scoreboard players operation xs stories260k = 17s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 17b q = xb stories260k
scoreboard players operation 17e q = xe stories260k
scoreboard players operation 17s q = xs stories260k
scoreboard players operation t0b stories260k = 16b k
scoreboard players operation t0e stories260k = 16e k
scoreboard players operation t0s stories260k = 16s k
scoreboard players operation xb stories260k = 16b k
scoreboard players operation xe stories260k = 16e k
scoreboard players operation xs stories260k = 16s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 17b k
scoreboard players operation xe stories260k = 17e k
scoreboard players operation xs stories260k = 17s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 16b k = xb stories260k
scoreboard players operation 16e k = xe stories260k
scoreboard players operation 16s k = xs stories260k
scoreboard players operation xb stories260k = 17b k
scoreboard players operation xe stories260k = 17e k
scoreboard players operation xs stories260k = 17s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 17b k = xb stories260k
scoreboard players operation 17e k = xe stories260k
scoreboard players operation 17s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 18b q
scoreboard players operation t0e stories260k = 18e q
scoreboard players operation t0s stories260k = 18s q
scoreboard players operation xb stories260k = 18b q
scoreboard players operation xe stories260k = 18e q
scoreboard players operation xs stories260k = 18s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 19b q
scoreboard players operation xe stories260k = 19e q
scoreboard players operation xs stories260k = 19s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 18b q = xb stories260k
scoreboard players operation 18e q = xe stories260k
scoreboard players operation 18s q = xs stories260k
scoreboard players operation xb stories260k = 19b q
scoreboard players operation xe stories260k = 19e q
scoreboard players operation xs stories260k = 19s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 19b q = xb stories260k
scoreboard players operation 19e q = xe stories260k
scoreboard players operation 19s q = xs stories260k
scoreboard players operation t0b stories260k = 18b k
scoreboard players operation t0e stories260k = 18e k
scoreboard players operation t0s stories260k = 18s k
scoreboard players operation xb stories260k = 18b k
scoreboard players operation xe stories260k = 18e k
scoreboard players operation xs stories260k = 18s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 19b k
scoreboard players operation xe stories260k = 19e k
scoreboard players operation xs stories260k = 19s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 18b k = xb stories260k
scoreboard players operation 18e k = xe stories260k
scoreboard players operation 18s k = xs stories260k
scoreboard players operation xb stories260k = 19b k
scoreboard players operation xe stories260k = 19e k
scoreboard players operation xs stories260k = 19s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 19b k = xb stories260k
scoreboard players operation 19e k = xe stories260k
scoreboard players operation 19s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 20b q
scoreboard players operation t0e stories260k = 20e q
scoreboard players operation t0s stories260k = 20s q
scoreboard players operation xb stories260k = 20b q
scoreboard players operation xe stories260k = 20e q
scoreboard players operation xs stories260k = 20s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 21b q
scoreboard players operation xe stories260k = 21e q
scoreboard players operation xs stories260k = 21s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 20b q = xb stories260k
scoreboard players operation 20e q = xe stories260k
scoreboard players operation 20s q = xs stories260k
scoreboard players operation xb stories260k = 21b q
scoreboard players operation xe stories260k = 21e q
scoreboard players operation xs stories260k = 21s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 21b q = xb stories260k
scoreboard players operation 21e q = xe stories260k
scoreboard players operation 21s q = xs stories260k
scoreboard players operation t0b stories260k = 20b k
scoreboard players operation t0e stories260k = 20e k
scoreboard players operation t0s stories260k = 20s k
scoreboard players operation xb stories260k = 20b k
scoreboard players operation xe stories260k = 20e k
scoreboard players operation xs stories260k = 20s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 21b k
scoreboard players operation xe stories260k = 21e k
scoreboard players operation xs stories260k = 21s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 20b k = xb stories260k
scoreboard players operation 20e k = xe stories260k
scoreboard players operation 20s k = xs stories260k
scoreboard players operation xb stories260k = 21b k
scoreboard players operation xe stories260k = 21e k
scoreboard players operation xs stories260k = 21s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 21b k = xb stories260k
scoreboard players operation 21e k = xe stories260k
scoreboard players operation 21s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 22b q
scoreboard players operation t0e stories260k = 22e q
scoreboard players operation t0s stories260k = 22s q
scoreboard players operation xb stories260k = 22b q
scoreboard players operation xe stories260k = 22e q
scoreboard players operation xs stories260k = 22s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 23b q
scoreboard players operation xe stories260k = 23e q
scoreboard players operation xs stories260k = 23s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 22b q = xb stories260k
scoreboard players operation 22e q = xe stories260k
scoreboard players operation 22s q = xs stories260k
scoreboard players operation xb stories260k = 23b q
scoreboard players operation xe stories260k = 23e q
scoreboard players operation xs stories260k = 23s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 23b q = xb stories260k
scoreboard players operation 23e q = xe stories260k
scoreboard players operation 23s q = xs stories260k
scoreboard players operation t0b stories260k = 22b k
scoreboard players operation t0e stories260k = 22e k
scoreboard players operation t0s stories260k = 22s k
scoreboard players operation xb stories260k = 22b k
scoreboard players operation xe stories260k = 22e k
scoreboard players operation xs stories260k = 22s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 23b k
scoreboard players operation xe stories260k = 23e k
scoreboard players operation xs stories260k = 23s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 22b k = xb stories260k
scoreboard players operation 22e k = xe stories260k
scoreboard players operation 22s k = xs stories260k
scoreboard players operation xb stories260k = 23b k
scoreboard players operation xe stories260k = 23e k
scoreboard players operation xs stories260k = 23s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 23b k = xb stories260k
scoreboard players operation 23e k = xe stories260k
scoreboard players operation 23s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 24b q
scoreboard players operation t0e stories260k = 24e q
scoreboard players operation t0s stories260k = 24s q
scoreboard players operation xb stories260k = 24b q
scoreboard players operation xe stories260k = 24e q
scoreboard players operation xs stories260k = 24s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 25b q
scoreboard players operation xe stories260k = 25e q
scoreboard players operation xs stories260k = 25s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 24b q = xb stories260k
scoreboard players operation 24e q = xe stories260k
scoreboard players operation 24s q = xs stories260k
scoreboard players operation xb stories260k = 25b q
scoreboard players operation xe stories260k = 25e q
scoreboard players operation xs stories260k = 25s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 25b q = xb stories260k
scoreboard players operation 25e q = xe stories260k
scoreboard players operation 25s q = xs stories260k
scoreboard players operation t0b stories260k = 24b k
scoreboard players operation t0e stories260k = 24e k
scoreboard players operation t0s stories260k = 24s k
scoreboard players operation xb stories260k = 24b k
scoreboard players operation xe stories260k = 24e k
scoreboard players operation xs stories260k = 24s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 25b k
scoreboard players operation xe stories260k = 25e k
scoreboard players operation xs stories260k = 25s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 24b k = xb stories260k
scoreboard players operation 24e k = xe stories260k
scoreboard players operation 24s k = xs stories260k
scoreboard players operation xb stories260k = 25b k
scoreboard players operation xe stories260k = 25e k
scoreboard players operation xs stories260k = 25s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 25b k = xb stories260k
scoreboard players operation 25e k = xe stories260k
scoreboard players operation 25s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 26b q
scoreboard players operation t0e stories260k = 26e q
scoreboard players operation t0s stories260k = 26s q
scoreboard players operation xb stories260k = 26b q
scoreboard players operation xe stories260k = 26e q
scoreboard players operation xs stories260k = 26s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 27b q
scoreboard players operation xe stories260k = 27e q
scoreboard players operation xs stories260k = 27s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 26b q = xb stories260k
scoreboard players operation 26e q = xe stories260k
scoreboard players operation 26s q = xs stories260k
scoreboard players operation xb stories260k = 27b q
scoreboard players operation xe stories260k = 27e q
scoreboard players operation xs stories260k = 27s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 27b q = xb stories260k
scoreboard players operation 27e q = xe stories260k
scoreboard players operation 27s q = xs stories260k
scoreboard players operation t0b stories260k = 26b k
scoreboard players operation t0e stories260k = 26e k
scoreboard players operation t0s stories260k = 26s k
scoreboard players operation xb stories260k = 26b k
scoreboard players operation xe stories260k = 26e k
scoreboard players operation xs stories260k = 26s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 27b k
scoreboard players operation xe stories260k = 27e k
scoreboard players operation xs stories260k = 27s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 26b k = xb stories260k
scoreboard players operation 26e k = xe stories260k
scoreboard players operation 26s k = xs stories260k
scoreboard players operation xb stories260k = 27b k
scoreboard players operation xe stories260k = 27e k
scoreboard players operation xs stories260k = 27s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 27b k = xb stories260k
scoreboard players operation 27e k = xe stories260k
scoreboard players operation 27s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 28b q
scoreboard players operation t0e stories260k = 28e q
scoreboard players operation t0s stories260k = 28s q
scoreboard players operation xb stories260k = 28b q
scoreboard players operation xe stories260k = 28e q
scoreboard players operation xs stories260k = 28s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 29b q
scoreboard players operation xe stories260k = 29e q
scoreboard players operation xs stories260k = 29s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 28b q = xb stories260k
scoreboard players operation 28e q = xe stories260k
scoreboard players operation 28s q = xs stories260k
scoreboard players operation xb stories260k = 29b q
scoreboard players operation xe stories260k = 29e q
scoreboard players operation xs stories260k = 29s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 29b q = xb stories260k
scoreboard players operation 29e q = xe stories260k
scoreboard players operation 29s q = xs stories260k
scoreboard players operation t0b stories260k = 28b k
scoreboard players operation t0e stories260k = 28e k
scoreboard players operation t0s stories260k = 28s k
scoreboard players operation xb stories260k = 28b k
scoreboard players operation xe stories260k = 28e k
scoreboard players operation xs stories260k = 28s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 29b k
scoreboard players operation xe stories260k = 29e k
scoreboard players operation xs stories260k = 29s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 28b k = xb stories260k
scoreboard players operation 28e k = xe stories260k
scoreboard players operation 28s k = xs stories260k
scoreboard players operation xb stories260k = 29b k
scoreboard players operation xe stories260k = 29e k
scoreboard players operation xs stories260k = 29s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 29b k = xb stories260k
scoreboard players operation 29e k = xe stories260k
scoreboard players operation 29s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 30b q
scoreboard players operation t0e stories260k = 30e q
scoreboard players operation t0s stories260k = 30s q
scoreboard players operation xb stories260k = 30b q
scoreboard players operation xe stories260k = 30e q
scoreboard players operation xs stories260k = 30s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 31b q
scoreboard players operation xe stories260k = 31e q
scoreboard players operation xs stories260k = 31s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 30b q = xb stories260k
scoreboard players operation 30e q = xe stories260k
scoreboard players operation 30s q = xs stories260k
scoreboard players operation xb stories260k = 31b q
scoreboard players operation xe stories260k = 31e q
scoreboard players operation xs stories260k = 31s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 31b q = xb stories260k
scoreboard players operation 31e q = xe stories260k
scoreboard players operation 31s q = xs stories260k
scoreboard players operation t0b stories260k = 30b k
scoreboard players operation t0e stories260k = 30e k
scoreboard players operation t0s stories260k = 30s k
scoreboard players operation xb stories260k = 30b k
scoreboard players operation xe stories260k = 30e k
scoreboard players operation xs stories260k = 30s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 31b k
scoreboard players operation xe stories260k = 31e k
scoreboard players operation xs stories260k = 31s k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 30b k = xb stories260k
scoreboard players operation 30e k = xe stories260k
scoreboard players operation 30s k = xs stories260k
scoreboard players operation xb stories260k = 31b k
scoreboard players operation xe stories260k = 31e k
scoreboard players operation xs stories260k = 31s k
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b k = xb stories260k
scoreboard players operation t1e k = xe stories260k
scoreboard players operation t1s k = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b k
scoreboard players operation ye stories260k = t1e k
scoreboard players operation ys stories260k = t1s k
function stories260k:add
scoreboard players operation 31b k = xb stories260k
scoreboard players operation 31e k = xe stories260k
scoreboard players operation 31s k = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 32b q
scoreboard players operation t0e stories260k = 32e q
scoreboard players operation t0s stories260k = 32s q
scoreboard players operation xb stories260k = 32b q
scoreboard players operation xe stories260k = 32e q
scoreboard players operation xs stories260k = 32s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 33b q
scoreboard players operation xe stories260k = 33e q
scoreboard players operation xs stories260k = 33s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 32b q = xb stories260k
scoreboard players operation 32e q = xe stories260k
scoreboard players operation 32s q = xs stories260k
scoreboard players operation xb stories260k = 33b q
scoreboard players operation xe stories260k = 33e q
scoreboard players operation xs stories260k = 33s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 33b q = xb stories260k
scoreboard players operation 33e q = xe stories260k
scoreboard players operation 33s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 34b q
scoreboard players operation t0e stories260k = 34e q
scoreboard players operation t0s stories260k = 34s q
scoreboard players operation xb stories260k = 34b q
scoreboard players operation xe stories260k = 34e q
scoreboard players operation xs stories260k = 34s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 35b q
scoreboard players operation xe stories260k = 35e q
scoreboard players operation xs stories260k = 35s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 34b q = xb stories260k
scoreboard players operation 34e q = xe stories260k
scoreboard players operation 34s q = xs stories260k
scoreboard players operation xb stories260k = 35b q
scoreboard players operation xe stories260k = 35e q
scoreboard players operation xs stories260k = 35s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 35b q = xb stories260k
scoreboard players operation 35e q = xe stories260k
scoreboard players operation 35s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 36b q
scoreboard players operation t0e stories260k = 36e q
scoreboard players operation t0s stories260k = 36s q
scoreboard players operation xb stories260k = 36b q
scoreboard players operation xe stories260k = 36e q
scoreboard players operation xs stories260k = 36s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 37b q
scoreboard players operation xe stories260k = 37e q
scoreboard players operation xs stories260k = 37s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 36b q = xb stories260k
scoreboard players operation 36e q = xe stories260k
scoreboard players operation 36s q = xs stories260k
scoreboard players operation xb stories260k = 37b q
scoreboard players operation xe stories260k = 37e q
scoreboard players operation xs stories260k = 37s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 37b q = xb stories260k
scoreboard players operation 37e q = xe stories260k
scoreboard players operation 37s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 38b q
scoreboard players operation t0e stories260k = 38e q
scoreboard players operation t0s stories260k = 38s q
scoreboard players operation xb stories260k = 38b q
scoreboard players operation xe stories260k = 38e q
scoreboard players operation xs stories260k = 38s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 39b q
scoreboard players operation xe stories260k = 39e q
scoreboard players operation xs stories260k = 39s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 38b q = xb stories260k
scoreboard players operation 38e q = xe stories260k
scoreboard players operation 38s q = xs stories260k
scoreboard players operation xb stories260k = 39b q
scoreboard players operation xe stories260k = 39e q
scoreboard players operation xs stories260k = 39s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 39b q = xb stories260k
scoreboard players operation 39e q = xe stories260k
scoreboard players operation 39s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 40b q
scoreboard players operation t0e stories260k = 40e q
scoreboard players operation t0s stories260k = 40s q
scoreboard players operation xb stories260k = 40b q
scoreboard players operation xe stories260k = 40e q
scoreboard players operation xs stories260k = 40s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 41b q
scoreboard players operation xe stories260k = 41e q
scoreboard players operation xs stories260k = 41s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 40b q = xb stories260k
scoreboard players operation 40e q = xe stories260k
scoreboard players operation 40s q = xs stories260k
scoreboard players operation xb stories260k = 41b q
scoreboard players operation xe stories260k = 41e q
scoreboard players operation xs stories260k = 41s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 41b q = xb stories260k
scoreboard players operation 41e q = xe stories260k
scoreboard players operation 41s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 42b q
scoreboard players operation t0e stories260k = 42e q
scoreboard players operation t0s stories260k = 42s q
scoreboard players operation xb stories260k = 42b q
scoreboard players operation xe stories260k = 42e q
scoreboard players operation xs stories260k = 42s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 43b q
scoreboard players operation xe stories260k = 43e q
scoreboard players operation xs stories260k = 43s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 42b q = xb stories260k
scoreboard players operation 42e q = xe stories260k
scoreboard players operation 42s q = xs stories260k
scoreboard players operation xb stories260k = 43b q
scoreboard players operation xe stories260k = 43e q
scoreboard players operation xs stories260k = 43s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 43b q = xb stories260k
scoreboard players operation 43e q = xe stories260k
scoreboard players operation 43s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 44b q
scoreboard players operation t0e stories260k = 44e q
scoreboard players operation t0s stories260k = 44s q
scoreboard players operation xb stories260k = 44b q
scoreboard players operation xe stories260k = 44e q
scoreboard players operation xs stories260k = 44s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 45b q
scoreboard players operation xe stories260k = 45e q
scoreboard players operation xs stories260k = 45s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 44b q = xb stories260k
scoreboard players operation 44e q = xe stories260k
scoreboard players operation 44s q = xs stories260k
scoreboard players operation xb stories260k = 45b q
scoreboard players operation xe stories260k = 45e q
scoreboard players operation xs stories260k = 45s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 45b q = xb stories260k
scoreboard players operation 45e q = xe stories260k
scoreboard players operation 45s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 46b q
scoreboard players operation t0e stories260k = 46e q
scoreboard players operation t0s stories260k = 46s q
scoreboard players operation xb stories260k = 46b q
scoreboard players operation xe stories260k = 46e q
scoreboard players operation xs stories260k = 46s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 47b q
scoreboard players operation xe stories260k = 47e q
scoreboard players operation xs stories260k = 47s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 46b q = xb stories260k
scoreboard players operation 46e q = xe stories260k
scoreboard players operation 46s q = xs stories260k
scoreboard players operation xb stories260k = 47b q
scoreboard players operation xe stories260k = 47e q
scoreboard players operation xs stories260k = 47s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 47b q = xb stories260k
scoreboard players operation 47e q = xe stories260k
scoreboard players operation 47s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 48b q
scoreboard players operation t0e stories260k = 48e q
scoreboard players operation t0s stories260k = 48s q
scoreboard players operation xb stories260k = 48b q
scoreboard players operation xe stories260k = 48e q
scoreboard players operation xs stories260k = 48s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 49b q
scoreboard players operation xe stories260k = 49e q
scoreboard players operation xs stories260k = 49s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 48b q = xb stories260k
scoreboard players operation 48e q = xe stories260k
scoreboard players operation 48s q = xs stories260k
scoreboard players operation xb stories260k = 49b q
scoreboard players operation xe stories260k = 49e q
scoreboard players operation xs stories260k = 49s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 49b q = xb stories260k
scoreboard players operation 49e q = xe stories260k
scoreboard players operation 49s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 50b q
scoreboard players operation t0e stories260k = 50e q
scoreboard players operation t0s stories260k = 50s q
scoreboard players operation xb stories260k = 50b q
scoreboard players operation xe stories260k = 50e q
scoreboard players operation xs stories260k = 50s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 51b q
scoreboard players operation xe stories260k = 51e q
scoreboard players operation xs stories260k = 51s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 50b q = xb stories260k
scoreboard players operation 50e q = xe stories260k
scoreboard players operation 50s q = xs stories260k
scoreboard players operation xb stories260k = 51b q
scoreboard players operation xe stories260k = 51e q
scoreboard players operation xs stories260k = 51s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 51b q = xb stories260k
scoreboard players operation 51e q = xe stories260k
scoreboard players operation 51s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 52b q
scoreboard players operation t0e stories260k = 52e q
scoreboard players operation t0s stories260k = 52s q
scoreboard players operation xb stories260k = 52b q
scoreboard players operation xe stories260k = 52e q
scoreboard players operation xs stories260k = 52s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 53b q
scoreboard players operation xe stories260k = 53e q
scoreboard players operation xs stories260k = 53s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 52b q = xb stories260k
scoreboard players operation 52e q = xe stories260k
scoreboard players operation 52s q = xs stories260k
scoreboard players operation xb stories260k = 53b q
scoreboard players operation xe stories260k = 53e q
scoreboard players operation xs stories260k = 53s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 53b q = xb stories260k
scoreboard players operation 53e q = xe stories260k
scoreboard players operation 53s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 54b q
scoreboard players operation t0e stories260k = 54e q
scoreboard players operation t0s stories260k = 54s q
scoreboard players operation xb stories260k = 54b q
scoreboard players operation xe stories260k = 54e q
scoreboard players operation xs stories260k = 54s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 55b q
scoreboard players operation xe stories260k = 55e q
scoreboard players operation xs stories260k = 55s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 54b q = xb stories260k
scoreboard players operation 54e q = xe stories260k
scoreboard players operation 54s q = xs stories260k
scoreboard players operation xb stories260k = 55b q
scoreboard players operation xe stories260k = 55e q
scoreboard players operation xs stories260k = 55s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 55b q = xb stories260k
scoreboard players operation 55e q = xe stories260k
scoreboard players operation 55s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 56b q
scoreboard players operation t0e stories260k = 56e q
scoreboard players operation t0s stories260k = 56s q
scoreboard players operation xb stories260k = 56b q
scoreboard players operation xe stories260k = 56e q
scoreboard players operation xs stories260k = 56s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 57b q
scoreboard players operation xe stories260k = 57e q
scoreboard players operation xs stories260k = 57s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 56b q = xb stories260k
scoreboard players operation 56e q = xe stories260k
scoreboard players operation 56s q = xs stories260k
scoreboard players operation xb stories260k = 57b q
scoreboard players operation xe stories260k = 57e q
scoreboard players operation xs stories260k = 57s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 57b q = xb stories260k
scoreboard players operation 57e q = xe stories260k
scoreboard players operation 57s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 58b q
scoreboard players operation t0e stories260k = 58e q
scoreboard players operation t0s stories260k = 58s q
scoreboard players operation xb stories260k = 58b q
scoreboard players operation xe stories260k = 58e q
scoreboard players operation xs stories260k = 58s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 59b q
scoreboard players operation xe stories260k = 59e q
scoreboard players operation xs stories260k = 59s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 58b q = xb stories260k
scoreboard players operation 58e q = xe stories260k
scoreboard players operation 58s q = xs stories260k
scoreboard players operation xb stories260k = 59b q
scoreboard players operation xe stories260k = 59e q
scoreboard players operation xs stories260k = 59s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 59b q = xb stories260k
scoreboard players operation 59e q = xe stories260k
scoreboard players operation 59s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -2
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 60b q
scoreboard players operation t0e stories260k = 60e q
scoreboard players operation t0s stories260k = 60s q
scoreboard players operation xb stories260k = 60b q
scoreboard players operation xe stories260k = 60e q
scoreboard players operation xs stories260k = 60s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 61b q
scoreboard players operation xe stories260k = 61e q
scoreboard players operation xs stories260k = 61s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 60b q = xb stories260k
scoreboard players operation 60e q = xe stories260k
scoreboard players operation 60s q = xs stories260k
scoreboard players operation xb stories260k = 61b q
scoreboard players operation xe stories260k = 61e q
scoreboard players operation xs stories260k = 61s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 61b q = xb stories260k
scoreboard players operation 61e q = xe stories260k
scoreboard players operation 61s q = xs stories260k
scoreboard players set xb stories260k 10000000
scoreboard players set xe stories260k -3
scoreboard players set xs stories260k 1
scoreboard players operation yb stories260k = posb stories260k
scoreboard players operation ye stories260k = pose stories260k
scoreboard players operation ys stories260k = poss stories260k
function stories260k:mul
scoreboard players set yb stories260k 17453293
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
function stories260k:div
scoreboard players operation vb stories260k = xb stories260k
scoreboard players operation ve stories260k = xe stories260k
scoreboard players operation vs stories260k = xs stories260k
function stories260k:sin
scoreboard players operation fcib stories260k = xb stories260k
scoreboard players operation fcie stories260k = xe stories260k
scoreboard players operation fcis stories260k = xs stories260k
scoreboard players operation xb stories260k = vb stories260k
scoreboard players operation xe stories260k = ve stories260k
scoreboard players operation xs stories260k = vs stories260k
function stories260k:cos
scoreboard players operation fcrb stories260k = xb stories260k
scoreboard players operation fcre stories260k = xe stories260k
scoreboard players operation fcrs stories260k = xs stories260k
scoreboard players operation t0b stories260k = 62b q
scoreboard players operation t0e stories260k = 62e q
scoreboard players operation t0s stories260k = 62s q
scoreboard players operation xb stories260k = 62b q
scoreboard players operation xe stories260k = 62e q
scoreboard players operation xs stories260k = 62s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b stories260k = xb stories260k
scoreboard players operation t1e stories260k = xe stories260k
scoreboard players operation t1s stories260k = xs stories260k
scoreboard players operation xb stories260k = 63b q
scoreboard players operation xe stories260k = 63e q
scoreboard players operation xs stories260k = 63s q
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation xs stories260k *= -1 stories260k
scoreboard players operation yb stories260k = t1b stories260k
scoreboard players operation ye stories260k = t1e stories260k
scoreboard players operation ys stories260k = t1s stories260k
function stories260k:add
scoreboard players operation 62b q = xb stories260k
scoreboard players operation 62e q = xe stories260k
scoreboard players operation 62s q = xs stories260k
scoreboard players operation xb stories260k = 63b q
scoreboard players operation xe stories260k = 63e q
scoreboard players operation xs stories260k = 63s q
scoreboard players operation yb stories260k = fcrb stories260k
scoreboard players operation ye stories260k = fcre stories260k
scoreboard players operation ys stories260k = fcrs stories260k
function stories260k:mul
scoreboard players operation t1b q = xb stories260k
scoreboard players operation t1e q = xe stories260k
scoreboard players operation t1s q = xs stories260k
scoreboard players operation xb stories260k = t0b stories260k
scoreboard players operation xe stories260k = t0e stories260k
scoreboard players operation xs stories260k = t0s stories260k
scoreboard players operation yb stories260k = fcib stories260k
scoreboard players operation ye stories260k = fcie stories260k
scoreboard players operation ys stories260k = fcis stories260k
function stories260k:mul
scoreboard players operation yb stories260k = t1b q
scoreboard players operation ye stories260k = t1e q
scoreboard players operation ys stories260k = t1s q
function stories260k:add
scoreboard players operation 63b q = xb stories260k
scoreboard players operation 63e q = xe stories260k
scoreboard players operation 63s q = xs stories260k
