$scoreboard players operation $(i)b kc = xb stories260k
$scoreboard players operation $(i)e kc = xe stories260k
$scoreboard players operation $(i)s kc = xs stories260k
