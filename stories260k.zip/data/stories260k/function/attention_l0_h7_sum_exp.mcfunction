execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation yb stories260k = maxb stories260k
scoreboard players operation ye stories260k = maxe stories260k
scoreboard players operation ys stories260k = maxs stories260k
scoreboard players operation ys stories260k *= -1 stories260k
function stories260k:add
function stories260k:exp
function stories260k:set_av with storage stories260k args
scoreboard players operation yb stories260k = expsumb stories260k
scoreboard players operation ye stories260k = expsume stories260k
scoreboard players operation ys stories260k = expsums stories260k
function stories260k:add
scoreboard players operation expsumb stories260k = xb stories260k
scoreboard players operation expsume stories260k = xe stories260k
scoreboard players operation expsums stories260k = xs stories260k
scoreboard players add i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l0_h7_sum_exp
