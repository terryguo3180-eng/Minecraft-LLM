execute if score temperature stories260k matches 0 run function stories260k:argmax
execute unless score temperature stories260k matches 0 run function stories260k:temperature_sample
bossbar set progress players
execute if score tok stories260k matches 2 run return 1
function stories260k:token_to_string
data modify storage stories260k args.output append from storage stories260k args.tok
tellraw @a ["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",{"storage":"stories260k","nbt":"args.output[]","separator":""}]
scoreboard players add pos stories260k 1
function stories260k:respond
