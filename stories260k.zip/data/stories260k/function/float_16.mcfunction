execute if score xb stories260k matches 1..329475 run return run scoreboard players set t0 stories260k 744
scoreboard players operation t0 stories260k = xb stories260k
execute if score xb stories260k matches 329476..18688328 run return run function stories260k:float_17
execute if score xb stories260k matches 18688329..533609999 run return run function stories260k:float_18
scoreboard players operation t0 stories260k /= 79249 stories260k
scoreboard players add t0 stories260k 19750
