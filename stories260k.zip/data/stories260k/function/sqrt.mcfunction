execute if score xb stories260k matches 0 run return run scoreboard players operation xe stories260k /= 2 stories260k
scoreboard players operation t0 stories260k = xe stories260k
scoreboard players operation t0 stories260k %= 2 stories260k
execute if score t0 stories260k matches 0 run function stories260k:float_11
scoreboard players operation xe stories260k /= 2 stories260k
function stories260k:float_16
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t1 stories260k /= t0 stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k /= 2 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t1 stories260k /= t0 stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k /= 2 stories260k
scoreboard players operation t1 stories260k = t0 stories260k
scoreboard players operation t1 stories260k *= t0 stories260k
execute if score t1 stories260k > xb stories260k run function stories260k:float_19
scoreboard players operation xb stories260k -= t1 stories260k
scoreboard players operation xb stories260k *= 500 stories260k
scoreboard players operation xb stories260k /= t0 stories260k
scoreboard players operation t0 stories260k *= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xb stories260k *= 10 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
