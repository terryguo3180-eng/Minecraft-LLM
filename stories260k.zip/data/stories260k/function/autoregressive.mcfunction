function stories260k:run_forward_pass
execute if data storage stories260k args{prompt_tokens:[]} run schedule function stories260k:autoregressive_next 52t
execute unless data storage stories260k args{prompt_tokens:[]} run schedule function stories260k:autoregressive_next 41t
