scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 16
scoreboard players set scoreb stories260k 0
scoreboard players set scoree stories260k 0
scoreboard players set scores stories260k 0
scoreboard players operation yb stories260k = 40b q
scoreboard players operation ye stories260k = 40e q
scoreboard players operation ys stories260k = 40s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 41b q
scoreboard players operation ye stories260k = 41e q
scoreboard players operation ys stories260k = 41s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 42b q
scoreboard players operation ye stories260k = 42e q
scoreboard players operation ys stories260k = 42s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 43b q
scoreboard players operation ye stories260k = 43e q
scoreboard players operation ys stories260k = 43s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 44b q
scoreboard players operation ye stories260k = 44e q
scoreboard players operation ys stories260k = 44s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 45b q
scoreboard players operation ye stories260k = 45e q
scoreboard players operation ys stories260k = 45s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 46b q
scoreboard players operation ye stories260k = 46e q
scoreboard players operation ys stories260k = 46s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 47b q
scoreboard players operation ye stories260k = 47e q
scoreboard players operation ys stories260k = 47s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation xb stories260k = scoreb stories260k
scoreboard players operation xe stories260k = scoree stories260k
scoreboard players operation xs stories260k = scores stories260k
scoreboard players set yb stories260k 28284271
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:div
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:set_av with storage stories260k args
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l0_h5_compute_score
