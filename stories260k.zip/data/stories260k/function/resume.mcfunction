$scoreboard players set steps stories260k $(s)
execute if score steps stories260k matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer!","color":"red"}
tellraw @a [{"text":"Resuming from step #","color":"green"},{"score":{"name":"pos","objective":"stories260k"}}]
scoreboard players operation steps stories260k += pos stories260k
function stories260k:autoregressive
