execute if score t3 stories260k matches 1 run return run scoreboard players operation t2 stories260k /= 10 stories260k
scoreboard players operation t2 stories260k /= 100 stories260k
