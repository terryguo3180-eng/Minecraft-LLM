$scoreboard players operation xb stories260k = $(i)b kc
$scoreboard players operation xe stories260k = $(i)e kc
$scoreboard players operation xs stories260k = $(i)s kc
