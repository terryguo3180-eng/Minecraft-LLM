data modify storage stories260k args.in set value "tx"
data modify storage stories260k args.out set value "k"
data modify storage stories260k args.m set value "wk_1"
scoreboard players set s1 stories260k 32
scoreboard players set s2 stories260k 64
function stories260k:matmul
bossbar set progress value 10
schedule function stories260k:forward_hidden_9 1t
