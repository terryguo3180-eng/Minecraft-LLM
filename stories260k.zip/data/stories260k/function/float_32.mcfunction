$data modify storage stories260k args.x set value $(s)$(b)E$(e)f
