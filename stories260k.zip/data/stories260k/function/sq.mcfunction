scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation t1 stories260k = t0 stories260k
scoreboard players operation t1 stories260k *= t0 stories260k
scoreboard players operation t1 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= xb stories260k
scoreboard players operation t0 stories260k *= 2 stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation xb stories260k *= xb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= xs stories260k
scoreboard players operation xe stories260k *= 2 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
