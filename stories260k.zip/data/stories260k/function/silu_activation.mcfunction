scoreboard players operation xb stories260k = 0b th
scoreboard players operation xe stories260k = 0e th
scoreboard players operation xs stories260k = 0s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 0b th2
scoreboard players operation xe stories260k = 0e th2
scoreboard players operation xs stories260k = 0s th2
function stories260k:div
scoreboard players operation yb stories260k = 0b th
scoreboard players operation ye stories260k = 0e th
scoreboard players operation ys stories260k = 0s th
function stories260k:mul
scoreboard players operation 0b th = xb stories260k
scoreboard players operation 0e th = xe stories260k
scoreboard players operation 0s th = xs stories260k
scoreboard players operation xb stories260k = 1b th
scoreboard players operation xe stories260k = 1e th
scoreboard players operation xs stories260k = 1s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 1b th2
scoreboard players operation xe stories260k = 1e th2
scoreboard players operation xs stories260k = 1s th2
function stories260k:div
scoreboard players operation yb stories260k = 1b th
scoreboard players operation ye stories260k = 1e th
scoreboard players operation ys stories260k = 1s th
function stories260k:mul
scoreboard players operation 1b th = xb stories260k
scoreboard players operation 1e th = xe stories260k
scoreboard players operation 1s th = xs stories260k
scoreboard players operation xb stories260k = 2b th
scoreboard players operation xe stories260k = 2e th
scoreboard players operation xs stories260k = 2s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 2b th2
scoreboard players operation xe stories260k = 2e th2
scoreboard players operation xs stories260k = 2s th2
function stories260k:div
scoreboard players operation yb stories260k = 2b th
scoreboard players operation ye stories260k = 2e th
scoreboard players operation ys stories260k = 2s th
function stories260k:mul
scoreboard players operation 2b th = xb stories260k
scoreboard players operation 2e th = xe stories260k
scoreboard players operation 2s th = xs stories260k
scoreboard players operation xb stories260k = 3b th
scoreboard players operation xe stories260k = 3e th
scoreboard players operation xs stories260k = 3s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 3b th2
scoreboard players operation xe stories260k = 3e th2
scoreboard players operation xs stories260k = 3s th2
function stories260k:div
scoreboard players operation yb stories260k = 3b th
scoreboard players operation ye stories260k = 3e th
scoreboard players operation ys stories260k = 3s th
function stories260k:mul
scoreboard players operation 3b th = xb stories260k
scoreboard players operation 3e th = xe stories260k
scoreboard players operation 3s th = xs stories260k
scoreboard players operation xb stories260k = 4b th
scoreboard players operation xe stories260k = 4e th
scoreboard players operation xs stories260k = 4s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 4b th2
scoreboard players operation xe stories260k = 4e th2
scoreboard players operation xs stories260k = 4s th2
function stories260k:div
scoreboard players operation yb stories260k = 4b th
scoreboard players operation ye stories260k = 4e th
scoreboard players operation ys stories260k = 4s th
function stories260k:mul
scoreboard players operation 4b th = xb stories260k
scoreboard players operation 4e th = xe stories260k
scoreboard players operation 4s th = xs stories260k
scoreboard players operation xb stories260k = 5b th
scoreboard players operation xe stories260k = 5e th
scoreboard players operation xs stories260k = 5s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 5b th2
scoreboard players operation xe stories260k = 5e th2
scoreboard players operation xs stories260k = 5s th2
function stories260k:div
scoreboard players operation yb stories260k = 5b th
scoreboard players operation ye stories260k = 5e th
scoreboard players operation ys stories260k = 5s th
function stories260k:mul
scoreboard players operation 5b th = xb stories260k
scoreboard players operation 5e th = xe stories260k
scoreboard players operation 5s th = xs stories260k
scoreboard players operation xb stories260k = 6b th
scoreboard players operation xe stories260k = 6e th
scoreboard players operation xs stories260k = 6s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 6b th2
scoreboard players operation xe stories260k = 6e th2
scoreboard players operation xs stories260k = 6s th2
function stories260k:div
scoreboard players operation yb stories260k = 6b th
scoreboard players operation ye stories260k = 6e th
scoreboard players operation ys stories260k = 6s th
function stories260k:mul
scoreboard players operation 6b th = xb stories260k
scoreboard players operation 6e th = xe stories260k
scoreboard players operation 6s th = xs stories260k
scoreboard players operation xb stories260k = 7b th
scoreboard players operation xe stories260k = 7e th
scoreboard players operation xs stories260k = 7s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 7b th2
scoreboard players operation xe stories260k = 7e th2
scoreboard players operation xs stories260k = 7s th2
function stories260k:div
scoreboard players operation yb stories260k = 7b th
scoreboard players operation ye stories260k = 7e th
scoreboard players operation ys stories260k = 7s th
function stories260k:mul
scoreboard players operation 7b th = xb stories260k
scoreboard players operation 7e th = xe stories260k
scoreboard players operation 7s th = xs stories260k
scoreboard players operation xb stories260k = 8b th
scoreboard players operation xe stories260k = 8e th
scoreboard players operation xs stories260k = 8s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 8b th2
scoreboard players operation xe stories260k = 8e th2
scoreboard players operation xs stories260k = 8s th2
function stories260k:div
scoreboard players operation yb stories260k = 8b th
scoreboard players operation ye stories260k = 8e th
scoreboard players operation ys stories260k = 8s th
function stories260k:mul
scoreboard players operation 8b th = xb stories260k
scoreboard players operation 8e th = xe stories260k
scoreboard players operation 8s th = xs stories260k
scoreboard players operation xb stories260k = 9b th
scoreboard players operation xe stories260k = 9e th
scoreboard players operation xs stories260k = 9s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 9b th2
scoreboard players operation xe stories260k = 9e th2
scoreboard players operation xs stories260k = 9s th2
function stories260k:div
scoreboard players operation yb stories260k = 9b th
scoreboard players operation ye stories260k = 9e th
scoreboard players operation ys stories260k = 9s th
function stories260k:mul
scoreboard players operation 9b th = xb stories260k
scoreboard players operation 9e th = xe stories260k
scoreboard players operation 9s th = xs stories260k
scoreboard players operation xb stories260k = 10b th
scoreboard players operation xe stories260k = 10e th
scoreboard players operation xs stories260k = 10s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 10b th2
scoreboard players operation xe stories260k = 10e th2
scoreboard players operation xs stories260k = 10s th2
function stories260k:div
scoreboard players operation yb stories260k = 10b th
scoreboard players operation ye stories260k = 10e th
scoreboard players operation ys stories260k = 10s th
function stories260k:mul
scoreboard players operation 10b th = xb stories260k
scoreboard players operation 10e th = xe stories260k
scoreboard players operation 10s th = xs stories260k
scoreboard players operation xb stories260k = 11b th
scoreboard players operation xe stories260k = 11e th
scoreboard players operation xs stories260k = 11s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 11b th2
scoreboard players operation xe stories260k = 11e th2
scoreboard players operation xs stories260k = 11s th2
function stories260k:div
scoreboard players operation yb stories260k = 11b th
scoreboard players operation ye stories260k = 11e th
scoreboard players operation ys stories260k = 11s th
function stories260k:mul
scoreboard players operation 11b th = xb stories260k
scoreboard players operation 11e th = xe stories260k
scoreboard players operation 11s th = xs stories260k
scoreboard players operation xb stories260k = 12b th
scoreboard players operation xe stories260k = 12e th
scoreboard players operation xs stories260k = 12s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 12b th2
scoreboard players operation xe stories260k = 12e th2
scoreboard players operation xs stories260k = 12s th2
function stories260k:div
scoreboard players operation yb stories260k = 12b th
scoreboard players operation ye stories260k = 12e th
scoreboard players operation ys stories260k = 12s th
function stories260k:mul
scoreboard players operation 12b th = xb stories260k
scoreboard players operation 12e th = xe stories260k
scoreboard players operation 12s th = xs stories260k
scoreboard players operation xb stories260k = 13b th
scoreboard players operation xe stories260k = 13e th
scoreboard players operation xs stories260k = 13s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 13b th2
scoreboard players operation xe stories260k = 13e th2
scoreboard players operation xs stories260k = 13s th2
function stories260k:div
scoreboard players operation yb stories260k = 13b th
scoreboard players operation ye stories260k = 13e th
scoreboard players operation ys stories260k = 13s th
function stories260k:mul
scoreboard players operation 13b th = xb stories260k
scoreboard players operation 13e th = xe stories260k
scoreboard players operation 13s th = xs stories260k
scoreboard players operation xb stories260k = 14b th
scoreboard players operation xe stories260k = 14e th
scoreboard players operation xs stories260k = 14s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 14b th2
scoreboard players operation xe stories260k = 14e th2
scoreboard players operation xs stories260k = 14s th2
function stories260k:div
scoreboard players operation yb stories260k = 14b th
scoreboard players operation ye stories260k = 14e th
scoreboard players operation ys stories260k = 14s th
function stories260k:mul
scoreboard players operation 14b th = xb stories260k
scoreboard players operation 14e th = xe stories260k
scoreboard players operation 14s th = xs stories260k
scoreboard players operation xb stories260k = 15b th
scoreboard players operation xe stories260k = 15e th
scoreboard players operation xs stories260k = 15s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 15b th2
scoreboard players operation xe stories260k = 15e th2
scoreboard players operation xs stories260k = 15s th2
function stories260k:div
scoreboard players operation yb stories260k = 15b th
scoreboard players operation ye stories260k = 15e th
scoreboard players operation ys stories260k = 15s th
function stories260k:mul
scoreboard players operation 15b th = xb stories260k
scoreboard players operation 15e th = xe stories260k
scoreboard players operation 15s th = xs stories260k
scoreboard players operation xb stories260k = 16b th
scoreboard players operation xe stories260k = 16e th
scoreboard players operation xs stories260k = 16s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 16b th2
scoreboard players operation xe stories260k = 16e th2
scoreboard players operation xs stories260k = 16s th2
function stories260k:div
scoreboard players operation yb stories260k = 16b th
scoreboard players operation ye stories260k = 16e th
scoreboard players operation ys stories260k = 16s th
function stories260k:mul
scoreboard players operation 16b th = xb stories260k
scoreboard players operation 16e th = xe stories260k
scoreboard players operation 16s th = xs stories260k
scoreboard players operation xb stories260k = 17b th
scoreboard players operation xe stories260k = 17e th
scoreboard players operation xs stories260k = 17s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 17b th2
scoreboard players operation xe stories260k = 17e th2
scoreboard players operation xs stories260k = 17s th2
function stories260k:div
scoreboard players operation yb stories260k = 17b th
scoreboard players operation ye stories260k = 17e th
scoreboard players operation ys stories260k = 17s th
function stories260k:mul
scoreboard players operation 17b th = xb stories260k
scoreboard players operation 17e th = xe stories260k
scoreboard players operation 17s th = xs stories260k
scoreboard players operation xb stories260k = 18b th
scoreboard players operation xe stories260k = 18e th
scoreboard players operation xs stories260k = 18s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 18b th2
scoreboard players operation xe stories260k = 18e th2
scoreboard players operation xs stories260k = 18s th2
function stories260k:div
scoreboard players operation yb stories260k = 18b th
scoreboard players operation ye stories260k = 18e th
scoreboard players operation ys stories260k = 18s th
function stories260k:mul
scoreboard players operation 18b th = xb stories260k
scoreboard players operation 18e th = xe stories260k
scoreboard players operation 18s th = xs stories260k
scoreboard players operation xb stories260k = 19b th
scoreboard players operation xe stories260k = 19e th
scoreboard players operation xs stories260k = 19s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 19b th2
scoreboard players operation xe stories260k = 19e th2
scoreboard players operation xs stories260k = 19s th2
function stories260k:div
scoreboard players operation yb stories260k = 19b th
scoreboard players operation ye stories260k = 19e th
scoreboard players operation ys stories260k = 19s th
function stories260k:mul
scoreboard players operation 19b th = xb stories260k
scoreboard players operation 19e th = xe stories260k
scoreboard players operation 19s th = xs stories260k
scoreboard players operation xb stories260k = 20b th
scoreboard players operation xe stories260k = 20e th
scoreboard players operation xs stories260k = 20s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 20b th2
scoreboard players operation xe stories260k = 20e th2
scoreboard players operation xs stories260k = 20s th2
function stories260k:div
scoreboard players operation yb stories260k = 20b th
scoreboard players operation ye stories260k = 20e th
scoreboard players operation ys stories260k = 20s th
function stories260k:mul
scoreboard players operation 20b th = xb stories260k
scoreboard players operation 20e th = xe stories260k
scoreboard players operation 20s th = xs stories260k
scoreboard players operation xb stories260k = 21b th
scoreboard players operation xe stories260k = 21e th
scoreboard players operation xs stories260k = 21s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 21b th2
scoreboard players operation xe stories260k = 21e th2
scoreboard players operation xs stories260k = 21s th2
function stories260k:div
scoreboard players operation yb stories260k = 21b th
scoreboard players operation ye stories260k = 21e th
scoreboard players operation ys stories260k = 21s th
function stories260k:mul
scoreboard players operation 21b th = xb stories260k
scoreboard players operation 21e th = xe stories260k
scoreboard players operation 21s th = xs stories260k
scoreboard players operation xb stories260k = 22b th
scoreboard players operation xe stories260k = 22e th
scoreboard players operation xs stories260k = 22s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 22b th2
scoreboard players operation xe stories260k = 22e th2
scoreboard players operation xs stories260k = 22s th2
function stories260k:div
scoreboard players operation yb stories260k = 22b th
scoreboard players operation ye stories260k = 22e th
scoreboard players operation ys stories260k = 22s th
function stories260k:mul
scoreboard players operation 22b th = xb stories260k
scoreboard players operation 22e th = xe stories260k
scoreboard players operation 22s th = xs stories260k
scoreboard players operation xb stories260k = 23b th
scoreboard players operation xe stories260k = 23e th
scoreboard players operation xs stories260k = 23s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 23b th2
scoreboard players operation xe stories260k = 23e th2
scoreboard players operation xs stories260k = 23s th2
function stories260k:div
scoreboard players operation yb stories260k = 23b th
scoreboard players operation ye stories260k = 23e th
scoreboard players operation ys stories260k = 23s th
function stories260k:mul
scoreboard players operation 23b th = xb stories260k
scoreboard players operation 23e th = xe stories260k
scoreboard players operation 23s th = xs stories260k
scoreboard players operation xb stories260k = 24b th
scoreboard players operation xe stories260k = 24e th
scoreboard players operation xs stories260k = 24s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 24b th2
scoreboard players operation xe stories260k = 24e th2
scoreboard players operation xs stories260k = 24s th2
function stories260k:div
scoreboard players operation yb stories260k = 24b th
scoreboard players operation ye stories260k = 24e th
scoreboard players operation ys stories260k = 24s th
function stories260k:mul
scoreboard players operation 24b th = xb stories260k
scoreboard players operation 24e th = xe stories260k
scoreboard players operation 24s th = xs stories260k
scoreboard players operation xb stories260k = 25b th
scoreboard players operation xe stories260k = 25e th
scoreboard players operation xs stories260k = 25s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 25b th2
scoreboard players operation xe stories260k = 25e th2
scoreboard players operation xs stories260k = 25s th2
function stories260k:div
scoreboard players operation yb stories260k = 25b th
scoreboard players operation ye stories260k = 25e th
scoreboard players operation ys stories260k = 25s th
function stories260k:mul
scoreboard players operation 25b th = xb stories260k
scoreboard players operation 25e th = xe stories260k
scoreboard players operation 25s th = xs stories260k
scoreboard players operation xb stories260k = 26b th
scoreboard players operation xe stories260k = 26e th
scoreboard players operation xs stories260k = 26s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 26b th2
scoreboard players operation xe stories260k = 26e th2
scoreboard players operation xs stories260k = 26s th2
function stories260k:div
scoreboard players operation yb stories260k = 26b th
scoreboard players operation ye stories260k = 26e th
scoreboard players operation ys stories260k = 26s th
function stories260k:mul
scoreboard players operation 26b th = xb stories260k
scoreboard players operation 26e th = xe stories260k
scoreboard players operation 26s th = xs stories260k
scoreboard players operation xb stories260k = 27b th
scoreboard players operation xe stories260k = 27e th
scoreboard players operation xs stories260k = 27s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 27b th2
scoreboard players operation xe stories260k = 27e th2
scoreboard players operation xs stories260k = 27s th2
function stories260k:div
scoreboard players operation yb stories260k = 27b th
scoreboard players operation ye stories260k = 27e th
scoreboard players operation ys stories260k = 27s th
function stories260k:mul
scoreboard players operation 27b th = xb stories260k
scoreboard players operation 27e th = xe stories260k
scoreboard players operation 27s th = xs stories260k
scoreboard players operation xb stories260k = 28b th
scoreboard players operation xe stories260k = 28e th
scoreboard players operation xs stories260k = 28s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 28b th2
scoreboard players operation xe stories260k = 28e th2
scoreboard players operation xs stories260k = 28s th2
function stories260k:div
scoreboard players operation yb stories260k = 28b th
scoreboard players operation ye stories260k = 28e th
scoreboard players operation ys stories260k = 28s th
function stories260k:mul
scoreboard players operation 28b th = xb stories260k
scoreboard players operation 28e th = xe stories260k
scoreboard players operation 28s th = xs stories260k
scoreboard players operation xb stories260k = 29b th
scoreboard players operation xe stories260k = 29e th
scoreboard players operation xs stories260k = 29s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 29b th2
scoreboard players operation xe stories260k = 29e th2
scoreboard players operation xs stories260k = 29s th2
function stories260k:div
scoreboard players operation yb stories260k = 29b th
scoreboard players operation ye stories260k = 29e th
scoreboard players operation ys stories260k = 29s th
function stories260k:mul
scoreboard players operation 29b th = xb stories260k
scoreboard players operation 29e th = xe stories260k
scoreboard players operation 29s th = xs stories260k
scoreboard players operation xb stories260k = 30b th
scoreboard players operation xe stories260k = 30e th
scoreboard players operation xs stories260k = 30s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 30b th2
scoreboard players operation xe stories260k = 30e th2
scoreboard players operation xs stories260k = 30s th2
function stories260k:div
scoreboard players operation yb stories260k = 30b th
scoreboard players operation ye stories260k = 30e th
scoreboard players operation ys stories260k = 30s th
function stories260k:mul
scoreboard players operation 30b th = xb stories260k
scoreboard players operation 30e th = xe stories260k
scoreboard players operation 30s th = xs stories260k
scoreboard players operation xb stories260k = 31b th
scoreboard players operation xe stories260k = 31e th
scoreboard players operation xs stories260k = 31s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 31b th2
scoreboard players operation xe stories260k = 31e th2
scoreboard players operation xs stories260k = 31s th2
function stories260k:div
scoreboard players operation yb stories260k = 31b th
scoreboard players operation ye stories260k = 31e th
scoreboard players operation ys stories260k = 31s th
function stories260k:mul
scoreboard players operation 31b th = xb stories260k
scoreboard players operation 31e th = xe stories260k
scoreboard players operation 31s th = xs stories260k
scoreboard players operation xb stories260k = 32b th
scoreboard players operation xe stories260k = 32e th
scoreboard players operation xs stories260k = 32s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 32b th2
scoreboard players operation xe stories260k = 32e th2
scoreboard players operation xs stories260k = 32s th2
function stories260k:div
scoreboard players operation yb stories260k = 32b th
scoreboard players operation ye stories260k = 32e th
scoreboard players operation ys stories260k = 32s th
function stories260k:mul
scoreboard players operation 32b th = xb stories260k
scoreboard players operation 32e th = xe stories260k
scoreboard players operation 32s th = xs stories260k
scoreboard players operation xb stories260k = 33b th
scoreboard players operation xe stories260k = 33e th
scoreboard players operation xs stories260k = 33s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 33b th2
scoreboard players operation xe stories260k = 33e th2
scoreboard players operation xs stories260k = 33s th2
function stories260k:div
scoreboard players operation yb stories260k = 33b th
scoreboard players operation ye stories260k = 33e th
scoreboard players operation ys stories260k = 33s th
function stories260k:mul
scoreboard players operation 33b th = xb stories260k
scoreboard players operation 33e th = xe stories260k
scoreboard players operation 33s th = xs stories260k
scoreboard players operation xb stories260k = 34b th
scoreboard players operation xe stories260k = 34e th
scoreboard players operation xs stories260k = 34s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 34b th2
scoreboard players operation xe stories260k = 34e th2
scoreboard players operation xs stories260k = 34s th2
function stories260k:div
scoreboard players operation yb stories260k = 34b th
scoreboard players operation ye stories260k = 34e th
scoreboard players operation ys stories260k = 34s th
function stories260k:mul
scoreboard players operation 34b th = xb stories260k
scoreboard players operation 34e th = xe stories260k
scoreboard players operation 34s th = xs stories260k
scoreboard players operation xb stories260k = 35b th
scoreboard players operation xe stories260k = 35e th
scoreboard players operation xs stories260k = 35s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 35b th2
scoreboard players operation xe stories260k = 35e th2
scoreboard players operation xs stories260k = 35s th2
function stories260k:div
scoreboard players operation yb stories260k = 35b th
scoreboard players operation ye stories260k = 35e th
scoreboard players operation ys stories260k = 35s th
function stories260k:mul
scoreboard players operation 35b th = xb stories260k
scoreboard players operation 35e th = xe stories260k
scoreboard players operation 35s th = xs stories260k
scoreboard players operation xb stories260k = 36b th
scoreboard players operation xe stories260k = 36e th
scoreboard players operation xs stories260k = 36s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 36b th2
scoreboard players operation xe stories260k = 36e th2
scoreboard players operation xs stories260k = 36s th2
function stories260k:div
scoreboard players operation yb stories260k = 36b th
scoreboard players operation ye stories260k = 36e th
scoreboard players operation ys stories260k = 36s th
function stories260k:mul
scoreboard players operation 36b th = xb stories260k
scoreboard players operation 36e th = xe stories260k
scoreboard players operation 36s th = xs stories260k
scoreboard players operation xb stories260k = 37b th
scoreboard players operation xe stories260k = 37e th
scoreboard players operation xs stories260k = 37s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 37b th2
scoreboard players operation xe stories260k = 37e th2
scoreboard players operation xs stories260k = 37s th2
function stories260k:div
scoreboard players operation yb stories260k = 37b th
scoreboard players operation ye stories260k = 37e th
scoreboard players operation ys stories260k = 37s th
function stories260k:mul
scoreboard players operation 37b th = xb stories260k
scoreboard players operation 37e th = xe stories260k
scoreboard players operation 37s th = xs stories260k
scoreboard players operation xb stories260k = 38b th
scoreboard players operation xe stories260k = 38e th
scoreboard players operation xs stories260k = 38s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 38b th2
scoreboard players operation xe stories260k = 38e th2
scoreboard players operation xs stories260k = 38s th2
function stories260k:div
scoreboard players operation yb stories260k = 38b th
scoreboard players operation ye stories260k = 38e th
scoreboard players operation ys stories260k = 38s th
function stories260k:mul
scoreboard players operation 38b th = xb stories260k
scoreboard players operation 38e th = xe stories260k
scoreboard players operation 38s th = xs stories260k
scoreboard players operation xb stories260k = 39b th
scoreboard players operation xe stories260k = 39e th
scoreboard players operation xs stories260k = 39s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 39b th2
scoreboard players operation xe stories260k = 39e th2
scoreboard players operation xs stories260k = 39s th2
function stories260k:div
scoreboard players operation yb stories260k = 39b th
scoreboard players operation ye stories260k = 39e th
scoreboard players operation ys stories260k = 39s th
function stories260k:mul
scoreboard players operation 39b th = xb stories260k
scoreboard players operation 39e th = xe stories260k
scoreboard players operation 39s th = xs stories260k
scoreboard players operation xb stories260k = 40b th
scoreboard players operation xe stories260k = 40e th
scoreboard players operation xs stories260k = 40s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 40b th2
scoreboard players operation xe stories260k = 40e th2
scoreboard players operation xs stories260k = 40s th2
function stories260k:div
scoreboard players operation yb stories260k = 40b th
scoreboard players operation ye stories260k = 40e th
scoreboard players operation ys stories260k = 40s th
function stories260k:mul
scoreboard players operation 40b th = xb stories260k
scoreboard players operation 40e th = xe stories260k
scoreboard players operation 40s th = xs stories260k
scoreboard players operation xb stories260k = 41b th
scoreboard players operation xe stories260k = 41e th
scoreboard players operation xs stories260k = 41s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 41b th2
scoreboard players operation xe stories260k = 41e th2
scoreboard players operation xs stories260k = 41s th2
function stories260k:div
scoreboard players operation yb stories260k = 41b th
scoreboard players operation ye stories260k = 41e th
scoreboard players operation ys stories260k = 41s th
function stories260k:mul
scoreboard players operation 41b th = xb stories260k
scoreboard players operation 41e th = xe stories260k
scoreboard players operation 41s th = xs stories260k
scoreboard players operation xb stories260k = 42b th
scoreboard players operation xe stories260k = 42e th
scoreboard players operation xs stories260k = 42s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 42b th2
scoreboard players operation xe stories260k = 42e th2
scoreboard players operation xs stories260k = 42s th2
function stories260k:div
scoreboard players operation yb stories260k = 42b th
scoreboard players operation ye stories260k = 42e th
scoreboard players operation ys stories260k = 42s th
function stories260k:mul
scoreboard players operation 42b th = xb stories260k
scoreboard players operation 42e th = xe stories260k
scoreboard players operation 42s th = xs stories260k
scoreboard players operation xb stories260k = 43b th
scoreboard players operation xe stories260k = 43e th
scoreboard players operation xs stories260k = 43s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 43b th2
scoreboard players operation xe stories260k = 43e th2
scoreboard players operation xs stories260k = 43s th2
function stories260k:div
scoreboard players operation yb stories260k = 43b th
scoreboard players operation ye stories260k = 43e th
scoreboard players operation ys stories260k = 43s th
function stories260k:mul
scoreboard players operation 43b th = xb stories260k
scoreboard players operation 43e th = xe stories260k
scoreboard players operation 43s th = xs stories260k
scoreboard players operation xb stories260k = 44b th
scoreboard players operation xe stories260k = 44e th
scoreboard players operation xs stories260k = 44s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 44b th2
scoreboard players operation xe stories260k = 44e th2
scoreboard players operation xs stories260k = 44s th2
function stories260k:div
scoreboard players operation yb stories260k = 44b th
scoreboard players operation ye stories260k = 44e th
scoreboard players operation ys stories260k = 44s th
function stories260k:mul
scoreboard players operation 44b th = xb stories260k
scoreboard players operation 44e th = xe stories260k
scoreboard players operation 44s th = xs stories260k
scoreboard players operation xb stories260k = 45b th
scoreboard players operation xe stories260k = 45e th
scoreboard players operation xs stories260k = 45s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 45b th2
scoreboard players operation xe stories260k = 45e th2
scoreboard players operation xs stories260k = 45s th2
function stories260k:div
scoreboard players operation yb stories260k = 45b th
scoreboard players operation ye stories260k = 45e th
scoreboard players operation ys stories260k = 45s th
function stories260k:mul
scoreboard players operation 45b th = xb stories260k
scoreboard players operation 45e th = xe stories260k
scoreboard players operation 45s th = xs stories260k
scoreboard players operation xb stories260k = 46b th
scoreboard players operation xe stories260k = 46e th
scoreboard players operation xs stories260k = 46s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 46b th2
scoreboard players operation xe stories260k = 46e th2
scoreboard players operation xs stories260k = 46s th2
function stories260k:div
scoreboard players operation yb stories260k = 46b th
scoreboard players operation ye stories260k = 46e th
scoreboard players operation ys stories260k = 46s th
function stories260k:mul
scoreboard players operation 46b th = xb stories260k
scoreboard players operation 46e th = xe stories260k
scoreboard players operation 46s th = xs stories260k
scoreboard players operation xb stories260k = 47b th
scoreboard players operation xe stories260k = 47e th
scoreboard players operation xs stories260k = 47s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 47b th2
scoreboard players operation xe stories260k = 47e th2
scoreboard players operation xs stories260k = 47s th2
function stories260k:div
scoreboard players operation yb stories260k = 47b th
scoreboard players operation ye stories260k = 47e th
scoreboard players operation ys stories260k = 47s th
function stories260k:mul
scoreboard players operation 47b th = xb stories260k
scoreboard players operation 47e th = xe stories260k
scoreboard players operation 47s th = xs stories260k
scoreboard players operation xb stories260k = 48b th
scoreboard players operation xe stories260k = 48e th
scoreboard players operation xs stories260k = 48s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 48b th2
scoreboard players operation xe stories260k = 48e th2
scoreboard players operation xs stories260k = 48s th2
function stories260k:div
scoreboard players operation yb stories260k = 48b th
scoreboard players operation ye stories260k = 48e th
scoreboard players operation ys stories260k = 48s th
function stories260k:mul
scoreboard players operation 48b th = xb stories260k
scoreboard players operation 48e th = xe stories260k
scoreboard players operation 48s th = xs stories260k
scoreboard players operation xb stories260k = 49b th
scoreboard players operation xe stories260k = 49e th
scoreboard players operation xs stories260k = 49s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 49b th2
scoreboard players operation xe stories260k = 49e th2
scoreboard players operation xs stories260k = 49s th2
function stories260k:div
scoreboard players operation yb stories260k = 49b th
scoreboard players operation ye stories260k = 49e th
scoreboard players operation ys stories260k = 49s th
function stories260k:mul
scoreboard players operation 49b th = xb stories260k
scoreboard players operation 49e th = xe stories260k
scoreboard players operation 49s th = xs stories260k
scoreboard players operation xb stories260k = 50b th
scoreboard players operation xe stories260k = 50e th
scoreboard players operation xs stories260k = 50s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 50b th2
scoreboard players operation xe stories260k = 50e th2
scoreboard players operation xs stories260k = 50s th2
function stories260k:div
scoreboard players operation yb stories260k = 50b th
scoreboard players operation ye stories260k = 50e th
scoreboard players operation ys stories260k = 50s th
function stories260k:mul
scoreboard players operation 50b th = xb stories260k
scoreboard players operation 50e th = xe stories260k
scoreboard players operation 50s th = xs stories260k
scoreboard players operation xb stories260k = 51b th
scoreboard players operation xe stories260k = 51e th
scoreboard players operation xs stories260k = 51s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 51b th2
scoreboard players operation xe stories260k = 51e th2
scoreboard players operation xs stories260k = 51s th2
function stories260k:div
scoreboard players operation yb stories260k = 51b th
scoreboard players operation ye stories260k = 51e th
scoreboard players operation ys stories260k = 51s th
function stories260k:mul
scoreboard players operation 51b th = xb stories260k
scoreboard players operation 51e th = xe stories260k
scoreboard players operation 51s th = xs stories260k
scoreboard players operation xb stories260k = 52b th
scoreboard players operation xe stories260k = 52e th
scoreboard players operation xs stories260k = 52s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 52b th2
scoreboard players operation xe stories260k = 52e th2
scoreboard players operation xs stories260k = 52s th2
function stories260k:div
scoreboard players operation yb stories260k = 52b th
scoreboard players operation ye stories260k = 52e th
scoreboard players operation ys stories260k = 52s th
function stories260k:mul
scoreboard players operation 52b th = xb stories260k
scoreboard players operation 52e th = xe stories260k
scoreboard players operation 52s th = xs stories260k
scoreboard players operation xb stories260k = 53b th
scoreboard players operation xe stories260k = 53e th
scoreboard players operation xs stories260k = 53s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 53b th2
scoreboard players operation xe stories260k = 53e th2
scoreboard players operation xs stories260k = 53s th2
function stories260k:div
scoreboard players operation yb stories260k = 53b th
scoreboard players operation ye stories260k = 53e th
scoreboard players operation ys stories260k = 53s th
function stories260k:mul
scoreboard players operation 53b th = xb stories260k
scoreboard players operation 53e th = xe stories260k
scoreboard players operation 53s th = xs stories260k
scoreboard players operation xb stories260k = 54b th
scoreboard players operation xe stories260k = 54e th
scoreboard players operation xs stories260k = 54s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 54b th2
scoreboard players operation xe stories260k = 54e th2
scoreboard players operation xs stories260k = 54s th2
function stories260k:div
scoreboard players operation yb stories260k = 54b th
scoreboard players operation ye stories260k = 54e th
scoreboard players operation ys stories260k = 54s th
function stories260k:mul
scoreboard players operation 54b th = xb stories260k
scoreboard players operation 54e th = xe stories260k
scoreboard players operation 54s th = xs stories260k
scoreboard players operation xb stories260k = 55b th
scoreboard players operation xe stories260k = 55e th
scoreboard players operation xs stories260k = 55s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 55b th2
scoreboard players operation xe stories260k = 55e th2
scoreboard players operation xs stories260k = 55s th2
function stories260k:div
scoreboard players operation yb stories260k = 55b th
scoreboard players operation ye stories260k = 55e th
scoreboard players operation ys stories260k = 55s th
function stories260k:mul
scoreboard players operation 55b th = xb stories260k
scoreboard players operation 55e th = xe stories260k
scoreboard players operation 55s th = xs stories260k
scoreboard players operation xb stories260k = 56b th
scoreboard players operation xe stories260k = 56e th
scoreboard players operation xs stories260k = 56s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 56b th2
scoreboard players operation xe stories260k = 56e th2
scoreboard players operation xs stories260k = 56s th2
function stories260k:div
scoreboard players operation yb stories260k = 56b th
scoreboard players operation ye stories260k = 56e th
scoreboard players operation ys stories260k = 56s th
function stories260k:mul
scoreboard players operation 56b th = xb stories260k
scoreboard players operation 56e th = xe stories260k
scoreboard players operation 56s th = xs stories260k
scoreboard players operation xb stories260k = 57b th
scoreboard players operation xe stories260k = 57e th
scoreboard players operation xs stories260k = 57s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 57b th2
scoreboard players operation xe stories260k = 57e th2
scoreboard players operation xs stories260k = 57s th2
function stories260k:div
scoreboard players operation yb stories260k = 57b th
scoreboard players operation ye stories260k = 57e th
scoreboard players operation ys stories260k = 57s th
function stories260k:mul
scoreboard players operation 57b th = xb stories260k
scoreboard players operation 57e th = xe stories260k
scoreboard players operation 57s th = xs stories260k
scoreboard players operation xb stories260k = 58b th
scoreboard players operation xe stories260k = 58e th
scoreboard players operation xs stories260k = 58s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 58b th2
scoreboard players operation xe stories260k = 58e th2
scoreboard players operation xs stories260k = 58s th2
function stories260k:div
scoreboard players operation yb stories260k = 58b th
scoreboard players operation ye stories260k = 58e th
scoreboard players operation ys stories260k = 58s th
function stories260k:mul
scoreboard players operation 58b th = xb stories260k
scoreboard players operation 58e th = xe stories260k
scoreboard players operation 58s th = xs stories260k
scoreboard players operation xb stories260k = 59b th
scoreboard players operation xe stories260k = 59e th
scoreboard players operation xs stories260k = 59s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 59b th2
scoreboard players operation xe stories260k = 59e th2
scoreboard players operation xs stories260k = 59s th2
function stories260k:div
scoreboard players operation yb stories260k = 59b th
scoreboard players operation ye stories260k = 59e th
scoreboard players operation ys stories260k = 59s th
function stories260k:mul
scoreboard players operation 59b th = xb stories260k
scoreboard players operation 59e th = xe stories260k
scoreboard players operation 59s th = xs stories260k
scoreboard players operation xb stories260k = 60b th
scoreboard players operation xe stories260k = 60e th
scoreboard players operation xs stories260k = 60s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 60b th2
scoreboard players operation xe stories260k = 60e th2
scoreboard players operation xs stories260k = 60s th2
function stories260k:div
scoreboard players operation yb stories260k = 60b th
scoreboard players operation ye stories260k = 60e th
scoreboard players operation ys stories260k = 60s th
function stories260k:mul
scoreboard players operation 60b th = xb stories260k
scoreboard players operation 60e th = xe stories260k
scoreboard players operation 60s th = xs stories260k
scoreboard players operation xb stories260k = 61b th
scoreboard players operation xe stories260k = 61e th
scoreboard players operation xs stories260k = 61s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 61b th2
scoreboard players operation xe stories260k = 61e th2
scoreboard players operation xs stories260k = 61s th2
function stories260k:div
scoreboard players operation yb stories260k = 61b th
scoreboard players operation ye stories260k = 61e th
scoreboard players operation ys stories260k = 61s th
function stories260k:mul
scoreboard players operation 61b th = xb stories260k
scoreboard players operation 61e th = xe stories260k
scoreboard players operation 61s th = xs stories260k
scoreboard players operation xb stories260k = 62b th
scoreboard players operation xe stories260k = 62e th
scoreboard players operation xs stories260k = 62s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 62b th2
scoreboard players operation xe stories260k = 62e th2
scoreboard players operation xs stories260k = 62s th2
function stories260k:div
scoreboard players operation yb stories260k = 62b th
scoreboard players operation ye stories260k = 62e th
scoreboard players operation ys stories260k = 62s th
function stories260k:mul
scoreboard players operation 62b th = xb stories260k
scoreboard players operation 62e th = xe stories260k
scoreboard players operation 62s th = xs stories260k
scoreboard players operation xb stories260k = 63b th
scoreboard players operation xe stories260k = 63e th
scoreboard players operation xs stories260k = 63s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 63b th2
scoreboard players operation xe stories260k = 63e th2
scoreboard players operation xs stories260k = 63s th2
function stories260k:div
scoreboard players operation yb stories260k = 63b th
scoreboard players operation ye stories260k = 63e th
scoreboard players operation ys stories260k = 63s th
function stories260k:mul
scoreboard players operation 63b th = xb stories260k
scoreboard players operation 63e th = xe stories260k
scoreboard players operation 63s th = xs stories260k
scoreboard players operation xb stories260k = 64b th
scoreboard players operation xe stories260k = 64e th
scoreboard players operation xs stories260k = 64s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 64b th2
scoreboard players operation xe stories260k = 64e th2
scoreboard players operation xs stories260k = 64s th2
function stories260k:div
scoreboard players operation yb stories260k = 64b th
scoreboard players operation ye stories260k = 64e th
scoreboard players operation ys stories260k = 64s th
function stories260k:mul
scoreboard players operation 64b th = xb stories260k
scoreboard players operation 64e th = xe stories260k
scoreboard players operation 64s th = xs stories260k
scoreboard players operation xb stories260k = 65b th
scoreboard players operation xe stories260k = 65e th
scoreboard players operation xs stories260k = 65s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 65b th2
scoreboard players operation xe stories260k = 65e th2
scoreboard players operation xs stories260k = 65s th2
function stories260k:div
scoreboard players operation yb stories260k = 65b th
scoreboard players operation ye stories260k = 65e th
scoreboard players operation ys stories260k = 65s th
function stories260k:mul
scoreboard players operation 65b th = xb stories260k
scoreboard players operation 65e th = xe stories260k
scoreboard players operation 65s th = xs stories260k
scoreboard players operation xb stories260k = 66b th
scoreboard players operation xe stories260k = 66e th
scoreboard players operation xs stories260k = 66s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 66b th2
scoreboard players operation xe stories260k = 66e th2
scoreboard players operation xs stories260k = 66s th2
function stories260k:div
scoreboard players operation yb stories260k = 66b th
scoreboard players operation ye stories260k = 66e th
scoreboard players operation ys stories260k = 66s th
function stories260k:mul
scoreboard players operation 66b th = xb stories260k
scoreboard players operation 66e th = xe stories260k
scoreboard players operation 66s th = xs stories260k
scoreboard players operation xb stories260k = 67b th
scoreboard players operation xe stories260k = 67e th
scoreboard players operation xs stories260k = 67s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 67b th2
scoreboard players operation xe stories260k = 67e th2
scoreboard players operation xs stories260k = 67s th2
function stories260k:div
scoreboard players operation yb stories260k = 67b th
scoreboard players operation ye stories260k = 67e th
scoreboard players operation ys stories260k = 67s th
function stories260k:mul
scoreboard players operation 67b th = xb stories260k
scoreboard players operation 67e th = xe stories260k
scoreboard players operation 67s th = xs stories260k
scoreboard players operation xb stories260k = 68b th
scoreboard players operation xe stories260k = 68e th
scoreboard players operation xs stories260k = 68s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 68b th2
scoreboard players operation xe stories260k = 68e th2
scoreboard players operation xs stories260k = 68s th2
function stories260k:div
scoreboard players operation yb stories260k = 68b th
scoreboard players operation ye stories260k = 68e th
scoreboard players operation ys stories260k = 68s th
function stories260k:mul
scoreboard players operation 68b th = xb stories260k
scoreboard players operation 68e th = xe stories260k
scoreboard players operation 68s th = xs stories260k
scoreboard players operation xb stories260k = 69b th
scoreboard players operation xe stories260k = 69e th
scoreboard players operation xs stories260k = 69s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 69b th2
scoreboard players operation xe stories260k = 69e th2
scoreboard players operation xs stories260k = 69s th2
function stories260k:div
scoreboard players operation yb stories260k = 69b th
scoreboard players operation ye stories260k = 69e th
scoreboard players operation ys stories260k = 69s th
function stories260k:mul
scoreboard players operation 69b th = xb stories260k
scoreboard players operation 69e th = xe stories260k
scoreboard players operation 69s th = xs stories260k
scoreboard players operation xb stories260k = 70b th
scoreboard players operation xe stories260k = 70e th
scoreboard players operation xs stories260k = 70s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 70b th2
scoreboard players operation xe stories260k = 70e th2
scoreboard players operation xs stories260k = 70s th2
function stories260k:div
scoreboard players operation yb stories260k = 70b th
scoreboard players operation ye stories260k = 70e th
scoreboard players operation ys stories260k = 70s th
function stories260k:mul
scoreboard players operation 70b th = xb stories260k
scoreboard players operation 70e th = xe stories260k
scoreboard players operation 70s th = xs stories260k
scoreboard players operation xb stories260k = 71b th
scoreboard players operation xe stories260k = 71e th
scoreboard players operation xs stories260k = 71s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 71b th2
scoreboard players operation xe stories260k = 71e th2
scoreboard players operation xs stories260k = 71s th2
function stories260k:div
scoreboard players operation yb stories260k = 71b th
scoreboard players operation ye stories260k = 71e th
scoreboard players operation ys stories260k = 71s th
function stories260k:mul
scoreboard players operation 71b th = xb stories260k
scoreboard players operation 71e th = xe stories260k
scoreboard players operation 71s th = xs stories260k
scoreboard players operation xb stories260k = 72b th
scoreboard players operation xe stories260k = 72e th
scoreboard players operation xs stories260k = 72s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 72b th2
scoreboard players operation xe stories260k = 72e th2
scoreboard players operation xs stories260k = 72s th2
function stories260k:div
scoreboard players operation yb stories260k = 72b th
scoreboard players operation ye stories260k = 72e th
scoreboard players operation ys stories260k = 72s th
function stories260k:mul
scoreboard players operation 72b th = xb stories260k
scoreboard players operation 72e th = xe stories260k
scoreboard players operation 72s th = xs stories260k
scoreboard players operation xb stories260k = 73b th
scoreboard players operation xe stories260k = 73e th
scoreboard players operation xs stories260k = 73s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 73b th2
scoreboard players operation xe stories260k = 73e th2
scoreboard players operation xs stories260k = 73s th2
function stories260k:div
scoreboard players operation yb stories260k = 73b th
scoreboard players operation ye stories260k = 73e th
scoreboard players operation ys stories260k = 73s th
function stories260k:mul
scoreboard players operation 73b th = xb stories260k
scoreboard players operation 73e th = xe stories260k
scoreboard players operation 73s th = xs stories260k
scoreboard players operation xb stories260k = 74b th
scoreboard players operation xe stories260k = 74e th
scoreboard players operation xs stories260k = 74s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 74b th2
scoreboard players operation xe stories260k = 74e th2
scoreboard players operation xs stories260k = 74s th2
function stories260k:div
scoreboard players operation yb stories260k = 74b th
scoreboard players operation ye stories260k = 74e th
scoreboard players operation ys stories260k = 74s th
function stories260k:mul
scoreboard players operation 74b th = xb stories260k
scoreboard players operation 74e th = xe stories260k
scoreboard players operation 74s th = xs stories260k
scoreboard players operation xb stories260k = 75b th
scoreboard players operation xe stories260k = 75e th
scoreboard players operation xs stories260k = 75s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 75b th2
scoreboard players operation xe stories260k = 75e th2
scoreboard players operation xs stories260k = 75s th2
function stories260k:div
scoreboard players operation yb stories260k = 75b th
scoreboard players operation ye stories260k = 75e th
scoreboard players operation ys stories260k = 75s th
function stories260k:mul
scoreboard players operation 75b th = xb stories260k
scoreboard players operation 75e th = xe stories260k
scoreboard players operation 75s th = xs stories260k
scoreboard players operation xb stories260k = 76b th
scoreboard players operation xe stories260k = 76e th
scoreboard players operation xs stories260k = 76s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 76b th2
scoreboard players operation xe stories260k = 76e th2
scoreboard players operation xs stories260k = 76s th2
function stories260k:div
scoreboard players operation yb stories260k = 76b th
scoreboard players operation ye stories260k = 76e th
scoreboard players operation ys stories260k = 76s th
function stories260k:mul
scoreboard players operation 76b th = xb stories260k
scoreboard players operation 76e th = xe stories260k
scoreboard players operation 76s th = xs stories260k
scoreboard players operation xb stories260k = 77b th
scoreboard players operation xe stories260k = 77e th
scoreboard players operation xs stories260k = 77s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 77b th2
scoreboard players operation xe stories260k = 77e th2
scoreboard players operation xs stories260k = 77s th2
function stories260k:div
scoreboard players operation yb stories260k = 77b th
scoreboard players operation ye stories260k = 77e th
scoreboard players operation ys stories260k = 77s th
function stories260k:mul
scoreboard players operation 77b th = xb stories260k
scoreboard players operation 77e th = xe stories260k
scoreboard players operation 77s th = xs stories260k
scoreboard players operation xb stories260k = 78b th
scoreboard players operation xe stories260k = 78e th
scoreboard players operation xs stories260k = 78s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 78b th2
scoreboard players operation xe stories260k = 78e th2
scoreboard players operation xs stories260k = 78s th2
function stories260k:div
scoreboard players operation yb stories260k = 78b th
scoreboard players operation ye stories260k = 78e th
scoreboard players operation ys stories260k = 78s th
function stories260k:mul
scoreboard players operation 78b th = xb stories260k
scoreboard players operation 78e th = xe stories260k
scoreboard players operation 78s th = xs stories260k
scoreboard players operation xb stories260k = 79b th
scoreboard players operation xe stories260k = 79e th
scoreboard players operation xs stories260k = 79s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 79b th2
scoreboard players operation xe stories260k = 79e th2
scoreboard players operation xs stories260k = 79s th2
function stories260k:div
scoreboard players operation yb stories260k = 79b th
scoreboard players operation ye stories260k = 79e th
scoreboard players operation ys stories260k = 79s th
function stories260k:mul
scoreboard players operation 79b th = xb stories260k
scoreboard players operation 79e th = xe stories260k
scoreboard players operation 79s th = xs stories260k
scoreboard players operation xb stories260k = 80b th
scoreboard players operation xe stories260k = 80e th
scoreboard players operation xs stories260k = 80s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 80b th2
scoreboard players operation xe stories260k = 80e th2
scoreboard players operation xs stories260k = 80s th2
function stories260k:div
scoreboard players operation yb stories260k = 80b th
scoreboard players operation ye stories260k = 80e th
scoreboard players operation ys stories260k = 80s th
function stories260k:mul
scoreboard players operation 80b th = xb stories260k
scoreboard players operation 80e th = xe stories260k
scoreboard players operation 80s th = xs stories260k
scoreboard players operation xb stories260k = 81b th
scoreboard players operation xe stories260k = 81e th
scoreboard players operation xs stories260k = 81s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 81b th2
scoreboard players operation xe stories260k = 81e th2
scoreboard players operation xs stories260k = 81s th2
function stories260k:div
scoreboard players operation yb stories260k = 81b th
scoreboard players operation ye stories260k = 81e th
scoreboard players operation ys stories260k = 81s th
function stories260k:mul
scoreboard players operation 81b th = xb stories260k
scoreboard players operation 81e th = xe stories260k
scoreboard players operation 81s th = xs stories260k
scoreboard players operation xb stories260k = 82b th
scoreboard players operation xe stories260k = 82e th
scoreboard players operation xs stories260k = 82s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 82b th2
scoreboard players operation xe stories260k = 82e th2
scoreboard players operation xs stories260k = 82s th2
function stories260k:div
scoreboard players operation yb stories260k = 82b th
scoreboard players operation ye stories260k = 82e th
scoreboard players operation ys stories260k = 82s th
function stories260k:mul
scoreboard players operation 82b th = xb stories260k
scoreboard players operation 82e th = xe stories260k
scoreboard players operation 82s th = xs stories260k
scoreboard players operation xb stories260k = 83b th
scoreboard players operation xe stories260k = 83e th
scoreboard players operation xs stories260k = 83s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 83b th2
scoreboard players operation xe stories260k = 83e th2
scoreboard players operation xs stories260k = 83s th2
function stories260k:div
scoreboard players operation yb stories260k = 83b th
scoreboard players operation ye stories260k = 83e th
scoreboard players operation ys stories260k = 83s th
function stories260k:mul
scoreboard players operation 83b th = xb stories260k
scoreboard players operation 83e th = xe stories260k
scoreboard players operation 83s th = xs stories260k
scoreboard players operation xb stories260k = 84b th
scoreboard players operation xe stories260k = 84e th
scoreboard players operation xs stories260k = 84s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 84b th2
scoreboard players operation xe stories260k = 84e th2
scoreboard players operation xs stories260k = 84s th2
function stories260k:div
scoreboard players operation yb stories260k = 84b th
scoreboard players operation ye stories260k = 84e th
scoreboard players operation ys stories260k = 84s th
function stories260k:mul
scoreboard players operation 84b th = xb stories260k
scoreboard players operation 84e th = xe stories260k
scoreboard players operation 84s th = xs stories260k
scoreboard players operation xb stories260k = 85b th
scoreboard players operation xe stories260k = 85e th
scoreboard players operation xs stories260k = 85s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 85b th2
scoreboard players operation xe stories260k = 85e th2
scoreboard players operation xs stories260k = 85s th2
function stories260k:div
scoreboard players operation yb stories260k = 85b th
scoreboard players operation ye stories260k = 85e th
scoreboard players operation ys stories260k = 85s th
function stories260k:mul
scoreboard players operation 85b th = xb stories260k
scoreboard players operation 85e th = xe stories260k
scoreboard players operation 85s th = xs stories260k
scoreboard players operation xb stories260k = 86b th
scoreboard players operation xe stories260k = 86e th
scoreboard players operation xs stories260k = 86s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 86b th2
scoreboard players operation xe stories260k = 86e th2
scoreboard players operation xs stories260k = 86s th2
function stories260k:div
scoreboard players operation yb stories260k = 86b th
scoreboard players operation ye stories260k = 86e th
scoreboard players operation ys stories260k = 86s th
function stories260k:mul
scoreboard players operation 86b th = xb stories260k
scoreboard players operation 86e th = xe stories260k
scoreboard players operation 86s th = xs stories260k
scoreboard players operation xb stories260k = 87b th
scoreboard players operation xe stories260k = 87e th
scoreboard players operation xs stories260k = 87s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 87b th2
scoreboard players operation xe stories260k = 87e th2
scoreboard players operation xs stories260k = 87s th2
function stories260k:div
scoreboard players operation yb stories260k = 87b th
scoreboard players operation ye stories260k = 87e th
scoreboard players operation ys stories260k = 87s th
function stories260k:mul
scoreboard players operation 87b th = xb stories260k
scoreboard players operation 87e th = xe stories260k
scoreboard players operation 87s th = xs stories260k
scoreboard players operation xb stories260k = 88b th
scoreboard players operation xe stories260k = 88e th
scoreboard players operation xs stories260k = 88s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 88b th2
scoreboard players operation xe stories260k = 88e th2
scoreboard players operation xs stories260k = 88s th2
function stories260k:div
scoreboard players operation yb stories260k = 88b th
scoreboard players operation ye stories260k = 88e th
scoreboard players operation ys stories260k = 88s th
function stories260k:mul
scoreboard players operation 88b th = xb stories260k
scoreboard players operation 88e th = xe stories260k
scoreboard players operation 88s th = xs stories260k
scoreboard players operation xb stories260k = 89b th
scoreboard players operation xe stories260k = 89e th
scoreboard players operation xs stories260k = 89s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 89b th2
scoreboard players operation xe stories260k = 89e th2
scoreboard players operation xs stories260k = 89s th2
function stories260k:div
scoreboard players operation yb stories260k = 89b th
scoreboard players operation ye stories260k = 89e th
scoreboard players operation ys stories260k = 89s th
function stories260k:mul
scoreboard players operation 89b th = xb stories260k
scoreboard players operation 89e th = xe stories260k
scoreboard players operation 89s th = xs stories260k
scoreboard players operation xb stories260k = 90b th
scoreboard players operation xe stories260k = 90e th
scoreboard players operation xs stories260k = 90s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 90b th2
scoreboard players operation xe stories260k = 90e th2
scoreboard players operation xs stories260k = 90s th2
function stories260k:div
scoreboard players operation yb stories260k = 90b th
scoreboard players operation ye stories260k = 90e th
scoreboard players operation ys stories260k = 90s th
function stories260k:mul
scoreboard players operation 90b th = xb stories260k
scoreboard players operation 90e th = xe stories260k
scoreboard players operation 90s th = xs stories260k
scoreboard players operation xb stories260k = 91b th
scoreboard players operation xe stories260k = 91e th
scoreboard players operation xs stories260k = 91s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 91b th2
scoreboard players operation xe stories260k = 91e th2
scoreboard players operation xs stories260k = 91s th2
function stories260k:div
scoreboard players operation yb stories260k = 91b th
scoreboard players operation ye stories260k = 91e th
scoreboard players operation ys stories260k = 91s th
function stories260k:mul
scoreboard players operation 91b th = xb stories260k
scoreboard players operation 91e th = xe stories260k
scoreboard players operation 91s th = xs stories260k
scoreboard players operation xb stories260k = 92b th
scoreboard players operation xe stories260k = 92e th
scoreboard players operation xs stories260k = 92s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 92b th2
scoreboard players operation xe stories260k = 92e th2
scoreboard players operation xs stories260k = 92s th2
function stories260k:div
scoreboard players operation yb stories260k = 92b th
scoreboard players operation ye stories260k = 92e th
scoreboard players operation ys stories260k = 92s th
function stories260k:mul
scoreboard players operation 92b th = xb stories260k
scoreboard players operation 92e th = xe stories260k
scoreboard players operation 92s th = xs stories260k
scoreboard players operation xb stories260k = 93b th
scoreboard players operation xe stories260k = 93e th
scoreboard players operation xs stories260k = 93s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 93b th2
scoreboard players operation xe stories260k = 93e th2
scoreboard players operation xs stories260k = 93s th2
function stories260k:div
scoreboard players operation yb stories260k = 93b th
scoreboard players operation ye stories260k = 93e th
scoreboard players operation ys stories260k = 93s th
function stories260k:mul
scoreboard players operation 93b th = xb stories260k
scoreboard players operation 93e th = xe stories260k
scoreboard players operation 93s th = xs stories260k
scoreboard players operation xb stories260k = 94b th
scoreboard players operation xe stories260k = 94e th
scoreboard players operation xs stories260k = 94s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 94b th2
scoreboard players operation xe stories260k = 94e th2
scoreboard players operation xs stories260k = 94s th2
function stories260k:div
scoreboard players operation yb stories260k = 94b th
scoreboard players operation ye stories260k = 94e th
scoreboard players operation ys stories260k = 94s th
function stories260k:mul
scoreboard players operation 94b th = xb stories260k
scoreboard players operation 94e th = xe stories260k
scoreboard players operation 94s th = xs stories260k
scoreboard players operation xb stories260k = 95b th
scoreboard players operation xe stories260k = 95e th
scoreboard players operation xs stories260k = 95s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 95b th2
scoreboard players operation xe stories260k = 95e th2
scoreboard players operation xs stories260k = 95s th2
function stories260k:div
scoreboard players operation yb stories260k = 95b th
scoreboard players operation ye stories260k = 95e th
scoreboard players operation ys stories260k = 95s th
function stories260k:mul
scoreboard players operation 95b th = xb stories260k
scoreboard players operation 95e th = xe stories260k
scoreboard players operation 95s th = xs stories260k
scoreboard players operation xb stories260k = 96b th
scoreboard players operation xe stories260k = 96e th
scoreboard players operation xs stories260k = 96s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 96b th2
scoreboard players operation xe stories260k = 96e th2
scoreboard players operation xs stories260k = 96s th2
function stories260k:div
scoreboard players operation yb stories260k = 96b th
scoreboard players operation ye stories260k = 96e th
scoreboard players operation ys stories260k = 96s th
function stories260k:mul
scoreboard players operation 96b th = xb stories260k
scoreboard players operation 96e th = xe stories260k
scoreboard players operation 96s th = xs stories260k
scoreboard players operation xb stories260k = 97b th
scoreboard players operation xe stories260k = 97e th
scoreboard players operation xs stories260k = 97s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 97b th2
scoreboard players operation xe stories260k = 97e th2
scoreboard players operation xs stories260k = 97s th2
function stories260k:div
scoreboard players operation yb stories260k = 97b th
scoreboard players operation ye stories260k = 97e th
scoreboard players operation ys stories260k = 97s th
function stories260k:mul
scoreboard players operation 97b th = xb stories260k
scoreboard players operation 97e th = xe stories260k
scoreboard players operation 97s th = xs stories260k
scoreboard players operation xb stories260k = 98b th
scoreboard players operation xe stories260k = 98e th
scoreboard players operation xs stories260k = 98s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 98b th2
scoreboard players operation xe stories260k = 98e th2
scoreboard players operation xs stories260k = 98s th2
function stories260k:div
scoreboard players operation yb stories260k = 98b th
scoreboard players operation ye stories260k = 98e th
scoreboard players operation ys stories260k = 98s th
function stories260k:mul
scoreboard players operation 98b th = xb stories260k
scoreboard players operation 98e th = xe stories260k
scoreboard players operation 98s th = xs stories260k
scoreboard players operation xb stories260k = 99b th
scoreboard players operation xe stories260k = 99e th
scoreboard players operation xs stories260k = 99s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 99b th2
scoreboard players operation xe stories260k = 99e th2
scoreboard players operation xs stories260k = 99s th2
function stories260k:div
scoreboard players operation yb stories260k = 99b th
scoreboard players operation ye stories260k = 99e th
scoreboard players operation ys stories260k = 99s th
function stories260k:mul
scoreboard players operation 99b th = xb stories260k
scoreboard players operation 99e th = xe stories260k
scoreboard players operation 99s th = xs stories260k
scoreboard players operation xb stories260k = 100b th
scoreboard players operation xe stories260k = 100e th
scoreboard players operation xs stories260k = 100s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 100b th2
scoreboard players operation xe stories260k = 100e th2
scoreboard players operation xs stories260k = 100s th2
function stories260k:div
scoreboard players operation yb stories260k = 100b th
scoreboard players operation ye stories260k = 100e th
scoreboard players operation ys stories260k = 100s th
function stories260k:mul
scoreboard players operation 100b th = xb stories260k
scoreboard players operation 100e th = xe stories260k
scoreboard players operation 100s th = xs stories260k
scoreboard players operation xb stories260k = 101b th
scoreboard players operation xe stories260k = 101e th
scoreboard players operation xs stories260k = 101s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 101b th2
scoreboard players operation xe stories260k = 101e th2
scoreboard players operation xs stories260k = 101s th2
function stories260k:div
scoreboard players operation yb stories260k = 101b th
scoreboard players operation ye stories260k = 101e th
scoreboard players operation ys stories260k = 101s th
function stories260k:mul
scoreboard players operation 101b th = xb stories260k
scoreboard players operation 101e th = xe stories260k
scoreboard players operation 101s th = xs stories260k
scoreboard players operation xb stories260k = 102b th
scoreboard players operation xe stories260k = 102e th
scoreboard players operation xs stories260k = 102s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 102b th2
scoreboard players operation xe stories260k = 102e th2
scoreboard players operation xs stories260k = 102s th2
function stories260k:div
scoreboard players operation yb stories260k = 102b th
scoreboard players operation ye stories260k = 102e th
scoreboard players operation ys stories260k = 102s th
function stories260k:mul
scoreboard players operation 102b th = xb stories260k
scoreboard players operation 102e th = xe stories260k
scoreboard players operation 102s th = xs stories260k
scoreboard players operation xb stories260k = 103b th
scoreboard players operation xe stories260k = 103e th
scoreboard players operation xs stories260k = 103s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 103b th2
scoreboard players operation xe stories260k = 103e th2
scoreboard players operation xs stories260k = 103s th2
function stories260k:div
scoreboard players operation yb stories260k = 103b th
scoreboard players operation ye stories260k = 103e th
scoreboard players operation ys stories260k = 103s th
function stories260k:mul
scoreboard players operation 103b th = xb stories260k
scoreboard players operation 103e th = xe stories260k
scoreboard players operation 103s th = xs stories260k
scoreboard players operation xb stories260k = 104b th
scoreboard players operation xe stories260k = 104e th
scoreboard players operation xs stories260k = 104s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 104b th2
scoreboard players operation xe stories260k = 104e th2
scoreboard players operation xs stories260k = 104s th2
function stories260k:div
scoreboard players operation yb stories260k = 104b th
scoreboard players operation ye stories260k = 104e th
scoreboard players operation ys stories260k = 104s th
function stories260k:mul
scoreboard players operation 104b th = xb stories260k
scoreboard players operation 104e th = xe stories260k
scoreboard players operation 104s th = xs stories260k
scoreboard players operation xb stories260k = 105b th
scoreboard players operation xe stories260k = 105e th
scoreboard players operation xs stories260k = 105s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 105b th2
scoreboard players operation xe stories260k = 105e th2
scoreboard players operation xs stories260k = 105s th2
function stories260k:div
scoreboard players operation yb stories260k = 105b th
scoreboard players operation ye stories260k = 105e th
scoreboard players operation ys stories260k = 105s th
function stories260k:mul
scoreboard players operation 105b th = xb stories260k
scoreboard players operation 105e th = xe stories260k
scoreboard players operation 105s th = xs stories260k
scoreboard players operation xb stories260k = 106b th
scoreboard players operation xe stories260k = 106e th
scoreboard players operation xs stories260k = 106s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 106b th2
scoreboard players operation xe stories260k = 106e th2
scoreboard players operation xs stories260k = 106s th2
function stories260k:div
scoreboard players operation yb stories260k = 106b th
scoreboard players operation ye stories260k = 106e th
scoreboard players operation ys stories260k = 106s th
function stories260k:mul
scoreboard players operation 106b th = xb stories260k
scoreboard players operation 106e th = xe stories260k
scoreboard players operation 106s th = xs stories260k
scoreboard players operation xb stories260k = 107b th
scoreboard players operation xe stories260k = 107e th
scoreboard players operation xs stories260k = 107s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 107b th2
scoreboard players operation xe stories260k = 107e th2
scoreboard players operation xs stories260k = 107s th2
function stories260k:div
scoreboard players operation yb stories260k = 107b th
scoreboard players operation ye stories260k = 107e th
scoreboard players operation ys stories260k = 107s th
function stories260k:mul
scoreboard players operation 107b th = xb stories260k
scoreboard players operation 107e th = xe stories260k
scoreboard players operation 107s th = xs stories260k
scoreboard players operation xb stories260k = 108b th
scoreboard players operation xe stories260k = 108e th
scoreboard players operation xs stories260k = 108s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 108b th2
scoreboard players operation xe stories260k = 108e th2
scoreboard players operation xs stories260k = 108s th2
function stories260k:div
scoreboard players operation yb stories260k = 108b th
scoreboard players operation ye stories260k = 108e th
scoreboard players operation ys stories260k = 108s th
function stories260k:mul
scoreboard players operation 108b th = xb stories260k
scoreboard players operation 108e th = xe stories260k
scoreboard players operation 108s th = xs stories260k
scoreboard players operation xb stories260k = 109b th
scoreboard players operation xe stories260k = 109e th
scoreboard players operation xs stories260k = 109s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 109b th2
scoreboard players operation xe stories260k = 109e th2
scoreboard players operation xs stories260k = 109s th2
function stories260k:div
scoreboard players operation yb stories260k = 109b th
scoreboard players operation ye stories260k = 109e th
scoreboard players operation ys stories260k = 109s th
function stories260k:mul
scoreboard players operation 109b th = xb stories260k
scoreboard players operation 109e th = xe stories260k
scoreboard players operation 109s th = xs stories260k
scoreboard players operation xb stories260k = 110b th
scoreboard players operation xe stories260k = 110e th
scoreboard players operation xs stories260k = 110s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 110b th2
scoreboard players operation xe stories260k = 110e th2
scoreboard players operation xs stories260k = 110s th2
function stories260k:div
scoreboard players operation yb stories260k = 110b th
scoreboard players operation ye stories260k = 110e th
scoreboard players operation ys stories260k = 110s th
function stories260k:mul
scoreboard players operation 110b th = xb stories260k
scoreboard players operation 110e th = xe stories260k
scoreboard players operation 110s th = xs stories260k
scoreboard players operation xb stories260k = 111b th
scoreboard players operation xe stories260k = 111e th
scoreboard players operation xs stories260k = 111s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 111b th2
scoreboard players operation xe stories260k = 111e th2
scoreboard players operation xs stories260k = 111s th2
function stories260k:div
scoreboard players operation yb stories260k = 111b th
scoreboard players operation ye stories260k = 111e th
scoreboard players operation ys stories260k = 111s th
function stories260k:mul
scoreboard players operation 111b th = xb stories260k
scoreboard players operation 111e th = xe stories260k
scoreboard players operation 111s th = xs stories260k
scoreboard players operation xb stories260k = 112b th
scoreboard players operation xe stories260k = 112e th
scoreboard players operation xs stories260k = 112s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 112b th2
scoreboard players operation xe stories260k = 112e th2
scoreboard players operation xs stories260k = 112s th2
function stories260k:div
scoreboard players operation yb stories260k = 112b th
scoreboard players operation ye stories260k = 112e th
scoreboard players operation ys stories260k = 112s th
function stories260k:mul
scoreboard players operation 112b th = xb stories260k
scoreboard players operation 112e th = xe stories260k
scoreboard players operation 112s th = xs stories260k
scoreboard players operation xb stories260k = 113b th
scoreboard players operation xe stories260k = 113e th
scoreboard players operation xs stories260k = 113s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 113b th2
scoreboard players operation xe stories260k = 113e th2
scoreboard players operation xs stories260k = 113s th2
function stories260k:div
scoreboard players operation yb stories260k = 113b th
scoreboard players operation ye stories260k = 113e th
scoreboard players operation ys stories260k = 113s th
function stories260k:mul
scoreboard players operation 113b th = xb stories260k
scoreboard players operation 113e th = xe stories260k
scoreboard players operation 113s th = xs stories260k
scoreboard players operation xb stories260k = 114b th
scoreboard players operation xe stories260k = 114e th
scoreboard players operation xs stories260k = 114s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 114b th2
scoreboard players operation xe stories260k = 114e th2
scoreboard players operation xs stories260k = 114s th2
function stories260k:div
scoreboard players operation yb stories260k = 114b th
scoreboard players operation ye stories260k = 114e th
scoreboard players operation ys stories260k = 114s th
function stories260k:mul
scoreboard players operation 114b th = xb stories260k
scoreboard players operation 114e th = xe stories260k
scoreboard players operation 114s th = xs stories260k
scoreboard players operation xb stories260k = 115b th
scoreboard players operation xe stories260k = 115e th
scoreboard players operation xs stories260k = 115s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 115b th2
scoreboard players operation xe stories260k = 115e th2
scoreboard players operation xs stories260k = 115s th2
function stories260k:div
scoreboard players operation yb stories260k = 115b th
scoreboard players operation ye stories260k = 115e th
scoreboard players operation ys stories260k = 115s th
function stories260k:mul
scoreboard players operation 115b th = xb stories260k
scoreboard players operation 115e th = xe stories260k
scoreboard players operation 115s th = xs stories260k
scoreboard players operation xb stories260k = 116b th
scoreboard players operation xe stories260k = 116e th
scoreboard players operation xs stories260k = 116s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 116b th2
scoreboard players operation xe stories260k = 116e th2
scoreboard players operation xs stories260k = 116s th2
function stories260k:div
scoreboard players operation yb stories260k = 116b th
scoreboard players operation ye stories260k = 116e th
scoreboard players operation ys stories260k = 116s th
function stories260k:mul
scoreboard players operation 116b th = xb stories260k
scoreboard players operation 116e th = xe stories260k
scoreboard players operation 116s th = xs stories260k
scoreboard players operation xb stories260k = 117b th
scoreboard players operation xe stories260k = 117e th
scoreboard players operation xs stories260k = 117s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 117b th2
scoreboard players operation xe stories260k = 117e th2
scoreboard players operation xs stories260k = 117s th2
function stories260k:div
scoreboard players operation yb stories260k = 117b th
scoreboard players operation ye stories260k = 117e th
scoreboard players operation ys stories260k = 117s th
function stories260k:mul
scoreboard players operation 117b th = xb stories260k
scoreboard players operation 117e th = xe stories260k
scoreboard players operation 117s th = xs stories260k
scoreboard players operation xb stories260k = 118b th
scoreboard players operation xe stories260k = 118e th
scoreboard players operation xs stories260k = 118s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 118b th2
scoreboard players operation xe stories260k = 118e th2
scoreboard players operation xs stories260k = 118s th2
function stories260k:div
scoreboard players operation yb stories260k = 118b th
scoreboard players operation ye stories260k = 118e th
scoreboard players operation ys stories260k = 118s th
function stories260k:mul
scoreboard players operation 118b th = xb stories260k
scoreboard players operation 118e th = xe stories260k
scoreboard players operation 118s th = xs stories260k
scoreboard players operation xb stories260k = 119b th
scoreboard players operation xe stories260k = 119e th
scoreboard players operation xs stories260k = 119s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 119b th2
scoreboard players operation xe stories260k = 119e th2
scoreboard players operation xs stories260k = 119s th2
function stories260k:div
scoreboard players operation yb stories260k = 119b th
scoreboard players operation ye stories260k = 119e th
scoreboard players operation ys stories260k = 119s th
function stories260k:mul
scoreboard players operation 119b th = xb stories260k
scoreboard players operation 119e th = xe stories260k
scoreboard players operation 119s th = xs stories260k
scoreboard players operation xb stories260k = 120b th
scoreboard players operation xe stories260k = 120e th
scoreboard players operation xs stories260k = 120s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 120b th2
scoreboard players operation xe stories260k = 120e th2
scoreboard players operation xs stories260k = 120s th2
function stories260k:div
scoreboard players operation yb stories260k = 120b th
scoreboard players operation ye stories260k = 120e th
scoreboard players operation ys stories260k = 120s th
function stories260k:mul
scoreboard players operation 120b th = xb stories260k
scoreboard players operation 120e th = xe stories260k
scoreboard players operation 120s th = xs stories260k
scoreboard players operation xb stories260k = 121b th
scoreboard players operation xe stories260k = 121e th
scoreboard players operation xs stories260k = 121s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 121b th2
scoreboard players operation xe stories260k = 121e th2
scoreboard players operation xs stories260k = 121s th2
function stories260k:div
scoreboard players operation yb stories260k = 121b th
scoreboard players operation ye stories260k = 121e th
scoreboard players operation ys stories260k = 121s th
function stories260k:mul
scoreboard players operation 121b th = xb stories260k
scoreboard players operation 121e th = xe stories260k
scoreboard players operation 121s th = xs stories260k
scoreboard players operation xb stories260k = 122b th
scoreboard players operation xe stories260k = 122e th
scoreboard players operation xs stories260k = 122s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 122b th2
scoreboard players operation xe stories260k = 122e th2
scoreboard players operation xs stories260k = 122s th2
function stories260k:div
scoreboard players operation yb stories260k = 122b th
scoreboard players operation ye stories260k = 122e th
scoreboard players operation ys stories260k = 122s th
function stories260k:mul
scoreboard players operation 122b th = xb stories260k
scoreboard players operation 122e th = xe stories260k
scoreboard players operation 122s th = xs stories260k
scoreboard players operation xb stories260k = 123b th
scoreboard players operation xe stories260k = 123e th
scoreboard players operation xs stories260k = 123s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 123b th2
scoreboard players operation xe stories260k = 123e th2
scoreboard players operation xs stories260k = 123s th2
function stories260k:div
scoreboard players operation yb stories260k = 123b th
scoreboard players operation ye stories260k = 123e th
scoreboard players operation ys stories260k = 123s th
function stories260k:mul
scoreboard players operation 123b th = xb stories260k
scoreboard players operation 123e th = xe stories260k
scoreboard players operation 123s th = xs stories260k
scoreboard players operation xb stories260k = 124b th
scoreboard players operation xe stories260k = 124e th
scoreboard players operation xs stories260k = 124s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 124b th2
scoreboard players operation xe stories260k = 124e th2
scoreboard players operation xs stories260k = 124s th2
function stories260k:div
scoreboard players operation yb stories260k = 124b th
scoreboard players operation ye stories260k = 124e th
scoreboard players operation ys stories260k = 124s th
function stories260k:mul
scoreboard players operation 124b th = xb stories260k
scoreboard players operation 124e th = xe stories260k
scoreboard players operation 124s th = xs stories260k
scoreboard players operation xb stories260k = 125b th
scoreboard players operation xe stories260k = 125e th
scoreboard players operation xs stories260k = 125s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 125b th2
scoreboard players operation xe stories260k = 125e th2
scoreboard players operation xs stories260k = 125s th2
function stories260k:div
scoreboard players operation yb stories260k = 125b th
scoreboard players operation ye stories260k = 125e th
scoreboard players operation ys stories260k = 125s th
function stories260k:mul
scoreboard players operation 125b th = xb stories260k
scoreboard players operation 125e th = xe stories260k
scoreboard players operation 125s th = xs stories260k
scoreboard players operation xb stories260k = 126b th
scoreboard players operation xe stories260k = 126e th
scoreboard players operation xs stories260k = 126s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 126b th2
scoreboard players operation xe stories260k = 126e th2
scoreboard players operation xs stories260k = 126s th2
function stories260k:div
scoreboard players operation yb stories260k = 126b th
scoreboard players operation ye stories260k = 126e th
scoreboard players operation ys stories260k = 126s th
function stories260k:mul
scoreboard players operation 126b th = xb stories260k
scoreboard players operation 126e th = xe stories260k
scoreboard players operation 126s th = xs stories260k
scoreboard players operation xb stories260k = 127b th
scoreboard players operation xe stories260k = 127e th
scoreboard players operation xs stories260k = 127s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 127b th2
scoreboard players operation xe stories260k = 127e th2
scoreboard players operation xs stories260k = 127s th2
function stories260k:div
scoreboard players operation yb stories260k = 127b th
scoreboard players operation ye stories260k = 127e th
scoreboard players operation ys stories260k = 127s th
function stories260k:mul
scoreboard players operation 127b th = xb stories260k
scoreboard players operation 127e th = xe stories260k
scoreboard players operation 127s th = xs stories260k
scoreboard players operation xb stories260k = 128b th
scoreboard players operation xe stories260k = 128e th
scoreboard players operation xs stories260k = 128s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 128b th2
scoreboard players operation xe stories260k = 128e th2
scoreboard players operation xs stories260k = 128s th2
function stories260k:div
scoreboard players operation yb stories260k = 128b th
scoreboard players operation ye stories260k = 128e th
scoreboard players operation ys stories260k = 128s th
function stories260k:mul
scoreboard players operation 128b th = xb stories260k
scoreboard players operation 128e th = xe stories260k
scoreboard players operation 128s th = xs stories260k
scoreboard players operation xb stories260k = 129b th
scoreboard players operation xe stories260k = 129e th
scoreboard players operation xs stories260k = 129s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 129b th2
scoreboard players operation xe stories260k = 129e th2
scoreboard players operation xs stories260k = 129s th2
function stories260k:div
scoreboard players operation yb stories260k = 129b th
scoreboard players operation ye stories260k = 129e th
scoreboard players operation ys stories260k = 129s th
function stories260k:mul
scoreboard players operation 129b th = xb stories260k
scoreboard players operation 129e th = xe stories260k
scoreboard players operation 129s th = xs stories260k
scoreboard players operation xb stories260k = 130b th
scoreboard players operation xe stories260k = 130e th
scoreboard players operation xs stories260k = 130s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 130b th2
scoreboard players operation xe stories260k = 130e th2
scoreboard players operation xs stories260k = 130s th2
function stories260k:div
scoreboard players operation yb stories260k = 130b th
scoreboard players operation ye stories260k = 130e th
scoreboard players operation ys stories260k = 130s th
function stories260k:mul
scoreboard players operation 130b th = xb stories260k
scoreboard players operation 130e th = xe stories260k
scoreboard players operation 130s th = xs stories260k
scoreboard players operation xb stories260k = 131b th
scoreboard players operation xe stories260k = 131e th
scoreboard players operation xs stories260k = 131s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 131b th2
scoreboard players operation xe stories260k = 131e th2
scoreboard players operation xs stories260k = 131s th2
function stories260k:div
scoreboard players operation yb stories260k = 131b th
scoreboard players operation ye stories260k = 131e th
scoreboard players operation ys stories260k = 131s th
function stories260k:mul
scoreboard players operation 131b th = xb stories260k
scoreboard players operation 131e th = xe stories260k
scoreboard players operation 131s th = xs stories260k
scoreboard players operation xb stories260k = 132b th
scoreboard players operation xe stories260k = 132e th
scoreboard players operation xs stories260k = 132s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 132b th2
scoreboard players operation xe stories260k = 132e th2
scoreboard players operation xs stories260k = 132s th2
function stories260k:div
scoreboard players operation yb stories260k = 132b th
scoreboard players operation ye stories260k = 132e th
scoreboard players operation ys stories260k = 132s th
function stories260k:mul
scoreboard players operation 132b th = xb stories260k
scoreboard players operation 132e th = xe stories260k
scoreboard players operation 132s th = xs stories260k
scoreboard players operation xb stories260k = 133b th
scoreboard players operation xe stories260k = 133e th
scoreboard players operation xs stories260k = 133s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 133b th2
scoreboard players operation xe stories260k = 133e th2
scoreboard players operation xs stories260k = 133s th2
function stories260k:div
scoreboard players operation yb stories260k = 133b th
scoreboard players operation ye stories260k = 133e th
scoreboard players operation ys stories260k = 133s th
function stories260k:mul
scoreboard players operation 133b th = xb stories260k
scoreboard players operation 133e th = xe stories260k
scoreboard players operation 133s th = xs stories260k
scoreboard players operation xb stories260k = 134b th
scoreboard players operation xe stories260k = 134e th
scoreboard players operation xs stories260k = 134s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 134b th2
scoreboard players operation xe stories260k = 134e th2
scoreboard players operation xs stories260k = 134s th2
function stories260k:div
scoreboard players operation yb stories260k = 134b th
scoreboard players operation ye stories260k = 134e th
scoreboard players operation ys stories260k = 134s th
function stories260k:mul
scoreboard players operation 134b th = xb stories260k
scoreboard players operation 134e th = xe stories260k
scoreboard players operation 134s th = xs stories260k
scoreboard players operation xb stories260k = 135b th
scoreboard players operation xe stories260k = 135e th
scoreboard players operation xs stories260k = 135s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 135b th2
scoreboard players operation xe stories260k = 135e th2
scoreboard players operation xs stories260k = 135s th2
function stories260k:div
scoreboard players operation yb stories260k = 135b th
scoreboard players operation ye stories260k = 135e th
scoreboard players operation ys stories260k = 135s th
function stories260k:mul
scoreboard players operation 135b th = xb stories260k
scoreboard players operation 135e th = xe stories260k
scoreboard players operation 135s th = xs stories260k
scoreboard players operation xb stories260k = 136b th
scoreboard players operation xe stories260k = 136e th
scoreboard players operation xs stories260k = 136s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 136b th2
scoreboard players operation xe stories260k = 136e th2
scoreboard players operation xs stories260k = 136s th2
function stories260k:div
scoreboard players operation yb stories260k = 136b th
scoreboard players operation ye stories260k = 136e th
scoreboard players operation ys stories260k = 136s th
function stories260k:mul
scoreboard players operation 136b th = xb stories260k
scoreboard players operation 136e th = xe stories260k
scoreboard players operation 136s th = xs stories260k
scoreboard players operation xb stories260k = 137b th
scoreboard players operation xe stories260k = 137e th
scoreboard players operation xs stories260k = 137s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 137b th2
scoreboard players operation xe stories260k = 137e th2
scoreboard players operation xs stories260k = 137s th2
function stories260k:div
scoreboard players operation yb stories260k = 137b th
scoreboard players operation ye stories260k = 137e th
scoreboard players operation ys stories260k = 137s th
function stories260k:mul
scoreboard players operation 137b th = xb stories260k
scoreboard players operation 137e th = xe stories260k
scoreboard players operation 137s th = xs stories260k
scoreboard players operation xb stories260k = 138b th
scoreboard players operation xe stories260k = 138e th
scoreboard players operation xs stories260k = 138s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 138b th2
scoreboard players operation xe stories260k = 138e th2
scoreboard players operation xs stories260k = 138s th2
function stories260k:div
scoreboard players operation yb stories260k = 138b th
scoreboard players operation ye stories260k = 138e th
scoreboard players operation ys stories260k = 138s th
function stories260k:mul
scoreboard players operation 138b th = xb stories260k
scoreboard players operation 138e th = xe stories260k
scoreboard players operation 138s th = xs stories260k
scoreboard players operation xb stories260k = 139b th
scoreboard players operation xe stories260k = 139e th
scoreboard players operation xs stories260k = 139s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 139b th2
scoreboard players operation xe stories260k = 139e th2
scoreboard players operation xs stories260k = 139s th2
function stories260k:div
scoreboard players operation yb stories260k = 139b th
scoreboard players operation ye stories260k = 139e th
scoreboard players operation ys stories260k = 139s th
function stories260k:mul
scoreboard players operation 139b th = xb stories260k
scoreboard players operation 139e th = xe stories260k
scoreboard players operation 139s th = xs stories260k
scoreboard players operation xb stories260k = 140b th
scoreboard players operation xe stories260k = 140e th
scoreboard players operation xs stories260k = 140s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 140b th2
scoreboard players operation xe stories260k = 140e th2
scoreboard players operation xs stories260k = 140s th2
function stories260k:div
scoreboard players operation yb stories260k = 140b th
scoreboard players operation ye stories260k = 140e th
scoreboard players operation ys stories260k = 140s th
function stories260k:mul
scoreboard players operation 140b th = xb stories260k
scoreboard players operation 140e th = xe stories260k
scoreboard players operation 140s th = xs stories260k
scoreboard players operation xb stories260k = 141b th
scoreboard players operation xe stories260k = 141e th
scoreboard players operation xs stories260k = 141s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 141b th2
scoreboard players operation xe stories260k = 141e th2
scoreboard players operation xs stories260k = 141s th2
function stories260k:div
scoreboard players operation yb stories260k = 141b th
scoreboard players operation ye stories260k = 141e th
scoreboard players operation ys stories260k = 141s th
function stories260k:mul
scoreboard players operation 141b th = xb stories260k
scoreboard players operation 141e th = xe stories260k
scoreboard players operation 141s th = xs stories260k
scoreboard players operation xb stories260k = 142b th
scoreboard players operation xe stories260k = 142e th
scoreboard players operation xs stories260k = 142s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 142b th2
scoreboard players operation xe stories260k = 142e th2
scoreboard players operation xs stories260k = 142s th2
function stories260k:div
scoreboard players operation yb stories260k = 142b th
scoreboard players operation ye stories260k = 142e th
scoreboard players operation ys stories260k = 142s th
function stories260k:mul
scoreboard players operation 142b th = xb stories260k
scoreboard players operation 142e th = xe stories260k
scoreboard players operation 142s th = xs stories260k
scoreboard players operation xb stories260k = 143b th
scoreboard players operation xe stories260k = 143e th
scoreboard players operation xs stories260k = 143s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 143b th2
scoreboard players operation xe stories260k = 143e th2
scoreboard players operation xs stories260k = 143s th2
function stories260k:div
scoreboard players operation yb stories260k = 143b th
scoreboard players operation ye stories260k = 143e th
scoreboard players operation ys stories260k = 143s th
function stories260k:mul
scoreboard players operation 143b th = xb stories260k
scoreboard players operation 143e th = xe stories260k
scoreboard players operation 143s th = xs stories260k
scoreboard players operation xb stories260k = 144b th
scoreboard players operation xe stories260k = 144e th
scoreboard players operation xs stories260k = 144s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 144b th2
scoreboard players operation xe stories260k = 144e th2
scoreboard players operation xs stories260k = 144s th2
function stories260k:div
scoreboard players operation yb stories260k = 144b th
scoreboard players operation ye stories260k = 144e th
scoreboard players operation ys stories260k = 144s th
function stories260k:mul
scoreboard players operation 144b th = xb stories260k
scoreboard players operation 144e th = xe stories260k
scoreboard players operation 144s th = xs stories260k
scoreboard players operation xb stories260k = 145b th
scoreboard players operation xe stories260k = 145e th
scoreboard players operation xs stories260k = 145s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 145b th2
scoreboard players operation xe stories260k = 145e th2
scoreboard players operation xs stories260k = 145s th2
function stories260k:div
scoreboard players operation yb stories260k = 145b th
scoreboard players operation ye stories260k = 145e th
scoreboard players operation ys stories260k = 145s th
function stories260k:mul
scoreboard players operation 145b th = xb stories260k
scoreboard players operation 145e th = xe stories260k
scoreboard players operation 145s th = xs stories260k
scoreboard players operation xb stories260k = 146b th
scoreboard players operation xe stories260k = 146e th
scoreboard players operation xs stories260k = 146s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 146b th2
scoreboard players operation xe stories260k = 146e th2
scoreboard players operation xs stories260k = 146s th2
function stories260k:div
scoreboard players operation yb stories260k = 146b th
scoreboard players operation ye stories260k = 146e th
scoreboard players operation ys stories260k = 146s th
function stories260k:mul
scoreboard players operation 146b th = xb stories260k
scoreboard players operation 146e th = xe stories260k
scoreboard players operation 146s th = xs stories260k
scoreboard players operation xb stories260k = 147b th
scoreboard players operation xe stories260k = 147e th
scoreboard players operation xs stories260k = 147s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 147b th2
scoreboard players operation xe stories260k = 147e th2
scoreboard players operation xs stories260k = 147s th2
function stories260k:div
scoreboard players operation yb stories260k = 147b th
scoreboard players operation ye stories260k = 147e th
scoreboard players operation ys stories260k = 147s th
function stories260k:mul
scoreboard players operation 147b th = xb stories260k
scoreboard players operation 147e th = xe stories260k
scoreboard players operation 147s th = xs stories260k
scoreboard players operation xb stories260k = 148b th
scoreboard players operation xe stories260k = 148e th
scoreboard players operation xs stories260k = 148s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 148b th2
scoreboard players operation xe stories260k = 148e th2
scoreboard players operation xs stories260k = 148s th2
function stories260k:div
scoreboard players operation yb stories260k = 148b th
scoreboard players operation ye stories260k = 148e th
scoreboard players operation ys stories260k = 148s th
function stories260k:mul
scoreboard players operation 148b th = xb stories260k
scoreboard players operation 148e th = xe stories260k
scoreboard players operation 148s th = xs stories260k
scoreboard players operation xb stories260k = 149b th
scoreboard players operation xe stories260k = 149e th
scoreboard players operation xs stories260k = 149s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 149b th2
scoreboard players operation xe stories260k = 149e th2
scoreboard players operation xs stories260k = 149s th2
function stories260k:div
scoreboard players operation yb stories260k = 149b th
scoreboard players operation ye stories260k = 149e th
scoreboard players operation ys stories260k = 149s th
function stories260k:mul
scoreboard players operation 149b th = xb stories260k
scoreboard players operation 149e th = xe stories260k
scoreboard players operation 149s th = xs stories260k
scoreboard players operation xb stories260k = 150b th
scoreboard players operation xe stories260k = 150e th
scoreboard players operation xs stories260k = 150s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 150b th2
scoreboard players operation xe stories260k = 150e th2
scoreboard players operation xs stories260k = 150s th2
function stories260k:div
scoreboard players operation yb stories260k = 150b th
scoreboard players operation ye stories260k = 150e th
scoreboard players operation ys stories260k = 150s th
function stories260k:mul
scoreboard players operation 150b th = xb stories260k
scoreboard players operation 150e th = xe stories260k
scoreboard players operation 150s th = xs stories260k
scoreboard players operation xb stories260k = 151b th
scoreboard players operation xe stories260k = 151e th
scoreboard players operation xs stories260k = 151s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 151b th2
scoreboard players operation xe stories260k = 151e th2
scoreboard players operation xs stories260k = 151s th2
function stories260k:div
scoreboard players operation yb stories260k = 151b th
scoreboard players operation ye stories260k = 151e th
scoreboard players operation ys stories260k = 151s th
function stories260k:mul
scoreboard players operation 151b th = xb stories260k
scoreboard players operation 151e th = xe stories260k
scoreboard players operation 151s th = xs stories260k
scoreboard players operation xb stories260k = 152b th
scoreboard players operation xe stories260k = 152e th
scoreboard players operation xs stories260k = 152s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 152b th2
scoreboard players operation xe stories260k = 152e th2
scoreboard players operation xs stories260k = 152s th2
function stories260k:div
scoreboard players operation yb stories260k = 152b th
scoreboard players operation ye stories260k = 152e th
scoreboard players operation ys stories260k = 152s th
function stories260k:mul
scoreboard players operation 152b th = xb stories260k
scoreboard players operation 152e th = xe stories260k
scoreboard players operation 152s th = xs stories260k
scoreboard players operation xb stories260k = 153b th
scoreboard players operation xe stories260k = 153e th
scoreboard players operation xs stories260k = 153s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 153b th2
scoreboard players operation xe stories260k = 153e th2
scoreboard players operation xs stories260k = 153s th2
function stories260k:div
scoreboard players operation yb stories260k = 153b th
scoreboard players operation ye stories260k = 153e th
scoreboard players operation ys stories260k = 153s th
function stories260k:mul
scoreboard players operation 153b th = xb stories260k
scoreboard players operation 153e th = xe stories260k
scoreboard players operation 153s th = xs stories260k
scoreboard players operation xb stories260k = 154b th
scoreboard players operation xe stories260k = 154e th
scoreboard players operation xs stories260k = 154s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 154b th2
scoreboard players operation xe stories260k = 154e th2
scoreboard players operation xs stories260k = 154s th2
function stories260k:div
scoreboard players operation yb stories260k = 154b th
scoreboard players operation ye stories260k = 154e th
scoreboard players operation ys stories260k = 154s th
function stories260k:mul
scoreboard players operation 154b th = xb stories260k
scoreboard players operation 154e th = xe stories260k
scoreboard players operation 154s th = xs stories260k
scoreboard players operation xb stories260k = 155b th
scoreboard players operation xe stories260k = 155e th
scoreboard players operation xs stories260k = 155s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 155b th2
scoreboard players operation xe stories260k = 155e th2
scoreboard players operation xs stories260k = 155s th2
function stories260k:div
scoreboard players operation yb stories260k = 155b th
scoreboard players operation ye stories260k = 155e th
scoreboard players operation ys stories260k = 155s th
function stories260k:mul
scoreboard players operation 155b th = xb stories260k
scoreboard players operation 155e th = xe stories260k
scoreboard players operation 155s th = xs stories260k
scoreboard players operation xb stories260k = 156b th
scoreboard players operation xe stories260k = 156e th
scoreboard players operation xs stories260k = 156s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 156b th2
scoreboard players operation xe stories260k = 156e th2
scoreboard players operation xs stories260k = 156s th2
function stories260k:div
scoreboard players operation yb stories260k = 156b th
scoreboard players operation ye stories260k = 156e th
scoreboard players operation ys stories260k = 156s th
function stories260k:mul
scoreboard players operation 156b th = xb stories260k
scoreboard players operation 156e th = xe stories260k
scoreboard players operation 156s th = xs stories260k
scoreboard players operation xb stories260k = 157b th
scoreboard players operation xe stories260k = 157e th
scoreboard players operation xs stories260k = 157s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 157b th2
scoreboard players operation xe stories260k = 157e th2
scoreboard players operation xs stories260k = 157s th2
function stories260k:div
scoreboard players operation yb stories260k = 157b th
scoreboard players operation ye stories260k = 157e th
scoreboard players operation ys stories260k = 157s th
function stories260k:mul
scoreboard players operation 157b th = xb stories260k
scoreboard players operation 157e th = xe stories260k
scoreboard players operation 157s th = xs stories260k
scoreboard players operation xb stories260k = 158b th
scoreboard players operation xe stories260k = 158e th
scoreboard players operation xs stories260k = 158s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 158b th2
scoreboard players operation xe stories260k = 158e th2
scoreboard players operation xs stories260k = 158s th2
function stories260k:div
scoreboard players operation yb stories260k = 158b th
scoreboard players operation ye stories260k = 158e th
scoreboard players operation ys stories260k = 158s th
function stories260k:mul
scoreboard players operation 158b th = xb stories260k
scoreboard players operation 158e th = xe stories260k
scoreboard players operation 158s th = xs stories260k
scoreboard players operation xb stories260k = 159b th
scoreboard players operation xe stories260k = 159e th
scoreboard players operation xs stories260k = 159s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 159b th2
scoreboard players operation xe stories260k = 159e th2
scoreboard players operation xs stories260k = 159s th2
function stories260k:div
scoreboard players operation yb stories260k = 159b th
scoreboard players operation ye stories260k = 159e th
scoreboard players operation ys stories260k = 159s th
function stories260k:mul
scoreboard players operation 159b th = xb stories260k
scoreboard players operation 159e th = xe stories260k
scoreboard players operation 159s th = xs stories260k
scoreboard players operation xb stories260k = 160b th
scoreboard players operation xe stories260k = 160e th
scoreboard players operation xs stories260k = 160s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 160b th2
scoreboard players operation xe stories260k = 160e th2
scoreboard players operation xs stories260k = 160s th2
function stories260k:div
scoreboard players operation yb stories260k = 160b th
scoreboard players operation ye stories260k = 160e th
scoreboard players operation ys stories260k = 160s th
function stories260k:mul
scoreboard players operation 160b th = xb stories260k
scoreboard players operation 160e th = xe stories260k
scoreboard players operation 160s th = xs stories260k
scoreboard players operation xb stories260k = 161b th
scoreboard players operation xe stories260k = 161e th
scoreboard players operation xs stories260k = 161s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 161b th2
scoreboard players operation xe stories260k = 161e th2
scoreboard players operation xs stories260k = 161s th2
function stories260k:div
scoreboard players operation yb stories260k = 161b th
scoreboard players operation ye stories260k = 161e th
scoreboard players operation ys stories260k = 161s th
function stories260k:mul
scoreboard players operation 161b th = xb stories260k
scoreboard players operation 161e th = xe stories260k
scoreboard players operation 161s th = xs stories260k
scoreboard players operation xb stories260k = 162b th
scoreboard players operation xe stories260k = 162e th
scoreboard players operation xs stories260k = 162s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 162b th2
scoreboard players operation xe stories260k = 162e th2
scoreboard players operation xs stories260k = 162s th2
function stories260k:div
scoreboard players operation yb stories260k = 162b th
scoreboard players operation ye stories260k = 162e th
scoreboard players operation ys stories260k = 162s th
function stories260k:mul
scoreboard players operation 162b th = xb stories260k
scoreboard players operation 162e th = xe stories260k
scoreboard players operation 162s th = xs stories260k
scoreboard players operation xb stories260k = 163b th
scoreboard players operation xe stories260k = 163e th
scoreboard players operation xs stories260k = 163s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 163b th2
scoreboard players operation xe stories260k = 163e th2
scoreboard players operation xs stories260k = 163s th2
function stories260k:div
scoreboard players operation yb stories260k = 163b th
scoreboard players operation ye stories260k = 163e th
scoreboard players operation ys stories260k = 163s th
function stories260k:mul
scoreboard players operation 163b th = xb stories260k
scoreboard players operation 163e th = xe stories260k
scoreboard players operation 163s th = xs stories260k
scoreboard players operation xb stories260k = 164b th
scoreboard players operation xe stories260k = 164e th
scoreboard players operation xs stories260k = 164s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 164b th2
scoreboard players operation xe stories260k = 164e th2
scoreboard players operation xs stories260k = 164s th2
function stories260k:div
scoreboard players operation yb stories260k = 164b th
scoreboard players operation ye stories260k = 164e th
scoreboard players operation ys stories260k = 164s th
function stories260k:mul
scoreboard players operation 164b th = xb stories260k
scoreboard players operation 164e th = xe stories260k
scoreboard players operation 164s th = xs stories260k
scoreboard players operation xb stories260k = 165b th
scoreboard players operation xe stories260k = 165e th
scoreboard players operation xs stories260k = 165s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 165b th2
scoreboard players operation xe stories260k = 165e th2
scoreboard players operation xs stories260k = 165s th2
function stories260k:div
scoreboard players operation yb stories260k = 165b th
scoreboard players operation ye stories260k = 165e th
scoreboard players operation ys stories260k = 165s th
function stories260k:mul
scoreboard players operation 165b th = xb stories260k
scoreboard players operation 165e th = xe stories260k
scoreboard players operation 165s th = xs stories260k
scoreboard players operation xb stories260k = 166b th
scoreboard players operation xe stories260k = 166e th
scoreboard players operation xs stories260k = 166s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 166b th2
scoreboard players operation xe stories260k = 166e th2
scoreboard players operation xs stories260k = 166s th2
function stories260k:div
scoreboard players operation yb stories260k = 166b th
scoreboard players operation ye stories260k = 166e th
scoreboard players operation ys stories260k = 166s th
function stories260k:mul
scoreboard players operation 166b th = xb stories260k
scoreboard players operation 166e th = xe stories260k
scoreboard players operation 166s th = xs stories260k
scoreboard players operation xb stories260k = 167b th
scoreboard players operation xe stories260k = 167e th
scoreboard players operation xs stories260k = 167s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 167b th2
scoreboard players operation xe stories260k = 167e th2
scoreboard players operation xs stories260k = 167s th2
function stories260k:div
scoreboard players operation yb stories260k = 167b th
scoreboard players operation ye stories260k = 167e th
scoreboard players operation ys stories260k = 167s th
function stories260k:mul
scoreboard players operation 167b th = xb stories260k
scoreboard players operation 167e th = xe stories260k
scoreboard players operation 167s th = xs stories260k
scoreboard players operation xb stories260k = 168b th
scoreboard players operation xe stories260k = 168e th
scoreboard players operation xs stories260k = 168s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 168b th2
scoreboard players operation xe stories260k = 168e th2
scoreboard players operation xs stories260k = 168s th2
function stories260k:div
scoreboard players operation yb stories260k = 168b th
scoreboard players operation ye stories260k = 168e th
scoreboard players operation ys stories260k = 168s th
function stories260k:mul
scoreboard players operation 168b th = xb stories260k
scoreboard players operation 168e th = xe stories260k
scoreboard players operation 168s th = xs stories260k
scoreboard players operation xb stories260k = 169b th
scoreboard players operation xe stories260k = 169e th
scoreboard players operation xs stories260k = 169s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 169b th2
scoreboard players operation xe stories260k = 169e th2
scoreboard players operation xs stories260k = 169s th2
function stories260k:div
scoreboard players operation yb stories260k = 169b th
scoreboard players operation ye stories260k = 169e th
scoreboard players operation ys stories260k = 169s th
function stories260k:mul
scoreboard players operation 169b th = xb stories260k
scoreboard players operation 169e th = xe stories260k
scoreboard players operation 169s th = xs stories260k
scoreboard players operation xb stories260k = 170b th
scoreboard players operation xe stories260k = 170e th
scoreboard players operation xs stories260k = 170s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 170b th2
scoreboard players operation xe stories260k = 170e th2
scoreboard players operation xs stories260k = 170s th2
function stories260k:div
scoreboard players operation yb stories260k = 170b th
scoreboard players operation ye stories260k = 170e th
scoreboard players operation ys stories260k = 170s th
function stories260k:mul
scoreboard players operation 170b th = xb stories260k
scoreboard players operation 170e th = xe stories260k
scoreboard players operation 170s th = xs stories260k
scoreboard players operation xb stories260k = 171b th
scoreboard players operation xe stories260k = 171e th
scoreboard players operation xs stories260k = 171s th
scoreboard players operation xs stories260k *= -1 stories260k
function stories260k:exp
scoreboard players set yb stories260k 10000000
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:add
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = 171b th2
scoreboard players operation xe stories260k = 171e th2
scoreboard players operation xs stories260k = 171s th2
function stories260k:div
scoreboard players operation yb stories260k = 171b th
scoreboard players operation ye stories260k = 171e th
scoreboard players operation ys stories260k = 171s th
function stories260k:mul
scoreboard players operation 171b th = xb stories260k
scoreboard players operation 171e th = xe stories260k
scoreboard players operation 171s th = xs stories260k
