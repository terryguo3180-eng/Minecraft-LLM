scoreboard players add pos stories260k 1
execute if score pos stories260k = len stories260k run scoreboard players operation tok stories260k = final_tok stories260k
execute if score pos stories260k = len stories260k run return run schedule function stories260k:respond 1t
function stories260k:chat_process_input
