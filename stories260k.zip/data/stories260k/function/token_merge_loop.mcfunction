scoreboard players set bs stories260k -2147483648
scoreboard players set bt stories260k -1
scoreboard players set bi stories260k -1
scoreboard players set i stories260k 0
scoreboard players set j stories260k 1
execute store result score len stories260k run data get storage stories260k args.prompt_tokens
data merge storage stories260k {args:{i:0,j:1}}
function stories260k:fetch_token_pair with storage stories260k args
function stories260k:try_merge_pair with storage stories260k args
execute if score bi stories260k matches -1 run return 0
execute store result storage stories260k args.i int 1 run scoreboard players get bi stories260k
execute store result storage stories260k args.j int 1 run scoreboard players add bi stories260k 1
scoreboard players remove bi stories260k 1
function stories260k:apply_token_merge with storage stories260k args
function stories260k:token_merge_loop
