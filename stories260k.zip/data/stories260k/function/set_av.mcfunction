$scoreboard players operation $(i)b av = xb stories260k
$scoreboard players operation $(i)e av = xe stories260k
$scoreboard players operation $(i)s av = xs stories260k
