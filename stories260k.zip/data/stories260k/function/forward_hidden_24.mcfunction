data modify storage stories260k args.in set value "tx"
data modify storage stories260k args.out set value "k"
data modify storage stories260k args.m set value "wk_3"
scoreboard players set s1 stories260k 32
scoreboard players set s2 stories260k 64
function stories260k:matmul
bossbar set progress value 26
schedule function stories260k:forward_hidden_25 1t
