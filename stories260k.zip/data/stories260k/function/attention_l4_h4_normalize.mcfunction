execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation yb stories260k = expsumb stories260k
scoreboard players operation ye stories260k = expsume stories260k
scoreboard players operation ys stories260k = expsums stories260k
function stories260k:div
function stories260k:set_av with storage stories260k args
scoreboard players add i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l4_h4_normalize
