$scoreboard players set temperature stories260k $(t)
execute if score temperature stories260k matches ..-1 run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
execute if score temperature stories260k matches 101.. run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
$data modify storage stories260k args.prompt set value "$(i)"
execute if data storage stories260k args{prompt:""} run return run tellraw @a {"text":"Message must be non-empty","color":"red"}
$data modify storage stories260k args.prompt set value "[INST] $(i) [/INST]"
$data modify storage stories260k args.output append value "\nUser: $(i)\nAssistant:"
tellraw @a ["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",{"storage":"stories260k","nbt":"args.output[]","separator":""}]
data modify storage stories260k args.prompt_tokens set value []
function stories260k:tokenize_prompt
data modify storage stories260k args.prompt_tokens prepend value 1
execute store result score final_tok stories260k run data get storage stories260k args.prompt_tokens[-1]
data remove storage stories260k args.prompt_tokens[0]
function stories260k:setup
scoreboard players operation xb stories260k = temperature stories260k
scoreboard players operation xb stories260k *= 2 stories260k
scoreboard players set xe stories260k 5
scoreboard players set xs stories260k 1
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation tb stories260k = xb stories260k
scoreboard players operation te stories260k = xe stories260k
scoreboard players operation ts stories260k = xs stories260k
scoreboard players set pos stories260k 0
execute store result score len stories260k run data get storage stories260k args.prompt_tokens
function stories260k:chat_process_input
