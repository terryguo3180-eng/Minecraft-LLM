$scoreboard players operation xb stories260k = $(i)b logits
$scoreboard players operation xe stories260k = $(i)e logits
$scoreboard players operation xs stories260k = $(i)s logits
function stories260k:cmp
execute if score r stories260k matches 1 run function stories260k:update_best_token
execute store result score t0 stories260k store result score t1 stories260k store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
scoreboard players operation t0 stories260k %= 100 stories260k
execute if score t0 stories260k matches 99 store result bossbar progress value run scoreboard players operation t1 stories260k /= 100 stories260k
execute if score i stories260k matches ..511 run function stories260k:argmax_scan with storage stories260k args
