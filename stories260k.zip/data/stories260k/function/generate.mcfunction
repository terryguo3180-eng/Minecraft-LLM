$scoreboard players set steps stories260k $(s)
$scoreboard players set temperature stories260k $(t)
execute if score steps stories260k matches ..0 run return run tellraw @a {"text":"Steps must be a positive integer","color":"red"}
execute if score temperature stories260k matches ..-1 run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
execute if score temperature stories260k matches 101.. run return run tellraw @a {"text":"Temperature must be an integer between 0 and 100 inclusive","color":"red"}
data modify storage stories260k args.prompt_tokens set value []
$data modify storage stories260k args.prompt set value "$(i)"
execute unless data storage stories260k args{prompt:""} run function stories260k:tokenize_prompt
function stories260k:setup
scoreboard players set tok stories260k 1
scoreboard players set pos stories260k 0
scoreboard players operation xb stories260k = temperature stories260k
scoreboard players operation xb stories260k *= 2 stories260k
scoreboard players set xe stories260k 5
scoreboard players set xs stories260k 1
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation tb stories260k = xb stories260k
scoreboard players operation te stories260k = xe stories260k
scoreboard players operation ts stories260k = xs stories260k
function stories260k:autoregressive
