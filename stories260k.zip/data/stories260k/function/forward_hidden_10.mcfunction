function stories260k:rotary_embedding
scoreboard players operation cache_idx stories260k = pos stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32768
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 0b k
scoreboard players operation xe stories260k = 0e k
scoreboard players operation xs stories260k = 0s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 0b v
scoreboard players operation xe stories260k = 0e v
scoreboard players operation xs stories260k = 0s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32769
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 1b k
scoreboard players operation xe stories260k = 1e k
scoreboard players operation xs stories260k = 1s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 1b v
scoreboard players operation xe stories260k = 1e v
scoreboard players operation xs stories260k = 1s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32770
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 2b k
scoreboard players operation xe stories260k = 2e k
scoreboard players operation xs stories260k = 2s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 2b v
scoreboard players operation xe stories260k = 2e v
scoreboard players operation xs stories260k = 2s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32771
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 3b k
scoreboard players operation xe stories260k = 3e k
scoreboard players operation xs stories260k = 3s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 3b v
scoreboard players operation xe stories260k = 3e v
scoreboard players operation xs stories260k = 3s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32772
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 4b k
scoreboard players operation xe stories260k = 4e k
scoreboard players operation xs stories260k = 4s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 4b v
scoreboard players operation xe stories260k = 4e v
scoreboard players operation xs stories260k = 4s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32773
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 5b k
scoreboard players operation xe stories260k = 5e k
scoreboard players operation xs stories260k = 5s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 5b v
scoreboard players operation xe stories260k = 5e v
scoreboard players operation xs stories260k = 5s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32774
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 6b k
scoreboard players operation xe stories260k = 6e k
scoreboard players operation xs stories260k = 6s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 6b v
scoreboard players operation xe stories260k = 6e v
scoreboard players operation xs stories260k = 6s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32775
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 7b k
scoreboard players operation xe stories260k = 7e k
scoreboard players operation xs stories260k = 7s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 7b v
scoreboard players operation xe stories260k = 7e v
scoreboard players operation xs stories260k = 7s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32776
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 8b k
scoreboard players operation xe stories260k = 8e k
scoreboard players operation xs stories260k = 8s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 8b v
scoreboard players operation xe stories260k = 8e v
scoreboard players operation xs stories260k = 8s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32777
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 9b k
scoreboard players operation xe stories260k = 9e k
scoreboard players operation xs stories260k = 9s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 9b v
scoreboard players operation xe stories260k = 9e v
scoreboard players operation xs stories260k = 9s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32778
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 10b k
scoreboard players operation xe stories260k = 10e k
scoreboard players operation xs stories260k = 10s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 10b v
scoreboard players operation xe stories260k = 10e v
scoreboard players operation xs stories260k = 10s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32779
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 11b k
scoreboard players operation xe stories260k = 11e k
scoreboard players operation xs stories260k = 11s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 11b v
scoreboard players operation xe stories260k = 11e v
scoreboard players operation xs stories260k = 11s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32780
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 12b k
scoreboard players operation xe stories260k = 12e k
scoreboard players operation xs stories260k = 12s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 12b v
scoreboard players operation xe stories260k = 12e v
scoreboard players operation xs stories260k = 12s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32781
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 13b k
scoreboard players operation xe stories260k = 13e k
scoreboard players operation xs stories260k = 13s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 13b v
scoreboard players operation xe stories260k = 13e v
scoreboard players operation xs stories260k = 13s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32782
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 14b k
scoreboard players operation xe stories260k = 14e k
scoreboard players operation xs stories260k = 14s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 14b v
scoreboard players operation xe stories260k = 14e v
scoreboard players operation xs stories260k = 14s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32783
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 15b k
scoreboard players operation xe stories260k = 15e k
scoreboard players operation xs stories260k = 15s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 15b v
scoreboard players operation xe stories260k = 15e v
scoreboard players operation xs stories260k = 15s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32784
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 16b k
scoreboard players operation xe stories260k = 16e k
scoreboard players operation xs stories260k = 16s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 16b v
scoreboard players operation xe stories260k = 16e v
scoreboard players operation xs stories260k = 16s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32785
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 17b k
scoreboard players operation xe stories260k = 17e k
scoreboard players operation xs stories260k = 17s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 17b v
scoreboard players operation xe stories260k = 17e v
scoreboard players operation xs stories260k = 17s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32786
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 18b k
scoreboard players operation xe stories260k = 18e k
scoreboard players operation xs stories260k = 18s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 18b v
scoreboard players operation xe stories260k = 18e v
scoreboard players operation xs stories260k = 18s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32787
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 19b k
scoreboard players operation xe stories260k = 19e k
scoreboard players operation xs stories260k = 19s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 19b v
scoreboard players operation xe stories260k = 19e v
scoreboard players operation xs stories260k = 19s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32788
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 20b k
scoreboard players operation xe stories260k = 20e k
scoreboard players operation xs stories260k = 20s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 20b v
scoreboard players operation xe stories260k = 20e v
scoreboard players operation xs stories260k = 20s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32789
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 21b k
scoreboard players operation xe stories260k = 21e k
scoreboard players operation xs stories260k = 21s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 21b v
scoreboard players operation xe stories260k = 21e v
scoreboard players operation xs stories260k = 21s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32790
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 22b k
scoreboard players operation xe stories260k = 22e k
scoreboard players operation xs stories260k = 22s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 22b v
scoreboard players operation xe stories260k = 22e v
scoreboard players operation xs stories260k = 22s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32791
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 23b k
scoreboard players operation xe stories260k = 23e k
scoreboard players operation xs stories260k = 23s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 23b v
scoreboard players operation xe stories260k = 23e v
scoreboard players operation xs stories260k = 23s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32792
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 24b k
scoreboard players operation xe stories260k = 24e k
scoreboard players operation xs stories260k = 24s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 24b v
scoreboard players operation xe stories260k = 24e v
scoreboard players operation xs stories260k = 24s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32793
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 25b k
scoreboard players operation xe stories260k = 25e k
scoreboard players operation xs stories260k = 25s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 25b v
scoreboard players operation xe stories260k = 25e v
scoreboard players operation xs stories260k = 25s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32794
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 26b k
scoreboard players operation xe stories260k = 26e k
scoreboard players operation xs stories260k = 26s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 26b v
scoreboard players operation xe stories260k = 26e v
scoreboard players operation xs stories260k = 26s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32795
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 27b k
scoreboard players operation xe stories260k = 27e k
scoreboard players operation xs stories260k = 27s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 27b v
scoreboard players operation xe stories260k = 27e v
scoreboard players operation xs stories260k = 27s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32796
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 28b k
scoreboard players operation xe stories260k = 28e k
scoreboard players operation xs stories260k = 28s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 28b v
scoreboard players operation xe stories260k = 28e v
scoreboard players operation xs stories260k = 28s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32797
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 29b k
scoreboard players operation xe stories260k = 29e k
scoreboard players operation xs stories260k = 29s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 29b v
scoreboard players operation xe stories260k = 29e v
scoreboard players operation xs stories260k = 29s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32798
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 30b k
scoreboard players operation xe stories260k = 30e k
scoreboard players operation xs stories260k = 30s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 30b v
scoreboard players operation xe stories260k = 30e v
scoreboard players operation xs stories260k = 30s v
function stories260k:set_vc with storage stories260k args
scoreboard players operation i stories260k = cache_idx stories260k
scoreboard players operation i stories260k *= 64 stories260k
scoreboard players add i stories260k 32799
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
scoreboard players operation xb stories260k = 31b k
scoreboard players operation xe stories260k = 31e k
scoreboard players operation xs stories260k = 31s k
function stories260k:set_kc with storage stories260k args
scoreboard players operation xb stories260k = 31b v
scoreboard players operation xe stories260k = 31e v
scoreboard players operation xs stories260k = 31s v
function stories260k:set_vc with storage stories260k args
function stories260k:crop_context
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h0_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h0_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h0_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h0_normalize
scoreboard players set 0b tx 0
scoreboard players set 0e tx 0
scoreboard players set 0s tx 0
scoreboard players set 1b tx 0
scoreboard players set 1e tx 0
scoreboard players set 1s tx 0
scoreboard players set 2b tx 0
scoreboard players set 2e tx 0
scoreboard players set 2s tx 0
scoreboard players set 3b tx 0
scoreboard players set 3e tx 0
scoreboard players set 3s tx 0
scoreboard players set 4b tx 0
scoreboard players set 4e tx 0
scoreboard players set 4s tx 0
scoreboard players set 5b tx 0
scoreboard players set 5e tx 0
scoreboard players set 5s tx 0
scoreboard players set 6b tx 0
scoreboard players set 6e tx 0
scoreboard players set 6s tx 0
scoreboard players set 7b tx 0
scoreboard players set 7e tx 0
scoreboard players set 7s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h0_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h1_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h1_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h1_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h1_normalize
scoreboard players set 8b tx 0
scoreboard players set 8e tx 0
scoreboard players set 8s tx 0
scoreboard players set 9b tx 0
scoreboard players set 9e tx 0
scoreboard players set 9s tx 0
scoreboard players set 10b tx 0
scoreboard players set 10e tx 0
scoreboard players set 10s tx 0
scoreboard players set 11b tx 0
scoreboard players set 11e tx 0
scoreboard players set 11s tx 0
scoreboard players set 12b tx 0
scoreboard players set 12e tx 0
scoreboard players set 12s tx 0
scoreboard players set 13b tx 0
scoreboard players set 13e tx 0
scoreboard players set 13s tx 0
scoreboard players set 14b tx 0
scoreboard players set 14e tx 0
scoreboard players set 14s tx 0
scoreboard players set 15b tx 0
scoreboard players set 15e tx 0
scoreboard players set 15s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h1_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h2_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h2_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h2_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h2_normalize
scoreboard players set 16b tx 0
scoreboard players set 16e tx 0
scoreboard players set 16s tx 0
scoreboard players set 17b tx 0
scoreboard players set 17e tx 0
scoreboard players set 17s tx 0
scoreboard players set 18b tx 0
scoreboard players set 18e tx 0
scoreboard players set 18s tx 0
scoreboard players set 19b tx 0
scoreboard players set 19e tx 0
scoreboard players set 19s tx 0
scoreboard players set 20b tx 0
scoreboard players set 20e tx 0
scoreboard players set 20s tx 0
scoreboard players set 21b tx 0
scoreboard players set 21e tx 0
scoreboard players set 21s tx 0
scoreboard players set 22b tx 0
scoreboard players set 22e tx 0
scoreboard players set 22s tx 0
scoreboard players set 23b tx 0
scoreboard players set 23e tx 0
scoreboard players set 23s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h2_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h3_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h3_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h3_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h3_normalize
scoreboard players set 24b tx 0
scoreboard players set 24e tx 0
scoreboard players set 24s tx 0
scoreboard players set 25b tx 0
scoreboard players set 25e tx 0
scoreboard players set 25s tx 0
scoreboard players set 26b tx 0
scoreboard players set 26e tx 0
scoreboard players set 26s tx 0
scoreboard players set 27b tx 0
scoreboard players set 27e tx 0
scoreboard players set 27s tx 0
scoreboard players set 28b tx 0
scoreboard players set 28e tx 0
scoreboard players set 28s tx 0
scoreboard players set 29b tx 0
scoreboard players set 29e tx 0
scoreboard players set 29s tx 0
scoreboard players set 30b tx 0
scoreboard players set 30e tx 0
scoreboard players set 30s tx 0
scoreboard players set 31b tx 0
scoreboard players set 31e tx 0
scoreboard players set 31s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h3_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h4_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h4_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h4_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h4_normalize
scoreboard players set 32b tx 0
scoreboard players set 32e tx 0
scoreboard players set 32s tx 0
scoreboard players set 33b tx 0
scoreboard players set 33e tx 0
scoreboard players set 33s tx 0
scoreboard players set 34b tx 0
scoreboard players set 34e tx 0
scoreboard players set 34s tx 0
scoreboard players set 35b tx 0
scoreboard players set 35e tx 0
scoreboard players set 35s tx 0
scoreboard players set 36b tx 0
scoreboard players set 36e tx 0
scoreboard players set 36s tx 0
scoreboard players set 37b tx 0
scoreboard players set 37e tx 0
scoreboard players set 37s tx 0
scoreboard players set 38b tx 0
scoreboard players set 38e tx 0
scoreboard players set 38s tx 0
scoreboard players set 39b tx 0
scoreboard players set 39e tx 0
scoreboard players set 39s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h4_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h5_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h5_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h5_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h5_normalize
scoreboard players set 40b tx 0
scoreboard players set 40e tx 0
scoreboard players set 40s tx 0
scoreboard players set 41b tx 0
scoreboard players set 41e tx 0
scoreboard players set 41s tx 0
scoreboard players set 42b tx 0
scoreboard players set 42e tx 0
scoreboard players set 42s tx 0
scoreboard players set 43b tx 0
scoreboard players set 43e tx 0
scoreboard players set 43s tx 0
scoreboard players set 44b tx 0
scoreboard players set 44e tx 0
scoreboard players set 44s tx 0
scoreboard players set 45b tx 0
scoreboard players set 45e tx 0
scoreboard players set 45s tx 0
scoreboard players set 46b tx 0
scoreboard players set 46e tx 0
scoreboard players set 46s tx 0
scoreboard players set 47b tx 0
scoreboard players set 47e tx 0
scoreboard players set 47s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h5_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h6_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h6_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h6_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h6_normalize
scoreboard players set 48b tx 0
scoreboard players set 48e tx 0
scoreboard players set 48s tx 0
scoreboard players set 49b tx 0
scoreboard players set 49e tx 0
scoreboard players set 49s tx 0
scoreboard players set 50b tx 0
scoreboard players set 50e tx 0
scoreboard players set 50s tx 0
scoreboard players set 51b tx 0
scoreboard players set 51e tx 0
scoreboard players set 51s tx 0
scoreboard players set 52b tx 0
scoreboard players set 52e tx 0
scoreboard players set 52s tx 0
scoreboard players set 53b tx 0
scoreboard players set 53e tx 0
scoreboard players set 53s tx 0
scoreboard players set 54b tx 0
scoreboard players set 54e tx 0
scoreboard players set 54s tx 0
scoreboard players set 55b tx 0
scoreboard players set 55e tx 0
scoreboard players set 55s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h6_weighted_sum_vals
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h7_compute_score
scoreboard players operation maxb stories260k = 0b av
scoreboard players operation maxe stories260k = 0e av
scoreboard players operation maxs stories260k = 0s av
scoreboard players set i stories260k 1
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h7_find_max
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h7_sum_exp
scoreboard players set i stories260k 0
execute if score i stories260k < window_len stories260k run function stories260k:attention_l1_h7_normalize
scoreboard players set 56b tx 0
scoreboard players set 56e tx 0
scoreboard players set 56s tx 0
scoreboard players set 57b tx 0
scoreboard players set 57e tx 0
scoreboard players set 57s tx 0
scoreboard players set 58b tx 0
scoreboard players set 58e tx 0
scoreboard players set 58s tx 0
scoreboard players set 59b tx 0
scoreboard players set 59e tx 0
scoreboard players set 59s tx 0
scoreboard players set 60b tx 0
scoreboard players set 60e tx 0
scoreboard players set 60s tx 0
scoreboard players set 61b tx 0
scoreboard players set 61e tx 0
scoreboard players set 61s tx 0
scoreboard players set 62b tx 0
scoreboard players set 62e tx 0
scoreboard players set 62s tx 0
scoreboard players set 63b tx 0
scoreboard players set 63e tx 0
scoreboard players set 63s tx 0
scoreboard players operation t stories260k = start stories260k
scoreboard players set i stories260k 0
execute if score t stories260k <= pos stories260k run function stories260k:attention_l1_h7_weighted_sum_vals
bossbar set progress value 12
schedule function stories260k:forward_hidden_11 1t
