function stories260k:rmsnorm_sum_squares
scoreboard players operation xb stories260k = 0b x
scoreboard players operation xe stories260k = 0e x
scoreboard players operation xs stories260k = 0s x
scoreboard players set yb stories260k 24583089
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 0b x = xb stories260k
scoreboard players operation 0e x = xe stories260k
scoreboard players operation 0s x = xs stories260k
scoreboard players operation xb stories260k = 1b x
scoreboard players operation xe stories260k = 1e x
scoreboard players operation xs stories260k = 1s x
scoreboard players set yb stories260k 13673227
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 1b x = xb stories260k
scoreboard players operation 1e x = xe stories260k
scoreboard players operation 1s x = xs stories260k
scoreboard players operation xb stories260k = 2b x
scoreboard players operation xe stories260k = 2e x
scoreboard players operation xs stories260k = 2s x
scoreboard players set yb stories260k 17504382
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 2b x = xb stories260k
scoreboard players operation 2e x = xe stories260k
scoreboard players operation 2s x = xs stories260k
scoreboard players operation xb stories260k = 3b x
scoreboard players operation xe stories260k = 3e x
scoreboard players operation xs stories260k = 3s x
scoreboard players set yb stories260k 11078318
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 3b x = xb stories260k
scoreboard players operation 3e x = xe stories260k
scoreboard players operation 3s x = xs stories260k
scoreboard players operation xb stories260k = 4b x
scoreboard players operation xe stories260k = 4e x
scoreboard players operation xs stories260k = 4s x
scoreboard players set yb stories260k 14840457
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 4b x = xb stories260k
scoreboard players operation 4e x = xe stories260k
scoreboard players operation 4s x = xs stories260k
scoreboard players operation xb stories260k = 5b x
scoreboard players operation xe stories260k = 5e x
scoreboard players operation xs stories260k = 5s x
scoreboard players set yb stories260k 44250941
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 5b x = xb stories260k
scoreboard players operation 5e x = xe stories260k
scoreboard players operation 5s x = xs stories260k
scoreboard players operation xb stories260k = 6b x
scoreboard players operation xe stories260k = 6e x
scoreboard players operation xs stories260k = 6s x
scoreboard players set yb stories260k 16743193
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 6b x = xb stories260k
scoreboard players operation 6e x = xe stories260k
scoreboard players operation 6s x = xs stories260k
scoreboard players operation xb stories260k = 7b x
scoreboard players operation xe stories260k = 7e x
scoreboard players operation xs stories260k = 7s x
scoreboard players set yb stories260k 15204191
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 7b x = xb stories260k
scoreboard players operation 7e x = xe stories260k
scoreboard players operation 7s x = xs stories260k
scoreboard players operation xb stories260k = 8b x
scoreboard players operation xe stories260k = 8e x
scoreboard players operation xs stories260k = 8s x
scoreboard players set yb stories260k 19353532
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 8b x = xb stories260k
scoreboard players operation 8e x = xe stories260k
scoreboard players operation 8s x = xs stories260k
scoreboard players operation xb stories260k = 9b x
scoreboard players operation xe stories260k = 9e x
scoreboard players operation xs stories260k = 9s x
scoreboard players set yb stories260k 18381100
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 9b x = xb stories260k
scoreboard players operation 9e x = xe stories260k
scoreboard players operation 9s x = xs stories260k
scoreboard players operation xb stories260k = 10b x
scoreboard players operation xe stories260k = 10e x
scoreboard players operation xs stories260k = 10s x
scoreboard players set yb stories260k 15329392
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 10b x = xb stories260k
scoreboard players operation 10e x = xe stories260k
scoreboard players operation 10s x = xs stories260k
scoreboard players operation xb stories260k = 11b x
scoreboard players operation xe stories260k = 11e x
scoreboard players operation xs stories260k = 11s x
scoreboard players set yb stories260k 15324423
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 11b x = xb stories260k
scoreboard players operation 11e x = xe stories260k
scoreboard players operation 11s x = xs stories260k
scoreboard players operation xb stories260k = 12b x
scoreboard players operation xe stories260k = 12e x
scoreboard players operation xs stories260k = 12s x
scoreboard players set yb stories260k 16811218
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 12b x = xb stories260k
scoreboard players operation 12e x = xe stories260k
scoreboard players operation 12s x = xs stories260k
scoreboard players operation xb stories260k = 13b x
scoreboard players operation xe stories260k = 13e x
scoreboard players operation xs stories260k = 13s x
scoreboard players set yb stories260k 13867575
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 13b x = xb stories260k
scoreboard players operation 13e x = xe stories260k
scoreboard players operation 13s x = xs stories260k
scoreboard players operation xb stories260k = 14b x
scoreboard players operation xe stories260k = 14e x
scoreboard players operation xs stories260k = 14s x
scoreboard players set yb stories260k 21763520
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 14b x = xb stories260k
scoreboard players operation 14e x = xe stories260k
scoreboard players operation 14s x = xs stories260k
scoreboard players operation xb stories260k = 15b x
scoreboard players operation xe stories260k = 15e x
scoreboard players operation xs stories260k = 15s x
scoreboard players set yb stories260k 26189833
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 15b x = xb stories260k
scoreboard players operation 15e x = xe stories260k
scoreboard players operation 15s x = xs stories260k
scoreboard players operation xb stories260k = 16b x
scoreboard players operation xe stories260k = 16e x
scoreboard players operation xs stories260k = 16s x
scoreboard players set yb stories260k 18949711
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 16b x = xb stories260k
scoreboard players operation 16e x = xe stories260k
scoreboard players operation 16s x = xs stories260k
scoreboard players operation xb stories260k = 17b x
scoreboard players operation xe stories260k = 17e x
scoreboard players operation xs stories260k = 17s x
scoreboard players set yb stories260k 25378916
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 17b x = xb stories260k
scoreboard players operation 17e x = xe stories260k
scoreboard players operation 17s x = xs stories260k
scoreboard players operation xb stories260k = 18b x
scoreboard players operation xe stories260k = 18e x
scoreboard players operation xs stories260k = 18s x
scoreboard players set yb stories260k 12839134
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 18b x = xb stories260k
scoreboard players operation 18e x = xe stories260k
scoreboard players operation 18s x = xs stories260k
scoreboard players operation xb stories260k = 19b x
scoreboard players operation xe stories260k = 19e x
scoreboard players operation xs stories260k = 19s x
scoreboard players set yb stories260k 15506765
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 19b x = xb stories260k
scoreboard players operation 19e x = xe stories260k
scoreboard players operation 19s x = xs stories260k
scoreboard players operation xb stories260k = 20b x
scoreboard players operation xe stories260k = 20e x
scoreboard players operation xs stories260k = 20s x
scoreboard players set yb stories260k 13185338
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 20b x = xb stories260k
scoreboard players operation 20e x = xe stories260k
scoreboard players operation 20s x = xs stories260k
scoreboard players operation xb stories260k = 21b x
scoreboard players operation xe stories260k = 21e x
scoreboard players operation xs stories260k = 21s x
scoreboard players set yb stories260k 20146048
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 21b x = xb stories260k
scoreboard players operation 21e x = xe stories260k
scoreboard players operation 21s x = xs stories260k
scoreboard players operation xb stories260k = 22b x
scoreboard players operation xe stories260k = 22e x
scoreboard players operation xs stories260k = 22s x
scoreboard players set yb stories260k 16434079
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 22b x = xb stories260k
scoreboard players operation 22e x = xe stories260k
scoreboard players operation 22s x = xs stories260k
scoreboard players operation xb stories260k = 23b x
scoreboard players operation xe stories260k = 23e x
scoreboard players operation xs stories260k = 23s x
scoreboard players set yb stories260k 26970017
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 23b x = xb stories260k
scoreboard players operation 23e x = xe stories260k
scoreboard players operation 23s x = xs stories260k
scoreboard players operation xb stories260k = 24b x
scoreboard players operation xe stories260k = 24e x
scoreboard players operation xs stories260k = 24s x
scoreboard players set yb stories260k 17330426
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 24b x = xb stories260k
scoreboard players operation 24e x = xe stories260k
scoreboard players operation 24s x = xs stories260k
scoreboard players operation xb stories260k = 25b x
scoreboard players operation xe stories260k = 25e x
scoreboard players operation xs stories260k = 25s x
scoreboard players set yb stories260k 14055369
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 25b x = xb stories260k
scoreboard players operation 25e x = xe stories260k
scoreboard players operation 25s x = xs stories260k
scoreboard players operation xb stories260k = 26b x
scoreboard players operation xe stories260k = 26e x
scoreboard players operation xs stories260k = 26s x
scoreboard players set yb stories260k 23391402
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 26b x = xb stories260k
scoreboard players operation 26e x = xe stories260k
scoreboard players operation 26s x = xs stories260k
scoreboard players operation xb stories260k = 27b x
scoreboard players operation xe stories260k = 27e x
scoreboard players operation xs stories260k = 27s x
scoreboard players set yb stories260k 18733059
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 27b x = xb stories260k
scoreboard players operation 27e x = xe stories260k
scoreboard players operation 27s x = xs stories260k
scoreboard players operation xb stories260k = 28b x
scoreboard players operation xe stories260k = 28e x
scoreboard players operation xs stories260k = 28s x
scoreboard players set yb stories260k 11588085
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 28b x = xb stories260k
scoreboard players operation 28e x = xe stories260k
scoreboard players operation 28s x = xs stories260k
scoreboard players operation xb stories260k = 29b x
scoreboard players operation xe stories260k = 29e x
scoreboard players operation xs stories260k = 29s x
scoreboard players set yb stories260k 15791907
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 29b x = xb stories260k
scoreboard players operation 29e x = xe stories260k
scoreboard players operation 29s x = xs stories260k
scoreboard players operation xb stories260k = 30b x
scoreboard players operation xe stories260k = 30e x
scoreboard players operation xs stories260k = 30s x
scoreboard players set yb stories260k 12902747
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 30b x = xb stories260k
scoreboard players operation 30e x = xe stories260k
scoreboard players operation 30s x = xs stories260k
scoreboard players operation xb stories260k = 31b x
scoreboard players operation xe stories260k = 31e x
scoreboard players operation xs stories260k = 31s x
scoreboard players set yb stories260k 31819742
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 31b x = xb stories260k
scoreboard players operation 31e x = xe stories260k
scoreboard players operation 31s x = xs stories260k
scoreboard players operation xb stories260k = 32b x
scoreboard players operation xe stories260k = 32e x
scoreboard players operation xs stories260k = 32s x
scoreboard players set yb stories260k 19418539
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 32b x = xb stories260k
scoreboard players operation 32e x = xe stories260k
scoreboard players operation 32s x = xs stories260k
scoreboard players operation xb stories260k = 33b x
scoreboard players operation xe stories260k = 33e x
scoreboard players operation xs stories260k = 33s x
scoreboard players set yb stories260k 12282383
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 33b x = xb stories260k
scoreboard players operation 33e x = xe stories260k
scoreboard players operation 33s x = xs stories260k
scoreboard players operation xb stories260k = 34b x
scoreboard players operation xe stories260k = 34e x
scoreboard players operation xs stories260k = 34s x
scoreboard players set yb stories260k 14699891
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 34b x = xb stories260k
scoreboard players operation 34e x = xe stories260k
scoreboard players operation 34s x = xs stories260k
scoreboard players operation xb stories260k = 35b x
scoreboard players operation xe stories260k = 35e x
scoreboard players operation xs stories260k = 35s x
scoreboard players set yb stories260k 21156664
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 35b x = xb stories260k
scoreboard players operation 35e x = xe stories260k
scoreboard players operation 35s x = xs stories260k
scoreboard players operation xb stories260k = 36b x
scoreboard players operation xe stories260k = 36e x
scoreboard players operation xs stories260k = 36s x
scoreboard players set yb stories260k 16925602
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 36b x = xb stories260k
scoreboard players operation 36e x = xe stories260k
scoreboard players operation 36s x = xs stories260k
scoreboard players operation xb stories260k = 37b x
scoreboard players operation xe stories260k = 37e x
scoreboard players operation xs stories260k = 37s x
scoreboard players set yb stories260k 33886461
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 37b x = xb stories260k
scoreboard players operation 37e x = xe stories260k
scoreboard players operation 37s x = xs stories260k
scoreboard players operation xb stories260k = 38b x
scoreboard players operation xe stories260k = 38e x
scoreboard players operation xs stories260k = 38s x
scoreboard players set yb stories260k 12709773
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 38b x = xb stories260k
scoreboard players operation 38e x = xe stories260k
scoreboard players operation 38s x = xs stories260k
scoreboard players operation xb stories260k = 39b x
scoreboard players operation xe stories260k = 39e x
scoreboard players operation xs stories260k = 39s x
scoreboard players set yb stories260k 24227686
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 39b x = xb stories260k
scoreboard players operation 39e x = xe stories260k
scoreboard players operation 39s x = xs stories260k
scoreboard players operation xb stories260k = 40b x
scoreboard players operation xe stories260k = 40e x
scoreboard players operation xs stories260k = 40s x
scoreboard players set yb stories260k 19202864
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 40b x = xb stories260k
scoreboard players operation 40e x = xe stories260k
scoreboard players operation 40s x = xs stories260k
scoreboard players operation xb stories260k = 41b x
scoreboard players operation xe stories260k = 41e x
scoreboard players operation xs stories260k = 41s x
scoreboard players set yb stories260k 17946631
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 41b x = xb stories260k
scoreboard players operation 41e x = xe stories260k
scoreboard players operation 41s x = xs stories260k
scoreboard players operation xb stories260k = 42b x
scoreboard players operation xe stories260k = 42e x
scoreboard players operation xs stories260k = 42s x
scoreboard players set yb stories260k 11313292
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 42b x = xb stories260k
scoreboard players operation 42e x = xe stories260k
scoreboard players operation 42s x = xs stories260k
scoreboard players operation xb stories260k = 43b x
scoreboard players operation xe stories260k = 43e x
scoreboard players operation xs stories260k = 43s x
scoreboard players set yb stories260k 16754479
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 43b x = xb stories260k
scoreboard players operation 43e x = xe stories260k
scoreboard players operation 43s x = xs stories260k
scoreboard players operation xb stories260k = 44b x
scoreboard players operation xe stories260k = 44e x
scoreboard players operation xs stories260k = 44s x
scoreboard players set yb stories260k 13792142
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 44b x = xb stories260k
scoreboard players operation 44e x = xe stories260k
scoreboard players operation 44s x = xs stories260k
scoreboard players operation xb stories260k = 45b x
scoreboard players operation xe stories260k = 45e x
scoreboard players operation xs stories260k = 45s x
scoreboard players set yb stories260k 12172118
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 45b x = xb stories260k
scoreboard players operation 45e x = xe stories260k
scoreboard players operation 45s x = xs stories260k
scoreboard players operation xb stories260k = 46b x
scoreboard players operation xe stories260k = 46e x
scoreboard players operation xs stories260k = 46s x
scoreboard players set yb stories260k 13975564
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 46b x = xb stories260k
scoreboard players operation 46e x = xe stories260k
scoreboard players operation 46s x = xs stories260k
scoreboard players operation xb stories260k = 47b x
scoreboard players operation xe stories260k = 47e x
scoreboard players operation xs stories260k = 47s x
scoreboard players set yb stories260k 15128528
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 47b x = xb stories260k
scoreboard players operation 47e x = xe stories260k
scoreboard players operation 47s x = xs stories260k
scoreboard players operation xb stories260k = 48b x
scoreboard players operation xe stories260k = 48e x
scoreboard players operation xs stories260k = 48s x
scoreboard players set yb stories260k 18040856
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 48b x = xb stories260k
scoreboard players operation 48e x = xe stories260k
scoreboard players operation 48s x = xs stories260k
scoreboard players operation xb stories260k = 49b x
scoreboard players operation xe stories260k = 49e x
scoreboard players operation xs stories260k = 49s x
scoreboard players set yb stories260k 18138452
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 49b x = xb stories260k
scoreboard players operation 49e x = xe stories260k
scoreboard players operation 49s x = xs stories260k
scoreboard players operation xb stories260k = 50b x
scoreboard players operation xe stories260k = 50e x
scoreboard players operation xs stories260k = 50s x
scoreboard players set yb stories260k 19154131
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 50b x = xb stories260k
scoreboard players operation 50e x = xe stories260k
scoreboard players operation 50s x = xs stories260k
scoreboard players operation xb stories260k = 51b x
scoreboard players operation xe stories260k = 51e x
scoreboard players operation xs stories260k = 51s x
scoreboard players set yb stories260k 11676961
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 51b x = xb stories260k
scoreboard players operation 51e x = xe stories260k
scoreboard players operation 51s x = xs stories260k
scoreboard players operation xb stories260k = 52b x
scoreboard players operation xe stories260k = 52e x
scoreboard players operation xs stories260k = 52s x
scoreboard players set yb stories260k 23573880
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 52b x = xb stories260k
scoreboard players operation 52e x = xe stories260k
scoreboard players operation 52s x = xs stories260k
scoreboard players operation xb stories260k = 53b x
scoreboard players operation xe stories260k = 53e x
scoreboard players operation xs stories260k = 53s x
scoreboard players set yb stories260k 16348422
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 53b x = xb stories260k
scoreboard players operation 53e x = xe stories260k
scoreboard players operation 53s x = xs stories260k
scoreboard players operation xb stories260k = 54b x
scoreboard players operation xe stories260k = 54e x
scoreboard players operation xs stories260k = 54s x
scoreboard players set yb stories260k 20924938
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 54b x = xb stories260k
scoreboard players operation 54e x = xe stories260k
scoreboard players operation 54s x = xs stories260k
scoreboard players operation xb stories260k = 55b x
scoreboard players operation xe stories260k = 55e x
scoreboard players operation xs stories260k = 55s x
scoreboard players set yb stories260k 18415017
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 55b x = xb stories260k
scoreboard players operation 55e x = xe stories260k
scoreboard players operation 55s x = xs stories260k
scoreboard players operation xb stories260k = 56b x
scoreboard players operation xe stories260k = 56e x
scoreboard players operation xs stories260k = 56s x
scoreboard players set yb stories260k 23340414
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 56b x = xb stories260k
scoreboard players operation 56e x = xe stories260k
scoreboard players operation 56s x = xs stories260k
scoreboard players operation xb stories260k = 57b x
scoreboard players operation xe stories260k = 57e x
scoreboard players operation xs stories260k = 57s x
scoreboard players set yb stories260k 18213681
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 57b x = xb stories260k
scoreboard players operation 57e x = xe stories260k
scoreboard players operation 57s x = xs stories260k
scoreboard players operation xb stories260k = 58b x
scoreboard players operation xe stories260k = 58e x
scoreboard players operation xs stories260k = 58s x
scoreboard players set yb stories260k 18475415
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 58b x = xb stories260k
scoreboard players operation 58e x = xe stories260k
scoreboard players operation 58s x = xs stories260k
scoreboard players operation xb stories260k = 59b x
scoreboard players operation xe stories260k = 59e x
scoreboard players operation xs stories260k = 59s x
scoreboard players set yb stories260k 19169949
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 59b x = xb stories260k
scoreboard players operation 59e x = xe stories260k
scoreboard players operation 59s x = xs stories260k
scoreboard players operation xb stories260k = 60b x
scoreboard players operation xe stories260k = 60e x
scoreboard players operation xs stories260k = 60s x
scoreboard players set yb stories260k 17217220
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 60b x = xb stories260k
scoreboard players operation 60e x = xe stories260k
scoreboard players operation 60s x = xs stories260k
scoreboard players operation xb stories260k = 61b x
scoreboard players operation xe stories260k = 61e x
scoreboard players operation xs stories260k = 61s x
scoreboard players set yb stories260k 97203809
scoreboard players set ye stories260k -1
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 61b x = xb stories260k
scoreboard players operation 61e x = xe stories260k
scoreboard players operation 61s x = xs stories260k
scoreboard players operation xb stories260k = 62b x
scoreboard players operation xe stories260k = 62e x
scoreboard players operation xs stories260k = 62s x
scoreboard players set yb stories260k 14526384
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 62b x = xb stories260k
scoreboard players operation 62e x = xe stories260k
scoreboard players operation 62s x = xs stories260k
scoreboard players operation xb stories260k = 63b x
scoreboard players operation xe stories260k = 63e x
scoreboard players operation xs stories260k = 63s x
scoreboard players set yb stories260k 17077769
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:mul
scoreboard players operation 63b x = xb stories260k
scoreboard players operation 63e x = xe stories260k
scoreboard players operation 63s x = xs stories260k
function stories260k:matmul_logits
