execute if score xe stories260k > ye stories260k run return run scoreboard players set r stories260k 1
execute if score xe stories260k < ye stories260k run return run scoreboard players set r stories260k -1
execute if score xb stories260k > yb stories260k run return run scoreboard players set r stories260k 1
execute if score xb stories260k < yb stories260k run return run scoreboard players set r stories260k -1
scoreboard players set r stories260k 0
