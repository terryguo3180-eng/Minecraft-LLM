execute if data storage stories260k args{c:'~'} run return run scoreboard players set tok stories260k 510
execute if data storage stories260k args{c:']'} run return run scoreboard players set tok stories260k 509
execute if data storage stories260k args{c:'['} run return run scoreboard players set tok stories260k 508
execute if data storage stories260k args{c:'™'} run return run scoreboard players set tok stories260k 507
execute if data storage stories260k args{c:'|'} run return run scoreboard players set tok stories260k 506
execute if data storage stories260k args{c:'>'} run return run scoreboard players set tok stories260k 505
execute if data storage stories260k args{c:'<'} run return run scoreboard players set tok stories260k 504
execute if data storage stories260k args{c:'€'} run return run scoreboard players set tok stories260k 503
execute if data storage stories260k args{c:'â'} run return run scoreboard players set tok stories260k 502
execute if data storage stories260k args{c:'%'} run return run scoreboard players set tok stories260k 501
execute if data storage stories260k args{c:'\\'} run return run scoreboard players set tok stories260k 500
execute if data storage stories260k args{c:'&'} run return run scoreboard players set tok stories260k 499
execute if data storage stories260k args{c:'*'} run return run scoreboard players set tok stories260k 497
execute if data storage stories260k args{c:'+'} run return run scoreboard players set tok stories260k 496
execute if data storage stories260k args{c:'`'} run return run scoreboard players set tok stories260k 495
execute if data storage stories260k args{c:'$'} run return run scoreboard players set tok stories260k 494
execute if data storage stories260k args{c:'ñ'} run return run scoreboard players set tok stories260k 493
execute if data storage stories260k args{c:'/'} run return run scoreboard players set tok stories260k 492
execute if data storage stories260k args{c:'7'} run return run scoreboard players set tok stories260k 491
execute if data storage stories260k args{c:'6'} run return run scoreboard players set tok stories260k 490
execute if data storage stories260k args{c:'('} run return run scoreboard players set tok stories260k 489
execute if data storage stories260k args{c:')'} run return run scoreboard players set tok stories260k 488
execute if data storage stories260k args{c:'8'} run return run scoreboard players set tok stories260k 487
execute if data storage stories260k args{c:'…'} run return run scoreboard players set tok stories260k 486
execute if data storage stories260k args{c:'é'} run return run scoreboard players set tok stories260k 485
execute if data storage stories260k args{c:'4'} run return run scoreboard players set tok stories260k 484
execute if data storage stories260k args{c:'9'} run return run scoreboard players set tok stories260k 483
execute if data storage stories260k args{c:'‘'} run return run scoreboard players set tok stories260k 482
execute if data storage stories260k args{c:'—'} run return run scoreboard players set tok stories260k 481
execute if data storage stories260k args{c:'5'} run return run scoreboard players set tok stories260k 480
execute if data storage stories260k args{c:'2'} run return run scoreboard players set tok stories260k 479
execute if data storage stories260k args{c:'X'} run return run scoreboard players set tok stories260k 478
execute if data storage stories260k args{c:'0'} run return run scoreboard players set tok stories260k 477
execute if data storage stories260k args{c:'–'} run return run scoreboard players set tok stories260k 476
execute if data storage stories260k args{c:'1'} run return run scoreboard players set tok stories260k 475
execute if data storage stories260k args{c:';'} run return run scoreboard players set tok stories260k 474
execute if data storage stories260k args{c:'Q'} run return run scoreboard players set tok stories260k 473
execute if data storage stories260k args{c:'3'} run return run scoreboard players set tok stories260k 472
execute if data storage stories260k args{c:'U'} run return run scoreboard players set tok stories260k 471
execute if data storage stories260k args{c:'V'} run return run scoreboard players set tok stories260k 470
execute if data storage stories260k args{c:'Z'} run return run scoreboard players set tok stories260k 469
execute if data storage stories260k args{c:'’'} run return run scoreboard players set tok stories260k 468
execute if data storage stories260k args{c:':'} run return run scoreboard players set tok stories260k 467
execute if data storage stories260k args{c:'”'} run return run scoreboard players set tok stories260k 466
execute if data storage stories260k args{c:'“'} run return run scoreboard players set tok stories260k 465
execute if data storage stories260k args{c:'-'} run return run scoreboard players set tok stories260k 464
execute if data storage stories260k args{c:'G'} run return run scoreboard players set tok stories260k 463
execute if data storage stories260k args{c:'K'} run return run scoreboard players set tok stories260k 462
execute if data storage stories260k args{c:'R'} run return run scoreboard players set tok stories260k 461
execute if data storage stories260k args{c:'P'} run return run scoreboard players set tok stories260k 460
execute if data storage stories260k args{c:'E'} run return run scoreboard players set tok stories260k 459
execute if data storage stories260k args{c:'N'} run return run scoreboard players set tok stories260k 458
execute if data storage stories260k args{c:'C'} run return run scoreboard players set tok stories260k 457
execute if data storage stories260k args{c:'q'} run return run scoreboard players set tok stories260k 456
execute if data storage stories260k args{c:'D'} run return run scoreboard players set tok stories260k 455
execute if data storage stories260k args{c:'J'} run return run scoreboard players set tok stories260k 454
execute if data storage stories260k args{c:'F'} run return run scoreboard players set tok stories260k 453
execute if data storage stories260k args{c:'Y'} run return run scoreboard players set tok stories260k 452
execute if data storage stories260k args{c:'z'} run return run scoreboard players set tok stories260k 451
execute if data storage stories260k args{c:'?'} run return run scoreboard players set tok stories260k 450
execute if data storage stories260k args{c:'j'} run return run scoreboard players set tok stories260k 449
execute if data storage stories260k args{c:'W'} run return run scoreboard players set tok stories260k 448
execute if data storage stories260k args{c:'A'} run return run scoreboard players set tok stories260k 447
execute if data storage stories260k args{c:'M'} run return run scoreboard players set tok stories260k 446
execute if data storage stories260k args{c:'B'} run return run scoreboard players set tok stories260k 445
execute if data storage stories260k args{c:'x'} run return run scoreboard players set tok stories260k 444
execute if data storage stories260k args{c:'!'} run return run scoreboard players set tok stories260k 443
execute if data storage stories260k args{c:'I'} run return run scoreboard players set tok stories260k 442
execute if data storage stories260k args{c:'O'} run return run scoreboard players set tok stories260k 441
execute if data storage stories260k args{c:'H'} run return run scoreboard players set tok stories260k 440
execute if data storage stories260k args{c:"'"} run return run scoreboard players set tok stories260k 439
execute if data storage stories260k args{c:'L'} run return run scoreboard players set tok stories260k 438
execute if data storage stories260k args{c:'S'} run return run scoreboard players set tok stories260k 437
execute if data storage stories260k args{c:'"'} run return run scoreboard players set tok stories260k 436
execute if data storage stories260k args{c:'v'} run return run scoreboard players set tok stories260k 435
execute if data storage stories260k args{c:'T'} run return run scoreboard players set tok stories260k 434
execute if data storage stories260k args{c:'k'} run return run scoreboard players set tok stories260k 433
execute if data storage stories260k args{c:','} run return run scoreboard players set tok stories260k 432
execute if data storage stories260k args{c:'f'} run return run scoreboard players set tok stories260k 431
execute if data storage stories260k args{c:'b'} run return run scoreboard players set tok stories260k 430
execute if data storage stories260k args{c:'c'} run return run scoreboard players set tok stories260k 429
execute if data storage stories260k args{c:'g'} run return run scoreboard players set tok stories260k 428
execute if data storage stories260k args{c:'p'} run return run scoreboard players set tok stories260k 427
execute if data storage stories260k args{c:'.'} run return run scoreboard players set tok stories260k 426
execute if data storage stories260k args{c:'u'} run return run scoreboard players set tok stories260k 425
execute if data storage stories260k args{c:'w'} run return run scoreboard players set tok stories260k 424
execute if data storage stories260k args{c:'m'} run return run scoreboard players set tok stories260k 423
execute if data storage stories260k args{c:'y'} run return run scoreboard players set tok stories260k 422
execute if data storage stories260k args{c:'l'} run return run scoreboard players set tok stories260k 421
execute if data storage stories260k args{c:'r'} run return run scoreboard players set tok stories260k 420
execute if data storage stories260k args{c:'s'} run return run scoreboard players set tok stories260k 419
execute if data storage stories260k args{c:'d'} run return run scoreboard players set tok stories260k 418
execute if data storage stories260k args{c:'i'} run return run scoreboard players set tok stories260k 417
execute if data storage stories260k args{c:'n'} run return run scoreboard players set tok stories260k 416
execute if data storage stories260k args{c:'h'} run return run scoreboard players set tok stories260k 415
execute if data storage stories260k args{c:'o'} run return run scoreboard players set tok stories260k 414
execute if data storage stories260k args{c:'t'} run return run scoreboard players set tok stories260k 413
execute if data storage stories260k args{c:'a'} run return run scoreboard players set tok stories260k 412
execute if data storage stories260k args{c:'e'} run return run scoreboard players set tok stories260k 411
execute if data storage stories260k args{c:' '} run return run scoreboard players set tok stories260k 410
execute if data storage stories260k args{c:' k'} run return run scoreboard players set tok stories260k 409
execute if data storage stories260k args{c:'out'} run return run scoreboard players set tok stories260k 408
execute if data storage stories260k args{c:' upon'} run return run scoreboard players set tok stories260k 407
execute if data storage stories260k args{c:'es'} run return run scoreboard players set tok stories260k 406
execute if data storage stories260k args{c:' Timmy'} run return run scoreboard players set tok stories260k 405
execute if data storage stories260k args{c:' ne'} run return run scoreboard players set tok stories260k 404
execute if data storage stories260k args{c:' Once'} run return run scoreboard players set tok stories260k 403
execute if data storage stories260k args{c:'ch'} run return run scoreboard players set tok stories260k 402
execute if data storage stories260k args{c:' lo'} run return run scoreboard players set tok stories260k 401
execute if data storage stories260k args{c:' do'} run return run scoreboard players set tok stories260k 400
execute if data storage stories260k args{c:' very'} run return run scoreboard players set tok stories260k 399
execute if data storage stories260k args{c:' but'} run return run scoreboard players set tok stories260k 398
execute if data storage stories260k args{c:' li'} run return run scoreboard players set tok stories260k 397
execute if data storage stories260k args{c:'ved'} run return run scoreboard players set tok stories260k 396
execute if data storage stories260k args{c:' named'} run return run scoreboard players set tok stories260k 395
execute if data storage stories260k args{c:' saw'} run return run scoreboard players set tok stories260k 394
execute if data storage stories260k args{c:' happy'} run return run scoreboard players set tok stories260k 393
execute if data storage stories260k args{c:' M'} run return run scoreboard players set tok stories260k 392
execute if data storage stories260k args{c:' want'} run return run scoreboard players set tok stories260k 391
execute if data storage stories260k args{c:' nam'} run return run scoreboard players set tok stories260k 390
execute if data storage stories260k args{c:'ould'} run return run scoreboard players set tok stories260k 389
execute if data storage stories260k args{c:'all'} run return run scoreboard players set tok stories260k 388
execute if data storage stories260k args{c:' for'} run return run scoreboard players set tok stories260k 387
execute if data storage stories260k args{c:'her'} run return run scoreboard players set tok stories260k 386
execute if data storage stories260k args{c:' One'} run return run scoreboard players set tok stories260k 385
execute if data storage stories260k args{c:' so'} run return run scoreboard players set tok stories260k 384
execute if data storage stories260k args{c:' there'} run return run scoreboard players set tok stories260k 383
execute if data storage stories260k args{c:' we'} run return run scoreboard players set tok stories260k 382
execute if data storage stories260k args{c:' had'} run return run scoreboard players set tok stories260k 381
execute if data storage stories260k args{c:'ad'} run return run scoreboard players set tok stories260k 380
execute if data storage stories260k args{c:'un'} run return run scoreboard players set tok stories260k 379
execute if data storage stories260k args{c:' time'} run return run scoreboard players set tok stories260k 378
execute if data storage stories260k args{c:'ent'} run return run scoreboard players set tok stories260k 377
execute if data storage stories260k args{c:' little'} run return run scoreboard players set tok stories260k 376
execute if data storage stories260k args{c:'ittle'} run return run scoreboard players set tok stories260k 375
execute if data storage stories260k args{c:' friend'} run return run scoreboard players set tok stories260k 374
execute if data storage stories260k args{c:' of'} run return run scoreboard players set tok stories260k 373
execute if data storage stories260k args{c:'se'} run return run scoreboard players set tok stories260k 372
execute if data storage stories260k args{c:' fri'} run return run scoreboard players set tok stories260k 371
execute if data storage stories260k args{c:' big'} run return run scoreboard players set tok stories260k 370
execute if data storage stories260k args{c:'ime'} run return run scoreboard players set tok stories260k 369
execute if data storage stories260k args{c:' B'} run return run scoreboard players set tok stories260k 368
execute if data storage stories260k args{c:'end'} run return run scoreboard players set tok stories260k 367
execute if data storage stories260k args{c:' they'} run return run scoreboard players set tok stories260k 366
execute if data storage stories260k args{c:' happ'} run return run scoreboard players set tok stories260k 365
execute if data storage stories260k args{c:' you'} run return run scoreboard players set tok stories260k 364
execute if data storage stories260k args{c:'very'} run return run scoreboard players set tok stories260k 363
execute if data storage stories260k args{c:'itt'} run return run scoreboard players set tok stories260k 362
execute if data storage stories260k args{c:'nt'} run return run scoreboard players set tok stories260k 361
execute if data storage stories260k args{c:'ve'} run return run scoreboard players set tok stories260k 360
execute if data storage stories260k args{c:' I'} run return run scoreboard players set tok stories260k 359
execute if data storage stories260k args{c:' she'} run return run scoreboard players set tok stories260k 358
execute if data storage stories260k args{c:' mom'} run return run scoreboard players set tok stories260k 357
execute if data storage stories260k args{c:'st'} run return run scoreboard players set tok stories260k 356
execute if data storage stories260k args{c:'ked'} run return run scoreboard players set tok stories260k 355
execute if data storage stories260k args{c:'ke'} run return run scoreboard players set tok stories260k 354
execute if data storage stories260k args{c:' on'} run return run scoreboard players set tok stories260k 353
execute if data storage stories260k args{c:' r'} run return run scoreboard players set tok stories260k 352
execute if data storage stories260k args{c:' that'} run return run scoreboard players set tok stories260k 351
execute if data storage stories260k args{c:' up'} run return run scoreboard players set tok stories260k 350
execute if data storage stories260k args{c:' st'} run return run scoreboard players set tok stories260k 349
execute if data storage stories260k args{c:' y'} run return run scoreboard players set tok stories260k 348
execute if data storage stories260k args{c:'oo'} run return run scoreboard players set tok stories260k 347
execute if data storage stories260k args{c:' He'} run return run scoreboard players set tok stories260k 346
execute if data storage stories260k args{c:' his'} run return run scoreboard players set tok stories260k 345
execute if data storage stories260k args{c:' e'} run return run scoreboard players set tok stories260k 344
execute if data storage stories260k args{c:'my'} run return run scoreboard players set tok stories260k 343
execute if data storage stories260k args{c:' They'} run return run scoreboard players set tok stories260k 342
execute if data storage stories260k args{c:'ld'} run return run scoreboard players set tok stories260k 341
execute if data storage stories260k args{c:'ck'} run return run scoreboard players set tok stories260k 340
execute if data storage stories260k args{c:'pp'} run return run scoreboard players set tok stories260k 339
execute if data storage stories260k args{c:' She'} run return run scoreboard players set tok stories260k 338
execute if data storage stories260k args{c:' play'} run return run scoreboard players set tok stories260k 337
execute if data storage stories260k args{c:' said'} run return run scoreboard players set tok stories260k 336
execute if data storage stories260k args{c:' with'} run return run scoreboard players set tok stories260k 335
execute if data storage stories260k args{c:' o'} run return run scoreboard players set tok stories260k 334
execute if data storage stories260k args{c:'ig'} run return run scoreboard players set tok stories260k 333
execute if data storage stories260k args{c:'ith'} run return run scoreboard players set tok stories260k 332
execute if data storage stories260k args{c:'ce'} run return run scoreboard players set tok stories260k 331
execute if data storage stories260k args{c:'ver'} run return run scoreboard players set tok stories260k 330
execute if data storage stories260k args{c:' be'} run return run scoreboard players set tok stories260k 329
execute if data storage stories260k args{c:' day'} run return run scoreboard players set tok stories260k 328
execute if data storage stories260k args{c:'ow'} run return run scoreboard players set tok stories260k 327
execute if data storage stories260k args{c:' Tim'} run return run scoreboard players set tok stories260k 326
execute if data storage stories260k args{c:'ri'} run return run scoreboard players set tok stories260k 325
execute if data storage stories260k args{c:' pl'} run return run scoreboard players set tok stories260k 324
execute if data storage stories260k args{c:'ut'} run return run scoreboard players set tok stories260k 323
execute if data storage stories260k args{c:' in'} run return run scoreboard players set tok stories260k 322
execute if data storage stories260k args{c:' On'} run return run scoreboard players set tok stories260k 321
execute if data storage stories260k args{c:' H'} run return run scoreboard players set tok stories260k 320
execute if data storage stories260k args{c:' O'} run return run scoreboard players set tok stories260k 319
execute if data storage stories260k args{c:' u'} run return run scoreboard players set tok stories260k 318
execute if data storage stories260k args{c:' Lily'} run return run scoreboard players set tok stories260k 317
execute if data storage stories260k args{c:'et'} run return run scoreboard players set tok stories260k 316
execute if data storage stories260k args{c:'ir'} run return run scoreboard players set tok stories260k 315
execute if data storage stories260k args{c:'am'} run return run scoreboard players set tok stories260k 314
execute if data storage stories260k args{c:' "'} run return run scoreboard players set tok stories260k 313
execute if data storage stories260k args{c:' it'} run return run scoreboard players set tok stories260k 312
execute if data storage stories260k args{c:' her'} run return run scoreboard players set tok stories260k 311
execute if data storage stories260k args{c:'ily'} run return run scoreboard players set tok stories260k 310
execute if data storage stories260k args{c:'ot'} run return run scoreboard players set tok stories260k 309
execute if data storage stories260k args{c:' th'} run return run scoreboard players set tok stories260k 308
execute if data storage stories260k args{c:' L'} run return run scoreboard players set tok stories260k 307
execute if data storage stories260k args{c:'ll'} run return run scoreboard players set tok stories260k 306
execute if data storage stories260k args{c:'le'} run return run scoreboard players set tok stories260k 305
execute if data storage stories260k args{c:'or'} run return run scoreboard players set tok stories260k 304
execute if data storage stories260k args{c:'an'} run return run scoreboard players set tok stories260k 303
execute if data storage stories260k args{c:'en'} run return run scoreboard players set tok stories260k 302
execute if data storage stories260k args{c:' S'} run return run scoreboard players set tok stories260k 301
execute if data storage stories260k args{c:' ha'} run return run scoreboard players set tok stories260k 300
execute if data storage stories260k args{c:'ing'} run return run scoreboard players set tok stories260k 299
execute if data storage stories260k args{c:' g'} run return run scoreboard players set tok stories260k 298
execute if data storage stories260k args{c:' n'} run return run scoreboard players set tok stories260k 297
execute if data storage stories260k args{c:' sa'} run return run scoreboard players set tok stories260k 296
execute if data storage stories260k args{c:'ar'} run return run scoreboard players set tok stories260k 295
execute if data storage stories260k args{c:'at'} run return run scoreboard players set tok stories260k 294
execute if data storage stories260k args{c:'is'} run return run scoreboard players set tok stories260k 293
execute if data storage stories260k args{c:'id'} run return run scoreboard players set tok stories260k 292
execute if data storage stories260k args{c:' The'} run return run scoreboard players set tok stories260k 291
execute if data storage stories260k args{c:'il'} run return run scoreboard players set tok stories260k 290
execute if data storage stories260k args{c:'on'} run return run scoreboard players set tok stories260k 289
execute if data storage stories260k args{c:'im'} run return run scoreboard players set tok stories260k 288
execute if data storage stories260k args{c:'om'} run return run scoreboard players set tok stories260k 287
execute if data storage stories260k args{c:' was'} run return run scoreboard players set tok stories260k 286
execute if data storage stories260k args{c:'er'} run return run scoreboard players set tok stories260k 285
execute if data storage stories260k args{c:' m'} run return run scoreboard players set tok stories260k 284
execute if data storage stories260k args{c:'ay'} run return run scoreboard players set tok stories260k 283
execute if data storage stories260k args{c:' p'} run return run scoreboard players set tok stories260k 282
execute if data storage stories260k args{c:' he'} run return run scoreboard players set tok stories260k 281
execute if data storage stories260k args{c:' c'} run return run scoreboard players set tok stories260k 280
execute if data storage stories260k args{c:' d'} run return run scoreboard players set tok stories260k 279
execute if data storage stories260k args{c:' l'} run return run scoreboard players set tok stories260k 278
execute if data storage stories260k args{c:'ou'} run return run scoreboard players set tok stories260k 277
execute if data storage stories260k args{c:'re'} run return run scoreboard players set tok stories260k 276
execute if data storage stories260k args{c:'it'} run return run scoreboard players set tok stories260k 275
execute if data storage stories260k args{c:' T'} run return run scoreboard players set tok stories260k 274
execute if data storage stories260k args{c:' wa'} run return run scoreboard players set tok stories260k 273
execute if data storage stories260k args{c:' f'} run return run scoreboard players set tok stories260k 272
execute if data storage stories260k args{c:'in'} run return run scoreboard players set tok stories260k 271
execute if data storage stories260k args{c:' h'} run return run scoreboard players set tok stories260k 270
execute if data storage stories260k args{c:' and'} run return run scoreboard players set tok stories260k 269
execute if data storage stories260k args{c:' b'} run return run scoreboard players set tok stories260k 268
execute if data storage stories260k args{c:' to'} run return run scoreboard players set tok stories260k 267
execute if data storage stories260k args{c:'ed'} run return run scoreboard players set tok stories260k 266
execute if data storage stories260k args{c:' the'} run return run scoreboard players set tok stories260k 265
execute if data storage stories260k args{c:'nd'} run return run scoreboard players set tok stories260k 264
execute if data storage stories260k args{c:' w'} run return run scoreboard players set tok stories260k 263
execute if data storage stories260k args{c:' s'} run return run scoreboard players set tok stories260k 262
execute if data storage stories260k args{c:' a'} run return run scoreboard players set tok stories260k 261
execute if data storage stories260k args{c:'he'} run return run scoreboard players set tok stories260k 260
execute if data storage stories260k args{c:' t'} run return run scoreboard players set tok stories260k 259
execute if data storage stories260k args{c:'ÿ'} run return run scoreboard players set tok stories260k 258
execute if data storage stories260k args{c:'þ'} run return run scoreboard players set tok stories260k 257
execute if data storage stories260k args{c:'ý'} run return run scoreboard players set tok stories260k 256
execute if data storage stories260k args{c:'ü'} run return run scoreboard players set tok stories260k 255
execute if data storage stories260k args{c:'û'} run return run scoreboard players set tok stories260k 254
execute if data storage stories260k args{c:'ú'} run return run scoreboard players set tok stories260k 253
execute if data storage stories260k args{c:'ù'} run return run scoreboard players set tok stories260k 252
execute if data storage stories260k args{c:'ø'} run return run scoreboard players set tok stories260k 251
execute if data storage stories260k args{c:'÷'} run return run scoreboard players set tok stories260k 250
execute if data storage stories260k args{c:'ö'} run return run scoreboard players set tok stories260k 249
execute if data storage stories260k args{c:'õ'} run return run scoreboard players set tok stories260k 248
execute if data storage stories260k args{c:'ô'} run return run scoreboard players set tok stories260k 247
execute if data storage stories260k args{c:'ó'} run return run scoreboard players set tok stories260k 246
execute if data storage stories260k args{c:'ò'} run return run scoreboard players set tok stories260k 245
execute if data storage stories260k args{c:'ñ'} run return run scoreboard players set tok stories260k 244
execute if data storage stories260k args{c:'ð'} run return run scoreboard players set tok stories260k 243
execute if data storage stories260k args{c:'ï'} run return run scoreboard players set tok stories260k 242
execute if data storage stories260k args{c:'î'} run return run scoreboard players set tok stories260k 241
execute if data storage stories260k args{c:'í'} run return run scoreboard players set tok stories260k 240
execute if data storage stories260k args{c:'ì'} run return run scoreboard players set tok stories260k 239
execute if data storage stories260k args{c:'ë'} run return run scoreboard players set tok stories260k 238
execute if data storage stories260k args{c:'ê'} run return run scoreboard players set tok stories260k 237
execute if data storage stories260k args{c:'é'} run return run scoreboard players set tok stories260k 236
execute if data storage stories260k args{c:'è'} run return run scoreboard players set tok stories260k 235
execute if data storage stories260k args{c:'ç'} run return run scoreboard players set tok stories260k 234
execute if data storage stories260k args{c:'æ'} run return run scoreboard players set tok stories260k 233
execute if data storage stories260k args{c:'å'} run return run scoreboard players set tok stories260k 232
execute if data storage stories260k args{c:'ä'} run return run scoreboard players set tok stories260k 231
execute if data storage stories260k args{c:'ã'} run return run scoreboard players set tok stories260k 230
execute if data storage stories260k args{c:'â'} run return run scoreboard players set tok stories260k 229
execute if data storage stories260k args{c:'á'} run return run scoreboard players set tok stories260k 228
execute if data storage stories260k args{c:'à'} run return run scoreboard players set tok stories260k 227
execute if data storage stories260k args{c:'ß'} run return run scoreboard players set tok stories260k 226
execute if data storage stories260k args{c:'Þ'} run return run scoreboard players set tok stories260k 225
execute if data storage stories260k args{c:'Ý'} run return run scoreboard players set tok stories260k 224
execute if data storage stories260k args{c:'Ü'} run return run scoreboard players set tok stories260k 223
execute if data storage stories260k args{c:'Û'} run return run scoreboard players set tok stories260k 222
execute if data storage stories260k args{c:'Ú'} run return run scoreboard players set tok stories260k 221
execute if data storage stories260k args{c:'Ù'} run return run scoreboard players set tok stories260k 220
execute if data storage stories260k args{c:'Ø'} run return run scoreboard players set tok stories260k 219
execute if data storage stories260k args{c:'×'} run return run scoreboard players set tok stories260k 218
execute if data storage stories260k args{c:'Ö'} run return run scoreboard players set tok stories260k 217
execute if data storage stories260k args{c:'Õ'} run return run scoreboard players set tok stories260k 216
execute if data storage stories260k args{c:'Ô'} run return run scoreboard players set tok stories260k 215
execute if data storage stories260k args{c:'Ó'} run return run scoreboard players set tok stories260k 214
execute if data storage stories260k args{c:'Ò'} run return run scoreboard players set tok stories260k 213
execute if data storage stories260k args{c:'Ñ'} run return run scoreboard players set tok stories260k 212
execute if data storage stories260k args{c:'Ð'} run return run scoreboard players set tok stories260k 211
execute if data storage stories260k args{c:'Ï'} run return run scoreboard players set tok stories260k 210
execute if data storage stories260k args{c:'Î'} run return run scoreboard players set tok stories260k 209
execute if data storage stories260k args{c:'Í'} run return run scoreboard players set tok stories260k 208
execute if data storage stories260k args{c:'Ì'} run return run scoreboard players set tok stories260k 207
execute if data storage stories260k args{c:'Ë'} run return run scoreboard players set tok stories260k 206
execute if data storage stories260k args{c:'Ê'} run return run scoreboard players set tok stories260k 205
execute if data storage stories260k args{c:'É'} run return run scoreboard players set tok stories260k 204
execute if data storage stories260k args{c:'È'} run return run scoreboard players set tok stories260k 203
execute if data storage stories260k args{c:'Ç'} run return run scoreboard players set tok stories260k 202
execute if data storage stories260k args{c:'Æ'} run return run scoreboard players set tok stories260k 201
execute if data storage stories260k args{c:'Å'} run return run scoreboard players set tok stories260k 200
execute if data storage stories260k args{c:'Ä'} run return run scoreboard players set tok stories260k 199
execute if data storage stories260k args{c:'Ã'} run return run scoreboard players set tok stories260k 198
execute if data storage stories260k args{c:'Â'} run return run scoreboard players set tok stories260k 197
execute if data storage stories260k args{c:'Á'} run return run scoreboard players set tok stories260k 196
execute if data storage stories260k args{c:'À'} run return run scoreboard players set tok stories260k 195
execute if data storage stories260k args{c:'¿'} run return run scoreboard players set tok stories260k 194
execute if data storage stories260k args{c:'¾'} run return run scoreboard players set tok stories260k 193
execute if data storage stories260k args{c:'½'} run return run scoreboard players set tok stories260k 192
execute if data storage stories260k args{c:'¼'} run return run scoreboard players set tok stories260k 191
execute if data storage stories260k args{c:'»'} run return run scoreboard players set tok stories260k 190
execute if data storage stories260k args{c:'º'} run return run scoreboard players set tok stories260k 189
execute if data storage stories260k args{c:'¹'} run return run scoreboard players set tok stories260k 188
execute if data storage stories260k args{c:'¸'} run return run scoreboard players set tok stories260k 187
execute if data storage stories260k args{c:'·'} run return run scoreboard players set tok stories260k 186
execute if data storage stories260k args{c:'¶'} run return run scoreboard players set tok stories260k 185
execute if data storage stories260k args{c:'µ'} run return run scoreboard players set tok stories260k 184
execute if data storage stories260k args{c:'´'} run return run scoreboard players set tok stories260k 183
execute if data storage stories260k args{c:'³'} run return run scoreboard players set tok stories260k 182
execute if data storage stories260k args{c:'²'} run return run scoreboard players set tok stories260k 181
execute if data storage stories260k args{c:'±'} run return run scoreboard players set tok stories260k 180
execute if data storage stories260k args{c:'°'} run return run scoreboard players set tok stories260k 179
execute if data storage stories260k args{c:'¯'} run return run scoreboard players set tok stories260k 178
execute if data storage stories260k args{c:'®'} run return run scoreboard players set tok stories260k 177
execute if data storage stories260k args{c:'¬'} run return run scoreboard players set tok stories260k 175
execute if data storage stories260k args{c:'«'} run return run scoreboard players set tok stories260k 174
execute if data storage stories260k args{c:'ª'} run return run scoreboard players set tok stories260k 173
execute if data storage stories260k args{c:'©'} run return run scoreboard players set tok stories260k 172
execute if data storage stories260k args{c:'¨'} run return run scoreboard players set tok stories260k 171
execute if data storage stories260k args{c:'§'} run return run scoreboard players set tok stories260k 170
execute if data storage stories260k args{c:'¦'} run return run scoreboard players set tok stories260k 169
execute if data storage stories260k args{c:'¥'} run return run scoreboard players set tok stories260k 168
execute if data storage stories260k args{c:'¤'} run return run scoreboard players set tok stories260k 167
execute if data storage stories260k args{c:'£'} run return run scoreboard players set tok stories260k 166
execute if data storage stories260k args{c:'¢'} run return run scoreboard players set tok stories260k 165
execute if data storage stories260k args{c:'¡'} run return run scoreboard players set tok stories260k 164
execute if data storage stories260k args{c:'~'} run return run scoreboard players set tok stories260k 129
execute if data storage stories260k args{c:'}'} run return run scoreboard players set tok stories260k 128
execute if data storage stories260k args{c:'|'} run return run scoreboard players set tok stories260k 127
execute if data storage stories260k args{c:'{'} run return run scoreboard players set tok stories260k 126
execute if data storage stories260k args{c:'z'} run return run scoreboard players set tok stories260k 125
execute if data storage stories260k args{c:'y'} run return run scoreboard players set tok stories260k 124
execute if data storage stories260k args{c:'x'} run return run scoreboard players set tok stories260k 123
execute if data storage stories260k args{c:'w'} run return run scoreboard players set tok stories260k 122
execute if data storage stories260k args{c:'v'} run return run scoreboard players set tok stories260k 121
execute if data storage stories260k args{c:'u'} run return run scoreboard players set tok stories260k 120
execute if data storage stories260k args{c:'t'} run return run scoreboard players set tok stories260k 119
execute if data storage stories260k args{c:'s'} run return run scoreboard players set tok stories260k 118
execute if data storage stories260k args{c:'r'} run return run scoreboard players set tok stories260k 117
execute if data storage stories260k args{c:'q'} run return run scoreboard players set tok stories260k 116
execute if data storage stories260k args{c:'p'} run return run scoreboard players set tok stories260k 115
execute if data storage stories260k args{c:'o'} run return run scoreboard players set tok stories260k 114
execute if data storage stories260k args{c:'n'} run return run scoreboard players set tok stories260k 113
execute if data storage stories260k args{c:'m'} run return run scoreboard players set tok stories260k 112
execute if data storage stories260k args{c:'l'} run return run scoreboard players set tok stories260k 111
execute if data storage stories260k args{c:'k'} run return run scoreboard players set tok stories260k 110
execute if data storage stories260k args{c:'j'} run return run scoreboard players set tok stories260k 109
execute if data storage stories260k args{c:'i'} run return run scoreboard players set tok stories260k 108
execute if data storage stories260k args{c:'h'} run return run scoreboard players set tok stories260k 107
execute if data storage stories260k args{c:'g'} run return run scoreboard players set tok stories260k 106
execute if data storage stories260k args{c:'f'} run return run scoreboard players set tok stories260k 105
execute if data storage stories260k args{c:'e'} run return run scoreboard players set tok stories260k 104
execute if data storage stories260k args{c:'d'} run return run scoreboard players set tok stories260k 103
execute if data storage stories260k args{c:'c'} run return run scoreboard players set tok stories260k 102
execute if data storage stories260k args{c:'b'} run return run scoreboard players set tok stories260k 101
execute if data storage stories260k args{c:'a'} run return run scoreboard players set tok stories260k 100
execute if data storage stories260k args{c:'`'} run return run scoreboard players set tok stories260k 99
execute if data storage stories260k args{c:'_'} run return run scoreboard players set tok stories260k 98
execute if data storage stories260k args{c:'^'} run return run scoreboard players set tok stories260k 97
execute if data storage stories260k args{c:']'} run return run scoreboard players set tok stories260k 96
execute if data storage stories260k args{c:'\\'} run return run scoreboard players set tok stories260k 95
execute if data storage stories260k args{c:'['} run return run scoreboard players set tok stories260k 94
execute if data storage stories260k args{c:'Z'} run return run scoreboard players set tok stories260k 93
execute if data storage stories260k args{c:'Y'} run return run scoreboard players set tok stories260k 92
execute if data storage stories260k args{c:'X'} run return run scoreboard players set tok stories260k 91
execute if data storage stories260k args{c:'W'} run return run scoreboard players set tok stories260k 90
execute if data storage stories260k args{c:'V'} run return run scoreboard players set tok stories260k 89
execute if data storage stories260k args{c:'U'} run return run scoreboard players set tok stories260k 88
execute if data storage stories260k args{c:'T'} run return run scoreboard players set tok stories260k 87
execute if data storage stories260k args{c:'S'} run return run scoreboard players set tok stories260k 86
execute if data storage stories260k args{c:'R'} run return run scoreboard players set tok stories260k 85
execute if data storage stories260k args{c:'Q'} run return run scoreboard players set tok stories260k 84
execute if data storage stories260k args{c:'P'} run return run scoreboard players set tok stories260k 83
execute if data storage stories260k args{c:'O'} run return run scoreboard players set tok stories260k 82
execute if data storage stories260k args{c:'N'} run return run scoreboard players set tok stories260k 81
execute if data storage stories260k args{c:'M'} run return run scoreboard players set tok stories260k 80
execute if data storage stories260k args{c:'L'} run return run scoreboard players set tok stories260k 79
execute if data storage stories260k args{c:'K'} run return run scoreboard players set tok stories260k 78
execute if data storage stories260k args{c:'J'} run return run scoreboard players set tok stories260k 77
execute if data storage stories260k args{c:'I'} run return run scoreboard players set tok stories260k 76
execute if data storage stories260k args{c:'H'} run return run scoreboard players set tok stories260k 75
execute if data storage stories260k args{c:'G'} run return run scoreboard players set tok stories260k 74
execute if data storage stories260k args{c:'F'} run return run scoreboard players set tok stories260k 73
execute if data storage stories260k args{c:'E'} run return run scoreboard players set tok stories260k 72
execute if data storage stories260k args{c:'D'} run return run scoreboard players set tok stories260k 71
execute if data storage stories260k args{c:'C'} run return run scoreboard players set tok stories260k 70
execute if data storage stories260k args{c:'B'} run return run scoreboard players set tok stories260k 69
execute if data storage stories260k args{c:'A'} run return run scoreboard players set tok stories260k 68
execute if data storage stories260k args{c:'@'} run return run scoreboard players set tok stories260k 67
execute if data storage stories260k args{c:'?'} run return run scoreboard players set tok stories260k 66
execute if data storage stories260k args{c:'>'} run return run scoreboard players set tok stories260k 65
execute if data storage stories260k args{c:'='} run return run scoreboard players set tok stories260k 64
execute if data storage stories260k args{c:'<'} run return run scoreboard players set tok stories260k 63
execute if data storage stories260k args{c:';'} run return run scoreboard players set tok stories260k 62
execute if data storage stories260k args{c:':'} run return run scoreboard players set tok stories260k 61
execute if data storage stories260k args{c:'9'} run return run scoreboard players set tok stories260k 60
execute if data storage stories260k args{c:'8'} run return run scoreboard players set tok stories260k 59
execute if data storage stories260k args{c:'7'} run return run scoreboard players set tok stories260k 58
execute if data storage stories260k args{c:'6'} run return run scoreboard players set tok stories260k 57
execute if data storage stories260k args{c:'5'} run return run scoreboard players set tok stories260k 56
execute if data storage stories260k args{c:'4'} run return run scoreboard players set tok stories260k 55
execute if data storage stories260k args{c:'3'} run return run scoreboard players set tok stories260k 54
execute if data storage stories260k args{c:'2'} run return run scoreboard players set tok stories260k 53
execute if data storage stories260k args{c:'1'} run return run scoreboard players set tok stories260k 52
execute if data storage stories260k args{c:'0'} run return run scoreboard players set tok stories260k 51
execute if data storage stories260k args{c:'/'} run return run scoreboard players set tok stories260k 50
execute if data storage stories260k args{c:'.'} run return run scoreboard players set tok stories260k 49
execute if data storage stories260k args{c:'-'} run return run scoreboard players set tok stories260k 48
execute if data storage stories260k args{c:','} run return run scoreboard players set tok stories260k 47
execute if data storage stories260k args{c:'+'} run return run scoreboard players set tok stories260k 46
execute if data storage stories260k args{c:'*'} run return run scoreboard players set tok stories260k 45
execute if data storage stories260k args{c:')'} run return run scoreboard players set tok stories260k 44
execute if data storage stories260k args{c:'('} run return run scoreboard players set tok stories260k 43
execute if data storage stories260k args{c:"'"} run return run scoreboard players set tok stories260k 42
execute if data storage stories260k args{c:'&'} run return run scoreboard players set tok stories260k 41
execute if data storage stories260k args{c:'%'} run return run scoreboard players set tok stories260k 40
execute if data storage stories260k args{c:'$'} run return run scoreboard players set tok stories260k 39
execute if data storage stories260k args{c:'#'} run return run scoreboard players set tok stories260k 38
execute if data storage stories260k args{c:'"'} run return run scoreboard players set tok stories260k 37
execute if data storage stories260k args{c:'!'} run return run scoreboard players set tok stories260k 36
execute if data storage stories260k args{c:' '} run return run scoreboard players set tok stories260k 35
execute if data storage stories260k args{c:'\n'} run return run scoreboard players set tok stories260k 13
execute if data storage stories260k args{c:'\t'} run return run scoreboard players set tok stories260k 12
execute if data storage stories260k args{c:'\n</s>\n'} run return run scoreboard players set tok stories260k 2
execute if data storage stories260k args{c:'\n<s>\n'} run return run scoreboard players set tok stories260k 1
execute if data storage stories260k args{c:'<unk>'} run return run scoreboard players set tok stories260k 0
scoreboard players set tok stories260k -1
