scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 98328
scoreboard players set scoreb stories260k 0
scoreboard players set scoree stories260k 0
scoreboard players set scores stories260k 0
scoreboard players operation yb stories260k = 56b q
scoreboard players operation ye stories260k = 56e q
scoreboard players operation ys stories260k = 56s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 57b q
scoreboard players operation ye stories260k = 57e q
scoreboard players operation ys stories260k = 57s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 58b q
scoreboard players operation ye stories260k = 58e q
scoreboard players operation ys stories260k = 58s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 59b q
scoreboard players operation ye stories260k = 59e q
scoreboard players operation ys stories260k = 59s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 60b q
scoreboard players operation ye stories260k = 60e q
scoreboard players operation ys stories260k = 60s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 61b q
scoreboard players operation ye stories260k = 61e q
scoreboard players operation ys stories260k = 61s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 62b q
scoreboard players operation ye stories260k = 62e q
scoreboard players operation ys stories260k = 62s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 63b q
scoreboard players operation ye stories260k = 63e q
scoreboard players operation ys stories260k = 63s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation xb stories260k = scoreb stories260k
scoreboard players operation xe stories260k = scoree stories260k
scoreboard players operation xs stories260k = scores stories260k
scoreboard players set yb stories260k 28284271
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:div
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:set_av with storage stories260k args
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l3_h7_compute_score
