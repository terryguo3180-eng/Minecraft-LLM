scoreboard players operation window_len stories260k = pos stories260k
scoreboard players add window_len stories260k 1
execute if score pos stories260k matches 513.. run scoreboard players set window_len stories260k 512
scoreboard players operation start stories260k = pos stories260k
scoreboard players operation start stories260k -= window_len stories260k
scoreboard players add start stories260k 1
