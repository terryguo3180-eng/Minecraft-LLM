scoreboard players set xs stories260k -1
scoreboard players operation xb stories260k *= -1 stories260k
