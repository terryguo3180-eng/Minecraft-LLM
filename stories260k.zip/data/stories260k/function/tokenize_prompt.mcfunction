data modify storage stories260k args.prompt_tokens set value [410]
scoreboard players set i stories260k 0
scoreboard players set j stories260k 1
execute store result score len stories260k run data get storage stories260k args.prompt
function stories260k:tokenize_characters {i:0,j:1}
function stories260k:token_merge_loop
