$execute store result score xb stories260k run data get storage stories260k params.emb.$(idx)b
$execute store result score xe stories260k run data get storage stories260k params.emb.$(idx)e
$execute store result score xs stories260k run data get storage stories260k params.emb.$(idx)s
$scoreboard players operation yb stories260k = $(j)b x
$scoreboard players operation ye stories260k = $(j)e x
$scoreboard players operation ys stories260k = $(j)s x
function stories260k:mul
$scoreboard players operation yb stories260k = $(i)b logits
$scoreboard players operation ye stories260k = $(i)e logits
$scoreboard players operation ys stories260k = $(i)s logits
function stories260k:add
$scoreboard players operation $(i)b logits = xb stories260k
$scoreboard players operation $(i)e logits = xe stories260k
$scoreboard players operation $(i)s logits = xs stories260k
scoreboard players add j stories260k 1
execute store result storage stories260k args.idx int 1 run scoreboard players add idx stories260k 1
execute if score j stories260k matches 64 run return 1
execute store result storage stories260k args.j int 1 run scoreboard players get j stories260k
function stories260k:matmul_logits_j with storage stories260k args
