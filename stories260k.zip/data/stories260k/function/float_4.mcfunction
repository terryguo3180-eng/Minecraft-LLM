execute if score t3 stories260k matches 3 run return run scoreboard players operation t2 stories260k /= 1000 stories260k
execute if score t3 stories260k matches 4 run return run scoreboard players operation t2 stories260k /= 10000 stories260k
scoreboard players operation t2 stories260k /= 100000 stories260k
