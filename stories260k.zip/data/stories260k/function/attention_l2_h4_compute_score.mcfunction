scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 65552
scoreboard players set scoreb stories260k 0
scoreboard players set scoree stories260k 0
scoreboard players set scores stories260k 0
scoreboard players operation yb stories260k = 32b q
scoreboard players operation ye stories260k = 32e q
scoreboard players operation ys stories260k = 32s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 33b q
scoreboard players operation ye stories260k = 33e q
scoreboard players operation ys stories260k = 33s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 34b q
scoreboard players operation ye stories260k = 34e q
scoreboard players operation ys stories260k = 34s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 35b q
scoreboard players operation ye stories260k = 35e q
scoreboard players operation ys stories260k = 35s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 36b q
scoreboard players operation ye stories260k = 36e q
scoreboard players operation ys stories260k = 36s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 37b q
scoreboard players operation ye stories260k = 37e q
scoreboard players operation ys stories260k = 37s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 38b q
scoreboard players operation ye stories260k = 38e q
scoreboard players operation ys stories260k = 38s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation yb stories260k = 39b q
scoreboard players operation ye stories260k = 39e q
scoreboard players operation ys stories260k = 39s q
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_kc with storage stories260k args
scoreboard players add cache_idx stories260k 1
function stories260k:mul
scoreboard players operation yb stories260k = scoreb stories260k
scoreboard players operation ye stories260k = scoree stories260k
scoreboard players operation ys stories260k = scores stories260k
function stories260k:add
scoreboard players operation scoreb stories260k = xb stories260k
scoreboard players operation scoree stories260k = xe stories260k
scoreboard players operation scores stories260k = xs stories260k
scoreboard players operation xb stories260k = scoreb stories260k
scoreboard players operation xe stories260k = scoree stories260k
scoreboard players operation xs stories260k = scores stories260k
scoreboard players set yb stories260k 28284271
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
function stories260k:div
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:set_av with storage stories260k args
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l2_h4_compute_score
