scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t1 stories260k = yb stories260k
scoreboard players operation t2 stories260k = t1 stories260k
scoreboard players operation t1 stories260k /= 25 stories260k
scoreboard players operation t2 stories260k %= 25 stories260k
scoreboard players operation t3 stories260k = xb stories260k
scoreboard players operation xb stories260k /= t1 stories260k
scoreboard players operation xb stories260k *= 40 stories260k
scoreboard players operation t3 stories260k %= t1 stories260k
scoreboard players operation t3 stories260k *= 40 stories260k
scoreboard players operation t0 stories260k = t3 stories260k
scoreboard players operation t3 stories260k /= t1 stories260k
scoreboard players operation xb stories260k += t3 stories260k
scoreboard players operation t0 stories260k %= t1 stories260k
scoreboard players operation t0 stories260k *= 25 stories260k
scoreboard players operation t4 stories260k = t2 stories260k
scoreboard players operation t4 stories260k *= xb stories260k
scoreboard players operation t0 stories260k -= t4 stories260k
scoreboard players operation t0 stories260k *= 10 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t0 stories260k /= t1 stories260k
scoreboard players operation t0 stories260k *= 40 stories260k
scoreboard players operation t3 stories260k %= t1 stories260k
scoreboard players operation t3 stories260k *= 40 stories260k
scoreboard players operation t3 stories260k /= t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xs stories260k *= ys stories260k
scoreboard players operation xe stories260k -= ye stories260k
scoreboard players remove xe stories260k 1
execute if score xs stories260k matches 0 run scoreboard players set xe stories260k 0
execute if score xb stories260k matches 100000.. run return 0
scoreboard players operation xb stories260k *= 10000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
