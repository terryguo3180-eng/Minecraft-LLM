execute if score xe stories260k > ye stories260k run return run scoreboard players set t1 stories260k 0
execute if score xe stories260k = ye stories260k if score xb stories260k >= t2 stories260k run return run scoreboard players set t1 stories260k 0
scoreboard players set t1 stories260k 1
