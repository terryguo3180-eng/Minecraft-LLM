execute if score xb stories260k matches 100000.. run return run function stories260k:float_6
execute if score xb stories260k matches 100..99999 run return run function stories260k:float_7
execute if score xb stories260k matches 1..9 run return run function stories260k:float_8
execute if score xb stories260k matches 10..99 run return run function stories260k:float_9
scoreboard players set xe stories260k 0
scoreboard players set xs stories260k 0
