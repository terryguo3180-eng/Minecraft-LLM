scoreboard players operation xb stories260k *= 100000000 stories260k
scoreboard players remove xe stories260k 8
