scoreboard players operation yb stories260k = tb stories260k
scoreboard players operation ye stories260k = te stories260k
scoreboard players operation ys stories260k = ts stories260k
bossbar set progress max 26
bossbar set progress value 0
bossbar set progress name [{"text":"Sampling","color":"gray","bold":true}]
bossbar set progress players @a
scoreboard players set i stories260k 0
function stories260k:apply_temperature_scale {i:0}
scoreboard players set yb stories260k 99999999
scoreboard players set ye stories260k 99999999
scoreboard players set ys stories260k -1
scoreboard players set i stories260k 0
function stories260k:find_max_logit {i:0}
scoreboard players set expsumb stories260k 0
scoreboard players set expsume stories260k 0
scoreboard players set expsums stories260k 0
scoreboard players operation nmb stories260k = yb stories260k
scoreboard players operation nme stories260k = ye stories260k
scoreboard players operation nms stories260k = ys stories260k
scoreboard players operation nms stories260k *= -1 stories260k
scoreboard players set i stories260k 0
function stories260k:compute_exp_sum {i:0}
scoreboard players set i stories260k 0
function stories260k:normalize_probs {i:0}
execute store result score xb stories260k run random value 0..99999999
scoreboard players set xe stories260k -1
scoreboard players set xs stories260k 1
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation rb stories260k = xb stories260k
scoreboard players operation re stories260k = xe stories260k
scoreboard players operation rs stories260k = xs stories260k
scoreboard players set cdfb stories260k 0
scoreboard players set cdfe stories260k 0
scoreboard players set cdfs stories260k 0
scoreboard players set i stories260k 0
function stories260k:sample_from_cdf {i:0}
execute if score i stories260k matches 512 run scoreboard players set tok stories260k 511
