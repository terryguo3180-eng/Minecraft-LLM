scoreboard players operation cache_idx stories260k = t stories260k
scoreboard players operation cache_idx stories260k %= 512 stories260k
scoreboard players operation cache_idx stories260k *= 64 stories260k
scoreboard players add cache_idx stories260k 98304
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:get_av with storage stories260k args
scoreboard players operation ab stories260k = xb stories260k
scoreboard players operation ae stories260k = xe stories260k
scoreboard players operation as stories260k = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 8b tx
scoreboard players operation ye stories260k = 8e tx
scoreboard players operation ys stories260k = 8s tx
function stories260k:add
scoreboard players operation 8b tx = xb stories260k
scoreboard players operation 8e tx = xe stories260k
scoreboard players operation 8s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 9b tx
scoreboard players operation ye stories260k = 9e tx
scoreboard players operation ys stories260k = 9s tx
function stories260k:add
scoreboard players operation 9b tx = xb stories260k
scoreboard players operation 9e tx = xe stories260k
scoreboard players operation 9s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 10b tx
scoreboard players operation ye stories260k = 10e tx
scoreboard players operation ys stories260k = 10s tx
function stories260k:add
scoreboard players operation 10b tx = xb stories260k
scoreboard players operation 10e tx = xe stories260k
scoreboard players operation 10s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 11b tx
scoreboard players operation ye stories260k = 11e tx
scoreboard players operation ys stories260k = 11s tx
function stories260k:add
scoreboard players operation 11b tx = xb stories260k
scoreboard players operation 11e tx = xe stories260k
scoreboard players operation 11s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 12b tx
scoreboard players operation ye stories260k = 12e tx
scoreboard players operation ys stories260k = 12s tx
function stories260k:add
scoreboard players operation 12b tx = xb stories260k
scoreboard players operation 12e tx = xe stories260k
scoreboard players operation 12s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 13b tx
scoreboard players operation ye stories260k = 13e tx
scoreboard players operation ys stories260k = 13s tx
function stories260k:add
scoreboard players operation 13b tx = xb stories260k
scoreboard players operation 13e tx = xe stories260k
scoreboard players operation 13s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 14b tx
scoreboard players operation ye stories260k = 14e tx
scoreboard players operation ys stories260k = 14s tx
function stories260k:add
scoreboard players operation 14b tx = xb stories260k
scoreboard players operation 14e tx = xe stories260k
scoreboard players operation 14s tx = xs stories260k
scoreboard players operation yb stories260k = ab stories260k
scoreboard players operation ye stories260k = ae stories260k
scoreboard players operation ys stories260k = as stories260k
execute store result storage stories260k args.i int 1 run scoreboard players get cache_idx stories260k
function stories260k:get_vc with storage stories260k args
function stories260k:mul
scoreboard players add cache_idx stories260k 1
scoreboard players operation yb stories260k = 15b tx
scoreboard players operation ye stories260k = 15e tx
scoreboard players operation ys stories260k = 15s tx
function stories260k:add
scoreboard players operation 15b tx = xb stories260k
scoreboard players operation 15e tx = xe stories260k
scoreboard players operation 15s tx = xs stories260k
scoreboard players add t stories260k 1
scoreboard players add i stories260k 1
execute if score t stories260k <= pos stories260k run function stories260k:attention_l3_h1_weighted_sum_vals
