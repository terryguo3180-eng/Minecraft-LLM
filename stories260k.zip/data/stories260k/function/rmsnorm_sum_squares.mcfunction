scoreboard players set ssb stories260k 0
scoreboard players set sse stories260k 0
scoreboard players set sss stories260k 0
scoreboard players operation xb stories260k = 0b x
scoreboard players operation xe stories260k = 0e x
scoreboard players operation xs stories260k = 0s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 1b x
scoreboard players operation xe stories260k = 1e x
scoreboard players operation xs stories260k = 1s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 2b x
scoreboard players operation xe stories260k = 2e x
scoreboard players operation xs stories260k = 2s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 3b x
scoreboard players operation xe stories260k = 3e x
scoreboard players operation xs stories260k = 3s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 4b x
scoreboard players operation xe stories260k = 4e x
scoreboard players operation xs stories260k = 4s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 5b x
scoreboard players operation xe stories260k = 5e x
scoreboard players operation xs stories260k = 5s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 6b x
scoreboard players operation xe stories260k = 6e x
scoreboard players operation xs stories260k = 6s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 7b x
scoreboard players operation xe stories260k = 7e x
scoreboard players operation xs stories260k = 7s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 8b x
scoreboard players operation xe stories260k = 8e x
scoreboard players operation xs stories260k = 8s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 9b x
scoreboard players operation xe stories260k = 9e x
scoreboard players operation xs stories260k = 9s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 10b x
scoreboard players operation xe stories260k = 10e x
scoreboard players operation xs stories260k = 10s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 11b x
scoreboard players operation xe stories260k = 11e x
scoreboard players operation xs stories260k = 11s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 12b x
scoreboard players operation xe stories260k = 12e x
scoreboard players operation xs stories260k = 12s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 13b x
scoreboard players operation xe stories260k = 13e x
scoreboard players operation xs stories260k = 13s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 14b x
scoreboard players operation xe stories260k = 14e x
scoreboard players operation xs stories260k = 14s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 15b x
scoreboard players operation xe stories260k = 15e x
scoreboard players operation xs stories260k = 15s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 16b x
scoreboard players operation xe stories260k = 16e x
scoreboard players operation xs stories260k = 16s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 17b x
scoreboard players operation xe stories260k = 17e x
scoreboard players operation xs stories260k = 17s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 18b x
scoreboard players operation xe stories260k = 18e x
scoreboard players operation xs stories260k = 18s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 19b x
scoreboard players operation xe stories260k = 19e x
scoreboard players operation xs stories260k = 19s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 20b x
scoreboard players operation xe stories260k = 20e x
scoreboard players operation xs stories260k = 20s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 21b x
scoreboard players operation xe stories260k = 21e x
scoreboard players operation xs stories260k = 21s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 22b x
scoreboard players operation xe stories260k = 22e x
scoreboard players operation xs stories260k = 22s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 23b x
scoreboard players operation xe stories260k = 23e x
scoreboard players operation xs stories260k = 23s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 24b x
scoreboard players operation xe stories260k = 24e x
scoreboard players operation xs stories260k = 24s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 25b x
scoreboard players operation xe stories260k = 25e x
scoreboard players operation xs stories260k = 25s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 26b x
scoreboard players operation xe stories260k = 26e x
scoreboard players operation xs stories260k = 26s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 27b x
scoreboard players operation xe stories260k = 27e x
scoreboard players operation xs stories260k = 27s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 28b x
scoreboard players operation xe stories260k = 28e x
scoreboard players operation xs stories260k = 28s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 29b x
scoreboard players operation xe stories260k = 29e x
scoreboard players operation xs stories260k = 29s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 30b x
scoreboard players operation xe stories260k = 30e x
scoreboard players operation xs stories260k = 30s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 31b x
scoreboard players operation xe stories260k = 31e x
scoreboard players operation xs stories260k = 31s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 32b x
scoreboard players operation xe stories260k = 32e x
scoreboard players operation xs stories260k = 32s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 33b x
scoreboard players operation xe stories260k = 33e x
scoreboard players operation xs stories260k = 33s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 34b x
scoreboard players operation xe stories260k = 34e x
scoreboard players operation xs stories260k = 34s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 35b x
scoreboard players operation xe stories260k = 35e x
scoreboard players operation xs stories260k = 35s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 36b x
scoreboard players operation xe stories260k = 36e x
scoreboard players operation xs stories260k = 36s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 37b x
scoreboard players operation xe stories260k = 37e x
scoreboard players operation xs stories260k = 37s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 38b x
scoreboard players operation xe stories260k = 38e x
scoreboard players operation xs stories260k = 38s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 39b x
scoreboard players operation xe stories260k = 39e x
scoreboard players operation xs stories260k = 39s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 40b x
scoreboard players operation xe stories260k = 40e x
scoreboard players operation xs stories260k = 40s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 41b x
scoreboard players operation xe stories260k = 41e x
scoreboard players operation xs stories260k = 41s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 42b x
scoreboard players operation xe stories260k = 42e x
scoreboard players operation xs stories260k = 42s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 43b x
scoreboard players operation xe stories260k = 43e x
scoreboard players operation xs stories260k = 43s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 44b x
scoreboard players operation xe stories260k = 44e x
scoreboard players operation xs stories260k = 44s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 45b x
scoreboard players operation xe stories260k = 45e x
scoreboard players operation xs stories260k = 45s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 46b x
scoreboard players operation xe stories260k = 46e x
scoreboard players operation xs stories260k = 46s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 47b x
scoreboard players operation xe stories260k = 47e x
scoreboard players operation xs stories260k = 47s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 48b x
scoreboard players operation xe stories260k = 48e x
scoreboard players operation xs stories260k = 48s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 49b x
scoreboard players operation xe stories260k = 49e x
scoreboard players operation xs stories260k = 49s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 50b x
scoreboard players operation xe stories260k = 50e x
scoreboard players operation xs stories260k = 50s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 51b x
scoreboard players operation xe stories260k = 51e x
scoreboard players operation xs stories260k = 51s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 52b x
scoreboard players operation xe stories260k = 52e x
scoreboard players operation xs stories260k = 52s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 53b x
scoreboard players operation xe stories260k = 53e x
scoreboard players operation xs stories260k = 53s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 54b x
scoreboard players operation xe stories260k = 54e x
scoreboard players operation xs stories260k = 54s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 55b x
scoreboard players operation xe stories260k = 55e x
scoreboard players operation xs stories260k = 55s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 56b x
scoreboard players operation xe stories260k = 56e x
scoreboard players operation xs stories260k = 56s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 57b x
scoreboard players operation xe stories260k = 57e x
scoreboard players operation xs stories260k = 57s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 58b x
scoreboard players operation xe stories260k = 58e x
scoreboard players operation xs stories260k = 58s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 59b x
scoreboard players operation xe stories260k = 59e x
scoreboard players operation xs stories260k = 59s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 60b x
scoreboard players operation xe stories260k = 60e x
scoreboard players operation xs stories260k = 60s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 61b x
scoreboard players operation xe stories260k = 61e x
scoreboard players operation xs stories260k = 61s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 62b x
scoreboard players operation xe stories260k = 62e x
scoreboard players operation xs stories260k = 62s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players operation xb stories260k = 63b x
scoreboard players operation xe stories260k = 63e x
scoreboard players operation xs stories260k = 63s x
function stories260k:sq
scoreboard players operation yb stories260k = ssb stories260k
scoreboard players operation ye stories260k = sse stories260k
scoreboard players operation ys stories260k = sss stories260k
function stories260k:add
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
scoreboard players set xb stories260k 64
scoreboard players set xe stories260k 7
scoreboard players set xs stories260k 1
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = xb stories260k
scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation ys stories260k = xs stories260k
scoreboard players operation xb stories260k = ssb stories260k
scoreboard players operation xe stories260k = sse stories260k
scoreboard players operation xs stories260k = sss stories260k
function stories260k:div
scoreboard players add xb stories260k 1
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
function stories260k:sqrt
function stories260k:inv
scoreboard players operation ssb stories260k = xb stories260k
scoreboard players operation sse stories260k = xe stories260k
scoreboard players operation sss stories260k = xs stories260k
