scoreboard players operation t0 stories260k /= 24703 stories260k
scoreboard players add t0 stories260k 4750
