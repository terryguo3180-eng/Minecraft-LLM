execute store result storage stories260k args.t int 4.3429448190325176 run scoreboard players get xb stories260k
execute store result score xb stories260k run data get storage stories260k args.t
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players remove xe stories260k 1
scoreboard players operation t4 stories260k = xb stories260k
scoreboard players operation t5 stories260k = xe stories260k
scoreboard players operation t6 stories260k = xs stories260k
function stories260k:floor
execute if score t6 stories260k matches -1 run function stories260k:float_30
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation ye stories260k = t5 stories260k
scoreboard players operation ys stories260k = t6 stories260k
scoreboard players operation ys stories260k *= -1 stories260k
function stories260k:add
scoreboard players operation xs stories260k *= -1 stories260k
execute store result storage stories260k args.t int 2.3025850929940456840 run scoreboard players get xb stories260k
execute store result score xb stories260k run data get storage stories260k args.t
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation t4 stories260k = xb stories260k
scoreboard players operation t5 stories260k = xe stories260k
scoreboard players operation t6 stories260k = xs stories260k
execute store result storage stories260k args.t int 3.2546203518824833519 run scoreboard players get t4 stories260k
execute store result score xb stories260k run data get storage stories260k args.t
scoreboard players remove xe stories260k 4
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 19813115
scoreboard players set ye stories260k -3
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 35871171
scoreboard players set ye stories260k -3
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 54159899
scoreboard players set ye stories260k -2
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 14960666
scoreboard players set ye stories260k -1
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 51295916
scoreboard players set ye stories260k -1
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 99479042
scoreboard players set ye stories260k -1
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation yb stories260k = t4 stories260k
scoreboard players operation t0 stories260k = xb stories260k
scoreboard players operation t0 stories260k %= 10000 stories260k
scoreboard players operation xb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k = xb stories260k
scoreboard players operation t2 stories260k = yb stories260k
scoreboard players operation t2 stories260k %= 10000 stories260k
scoreboard players operation yb stories260k /= 10000 stories260k
scoreboard players operation t1 stories260k *= t2 stories260k
scoreboard players operation t3 stories260k = t0 stories260k
scoreboard players operation t3 stories260k *= yb stories260k
scoreboard players operation t3 stories260k /= 10000 stories260k
scoreboard players operation t0 stories260k *= yb stories260k
scoreboard players operation t0 stories260k += t1 stories260k
scoreboard players operation t0 stories260k += t3 stories260k
scoreboard players operation xb stories260k *= yb stories260k
scoreboard players operation xb stories260k *= 10 stories260k
scoreboard players operation t0 stories260k /= 1000 stories260k
scoreboard players operation xb stories260k += t0 stories260k
scoreboard players operation xs stories260k *= t6 stories260k
scoreboard players operation xe stories260k += t5 stories260k
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players set yb stories260k 10008708
scoreboard players set ye stories260k 0
scoreboard players set ys stories260k 1
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
scoreboard players operation xe stories260k = r stories260k
