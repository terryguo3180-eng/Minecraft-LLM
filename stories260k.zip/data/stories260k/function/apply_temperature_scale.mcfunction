$scoreboard players operation xb stories260k = $(i)b logits
$scoreboard players operation xe stories260k = $(i)e logits
$scoreboard players operation xs stories260k = $(i)s logits
function stories260k:div
$scoreboard players operation $(i)b logits = xb stories260k
$scoreboard players operation $(i)e logits = xe stories260k
$scoreboard players operation $(i)s logits = xs stories260k
execute store result score t0 stories260k store result score t1 stories260k store result storage stories260k args.i int 1 run scoreboard players add i stories260k 1
scoreboard players operation t0 stories260k %= 100 stories260k
execute if score t0 stories260k matches 99 store result bossbar progress value run scoreboard players operation t1 stories260k /= 100 stories260k
execute if score i stories260k matches ..511 run function stories260k:apply_temperature_scale with storage stories260k args
