execute unless data storage stories260k args{prompt_tokens:[]} run return run function stories260k:run_forward_prompt
bossbar set progress max 48
bossbar set progress value 0
bossbar set progress name [{"text":"Inferring, Step #","color":"green","bold":true},{"score":{"name":"pos","objective":"stories260k"}}]
bossbar set progress players @a
function stories260k:forward
