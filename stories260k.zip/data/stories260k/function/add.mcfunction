execute if score xb stories260k matches 0 run scoreboard players operation xe stories260k = ye stories260k
execute if score yb stories260k matches 0 run scoreboard players operation ye stories260k = xe stories260k
scoreboard players operation t0 stories260k = ys stories260k
scoreboard players operation t0 stories260k *= xs stories260k
scoreboard players operation t2 stories260k = yb stories260k
function stories260k:float_0
scoreboard players operation t3 stories260k = xe stories260k
scoreboard players operation t3 stories260k -= ye stories260k
execute if score t1 stories260k matches 1 run function stories260k:float_1
scoreboard players operation t2 stories260k *= t0 stories260k
execute unless score t3 stories260k matches 0 run function stories260k:float_2
scoreboard players operation xb stories260k += t2 stories260k
function stories260k:float_5
execute if score xb stories260k matches 100000000.. run function stories260k:float_15
