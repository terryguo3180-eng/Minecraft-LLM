execute if score xb stories260k matches 100000..999999 run return run function stories260k:float_10
execute if score xb stories260k matches 1000000..9999999 run return run function stories260k:float_11
