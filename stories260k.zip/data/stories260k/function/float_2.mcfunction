execute if score t3 stories260k matches 1..2 run return run function stories260k:float_3
execute if score t3 stories260k matches 3..5 run return run function stories260k:float_4
execute if score t3 stories260k matches 6 run return run scoreboard players operation t2 stories260k /= 1000000 stories260k
execute if score t3 stories260k matches 7 run return run scoreboard players operation t2 stories260k /= 10000000 stories260k
scoreboard players operation t2 stories260k /= 1000000000 stories260k
