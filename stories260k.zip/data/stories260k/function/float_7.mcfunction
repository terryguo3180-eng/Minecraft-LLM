execute if score xb stories260k matches 100..999 run return run function stories260k:float_12
execute if score xb stories260k matches 1000..9999 run return run function stories260k:float_13
scoreboard players operation xb stories260k *= 10000 stories260k
scoreboard players remove xe stories260k 4
