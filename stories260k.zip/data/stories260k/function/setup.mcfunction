gamerule max_command_sequence_length 2147483647
scoreboard objectives add stories260k dummy
scoreboard objectives add x dummy
scoreboard objectives add tx dummy
scoreboard objectives add tx2 dummy
scoreboard objectives add th dummy
scoreboard objectives add th2 dummy
scoreboard objectives add q dummy
scoreboard objectives add k dummy
scoreboard objectives add v dummy
scoreboard objectives add av dummy
scoreboard objectives add kc dummy
scoreboard objectives add vc dummy
scoreboard objectives add logits dummy
scoreboard players set -1 stories260k -1
scoreboard players set 2 stories260k 2
scoreboard players set 10 stories260k 10
scoreboard players set 25 stories260k 25
scoreboard players set 40 stories260k 40
scoreboard players set 64 stories260k 64
scoreboard players set 100 stories260k 100
scoreboard players set 500 stories260k 500
scoreboard players set 512 stories260k 512
scoreboard players set 1000 stories260k 1000
scoreboard players set 4750 stories260k 4750
scoreboard players set 10000 stories260k 10000
scoreboard players set 24703 stories260k 24703
scoreboard players set 79249 stories260k 79249
scoreboard players set 100000 stories260k 100000
scoreboard players set 1000000 stories260k 1000000
scoreboard players set 10000000 stories260k 10000000
scoreboard players set 100000000 stories260k 100000000
scoreboard players set 1000000000 stories260k 1000000000
bossbar add progress "Progress"
function stories260k:load_parameters
scoreboard players reset * kc
scoreboard players reset * vc
