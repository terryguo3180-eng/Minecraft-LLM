$scoreboard players operation $(i)b vc = xb stories260k
$scoreboard players operation $(i)e vc = xe stories260k
$scoreboard players operation $(i)s vc = xs stories260k
