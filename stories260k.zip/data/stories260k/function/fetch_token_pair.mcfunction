$execute store result score tok stories260k run data get storage stories260k args.prompt_tokens[$(i)]
function stories260k:token_to_string
data modify storage stories260k args.tok0 set from storage stories260k args.tok
$execute store result score tok stories260k run data get storage stories260k args.prompt_tokens[$(j)]
function stories260k:token_to_string
data modify storage stories260k args.tok1 set from storage stories260k args.tok
