execute if score xs stories260k > ys stories260k run return run scoreboard players set r stories260k 1
execute if score xs stories260k < ys stories260k run return run scoreboard players set r stories260k -1
function stories260k:float_14
execute if score xs stories260k matches -1 run scoreboard players operation r stories260k *= -1 stories260k
