execute store result score progress stories260k run bossbar get progress value
execute store result bossbar progress value run scoreboard players add progress stories260k 1
scoreboard players set n stories260k 0
schedule function stories260k:matmul_logits_resume 1t
