$scoreboard players set $(i)b logits 0
$scoreboard players set $(i)e logits 0
$scoreboard players set $(i)s logits 0
scoreboard players set j stories260k 0
data modify storage stories260k args.j set value 0
function stories260k:matmul_logits_j with storage stories260k args
scoreboard players add i stories260k 1
execute if score i stories260k matches 512 run return 1
scoreboard players add n stories260k 1
execute if score n stories260k matches 64 run return run function stories260k:matmul_logits_update
execute store result storage stories260k args.i int 1 run scoreboard players get i stories260k
function stories260k:matmul_logits_i with storage stories260k args
